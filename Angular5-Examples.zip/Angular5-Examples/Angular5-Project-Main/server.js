// Get dependencies
const express = require('express');
const path = require('path');
const https = require('https');
const bodyParser = require('body-parser');
const fs = require('fs');

// Get our API routes
//const api = require('./server/routes/api');

// Get Server properties
const server_property = require('/opt/app/nodejs/plm_properties/server-properties');

const app = express();

// Parsers for POST data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Point static path to dist
app.use(express.static(path.join(__dirname, 'dist')));

// Set our api routes
// app.use('/api', api);

// Catch all other routes and return the index file
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
 // console.log(req);
  if (req.protocol === 'https')
    console.log(req.connection.getProtocol());
  else
    console.log('Not SSL');
});

/**
 * Get port from environment and store in Express.
 */
const port = server_property.port || '3000';
app.set('port', port);

// /**
//  * set Key and certificates for the 
//  */

// /**
//  * Create https server.
//  */
// const server = https.createServer({},app);

// /**
//  * Listen on provided port, on all network interfaces.
//  */
// server.listen(port, () => console.log(`API running on localhost:${port}`));

var server = https.createServer({
	key: fs.readFileSync(server_property.key),
  cert: fs.readFileSync(server_property.cert),
//  ca: fs.readFileSync(server_property.ca),
	ciphers: server_property.ciphers.join(':'),
	honorCipherOrder: true
}, app).listen(port, () => {
  console.log(`Listening on :${port}`);
});