import { PLMPage } from './plm.po';

describe('test-ng4 PLM', () => {
  let page: PLMPage;

  beforeEach(() => {
    page = new PLMPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to PLM!');
  });
});
