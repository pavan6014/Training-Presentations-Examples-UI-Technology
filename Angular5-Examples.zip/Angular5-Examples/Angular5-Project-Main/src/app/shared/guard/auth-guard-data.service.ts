import { Injectable } from '@angular/core';

@Injectable()
export class AuthGuardDataService {
  public rolesMatrix: any;
  public currentRoleMatrix: any;
  constructor() { }

}
