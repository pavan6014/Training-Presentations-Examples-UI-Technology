import { Injectable } from '@angular/core';

@Injectable()
export class DistributorDataService {
  
  public submitButtonErrorMessage: string;
  constructor() { }

}
