import { TestBed, inject } from '@angular/core/testing';

import { DistributorDataServiceService } from './distributor-data-service.service';

describe('DistributorDataServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DistributorDataServiceService]
    });
  });

  it('should be created', inject([DistributorDataServiceService], (service: DistributorDataServiceService) => {
    expect(service).toBeTruthy();
  }));
});
