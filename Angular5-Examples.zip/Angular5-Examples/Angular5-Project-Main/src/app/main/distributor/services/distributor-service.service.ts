import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { AppConfigService } from '../../../shared/services/app-config.service';

@Injectable()
export class DistributorService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

  getMarketMasterData(): Observable<any>{
    // const getMarketMasterDataUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_MASTER_DATA'];
    const getMarketMasterDataUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_MASTER_DATA'];
    return this.http
      .get(getMarketMasterDataUrl)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getProjectOfferList(): Observable<any>{
    // const getProjectOfferListUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_INTAKE_OFFER_LIST'];
    const getProjectOfferListUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_INTAKE_OFFER_LIST'];
    return this.http
      .get(getProjectOfferListUrl)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


  getProdProjectOfferList(): Observable<any>{
    // const getProjectOfferListUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_INTAKE_OFFER_LIST'];
    const getProdProjectOfferListUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_PROD_INTAKE_OFFER_LIST'];
    return this.http
      .get(getProdProjectOfferListUrl)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  submitToOMC(offersList): Observable<any> {
    const submitOMCUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_OMC'];
    return this.http
      .post(submitOMCUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitOMCUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_OMC']
    // return this.http
    //   .get(submitOMCUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  submitToPinPoint(offersList): Observable<any> {
    const submitPinPointUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_PINPOINT'];
    return this.http
      .post(submitPinPointUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitPinPointUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_PINPOINT']
    // return this.http
    //   .get(submitPinPointUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  submitToUAT(offersList): Observable<any> {
    const submitUATUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_UAT'];
    return this.http
      .post(submitUATUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitUATUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_UAT']
    // return this.http
    //   .get(submitUATUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  submitToByPass(offersList): Observable<any> {
    const submitToByPassUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_BYPASS'];
    return this.http
      .post(submitToByPassUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitToByPassUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_BYPASS']
    // return this.http
    //   .get(submitToByPassUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  submitToProdOMC(offersList): Observable<any> {
    const submitOMCUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_PROD_SUBMIT_OMC'];
    return this.http
      .post(submitOMCUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitOMCUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_OMC']
    // return this.http
    //   .get(submitOMCUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  submitToProdPinPoint(offersList): Observable<any> {
    const submitPinPointUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_PROD_SUBMIT_PINPOINT'];
    return this.http
      .post(submitPinPointUrl, offersList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitPinPointUrl = this.appConfigService.urlConstants['PLM_OFFER_TEST_SUBMIT_PINPOINT']
    // return this.http
    //   .get(submitPinPointUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
