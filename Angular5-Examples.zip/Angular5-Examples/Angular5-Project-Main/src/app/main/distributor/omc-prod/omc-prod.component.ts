import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, OnInit } from '@angular/core';
import { DiscountOfferList, OMCTestQueueList, Offer } from '../distributor.interface';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { DistributorService } from '../services/distributor-service.service';
import { Router } from '@angular/router';
import { UtilitiesService } from '../../../shared/services/utilities.service';

@Component({
  selector: 'plm-omc-prod',
  templateUrl: './omc-prod.component.html',
  providers: [DistributorService, UtilitiesService]
})

export class OmcProdComponent implements OnInit {

    @BlockUI() blockUI: NgBlockUI;
    private fetchProjectOfferList: DiscountOfferList;
    private projectOfferList: OMCTestQueueList[];
    private masterData: any;
    private omcSubmitFailed: boolean;
    private pinPointSubmitFailed: boolean;
    private enableSubmitOMC: boolean;
    private enableSubmitPinPoint: boolean;
    private offerIdList: number[];
    private offerListForSubmit: OMCTestQueueList[];
    private pinpointSuccess = [];
    private pinpointFail = [];
    private pinpointList: any;
    private showPinpointSuccess: boolean;
    private showPinpointFail: boolean;
    private showOmcSuccess: boolean;
    private showOmcFail: boolean;
    private omcValidateSubmitSuccessList: any[];
    private omcValidateSubmitFailList: any[];
    private selectAll: boolean;
    private key: string;
    private reverse: boolean;
  
    constructor(
      private distributorService: DistributorService,
      private router: Router,
      public dialog: MatDialog,
      private utilitiesService: UtilitiesService
    ) {
      this.intializeOfferTestPage();
      this.resetValidateMessage();
      this.selectAll = false;
      dialog.afterAllClosed
        .subscribe(() => {
          this.intializeOfferTestPage();
        }
      );
    }
  
    ngOnInit() {
      this.sort('projectCode');
    }
    
    sort(key) {
      this.key = key;
      this.reverse = !this.reverse;
    }
    intializeOfferTestPage() {
      this.resetErrorMessageSection();
      this.resetSubmitButtons();
      this.getMasterData();
      this.offerListForSubmit = [];
      this.offerIdList = [];
    }
  
    getMasterData() {
      this.distributorService.getMarketMasterData()
        .subscribe(
          data => {
            this.masterData = data;
            this.getProjectOfferTestList();
          },
          error => {
            console.log('Error :: ' + error)
          }
        );
    }
  
    getProjectOfferTestList() {
      this.distributorService.getProdProjectOfferList()
        .subscribe(
          data => {
            this.fetchProjectOfferList = data.distributorOfferList;
            this.getProjectOfferList();
          },
          error => {
            console.log('Error :: ' + error)
          }
        );
    }
  
    getProjectOfferList(){
      this.projectOfferList = [];
      for (let prop in this.fetchProjectOfferList) {
        let resultObj = this.initializeProjectOfferListObj();
        resultObj['isProjectRow'] = true;
        resultObj['showRow'] = true;
        resultObj['checked'] = false;
        resultObj['projectCode'] = prop;
        this.projectOfferList.push(resultObj);
        let offerList = this.getOfferList(this.fetchProjectOfferList[prop]);
        this.updateOfferList(offerList);
      }
    }
  
    getOfferList(offers) {
      const result = [];
    for (let i = 0; i < offers.length; i++) {
        const resultObj = this.initializeProjectOfferListObj();
        const omcStatusVal = this.getOMCStatusVal(offers[i].status);
        const pinpointStatusVal = this.getPinpointStatusVal(offers[i].status);
        const testMarketsSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'MARKETS', offers[i].sites);
        resultObj['isProjectRow'] = false;
        resultObj['showRow'] = true;
        resultObj['checked'] = false;
        resultObj['projectCode'] = offers[i].projectCode;
        resultObj['releaseCode'] = offers[i].releaseCode;
        resultObj['offerId'] = offers[i].offerId;
        resultObj['offerName'] = offers[i].offerName;
        resultObj['offerType'] = offers[i].offerType;
        resultObj['offerDescription'] = offers[i].offerDescription;
        resultObj['offerCategory'] = offers[i].offerCategory;
        resultObj['startDt'] = offers[i].startDt;
        resultObj['endDt'] = offers[i].endDt;
        resultObj['omcStatus'] = omcStatusVal;
        resultObj['pinPointStatus'] = pinpointStatusVal;
        // resultObj['testMarketsSelectedItems'] = testMarketsSelectedItems;
        resultObj['sites'] = offers[i].sites;
        resultObj['uatComments'] = offers[i].uatComments;
        resultObj['status'] = offers[i].status;
        resultObj['projectType'] = offers[i].projectType;
        result.push(resultObj);
      }
      return result;
    }
  
    updateOfferList(offerList) {
      for (let i=0; i<offerList.length; i++) {
        this.projectOfferList.push(offerList[i]);
      }
    }
  
    getOMCStatusVal(status) {
      let result = '';
      if (status.trim() === 'PROD OMC Create Failed') {
        result = 'red';
      } else if ((status.trim() === 'PROD OMC Create Passed') || 
                (status.trim() === 'PROD Pinpoint Create Failed') || 
                (status.trim() === 'Production Published')) {
        result = 'green';
      }
      return result;
    }
  
    getPinpointStatusVal(status) {
      let result = '';
      if (status.trim() === 'PROD Pinpoint Create Failed') {
        result = 'red';
      } else if (status.trim() === 'Production Published') {
        result = 'green';
      }
      return result;
    }
  
    resetErrorMessageSection() {
      this.omcSubmitFailed = false;
      this.pinPointSubmitFailed = false;
    }
  
    resetSubmitButtons() {
      this.enableSubmitOMC = false;
      this.enableSubmitPinPoint = false;
    }
  
    initializeProjectOfferListObj() {
      return {
        'isProjectRow': false,
        'showRow': false,
        'checked': false,
        'projectCode': '',
        'status': '',
        'projectType': '',
        'releaseCode': '',
        'offerId': 0,
        'offerType': '',
        'offerName': '',
        'offerDescription': '',
        'offerCategory': '',
        'startDt': '',
        'endDt': '',
        'omcStatus': '',
        'pinPointStatus': '',
        'testMarkets': [],
        'uatStatus': '',
        'uatComments': '',
        'testMarketsSelectedItems': [],
        'sites': [],
        'childrensVisible': true
      }
    }
  
    showSubRows(projectCode, isProjectRow) {
      if(!isProjectRow){
        return false;
      }
      for (let i=0; i<this.projectOfferList.length; i++) {
        if ((this.projectOfferList[i].projectCode === projectCode) && (!this.projectOfferList[i].isProjectRow)) {
          this.projectOfferList[i].showRow = !this.projectOfferList[i].showRow;
        } else if ((this.projectOfferList[i].projectCode === projectCode) && (this.projectOfferList[i].isProjectRow)) {
          this.projectOfferList[i].childrensVisible = !this.projectOfferList[i].childrensVisible;
        }
      }
    }

    
  selectAllOfferForSubmit(event) {
    event.stopPropagation();
    this.selectAll = event.target.checked;
    for (let i=0; i<this.projectOfferList.length; i++) {
      if (!this.projectOfferList[i]['isProjectRow']) {
        this.addRemoveOfferForSubmit(event, i, this.projectOfferList[i]['offerId'], this.projectOfferList[i]['projectCode']);
      }
    }
  }

  
    addRemoveOfferForSubmit(event, index, offerId, projectCode) {
       event.stopPropagation();
       const isChecked = event.target.checked;
       if (isChecked) {
         this.projectOfferList[index]['checked'] = true;
         this.offerIdList.push(offerId);
       } else {
         this.projectOfferList[index]['checked'] = false;
         this.offerIdList.splice(this.offerIdList.indexOf(offerId), 1);
       }
       this.updateCheckedOnProjectRow(projectCode);
       this.updateOfferSubmitList();
    }

    updateCheckedOnProjectRow(projectCode) {
      let offerListCount = 0, offerCheckedCount = 0, data = {}, projectHeadRow = null;
      for (let i = 0; i < this.projectOfferList.length; i++) {
        if (this.projectOfferList[i]['projectCode'] === projectCode) {
          projectHeadRow = (this.projectOfferList[i]['isProjectRow']) ? (this.projectOfferList[i]) : projectHeadRow; 
          data = this.updateOfferCheckedCount(projectHeadRow, this.projectOfferList[i], offerListCount, offerCheckedCount);
          offerListCount = data['offerListCount'];
          offerCheckedCount = data['offerCheckedCount'];
        }
      }
    }

    updateOfferCheckedCount(projectHeadRow, projectOfferList, offerListCount, offerCheckedCount) {
      if (!projectOfferList['isProjectRow']) {
        offerListCount++;
        if(projectOfferList['checked']) {
          offerCheckedCount++;
        }
      }
      return this.updateCheckAttrOnProjectRow(projectHeadRow, projectOfferList, offerListCount, offerCheckedCount);
    }

    updateCheckAttrOnProjectRow(projectHeadRow, projectOfferList, offerListCount, offerCheckedCount) {
      if (offerListCount === offerCheckedCount) {
        projectHeadRow['checked'] = true;
      } else {
        projectHeadRow['checked'] = false;
      }
      return {
        'offerListCount': offerListCount, 
        'offerCheckedCount': offerCheckedCount
      };
    }

    addRemoveProjectOfferForSubmit(event, index, projectCode) {
      event.stopPropagation();
      const isChecked = event.target.checked;
      for (let i = 0; i < this.projectOfferList.length; i++) {
        if (this.projectOfferList[i]['projectCode'] === projectCode) {
          this.updateIsNotProjectRow(isChecked, i);
        }
      }
      this.updateOfferSubmitList();
    }

    updateIsNotProjectRow(isChecked, index) {
      if (!this.projectOfferList[index]['isProjectRow']) {
        this.updateProjectOfferListChecked(isChecked, index);
      } else {
        this.projectOfferList[index]['checked'] = isChecked;
      }
    }
  
    updateProjectOfferListChecked(isChecked, index) {
      if (isChecked) {
        this.projectOfferList[index]['checked'] = true;
        this.offerIdList.push(this.projectOfferList[index]['offerId']);
      } else {
        this.projectOfferList[index]['checked'] = false;
        this.offerIdList.splice(this.offerIdList.indexOf(this.projectOfferList[index]['offerId']), 1);
      }
      this.updateOfferSubmitList();
    }
  
    updateOfferSubmitList() {
      this.offerListForSubmit = [];
      for (let i=0; i<this.projectOfferList.length; i++) {
          if (this.offerIdList.indexOf(this.projectOfferList[i].offerId) !== -1) {
            this.offerListForSubmit.push(this.projectOfferList[i]);
          }
      }
      this.intiateSubmitButtons();
    }
  
    intiateSubmitButtons() {
      let omcSubmitCount = 0, pinpointSubmitCount = 0;
      const uatSubmitCount = 0;
      this.resetSubmitButtons();
      for (let i=0; i<this.offerListForSubmit.length; i++) {
        if ((this.offerListForSubmit[i].status.trim() === 'Test Bypassed') || (this.offerListForSubmit[i].status.trim() === 'Prod Publish Ready') || (this.offerListForSubmit[i].status.trim() === 'PROD OMC Create Failed')) {
          omcSubmitCount += 1;
        } else if ((this.offerListForSubmit[i].status.trim() === 'PROD OMC Create Passed') || (this.offerListForSubmit[i].status.trim() === 'PROD Pinpoint Create Failed')) {
          pinpointSubmitCount += 1;
        }
      }
      this.showHideButtons(omcSubmitCount, pinpointSubmitCount, uatSubmitCount);
    }
  
    showHideButtons(omcSubmitCount, pinpointSubmitCount, uatSubmitCount) {
      this.resetSubmitButtons();
      if (this.offerListForSubmit.length > 0) {
        this.showOMCSubmitButton(omcSubmitCount);
        this.showPinPointSubmitButton(pinpointSubmitCount);
      }
    }
  
    showOMCSubmitButton(omcSubmitCount) {
      if (this.offerListForSubmit.length === omcSubmitCount) {
        this.enableSubmitOMC = true;
      } else {
        this.enableSubmitOMC = false;
      }
    }
  
    showPinPointSubmitButton(pinpointSubmitCount) {
      if (this.offerListForSubmit.length === pinpointSubmitCount) {
        this.enableSubmitPinPoint = true;
      } else {
        this.enableSubmitPinPoint = false;
      }
    }
  
    submitForOMC() {
      this.resetValidateMessage();
      this.blockUI.start('Submitting Offer for OMC...');
      const submitObj = {};
     // submitObj['listOffer'] = this.offerIdList;
     submitObj['listOffer'] = [];
      for(let i=0; i<this.offerListForSubmit.length; i++) {
        const result = {};
        result['offerId'] = this.offerListForSubmit[i].offerId;
        result['uatComment'] = '';
        result['sites'] = [];
        submitObj['listOffer'].push(result);
      }
      this.distributorService.submitToProdOMC(submitObj)
        .subscribe(
          data => {
            if (data.actionStatus === 'SUCCESS') {
              //this.openOfferProdOMCSubmitSuccessDialog();
              this.updateModifyOfferValidateMessages(data.omcPinpointInterfaceResponseList);
              this.getProjectOfferTestList();
              this.intializeOfferTestPage();
            } else if (data.actionStatus === 'FAIL') {
              this.resetErrorMessageSection();
              this.omcSubmitFailed = true;
            }
            this.blockUI.stop();
          },
          error => {
            console.log('Error :: ' + error);
            this.blockUI.stop();
          }
        );
    }

    updateModifyOfferValidateMessages(releaseList) {
      for (let i = 0; i < releaseList.length; i++) {
        const currentReleaseObj = releaseList[i];
        const offerObj = {
          'offerID': currentReleaseObj['vwOmcPinpntInterfaceDefnModel']['EXTERNAL_ID'],
          'errorMessage': currentReleaseObj['error_details']['error_desc']
        };
        if (currentReleaseObj['actionStatus'] === 'SUCCESS') {
          this.omcValidateSubmitSuccessList.push(offerObj);
          this.showOmcSuccess = true;
        } else if (currentReleaseObj['actionStatus'] === 'FAIL') {
          this.omcValidateSubmitFailList.push(offerObj);
          this.showOmcFail = true;
        }
      }
    }

    resetValidateMessage() {
      this.omcValidateSubmitSuccessList = [];
      this.omcValidateSubmitFailList = [];
      this.pinpointSuccess = [];
      this.pinpointFail = [];
      this.showPinpointSuccess= false;
      this.showPinpointFail= false;
      this.showOmcSuccess = false;
      this.showOmcFail = false;
    }
  
    submitForPinPoint() {
      this.resetValidateMessage();
      this.blockUI.start('Submitting Offer for Pin Point...');
      const submitObj = {};
      submitObj['listOffer'] = [];
      //submitObj['listOffer'] = this.offerIdList;
      for(let i=0; i<this.offerListForSubmit.length; i++) {
        const result = {};
        result['offerId'] = this.offerListForSubmit[i].offerId;
        result['uatComment'] = '';
        result['sites'] = [];
        submitObj['listOffer'].push(result);
      }
      this.distributorService.submitToProdPinPoint(submitObj)
        .subscribe(
          data => {
            if (data.actionStatus === 'SUCCESS') {
              //this.openOfferProdPinPointSubmitSuccessDialog();
              this.commonMessageHolder(data.pinPointAddResponseList);
              this.getProjectOfferTestList();
              this.intializeOfferTestPage();
            } else if (data.actionStatus === 'FAIL') {
              this.resetErrorMessageSection();
              this.pinPointSubmitFailed = true;
            }
            this.blockUI.stop();
          },
          error => {
            console.log('Error :: ' + error);
            this.blockUI.stop();
          }
        );
    }


    commonMessageHolder(value){
      this.pinpointList = value;
      for(let i=0; i< this.pinpointList[0].OffersStatus.length; i++) {
        if (this.pinpointList[0].OffersStatus[i].actionStatus === 'SUCCESS') {
          this.pinpointSuccess.push(this.pinpointList[0].OffersStatus[i]);
          this.showPinpointSuccess= true;
        }
        else if(this.pinpointList[0].OffersStatus[i].actionStatus === 'FAIL'){
          this.pinpointFail.push(this.pinpointList[0].OffersStatus[i]); 
          this.showPinpointFail= true;
        }
      }
    }
    
    openOfferProdOMCSubmitSuccessDialog(): void {
      const dialogRef = this.dialog.open(OfferProdOMCSubmitSuccessDialogComponent, {
        width: 'auto'
      });
  
      dialogRef.afterClosed().subscribe(result => {
        //this.getProjectOfferTestList();
      });
    }
  
    openOfferProdPinPointSubmitSuccessDialog(): void {
      const dialogRef = this.dialog.open(OfferProdPinPointSubmitSuccessDialogComponent, {
        width: 'auto'
      });
  
      dialogRef.afterClosed().subscribe(result => {
        //this.getProjectOfferTestList();
      });
    }
  
       
    redirectTo(url) {
      this.router.navigate([url]);
    }
  }
  
  
  @Component({
    selector: 'plm-offer-test-omc-submit-success',
    templateUrl: './submit-omc-success-dialog.html'
  })
  export class OfferProdOMCSubmitSuccessDialogComponent {
  
    constructor(
      public dialogRef: MatDialogRef<OfferProdOMCSubmitSuccessDialogComponent>, private router: Router,
      @Inject(MAT_DIALOG_DATA) public data: any) {
        dialogRef.disableClose = true;
       }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
    reloadPage() {
      this.dialogRef.close();
      this.router.navigate(['plm-work-flow/distributor/omc-prod']);
    }
  }
  
  
  @Component({
    selector: 'plm-offer-test-pin-point-submit-success',
    templateUrl: './submit-pinpoint-success-dialog.html'
  })
  export class OfferProdPinPointSubmitSuccessDialogComponent {
  
    constructor(
      public dialogRef: MatDialogRef<OfferProdPinPointSubmitSuccessDialogComponent>, private router: Router,
      @Inject(MAT_DIALOG_DATA) public data: any) { 
        dialogRef.disableClose = true;
       }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
    reloadPage() {
      this.dialogRef.close();
      this.router.navigate(['plm-work-flow/distributor/omc-prod']);
    }
  
  }
