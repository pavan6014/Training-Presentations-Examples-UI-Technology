export interface Distributor {
}

export interface DiscountOfferList {
    actionStatus: string;
	actionResult: string;
    distributorOfferList: Map<string, Offer[]>
}

export interface Offer {
    projectCode: string;
    offerId: number;
    offerType: string;
    startDt: string;
    releaseDt: string;
    statusId: number;
    status: string;
    releaseCode: string;
    psu: string;
    offerName: string;
    offerDescription: string;
    offerCategory: string;
    endDt: string;
    offerBundleName: string;
    salesAdvise: string;
    lastUpdateDate: string;
    primaryDiscountCode: string;
    sites: number[];
    estimatedMrc: string;
    projType: string;
    testMarketsSelectedItems: any;
}

export interface OMCTestQueueList {
    isProjectRow: boolean;
    showRow: boolean;
    checked: boolean;
    projectCode: string;
    status: string;
    projectType: string;
    releaseCode: string;
    offerId: number;
    offerType: string;
    offerName: string;
    offerDescription: string;
    offerCategory: string;
    startDt: string;
    endDt: string;
    omcStatus: string;
    pinPointStatus: string;
    testMarkets: number[];
    uatStatus: string;
    uatComments: string;
    testMarketsSelectedItems: any;
    sites: any;
    childrensVisible: boolean;
}
