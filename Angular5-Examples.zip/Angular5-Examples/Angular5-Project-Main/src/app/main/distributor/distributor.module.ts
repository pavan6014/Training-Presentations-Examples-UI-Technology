import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {MatDialogModule} from '@angular/material/dialog';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { DistributorRoutingModule } from './distributor-routing.module';
import { NgSelectModule } from '@ng-select/ng-select';
import {MatTooltipModule} from '@angular/material/tooltip';
import { OrderModule } from 'ngx-order-pipe';
import { 
  OmcTestComponent, 
  OfferTestBypassTestingSubmitSuccessDialogComponent, 
  OfferTestOMCSubmitSuccessDialogComponent, 
  OfferTestPinPointSubmitSuccessDialogComponent, 
  OfferTestUATSubmitSuccessDialogComponent, 
  OfferTestInvalidInputDialogComponent
} from './omc-test/omc-test.component';
import { 
  OmcProdComponent, 
  OfferProdOMCSubmitSuccessDialogComponent, 
  OfferProdPinPointSubmitSuccessDialogComponent
} from './omc-prod/omc-prod.component';
import { ProductComponent } from './product/product.component';
import { DiscountComponent } from './discount/discount.component';
import { DistributorDataService } from './services/distributor-data-service.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    AngularMultiSelectModule,
    DistributorRoutingModule,
    MatTooltipModule,
    NgSelectModule,
    OrderModule
  ],
  declarations: [
    OmcTestComponent,
    OmcProdComponent,
    ProductComponent,
    DiscountComponent, 
    OfferTestBypassTestingSubmitSuccessDialogComponent, 
    OfferTestOMCSubmitSuccessDialogComponent, 
    OfferTestPinPointSubmitSuccessDialogComponent, 
    OfferTestUATSubmitSuccessDialogComponent, 
    OfferTestInvalidInputDialogComponent, 
    OfferProdOMCSubmitSuccessDialogComponent, 
    OfferProdPinPointSubmitSuccessDialogComponent
  ],
  entryComponents: [
    OfferTestBypassTestingSubmitSuccessDialogComponent, 
    OfferTestOMCSubmitSuccessDialogComponent, 
    OfferTestPinPointSubmitSuccessDialogComponent, 
    OfferTestUATSubmitSuccessDialogComponent, 
    OfferTestInvalidInputDialogComponent, 
    OfferProdOMCSubmitSuccessDialogComponent, 
    OfferProdPinPointSubmitSuccessDialogComponent
  ], 
  providers: [DistributorDataService]
})
export class DistributorModule { }
