import {MatAutocompleteModule, MatButtonModule, MatCheckboxModule, MatExpansionModule, MatInputModule} from '@angular/material';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSelectModule} from '@angular/material/select';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2PaginationModule } from 'ng2-pagination';
import { NgModule } from '@angular/core';
import { PriceBookDetailsComponent } from './price-book-details/price-book-details.component';
import { PriceBookListComponent } from './price-book-list/price-book-list.component';
import { PriceBookService } from '../pricebook/price-book.service';
import { PriceBookSuccessNotesComponent } from '../pricebook/price-book-view/price-book-view.component';
import { PriceBookViewComponent } from './price-book-view/price-book-view.component';
import { PricebookRoutingModule } from '../pricebook/pricebook-routing.module';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    PricebookRoutingModule, 
    MatExpansionModule,
    Ng2PaginationModule,
    Ng2OrderModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    SharedModule, 
    FormsModule
  ],
  declarations: [PriceBookListComponent, PriceBookDetailsComponent, PriceBookViewComponent, PriceBookSuccessNotesComponent],
  entryComponents: [PriceBookSuccessNotesComponent],
  providers: [PriceBookService]
})
export class PricebookModule { }
