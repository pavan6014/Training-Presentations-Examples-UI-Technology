import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, OnChanges, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';
import { PriceBookData, PriceBookDataDetails, PriceBookSiteMaps, SubmitPriceBookDetails } from '../price-book';

import { ConfiguratorDataService } from '../../configurator-data.service';
import { Observable } from 'rxjs/Observable';
import { PriceBook } from '../../pricebook/price-book';
import { PriceBookDetailsComponent } from '../price-book-details/price-book-details.component';
import { PriceBookService } from '../../pricebook/price-book.service';
import { Router } from '@angular/router';
import { Serializer } from '@angular/compiler';

@Component({
  selector: 'plm-price-book-view',
  templateUrl: './price-book-view.component.html',
  styleUrls: ['./price-book-view.component.css']
})

export class PriceBookViewComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;

  private priceBookView: any;
  private priceBookViewData: any;
  private priceBookMasterId: string;
  private editMode: Boolean;
  private viewMode: Boolean;

  private disableBtn: Boolean;
  private priceBookList: PriceBookDataDetails[];
  private priceBookDataSubmit: any[];
  private priceBookListResponse: any[];
  private PriceBookDataList: any[];
  private addEditPriceBookSubmitData: any;
  private saveFail: boolean;
  private priceBookEndDate: any;
  private priceBookstartDate: any;
  private projectEndMinDate: any;
  private projectStartMinDate: any;
  private priceBookSiteMaps: any;

  private fetchSitesFailed: boolean;
  private fetchPriceBookFailed: boolean;
  private showSearch: boolean;
  
  private filterByRelatedIcomsCode : String;
  private filterByIcomsCodeDesc : String;
  private filterByOldIcomsCode : string;
  private filterByCon : String;
  private filterByRhi : string;
  private filterByCle : string;
  private filterByNva : string;
  private filterByRoa : string;
  private filterByHrd : string;
  private filterByMac : string;
  private filterByGan : string;
  private filterByPen : string;
  private filterByBtr : string;
  private filterByLou : string;
  private filterByTul : string;
  private filterByOkc : string; 
  private filterByKan : string;
  private filterByOma : string;
  private filterByPhx : string;
  private filterByLas : string; 
  private filterByOrg : string;
  private filterByPal : string;
  private filterBySab : string;
  private filterBySan : string;

  private filterByRelatedIcomsCodeSearchObj: any;
  private filterByIcomsCodeDescSearchObj:any;
  private filterByOldIcomsCodeSearchObj:any;
  private filterByConSearchObj:any;
  private filterByRhiSearchObj:any;
  private filterByCleSearchObj:any;
  private filterByRoaSearchObj:any;
  private filterByHrdSearchObj:any;
  private filterByMacSearchObj:any;
  private filterByGanSearchObj:any;
  private filterByPenSearchObj:any;
  private filterByBtrSearchObj:any;
  private filterByLouSearchObj:any;
  private filterByTulSearchObj:any;
  private filterByOkcSearchObj:any;
  private filterByKanSearchObj:any;
  private filterByOmaSearchObj:any;
  private filterByPhxSearchObj:any;
  private filterByLasSearchObj:any;
  private filterByOrgSearchObj:any;
  private filterByPalSearchObj:any;
  private filterBySabSearchObj:any;
  private filterBySanSearchObj:any;
  private currentUser:String;
 

  constructor(private router: Router,
    private priceBookService: PriceBookService,
    private configuratorDataService: ConfiguratorDataService,
    public dialog: MatDialog,
  ) {
    this.priceBookView = [];
    this.priceBookViewData = {};
    this.priceBookMasterId = this.configuratorDataService.priceBookId;
    this.editMode = false;
    this.viewMode = false;
    this.disableBtn = false;
    this.saveFail = false;
    this.fetchSitesFailed = false;
    this.fetchPriceBookFailed = false;
    this.updatePageMode();

    this.priceBookDataSubmit = [];
    this.priceBookListResponse = [];
    this.priceBookEndDate = '';
    this.priceBookstartDate = '';
    this.projectEndMinDate = '';
    this.projectStartMinDate = '';
    this.priceBookSiteMaps = [];
   
    this.filterByRelatedIcomsCode = '';
    this.filterByIcomsCodeDesc ='';
    this.filterByOldIcomsCode = '';
    this.filterByCon = '';
    this.filterByRhi = '';
    this.filterByCle = '';
    this.filterByNva = '';
    this.filterByRoa = '';
    this.filterByHrd = '';
    this.filterByMac = '';
    this.filterByGan = '';
    this.filterByPen = '';
    this.filterByBtr = '';
    this.filterByLou = '';
    this.filterByTul = '';
    this.filterByOkc = ''; 
    this.filterByKan = '';
    this.filterByOma = '';
    this.filterByPhx = '';
    this.filterByLas = ''; 
    this.filterByOrg = '';
    this.filterByPal = '';
    this.filterBySab = '';
    this.filterBySan = '';
    this.filterByRelatedIcomsCodeSearchObj = '';
    this.filterByIcomsCodeDescSearchObj = '';
    this.filterByOldIcomsCodeSearchObj = '';
    this.filterByConSearchObj='';
    this.filterByRhiSearchObj= '';
    this.filterByCleSearchObj= '';
    this.filterByRoaSearchObj= '';
    this.filterByHrdSearchObj= '';
    this.filterByMacSearchObj= '';
    this.filterByGanSearchObj= '';
    this.filterByPenSearchObj= '';
    this.filterByBtrSearchObj= '';
    this.filterByLouSearchObj= '';
    this.filterByTulSearchObj= '';
    this.filterByOkcSearchObj= '';
    this.filterByKanSearchObj= '';
    this.filterByOmaSearchObj= '';
    this.filterByPhxSearchObj= '';
    this.filterByLasSearchObj= '';
    this.filterByOrgSearchObj= '';
    this.filterByPalSearchObj= '';
    this.filterBySabSearchObj= '';
    this.filterBySanSearchObj= '';
    this.currentUser='';
    
  }

  ngOnInit() {
    this.getPriceBookSiteMaps();
    this.intializeProjectDate();
    this.initializeFilterContext();
    this.currentUser = sessionStorage.getItem('userName');
    if (this.configuratorDataService.priceBookMode !== 'add') {
      this.getPriceBookData();
    } else {
      this.priceBookView = this.configuratorDataService.priceBookData.csvData;
      this.priceBookViewData.priceBookName = this.configuratorDataService.priceBookData.priceBookName;
      this.priceBookViewData.startDateVal = new Date(this.configuratorDataService.priceBookData.priceBookstartDate);
      this.priceBookViewData.endDateVal = new Date(this.configuratorDataService.priceBookData.priceBookEndDate);
      this.priceBookViewData.endDateVal = new Date(this.configuratorDataService.priceBookData.priceBookEndDate);
      this.priceBookViewData.note = this.configuratorDataService.priceBookData.priceBookNotes;
      this.populatePriceBookMasterDetails();
    }
  }

  resetPricingBookSearchData() {

  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  initializeFilterContext() {
    this.filterByRelatedIcomsCodeSearchObj = {
      'relatedIcomsCode': {
        'type': 'text',
        'value': this.filterByRelatedIcomsCode,
        'matchFullCase': false
      }
    };

    this.filterByIcomsCodeDescSearchObj = {
      'icomsCodeDescription': {
        'type': 'text',
        'value': this.filterByIcomsCodeDesc,
        'matchFullCase': false
      }
    };
    
    this.filterByOldIcomsCodeSearchObj = {
      'oldIcomsCodeRi': {
        'type': 'text',
        'value': this.filterByOldIcomsCode,
        'matchFullCase': false
      }
    };
    this.filterByConSearchObj = {
      'CON': {
        'type': 'text',
        'value': this.filterByCon,
        'matchFullCase': false
      }
    };
    this.filterByRhiSearchObj = {
      'RHI': {
        'type': 'text',
        'value': this.filterByRhi,
        'matchFullCase': false
      }
    };
    this.filterByCleSearchObj = {
      'CLE': {
        'type': 'text',
        'value': this.filterByCle,
        'matchFullCase': false
      }
    };
    this.filterByRoaSearchObj = {
      'ROA': {
        'type': 'text',
        'value': this.filterByRoa,
        'matchFullCase': false
      }
    };
    this.filterByHrdSearchObj = {
      'HRD': {
        'type': 'text',
        'value': this.filterByHrd,
        'matchFullCase': false
      }
    };
    this.filterByMacSearchObj = {
      'MAC': {
        'type': 'text',
        'value': this.filterByMac,
        'matchFullCase': false
      }
    };
    this.filterByGanSearchObj = {
      'GAN': {
        'type': 'text',
        'value': this.filterByGan,
        'matchFullCase': false
      }
    };
    this.filterByPenSearchObj = {
      'PEN': {
        'type': 'text',
        'value': this.filterByPen,
        'matchFullCase': false
      }
    };
    this.filterByBtrSearchObj = {
      'BTR': {
        'type': 'text',
        'value': this.filterByBtr,
        'matchFullCase': false
      }
    };
    this.filterByLouSearchObj = {
      'LOU': {
        'type': 'text',
        'value': this.filterByLou,
        'matchFullCase': false
      }
    };
    this.filterByTulSearchObj = {
      'TUL': {
        'type': 'text',
        'value': this.filterByTul,
        'matchFullCase': false
      }
    };
    this.filterByOkcSearchObj = {
      'OKC': {
        'type': 'text',
        'value': this.filterByOkc,
        'matchFullCase': false
      }
    };
    this.filterByKanSearchObj = {
      'KAN': {
        'type': 'text',
        'value': this.filterByKan,
        'matchFullCase': false
      }
    };
    this.filterByOmaSearchObj = {
      'OMA': {
        'type': 'text',
        'value': this.filterByOma,
        'matchFullCase': false
      }
    };
    this.filterByPhxSearchObj = {
      'PHX': {
        'type': 'text',
        'value': this.filterByPhx,
        'matchFullCase': false
      }
    };
    this.filterByLasSearchObj = {
      'LAS': {
        'type': 'text',
        'value': this.filterByLas,
        'matchFullCase': false
      }
    };
    this.filterByOrgSearchObj = {
      'ORG': {
        'type': 'text',
        'value': this.filterByOrg,
        'matchFullCase': false
      }
    };
    this.filterByPalSearchObj = {
      'PAL': {
        'type': 'text',
        'value': this.filterByPal,
        'matchFullCase': false
      }
    };
    this.filterBySabSearchObj = {
      'SAB': {
        'type': 'text',
        'value': this.filterBySab,
        'matchFullCase': false
      }
    };
    this.filterBySanSearchObj = {
      'SAN': {
        'type': 'text',
        'value': this.filterBySan,
        'matchFullCase': false
      }
    };

  }

  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  //Start


  startDateChanged(key, dateVal, priceBookViewData) {
    const startDateObj = new Date(dateVal);
    const endMinDate = Number(startDateObj.getDate());
    const endMinMonth = startDateObj.getMonth();
    const endMinYear = startDateObj.getFullYear();
    this.projectEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
    this.priceBookViewData.startDateVal = new Date(dateVal);
  }


  endDateChanged(key, dateVal, priceBookViewData) {
    this.priceBookViewData.endDateVal = new Date(dateVal);
  }
  
  getDateInFormat(date) {
    const dateObj = new Date(date);
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }

  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }

  getPriceBookSiteMaps() {
    this.priceBookService.getPricebookSiteMaps().subscribe(
      data => {
        this.fetchSitesFailed = false;
        if (data.actionStatus === 'SUCCESS') {
          this.priceBookSiteMaps = data.priceBookSiteMaps;
        } else if (data.actionStatus === 'FAIL') {
          this.fetchSitesFailed = true;
        }
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  intializeProjectDate() {
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    this.projectStartMinDate = new Date(todayYear, todayMonth, todayDate);
    this.projectEndMinDate = new Date(todayYear, todayMonth, todayDate);
  }
  getPriceBookData() {
    this.blockUI.start('Loading Price Books...');
    this.priceBookService.getPricebookViewData(this.priceBookMasterId).subscribe(
      data => {
        this.fetchPriceBookFailed = false;
        if (data.actionStatus === 'SUCCESS') {
          this.priceBookViewData = data.priceBookMasterModel;
          this.priceBookViewData.startDateVal = new Date(this.priceBookViewData.startDate);
          this.priceBookViewData.endDateVal = new Date(this.priceBookViewData.endDate);
          this.priceBookView = this.priceBookViewData.priceBookMasterDets;
          this.populatePriceBookMasterDetails();
          this.blockUI.stop();
        } else if (data.actionStatus === 'FAIL') {
          this.fetchPriceBookFailed = true;
          this.blockUI.stop();
        }
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  populatePriceBookMasterDetails() {
    for (let i = 0; i < this.priceBookView.length; i++) {
      this.populateSiteMapValues(this.priceBookView[i]['priceBookSiteMaps'], i);
    }
  }

  populateSiteMapValues(arr, index) {
    if ((!arr) || (arr.length === 0)) {
      return '';
    }
    for (let i = 0; i < arr.length; i++) {
      const siteName = arr[i]['site'];
      const amount = arr[i]['amount'];
      this.priceBookView[index][siteName] = amount;
    }
  }

  getPriceBookSiteAmount(arr, site) {
    let result = '';
    if ((!arr) || (arr.length === 0)) {
      return '';
    }
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]['site'] === site) {
        result = arr[i]['amount'];
        break;
      }
    }
    return result;
  }

  updatePriceBookSitesData(priceBookView) {
    for (let i = 0; i < priceBookView.length; i++) {
      console.error(priceBookView[i]);
      for (let j = 0; j < priceBookView[i]['priceBookSiteMaps'].length; j++) {
        priceBookView[i][priceBookView[i]['priceBookSiteMaps'][j]['site']] = priceBookView[i]['priceBookSiteMaps'][j]['amount'];
      }
    }
  }

  updatePageMode() {
    if ((this.configuratorDataService.priceBookMode === 'edit') || (this.configuratorDataService.priceBookMode === 'add')) {
      this.viewMode = false;
      this.editMode = true;
    }
    else if ((this.configuratorDataService.priceBookMode === 'view')) {
      this.viewMode = true;
      this.editMode = false;
    }
  }

  returnBack() {
    if (this.configuratorDataService.priceBookMode === 'add') {
      this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-details']);
    } else {
      this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-list']);
    }
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  getpriceBookMasterDets() {
    return {
      'priceBookMasterDetId': '',
      'priceBookMasterId': '',
      'icomsCodeDescription': '',
      'oldIcomsCodeRi': '',
      'relatedIcomsCode': ''
    };
  }

  getpriceBookSiteMaps() {
    return {
      'site': '',
      'siteId': '',
      'amount': '',
    };
  }


  saveAndExit() {
    this.blockUI.start('Saving PriceBook Data...');
    this.priceBookUpdate();
  }

  priceBookUpdate() {
    const reqObj = this.getSaveSubmitData();
    this.priceBookService.priceBookAddDetails(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus === 'SUCCESS') {
            this.showSaveSubmitDialog();
            this.blockUI.stop();
          } else if (data.actionStatus === 'FAIL') {
            this.showErrorMessage();
            this.blockUI.stop();
          }
          this.updatePriceBookForSubmit();
          this.blockUI.stop();

        },
        error => {
          console.log('Error :: ' + error);
          this.showErrorMessage();
          this.blockUI.stop();
        }
      );
  }
  showErrorMessage() {
    this.saveFail = true;
  }

  showSaveSubmitDialog() {
    this.openPriceBookSuccess();
  }

  openPriceBookSuccess(): void {
    const dialogRef = this.dialog.open(PriceBookSuccessNotesComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }

  updatePriceBookForSubmit() {
    this.priceBookDataSubmit = [];
    for (let i = 0; i < this.PriceBookDataList.length; i++) {
      const result = {};
      result['relatedIcomsCode'] = this.PriceBookDataList[i]['relatedIcomsCode'];
      result['icomsCodeDescription'] = this.PriceBookDataList[i]['icomsCodeDescription'];
      result['oldIcomsCodeRi'] = this.PriceBookDataList[i]['oldIcomsCodeRi'];

      this.priceBookDataSubmit.push(result);
    }
  }

  getPriceBookList() {
    return {
      'priceBookMasterId': '',
      'createdBy': '',
      'createdDate': '',
      'endDate': '',
      'modifiedBy': '',
      'modifiedDate': '',
      'note': '',
      'priceBookName': '',
      'startDate': '',
      'future': '',
      'active': '',
      'priceBookMasterDets': this.getpriceBookMasterDets(),
      'priceBookSiteMaps': this.getpriceBookSiteMaps(),
    }
  }

  getSaveSubmitData() {
    return {
      "priceBookMasterModelList": [
        {
          "priceBookMasterId": ((this.configuratorDataService.priceBookMode === 'add') ? null : this.priceBookViewData.priceBookMasterId),
          //"createdBy": ((this.configuratorDataService.priceBookMode === 'add') ? null : this.priceBookViewData.createdBy),
          "createdBy": ((this.configuratorDataService.priceBookMode === 'add') ? this.currentUser : this.currentUser),
          "createdDate": ((this.configuratorDataService.priceBookMode === 'add') ? this.getDateInFormat(new Date()) : this.priceBookViewData.createdDate),
          "endDate": ((typeof this.priceBookViewData.endDateVal === 'undefined') ? this.priceBookViewData.endDate : this.getDateInFormat(this.priceBookViewData.endDateVal)),
          "modifiedBy": ((this.configuratorDataService.priceBookMode === 'add') ? null : this.priceBookViewData.modifiedBy),
          "modifiedDate": ((this.configuratorDataService.priceBookMode === 'add') ? null :'08-28-2018'),
          "note": (this.priceBookViewData.note),
          "priceBookName": (this.priceBookViewData.priceBookName),
          "startDate": ((typeof this.priceBookViewData.startDateVal === 'undefined') ? this.priceBookViewData.startDate : this.getDateInFormat(this.priceBookViewData.startDateVal)),
          "future": ((this.priceBookViewData.startDateVal >new Date())?'Yes':'No'),
          "active": "yes",
          "priceBookMasterDets": this.getPriceBookMasterDets()
        }
      ]
    }
  }

  getPriceBookMasterDets() {
    const result = [];
    for (let i = 0; i < this.priceBookView.length; i++) {
      const resultObj = {};
      resultObj['priceBookMasterDetId'] = this.priceBookView[i]['priceBookMasterDetId'];
      resultObj['priceBookMasterId'] = this.priceBookView[i]['priceBookMasterId'];
      resultObj['icomsCodeDescription'] = this.priceBookView[i]['icomsCodeDescription'];
      resultObj['oldIcomsCodeRi'] = this.priceBookView[i]['oldIcomsCodeRi'];
      resultObj['relatedIcomsCode'] = this.priceBookView[i]['relatedIcomsCode'];
      resultObj['priceBookSiteMaps'] = this.getSiteValueArray(this.priceBookView[i]);
      result.push(resultObj);
    }
    return result;
  }

  getSiteValueArray(priceBookView) {
    const siteObj = [
      {
        "site": "ORG",
        "siteId": 333,
        "amount": "0"
      },
      {
        "siteId": 476,
        "site": "LAS",
        "amount": "0"
      },
      {
        "siteId": 334,
        "site": "PAL",
        "amount": "0"
      },
      {
        "siteId": 342,
        "site": "SAB",
        "amount": "0"
      },
      {
        "siteId": 477,
        "site": "NVA",
        "amount": "0"
      },
      {
        "siteId": 541,
        "site": "SAN",
        "amount": "0"
      },
      {
        "siteId": 436,
        "site": "PHX",
        "amount": "0"
      },
      {
        "siteId": 216,
        "site": "CON",
        "amount": "0"
      },
      {
        "siteId": 238,
        "site": "RHI",
        "amount": "0"
      },
      {
        "siteId": 609,
        "site": "CLE",
        "amount": "0"
      },
      {
        "siteId": 215,
        "site": "HRD",
        "amount": "0"
      },
      {
        "siteId": 239,
        "site": "ROA",
        "amount": "0"
      },
      {
        "siteId": 580,
        "site": "KAN",
        "amount": "0"
      },
      {
        "siteId": 126,
        "site": "LOU",
        "amount": "0"
      },
      {
        "siteId": 182,
        "site": "BTR",
        "amount": "0"
      },
      {
        "siteId": 186,
        "site": "TUL",
        "amount": "0"
      },
      {
        "siteId": 132,
        "site": "OMA",
        "amount": "0"
      },
      {
        "siteId": 214,
        "site": "GAN",
        "amount": "0"
      },
      {
        "siteId": 135,
        "site": "PEN",
        "amount": "0"
      },
      {
        "siteId": 131,
        "site": "OKC",
        "amount": "0"
      },
      {
        "siteId": 1,
        "site": "MAC",
        "amount": "0"
      }
    ]
    for (let i = 0; i < siteObj.length; i++) {
      siteObj[i]['amount'] = priceBookView[siteObj[i]['site']];
    }
    return siteObj;
  }
}


@Component({
  selector: 'plm-price-book-view-success',
  templateUrl: './price-book-viewSuccess.html'
})
export class PriceBookSuccessNotesComponent implements OnInit, OnChanges {


  private showSuccessNotes: boolean;
  constructor(
    public dialogRef: MatDialogRef<PriceBookSuccessNotesComponent>,
    private router: Router,
    private configuratorDataService: ConfiguratorDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.showSuccessNotes = true;
  }

  ngOnInit() { }
  ngOnChanges() { }
  onNoClick(): void {
    this.dialogRef.close();
  }
  moveToProjectList() {
    this.dialogRef.close();
    this.router.navigate(['plm-work-flow/configurator/pricebook/price-book-list']);
  }

  reloadPage() {
    this.dialogRef.close();
  }
}


