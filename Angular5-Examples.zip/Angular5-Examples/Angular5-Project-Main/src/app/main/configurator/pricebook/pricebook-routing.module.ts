import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../shared';
import { PriceBookListComponent } from '../pricebook/price-book-list/price-book-list.component';
import { PriceBookDetailsComponent } from '../pricebook/price-book-details/price-book-details.component';
import { PriceBookViewComponent } from '../pricebook/price-book-view/price-book-view.component';

const routes: Routes = [
  { 
    path: 'price-book-list', 
    component: PriceBookListComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/pricebook/price-book-list'}  
  },
  { 
    path: 'price-book-details', 
    component: PriceBookDetailsComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/pricebook/price-book-details'}  
  },
   { 
    path: 'price-book-view', 
    component: PriceBookViewComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/pricebook/price-book-view'}  
  }
];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class PricebookRoutingModule { }
