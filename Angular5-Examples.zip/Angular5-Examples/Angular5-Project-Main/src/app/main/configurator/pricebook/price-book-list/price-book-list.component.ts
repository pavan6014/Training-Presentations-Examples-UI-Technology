import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit } from '@angular/core';

import { ConfiguratorDataService } from '../../configurator-data.service';
import { FetchPriceBook } from '../../configurator.interface';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { PriceBook } from '../../pricebook/price-book';
import { PriceBookDetailsComponent } from '../price-book-details/price-book-details.component';
import { PriceBookService } from '../../pricebook/price-book.service';
import { Router } from '@angular/router';
import { Serializer } from '@angular/compiler';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-price-book-list',
  templateUrl: './price-book-list.component.html',
  styleUrls: ['./price-book-list.component.css'],
  providers: [UtilitiesService]
})
export class PriceBookListComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private priceBookList: any;
  private fetchPriceBookFailed: boolean;

  private filterByPriceBookName: string;
  private filterByStartDate: string;
  private filterByEndDate: string;
  private filterByNote: string;
  private filterByActive: string;
  private filterByFuture: string;
  private filterByCreatedDate: string;
  private filterByModifiedBy: string;
  private filterByCreatedBy: string;

  private filterByPriceBookNameSearchObj: any;
  private filterByStartDateSearchObj: any;
  private filterByEndDateSearchObj: any;
  private filterByNoteSearchObj: any;
  private filterByActiveSearchObj: any;
  private filterByFutureSearchObj: any;
  private filterByCreatedDateSearchObj: any;
  private filterByModifiedBySearchObj: any;
  private filterByCreatedBySearchObj: any;



  private showSearch: boolean;
  private key: string;
  private reverse: boolean;

  private EditMode: string;
  private priceBookId: string;
  private capitalizedAddEdiitMode: string;
  private priceBookDetails: FetchPriceBook[];


  constructor(
    private router: Router,
    private priceBookService: PriceBookService,
    private configuratorDataService: ConfiguratorDataService,
    private utilitiesService: UtilitiesService,
  ) {
    this.priceBookList = [];
    this.fetchPriceBookFailed = false;
    
    this.priceBookId = this.configuratorDataService.priceBookId;

    this.filterByPriceBookName = '';
    this.filterByStartDate = '';
    this.filterByEndDate = '';
    this.filterByNote = '';
    this.filterByActive = '';
    this.filterByFuture = '';
    this.filterByCreatedDate = '';
    this.filterByModifiedBy = '';
    this.filterByCreatedBy = '';

    this.filterByPriceBookNameSearchObj = '';
    this.filterByStartDateSearchObj = '';
    this.filterByEndDateSearchObj = '';
    this.filterByNoteSearchObj = '';
    this.filterByActiveSearchObj = '';
    this.filterByFutureSearchObj = '';
    this.filterByCreatedDateSearchObj = '';
    this.filterByModifiedBySearchObj = '';
    this.filterByCreatedBySearchObj = '';
  }

  ngOnInit() {
    this.getPriceBookList();
  }

  moveToPriceBookView() {
    this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-view']);
  }

  moveToPriceBookViewEdit() {
    this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-view']);
  }

  resetPricingBookSearchData() {
    this.priceBookList = [];
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-details']);
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }


  getPriceBookList() {
    this.blockUI.start('Loading Price Books...');
    this.priceBookService.getBuPricebookData().subscribe(
      data => {
        if (data.actionStatus === 'SUCCESS') {
          this.fetchPriceBookFailed = false;
          this.priceBookList = data.priceBookMasterModelList;
          this.initializeFilterContext();
          this.blockUI.stop();
        } else {
          this.fetchPriceBookFailed = true;
          this.blockUI.stop();
        }
      },
      error => {
        console.log('Error :: ' + error);
        this.fetchPriceBookFailed = true;
        this.blockUI.stop();
      }
    );
  }


  initializeFilterContext() {
    this.filterByPriceBookNameSearchObj = {
      'priceBookName': {
        'type': 'text',
        'value': this.filterByPriceBookName,
        'matchFullCase': false
      }
    };
    this.filterByStartDateSearchObj = {
      'startDate': {
        'type': 'date',
        'value': this.filterByStartDate,
        'matchFullCase': true
      }
    };
    this.filterByEndDateSearchObj = {
      'endDate': {
        'type': 'date',
        'value': this.filterByEndDate,
        'matchFullCase': true
      }
    };
    this.filterByNoteSearchObj = {
      'note': {
        'type': 'text',
        'value': this.filterByNote,
        'matchFullCase': false
      }
    };
    this.filterByActiveSearchObj = {
      'active': {
        'type': 'text',
        'value': this.filterByActive,
        'matchFullCase': false
      }
    };
    this.filterByFutureSearchObj = {
      'future': {
        'type': 'text',
        'value': this.filterByFuture,
        'matchFullCase': true
      }
    };
    this.filterByCreatedDateSearchObj = {
      'createdDate': {
        'type': 'date',
        'value': this.filterByCreatedDate,
        'matchFullCase': true
      }
    };
    this.filterByModifiedBySearchObj = {
      'modifiedBy': {
        'type': 'text',
        'value': this.filterByModifiedBy,
        'matchFullCase': false
      }
    };
    this.filterByCreatedBySearchObj = {
      'createdBy': {
        'type': 'text',
        'value': this.filterByCreatedBy,
        'matchFullCase': false
      }
    };
  }



  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  getDateInFormat(date) {
    const currentDate = new Date(date);
    const result = ("0" + (currentDate.getDate() + 1)).slice(-2) + '/' + ("0" + (currentDate.getMonth() + 1)).slice(-2) + '/' + currentDate.getFullYear();
    return result;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  viewPriceBook(priceBookMasterId) {
    this.triggerEditViewPriceBook('view', priceBookMasterId, 'plm-work-flow/configurator/pricebook/price-book-view');
  }

  editPriceBook(priceBookMasterId) {
    this.triggerEditViewPriceBook('edit', priceBookMasterId, 'plm-work-flow/configurator/pricebook/price-book-view');
  }

  triggerEditViewPriceBook(mode, priceBookMasterId, url) {
    this.configuratorDataService.priceBookMode = mode;
    this.configuratorDataService.priceBookId = priceBookMasterId;
    this.configuratorDataService.backURL = 'plm-work-flow/configurator/pricebook/price-book-list';
    this.router.navigate([url]);
  }

}

