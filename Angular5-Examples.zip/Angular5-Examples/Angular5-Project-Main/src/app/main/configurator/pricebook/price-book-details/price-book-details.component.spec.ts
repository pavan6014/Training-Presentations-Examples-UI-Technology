import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PriceBookDetailsComponent } from './price-book-details.component';

describe('PriceBookDetailsComponent', () => {
  let component: PriceBookDetailsComponent;
  let fixture: ComponentFixture<PriceBookDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PriceBookDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PriceBookDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
