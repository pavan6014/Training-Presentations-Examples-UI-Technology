export interface PriceBook {
    pricebookName: string;
    pricebookStartDate: string;
    pricebookEndDate: string;
    pricebookNotes: string;
    pricebookActive: string;
    pricebookFuture: string;
    pricebookCreatedDate: string;
    pricebookLastModifiedDate: string;
    pricebookCreatedBy: string;
    PriceBook: any;



}


export interface PriceBookData {
    isSubmitted: number;
    priceBookDataDEtails: PriceBookDataDetails;
}


export interface PriceBookDataDetails {
    priceBookMasterId: number;
    createdBy: string;
    createdDate: string;
    endDate: string;
    modifiedBy: string;
    modifiedDate: string;
    note: string;
    priceBookName: string;
    startDate: string;
    future: string;
    active: string;
    priceBookMasterDetId: string;

    icomsCodeDescription: string;
    oldIcomsCodeRi: string;
    relatedIcomsCode: string;
    priceBookSiteMaps: PriceBookSiteMaps[]
}

export interface SubmitPriceBookDetails {
   
    icomsCodeDescription: string;
    oldIcomsCodeRi: string;
    relatedIcomsCode: string;
    priceBookSiteMaps: PriceBookSiteMaps[]
}

export interface PriceBookSiteMaps {
    site: string;
    siteId: number
    amount: string;
}


export interface AddUpdatePriceBookAddUpdate {

    searchKey: null;

    actionResult: string;
    actionStatus: string;
    isSubmitted: number;
    priceBookModel: PriceBookModel;
}

export interface PriceBookModel {
    priceBookMasterId: string;
    createdBy: string;
    createdDate: string;
    endDate: string;
    modifiedBy: string;
    modifiedDate: string;
    note: string;
    priceBookName: string;
    startDate: string;
    future: string;
    active: string;
    priceBookMasterDetId: string;

    icomsCodeDescription: string;
    oldIcomsCodeRi: string;
    relatedIcomsCode: string;
    priceBookSiteMapsModel: PriceBookSiteMapsModel[]
}

export interface PriceBookSiteMapsModel {
    site: string;
    siteId: number
    amount: string;
}