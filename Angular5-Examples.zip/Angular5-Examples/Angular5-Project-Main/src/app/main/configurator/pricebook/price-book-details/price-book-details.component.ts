import { Component, OnInit } from '@angular/core';

import { ConfiguratorDataService } from '../../../configurator/configurator-data.service';
import { PriceBookViewComponent } from '../price-book-view/price-book-view.component';
import { Router } from '@angular/router';

@Component({
  selector: 'plm-price-book-details',
  templateUrl: './price-book-details.component.html',
  styleUrls: ['./price-book-details.component.css']
})
export class PriceBookDetailsComponent implements OnInit {
  private fileReaded: any;
  public result = {};
  private csvData: any;
  private disableSubmit: boolean;
  private priceBookName: string;
  private priceBookstartDate: any;
  private priceBookEndDate: any;
  private priceBookNotes: string;
  private projectStartMinDate: any;
  private projectEndMinDate: any;

  constructor(private router: Router, private configuratorDataService: ConfiguratorDataService) {
    this.csvData = [];
    this.priceBookName = '';
    this.priceBookstartDate = '';
    this.priceBookEndDate = '';
    this.priceBookNotes = '';
    this.projectStartMinDate = '';
    this.projectEndMinDate = '';
    this.disableSubmit = true;
  }

  ngOnInit() {
    this.configuratorDataService.priceBookMode = 'add';
    this.intializeProjectDate();
  }

  intializeProjectDate() {
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    this.projectStartMinDate = new Date(todayYear, todayMonth, todayDate);
    this.projectEndMinDate = new Date(todayYear, todayMonth, todayDate);
  }

  getDateInFormat(date) {
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }
  
  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }

  startDateChanged(startDate) {
    const startDateObj = new Date(startDate);
    const endMinDate = Number(startDateObj.getDate());
    const endMinMonth = startDateObj.getMonth();
    const endMinYear = startDateObj.getFullYear();
    this.projectEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
    this.priceBookEndDate = '';
    this.updateSubmitData('priceBookstartDate', this.getDateInFormat(startDate));
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/pricebook/price-book-list']);
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  convertFile(csv: any) {

    this.fileReaded = csv.target.files[0];

    const reader: FileReader = new FileReader();
    const jsonData = [];
    reader.readAsText(this.fileReaded);

    reader.onload = (e) => {
      const csvVal: string = reader.result;
      const allTextLines = csvVal.split(/\r|\n|\r/);
      const headers = allTextLines[0].split(',');
      const lines = [];
      for (let i = 1; i < allTextLines.length; i++) {
        const result = {};
        const data = allTextLines[i].split(',');
        if (data.length === headers.length) {
          for (let j = 0; j < headers.length; j++) {
            result[headers[j]] = data[j];
            result['relatedIcomsCode'] = result['Related ICOMS Code'];
            result['icomsCodeDescription'] = result['ICOMS Code - Code-Description'];
            result['oldIcomsCodeRi'] = result['Related ICOMS Code'];
          }
          jsonData.push(result);
        }
      }
      this.csvData = jsonData;
      this.updateSubmitData('csvData', jsonData);
    }
  }

  goToPriceBookEditViewPage() {
    this.router.navigate(['plm-work-flow/configurator/pricebook/price-book-view']);
  }

  updateSubmitData(field, value) {
    this.configuratorDataService.priceBookData[field] = value;
    this.enableDisableSubmitButton();
  }

  enableDisableSubmitButton() {
    const inputsArray = [this.priceBookName, this.priceBookstartDate, this.priceBookEndDate, this.priceBookNotes];
    let counts = 0;
    for (let i=0; i<inputsArray.length; i++) {
      if (inputsArray[i] !== '') {
        counts++;
      }
    }
    this.disableSubmit = true;
    if ((counts === inputsArray.length) && (this.configuratorDataService.priceBookData.csvData.length > 0))  {
      this.disableSubmit = false;
    }
  }
 }
