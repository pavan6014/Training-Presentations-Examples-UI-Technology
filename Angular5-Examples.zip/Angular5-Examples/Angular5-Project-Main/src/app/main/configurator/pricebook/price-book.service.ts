import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import {PriceBook } from '../pricebook/price-book';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import {AddUpdatePriceBookAddUpdate} from '../pricebook/price-book';

@Injectable()
export class PriceBookService {

  constructor( private http: HttpClient,
    private appConfigService: AppConfigService) { }


     getBuPricebookData():Observable<any> {
    const buPricebookLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_LIST'] ;
    return this.http
      .get(buPricebookLanding)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const buPricebookLanding = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
    // return this.http
    //   .get(buPricebookLanding)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  getPricebookViewData(priceBookID):Observable<any> {
    const PricebookView = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_VIEW'] + '/' + priceBookID;
    return this.http
      .get(PricebookView)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const PricebookView = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
    // return this.http
    //   .get(PricebookView)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  pricebookEditData(priceBookID):Observable<any> {
    const PricebookView = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_VIEW'] + '/' + priceBookID;
    return this.http
      .get(PricebookView)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const PricebookView = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
    // return this.http
    //   .get(PricebookView)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  submitPriceBook(reqObj): Observable<any> {
    const getPriceBookSaveURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_SAVE'];
    return this.http
      .post(getPriceBookSaveURL, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getPriceBookSaveURL = this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_SAVE']
    // return this.http
    //   .get(getPriceBookSaveURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

//  pricebookDataSave():Observable<any> {
//     const PricebookData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_SAVE'] ;
//     return this.http
//       .get(PricebookData)
//       .map((response: any) => {
//         return response;
//       })
//       .catch(this.handleError);
//     // const PricebookView = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
//     // return this.http
//     //   .get(PricebookView)
//     //   .map((response: Response) => {
//     //     return response;
//     //   })
//     //   .catch(this.handleError);
//   }




  priceBookAddDetails(reqObj):Observable<any>{
        const postAddPriceBookDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_SAVE'];
        return this.http
          .post(postAddPriceBookDetailsURL,  reqObj) 
          .map((response: Response) => {
            return response;
          })
          .catch(this.handleError);
        // const postAddPriceBookDetailsURL = this.appConfigService.urlConstants[
        //     'PLM_ADD_UPDATE_PROJECT_RESPONSE'
        // ];
        // return this.http
        //     .get(postAddPriceBookDetailsURL)
        //     .map((response: Response) => {
        //         return response;
        //     })
        //     .catch(this.handleError);
    }

    getPricebookSiteMaps():Observable<any> {
      console.log("getPricebookSiteMaps::");
      const PricebookSites = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_PRICEBOOK_PRICEBOOK_SITES'];
      return this.http
        .get(PricebookSites)
        .map((response: any) => {
          return response;
        })
        .catch(this.handleError);
    }



private handleError(error: Response) {
  return Observable.throw(error.statusText);
}

}
