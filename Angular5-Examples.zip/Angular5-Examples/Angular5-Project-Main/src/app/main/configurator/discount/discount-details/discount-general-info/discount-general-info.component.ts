import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, Input, OnChanges, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { Discount, GetDiscountListResponse, ModifyDiscountList } from '../../discount-codes-list/discount--codes-list.interface';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { ConfiguratorDiscountDataService } from '../../services/configurator-discount-data.service';
import { DiscountService } from '../discount.service';
import { Router } from '@angular/router';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';

@Component({
    selector: 'plm-discount-general-info',
    templateUrl: './discount-general-info.component.html',
    styleUrls: ['./discount-general-info.component.css'],
    providers: [UtilitiesService, DiscountService]
})
export class DiscountGeneralInfoComponent implements OnInit, OnChanges {

    // @Input() masterData: any;
    // @Input() addEditDiscountSubmitData: any;
    
    @BlockUI() blockUI: NgBlockUI;
    private masterData: any;
    private addEditDiscountSubmitData: any;
    private discountDropDownList = [];
    private parentDiscountCodeDropDownList = [];
    private replacingDiscountCodeDropDownList = [];
    private projectDropDownList = [];
    private reviewBeforeExpirationStatusDropDownList = [];
    private parentDiscountCodeSelectedItems = [];
    private replacingDiscountCodeSelectedItems = [];
    private projectSelectedItems = [];
    private reviewBeforeExpirationStatusSelectedItems = [];
    private addEditMode: Boolean;
    private viewMode: Boolean;
    private singleSelectSettings = {};
    private multiSelectSettings = {};
    private salesStartMinDate: Date;
    private salesEndMinDate: Date;
    private salesCreatedMinDate: Date;
    private salesEndLastChangeMinDate: Date;
    private salesModifiedMinDate: Date;

    private discountSearchList: Discount[];
    private showButton: Boolean;
    private searchDiscountVal: string;
    private discountIDForSearch: number;
    private copyDiscountFormData: any;
    private showCopyDiscountAddButton: boolean;

    constructor(
        private configuratorDiscountDataService: ConfiguratorDiscountDataService,
        private utilitiesService: UtilitiesService, 
        private discountService: DiscountService,
        public dialog: MatDialog,
        private router: Router,
    ) {
        this.addEditMode = false;
        this.viewMode = false;
        this.showButton = false;
        this.searchDiscountVal = '';
        this.masterData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.discountMasterData));
        this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
        this.addEditDiscountSubmitData.startDate = new Date(this.addEditDiscountSubmitData.startDate);
        this.addEditDiscountSubmitData.endDate = new Date(this.addEditDiscountSubmitData.endDate);
        if(this.addEditDiscountSubmitData.endDateLastChange){
            this.addEditDiscountSubmitData.endDateLastChange = new Date(this.addEditDiscountSubmitData.endDateLastChange);
        }
        else{
            this.addEditDiscountSubmitData.endDateLastChange = ''; 
        }
        if ((typeof this.masterData !== 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
            this.updateDropDownList();
            this.updatePageMode();
            this.intializeProjectDate();
            this.initializeSelectedItems();
        }
    }

    ngOnInit() {
        this.singleSelectSettings = {
            singleSelection: true,
            text: 'Select One',
            enableSearchFilter: true
        };
        this.multiSelectSettings = {
            singleSelection: false,
            text: 'Select',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            classes: 'myclass custom-class',
            badgeShowLimit: 3,
            maxHeight: 120
        };
        this.configuratorDiscountDataService.copyDiscountAddEditViewOfferFormData.subscribe(
            text => {
                this.configuratorDiscountDataService.addEditDiscountSubmitData = text;
                this.configuratorDiscountDataService.addEditDiscountSubmitData.discountId = null;
                this.configuratorDiscountDataService.addEditDiscountSubmitData.status = null;
                this.configuratorDiscountDataService.addEditDiscountSubmitData.modifiedDate = '';
                this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
                this.addEditDiscountSubmitData.startDate = new Date(this.addEditDiscountSubmitData.startDate);
                this.addEditDiscountSubmitData.endDate = new Date(this.addEditDiscountSubmitData.endDate);
                if(this.addEditDiscountSubmitData.endDateLastChange){
                    this.addEditDiscountSubmitData.endDateLastChange = new Date(this.addEditDiscountSubmitData.endDateLastChange);
                }
                else{
                    this.addEditDiscountSubmitData.endDateLastChange = ''; 
                }
                this.intializeProjectDate();
                this.initializeSelectedItems();
            }
        );
        this.configuratorDiscountDataService.newProjectList.subscribe(
            text => {
                this.masterData['PROJECT'] = text.projectNamesList[0]['records'];
                this.projectDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'PROJECT');
                this.projectDropDownList.unshift({
                    'id':  '',
                    'name':  'Select One'
                });
                this.projectDropDownList.push({
                    'id':  'addProject',
                    'name':  '< Add a Project >'
                });
                this.projectSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PROJECT', text.projectId);
                this.onItemSelect('projectId', this.projectSelectedItems, 'single');
            }
        );
    }

    ngOnChanges(changes: SimpleChanges) {}

    updatePageMode() {
        if ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'edit'))) {
            this.addEditMode = true;
            this.viewMode = false;
            this.showButton = ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'add')) ? true : false;
        }
        else if (this.configuratorDiscountDataService.addEditViewDiscountMode === 'view') {
            this.addEditMode = false;
            this.viewMode = true;
            this.showButton = false;
        }
    }


    intializeProjectDate() {
        const today = new Date();
        const todayDate = today.getDate();
        const todayMonth = today.getMonth();
        const todayYear = today.getFullYear();
        this.salesStartMinDate = new Date(todayYear, todayMonth, todayDate);
        this.salesEndMinDate = new Date(todayYear, todayMonth, todayDate);
        this.salesCreatedMinDate = new Date(todayYear, todayMonth, todayDate);
        this.salesModifiedMinDate = new Date(todayYear, todayMonth, todayDate);
        this.salesEndLastChangeMinDate = new Date(todayYear, todayMonth, todayDate);
    }

    startDateChanged(key, startDate) {
        const startDateObj = new Date(startDate);
        const endMinDate = Number(startDateObj.getDate()) + 1;
        const endMinMonth = startDateObj.getMonth();
        const endMinYear = startDateObj.getFullYear();
        this.updateSubmitData(key, this.getDateInFormat(startDate));
        if (key === 'startDate') {
            this.salesEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
            this.addEditDiscountSubmitData.endDate = '';
        } else if (key === 'createdDate') {
            this.salesModifiedMinDate = new Date(endMinYear, endMinMonth, endMinDate);
            this.addEditDiscountSubmitData.modifiedDate = '';
        }
    }

    getDateInFormat(date) {
        const dateObj = new Date(date);
        const dateInFormatVal = Number(dateObj.getDate());
        const monthInFormatVal = Number(dateObj.getMonth()) + 1;
        const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
        const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
        const yearInFormat = dateObj.getFullYear();
        return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
    }

    getDateMonthInTwoDigits(value) {
        return (value < 10 ? '0' : '') + value;
    }

    updateDateInFormat(key, date) {
        const dateObj = new Date(date);
        const endMinDate = Number(dateObj.getDate());
        const endMinMonth = dateObj.getMonth();
        const endMinYear = dateObj.getFullYear();
        this.updateSubmitData(key, endMinMonth + '-' + endMinDate + '-' + endMinYear);
    }


    updateDropDownList() {
        this.parentDiscountCodeDropDownList  =  this.utilitiesService.getDropDownListNgSelect(this.masterData,  'campaignCodesList');
        this.parentDiscountCodeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
        this.replacingDiscountCodeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'campaignCodesList');
         this.replacingDiscountCodeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
        this.projectDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'PROJECT');
        this.projectDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
        this.projectDropDownList.push({
            'id':  'addProject',
            'name':  '< Add a Project >'
        });
       
        this.reviewBeforeExpirationStatusDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'REVW_BFR_EXPIRATION_STATUS');
        this.reviewBeforeExpirationStatusDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
        if ((typeof this.masterData !== 'undefined') && (typeof this.addEditDiscountSubmitData !== 'undefined') && (typeof this.configuratorDiscountDataService.addEditViewDiscountMode !== 'undefined') && (this.addEditDiscountSubmitData.discMapDescrBuild !== null)) {
            this.initializeSelectedItems();
        }
    }

    initializeSelectedItems() {
        this.parentDiscountCodeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'campaignCodesList', this.addEditDiscountSubmitData.parentCampaignId);
        this.replacingDiscountCodeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'campaignCodesList', this.addEditDiscountSubmitData.replacingCampaignId);
        this.projectSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PROJECT', this.addEditDiscountSubmitData.projectId);
        this.reviewBeforeExpirationStatusSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'REVW_BFR_EXPIRATION_STATUS', this.addEditDiscountSubmitData.reviewBeforeExpirationStatusId);
    }

    onChange(key: string, item: any, selectType: string){
        if(item.id === 'addProject'){
            this.openAddProject();
        } else {
            this.onItemSelect(key, item, selectType);
        }
    }

    onItemSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onItemDeSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    onDeSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    updateSelectedVal(key: string, items: any, selectType: string) {
        const resultVal = this.getValueBySelectType(items, selectType);
        this.updateSubmitData(key, resultVal);
    }

    getValueBySelectType(item: any, selectType: string) {
        let result;
        if (selectType === 'single') {
            result = this.utilitiesService.getSingleSelectIDNgSelect(item);
        } else {
            result = this.utilitiesService.getMultiSelectID(item)
        }
        return result;
    }

    convertTextAreaContentWithBreaks(field, value) {
        this.updateSubmitData(field, value.split('\n').join('<br />'));
    }

    convertBreakTagToLineBreak(value) {
        const result = '';
        if (value != null) {
            return value.split('<br />').join('\n');
        }
        return value;
    }

    updateSubmitData(field, value) {
        this.configuratorDiscountDataService.addEditDiscountSubmitData[field] = value;
        this.configuratorDiscountDataService.isAddEditDiscountModified = true;
    }

    resetDiscountSearchData() {
        this.discountSearchList =[];    
    }

    searchDiscount(searchDiscountVal) {
        this.blockUI.start('Loading Discount Search List...');
        this.discountService.getCopyDiscountSearch(this.searchDiscountVal)
            .subscribe(
                data => {
                    this.discountSearchList = data.discountSearchList;
                    this.updateDiscountSearchSites(this.discountSearchList);
                    this.blockUI.stop();
                },
                error => {
                    console.log("Error :: " + error);
                    this.blockUI.stop();
                }
            );
    }

    updateDiscountSearchSites(discountSearchList) {
        for(let i=0; i<discountSearchList.length; i++) {
            discountSearchList[i]['markets'] = this.getMarketsList( discountSearchList[i]['site']);
        }
    }

    getMarketsList(site) {
        const siteArray = (site) ? (site.split(',')) : [];
        const result = [];
        for(let i=0; i<this.masterData.MARKETS.length; i++) {
            if (siteArray.indexOf(this.masterData.MARKETS[i]['siteId']) > -1) {
                result.push(this.masterData.MARKETS[i]['siteCodeName']);
            }
        }
        return result.join(', ');
    }
    
    updateDiscountCodeForCopy(offerId) {
        this.discountIDForSearch = offerId;
        this.showCopyOfferAddButtonEnable();
    }

    showCopyOfferAddButtonEnable() {
        if ((!this.discountIDForSearch) || (this.discountIDForSearch === 0) || (typeof this.discountIDForSearch === 'undefined') || (this.discountIDForSearch == null)) {
            this.showCopyDiscountAddButton = false;
        } else {
            this.showCopyDiscountAddButton = true;
        }
    }
    
    triggerCopyDiscount() {
        if (!this.discountIDForSearch) {
            return false;
        }
        this.blockUI.start('Copying Discount...');
        this.discountService.addDiscountSearchForCopy(this.discountIDForSearch)
            .subscribe(
                data => {
                    this.copyDiscountFormData = data.discount;
                    this.copyDiscountFormData.projectCode = this.configuratorDiscountDataService.discountProjectCode;
                    this.updateCopyDiscountFormData();
                    this.configuratorDiscountDataService.modifyCopyDiscountData(this.copyDiscountFormData);
                    this.blockUI.stop();
                },
                error => {
                    console.log("Error :: " + error);
                    this.blockUI.stop();
                }
            );
    }

    updateCopyDiscountFormData() {
        for (let i=0; i<this.copyDiscountFormData.pricingRules.length; i++) {
            this.copyDiscountFormData.pricingRules[i]['codepricingRulesId'] = '';
        }
    }

    openAddProject(): void {
        const dialogRef = this.dialog.open(DiscountGeneralAddProjectComponent, {
            width: 'auto'
        });

        dialogRef.afterClosed().subscribe(result => {
            //this.getProjectOfferTestList();
        });
    }

}

@Component({
    selector: 'plm-discount-general-add-project',
    templateUrl: './discount-general-add-project.html'
  })
  export class DiscountGeneralAddProjectComponent implements OnInit, OnChanges {
    @BlockUI() blockUI: NgBlockUI;
    private projectName: string;
    private addProjectFailed: boolean;
    private noProjectName: boolean;
    constructor(
      public dialogRef: MatDialogRef<DiscountGeneralAddProjectComponent>, 
      private router: Router,
      private discountService: DiscountService,
      private configuratorDiscountDataService: ConfiguratorDiscountDataService,  
      @Inject(MAT_DIALOG_DATA) public data: any) {
        dialogRef.disableClose = true;
        this.projectName = '';
        this.addProjectFailed = false;
        this.noProjectName = false;
       }
  
    ngOnInit() {}
    ngOnChanges(){}
    onNoClick(): void {
      this.dialogRef.close();
    }

    validateProjectName() {
        this.noProjectName = false;
        if (this.projectName !== '') {
            this.noProjectName = true;
        }
    }

    addProjectName() {
        this.blockUI.start('Adding New Project...');
        const reqObj = {
            'projectName': this.projectName
        } ;
        this.discountService.addProjectName(reqObj)
        .subscribe(
            data => {
                this.blockUI.stop();
                if (data.actionStatus === 'SUCCESS') {
                    this.configuratorDiscountDataService.modifyNewProjectList(data);
                    this.dialogRef.close();
                } else if (data.actionStatus === 'FAIL') {
                    this.showAddProjectErrorMessage();
                }
            },
            error => {
              console.log('Error :: ' + error);
              this.showAddProjectErrorMessage();
              this.blockUI.stop();
            }
        );
    }

    showAddProjectErrorMessage() {
        this.addProjectFailed = true;
    }
  
    reloadPage() {
      this.dialogRef.close();
    }
  }