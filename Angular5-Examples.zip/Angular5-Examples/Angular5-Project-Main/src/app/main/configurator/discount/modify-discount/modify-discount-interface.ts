export interface ModifyDiscountInterface {
}


export interface SearchDiscount {
  discountCode: string;
  description: string;
  discountStatus: string;
  discountVersion: string;
  primary: string;
  site: string;
  intakeRequest:string;
  startDate: string;
  endDate: string;
  srvcAgreementRequired:string;
  marketingCode: number;
  amount: number;
  statusId: number;
  discountId: number;
}
