import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { PriceBookService } from '../../pricebook/price-book.service';
import { BusinessCatalogDataService } from '../../../business-catalog/business-catalog-data.service';

@Component({
  selector: 'plm-price-book',
  templateUrl: './price-book.component.html',
  styleUrls: ['./price-book.component.css'],
  providers: [PriceBookService]
})
export class PriceBookComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private searchPriceBook: string;
  private priceBookList: any;
  private buttonDisabled: boolean;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;

  private searchPriceBookList: any;


  private filterByPriceBookName: string;
  private filterByStartDate: string;
  private filterByendDate: string;
  private filterBynote: string;
  private filterBycreatedDate: string;
  private filterBymodifiedDate: string;
  private filterBycreated: string;
  private filterByactive: string;
  private filterByfuture: string;


  private filterByPriceBookNameSearchObj: any;
  private filterByStartDateSearchObj: any;
  private filterByendDateSearchObj: any;
  private filterBynoteSearchObj: any;
  private filterBycreatedDateSearchObj: any;
  private filterBymodifiedDateSearchObj: any;
  private filterBycreatedSearchObj: any;
  private filterByactiveSearchObj: any;
  private filterByfutureSearchObj: any;




  constructor(
    private router: Router,
    private priceBookService: PriceBookService,
    private businessCatalogDataService: BusinessCatalogDataService
  ) {
    this.buttonDisabled = false;
    this.searchPriceBook = '';
    this.priceBookList = [];

    this.searchPriceBookList = {};

    this.filterByPriceBookName = '';
    this.filterByStartDate = '';
    this.filterByendDate = '';
    this.filterBynote = '';
    this.filterBycreatedDate = '';
    this.filterBymodifiedDate = '';
    this.filterBycreated = '';
    this.filterByactive = '';
    this.filterByfuture = '';

    this.filterByPriceBookNameSearchObj = '';
    this.filterByStartDateSearchObj = '';
    this.filterByendDateSearchObj = '';
    this.filterBynoteSearchObj = '';
    this.filterBycreatedDateSearchObj = '';
    this.filterBymodifiedDateSearchObj = '';
    this.filterBycreatedSearchObj = '';
    this.filterByactiveSearchObj = '';
    this.filterByfutureSearchObj = '';
  }

  ngOnInit() {
    //this.getPriceBookList();
  }

  resetPricingBookSearchData() {
    this.priceBookList = [];
  }

  // getPriceBookList() {
  //   this.blockUI.start('Loading Price Books...');
  //   this.priceBookService.getPricingBookList().subscribe(
  //     data => {
  //       this.priceBookList = data.priceBookMasterModelList;
  //       this.updateSearchPriceBookList();
  //       this.initializeFilterContext();
  //       this.searchPriceBookList = this.priceBookList;
  //       this.blockUI.stop();
  //     },
  //     error => {
  //       console.log('Error :: ' + error);
  //       this.blockUI.stop();
  //     }
  //   );
  // }

  getSearchPriceBookDetails() {
    const searchString = this.searchPriceBook;
    this.searchPriceBookList = [];
    for (let i = 0; i < this.priceBookList.length; i++) {
      const searchStringVal = this.priceBookList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchPriceBookList.push(this.priceBookList[i]);
      }
    }
  }

  updateSearchPriceBookList() {
    for (let i = 0; i < this.priceBookList.length; i++) {
      this.priceBookList[i]['searchString'] = this.getPriceBookListConctString(this.priceBookList[i]);
    }
  }

   getPriceBookListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }

  moveToPriceBookView(priceBookID) {
    this.businessCatalogDataService.priceBookId = priceBookID;
    this.router.navigate(['/business-catalog/priceBookView']);
  }

  initializeFilterContext() {
    this.filterByPriceBookNameSearchObj = {
      'priceBookName': {
        'type': 'text',
        'value': this.filterByPriceBookName,
        'matchFullCase': false
      }
    };
    this.filterByStartDateSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterByStartDate,
        'matchFullCase': false
      }
    };
    this.filterByendDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByendDate,
        'matchFullCase': false
      }
    };
    this.filterBynoteSearchObj = {
      'notes': {
        'type': 'text',
        'value': this.filterBynote,
        'matchFullCase': false
      }
    };
    this.filterBycreatedDateSearchObj = {
      'createdDate': {
        'type': 'text',
        'value': this.filterBycreatedDate,
        'matchFullCase': false
      }
    };
    this.filterBymodifiedDateSearchObj = {
      'modifiedDate': {
        'type': 'text',
        'value': this.filterBymodifiedDate,
        'matchFullCase': false
      }
    };
    this.filterBycreatedSearchObj = {
      'created': {
        'type': 'text',
        'value': this.filterBycreated,
        'matchFullCase': false
      }
    };
    this.filterByactiveSearchObj = {
      'active': {
        'type': 'text',
        'value': this.filterByactive,
        'matchFullCase': false
      }
    };
    this.filterByfutureSearchObj = {
      'future': {
        'type': 'text',
        'value': this.filterByfuture,
        'matchFullCase': false
      }
    };
  }
  returnBack(){
    this.router.navigate(['']);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }
redirectTo(url) {
    this.router.navigate([url]);
  }


  //  moveToPriceBookViewEdit(){
  //   this.router.navigate(['/business-catalog/priceBookView']);

  // }
  // moveToCreateView(){

  //   this.router.navigate(['business-catalog/createPriceBook']);

  // }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

}

