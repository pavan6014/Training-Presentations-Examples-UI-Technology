import { Injectable } from '@angular/core';
import {Subject} from "rxjs/Subject";

@Injectable()
export class ConfiguratorDiscountDataService {
  public discountProjectCode: string;
  public addEditViewDiscountCode: String;
  public addEditViewDiscountMode: String;
  public addEditDiscountSubmitData: any;
  public isAddEditDiscountModified: Boolean;
  public discountMasterData: any;
  public pricingRules: any;
  public discountFileUpload: any;
  public payPercentToNormalRate: any;
  public preReqOfferTemplate: any;
  public isSubmitted: Boolean;
  public projectStatus: string;
  public projectType: string;
  public teCodes: any;
  public marketIDsVal: string;
  public backURL: string;
  public modifyDiscountList: any;
  public isModifyDiscount: Boolean;
  public projectCode: string;
  public isFromBusinessCatalog: string;
  public isFromTechnologySystems: string;
  public discountListForSavePop: string;
  
  public descriptionBuilderAmount: Subject<string>  = new Subject<string>();
  public marketList: Subject<number[]>  = new Subject<number[]>();
  public pricingMethod: Subject<number>  = new Subject<number>();
  public marketingIDs: Subject<string>  = new Subject<string>();
  public percentToNormalRate: Subject<number>  = new Subject<number>();
  public copyDiscountAddEditViewOfferFormData: Subject<any>  = new Subject<any>();
  public monthVal: Subject<any>  = new Subject<any>();

  public prereqDiscountLongInstruction: Subject<any>  = new Subject<any>();
  
  public prereqDiscountInstallA: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallB: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallCAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallCAll: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallD: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallE: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallFAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountInstallFAll: Subject<any>  = new Subject<any>();

  public prereqDiscountCurrentA: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentB: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentCAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentCAll: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentD: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentE: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentFAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountCurrentFAll: Subject<any>  = new Subject<any>();
  
  public prereqDiscountRetentionA: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionB: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionCAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionCAll: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionD: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionE: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionFAtleast: Subject<any>  = new Subject<any>();
  public prereqDiscountRetentionFAll: Subject<any>  = new Subject<any>();

  public prereqDiscountSAInstallAIfOne: Subject<any>  = new Subject<any>();
  public prereqDiscountSAInstallB: Subject<any>  = new Subject<any>();
  public prereqDiscountSAInstallD: Subject<any>  = new Subject<any>();
  public prereqDiscountSARetentionAIfOne: Subject<any>  = new Subject<any>();
  public prereqDiscountSARetentionDIfAny: Subject<any>  = new Subject<any>();

  public prereqDiscountTECodeIncludeIfOne: Subject<any>  = new Subject<any>();
  public prereqDiscountTECodeExcludeIfAny: Subject<any>  = new Subject<any>();

  public prereqDiscountCodeNoOfDays: Subject<any>  = new Subject<any>();
  public prereqDiscountCodeAIncludeIfOne: Subject<any>  = new Subject<any>();
  public prereqDiscountCodeDExcludeIfAny: Subject<any>  = new Subject<any>();

  public prereqDiscountOtherInstructions: Subject<any>  = new Subject<any>();

  public newProjectList: Subject<any>  = new Subject<any>();

  public modifyDescriptionBuilderAmount(value) {
    this.descriptionBuilderAmount.next(value);
}

  public modifyNewProjectList(value) {
      this.newProjectList.next(value);
  }
    
  public modifyMarketList(value) {
      this.marketList.next(value);
  }
  
  public modifyPricingMethod(value) {
      this.pricingMethod.next(value);
  }
  
  public modifyMarketingIDs(value) {
      this.marketingIDs.next(value);
  }

  public modifyPercentToNormalRate(value) {
      this.percentToNormalRate.next(value);
  }
  
  public modifyCopyDiscountData(value) {
      this.copyDiscountAddEditViewOfferFormData.next(value);
  }
    
  public modifyMonthVal(value) {
    this.monthVal.next(value);
  }

  public modifyPrereqDiscountLongInstruction(value) {
    this.prereqDiscountLongInstruction.next(value);
  }
  public modifyPrereqDiscountInstallA(value) {
    this.prereqDiscountInstallA.next(value);
  }
  public modifyPrereqDiscountInstallB(value) {
    this.prereqDiscountInstallB.next(value);
  }
  public modifyPrereqDiscountInstallCAtleast(value) {
    this.prereqDiscountInstallCAtleast.next(value);
  }
  public modifyPrereqDiscountInstallCAll(value) {
    this.prereqDiscountInstallCAll.next(value);
  }
  public modifyPrereqDiscountInstallD(value) {
    this.prereqDiscountInstallD.next(value);
  }
  public modifyPrereqDiscountInstallE(value) {
    this.prereqDiscountInstallE.next(value);
  }
  public modifyPrereqDiscountInstallFAtleast(value) {
    this.prereqDiscountInstallFAtleast.next(value);
  }
  public modifyPrereqDiscountInstallFAll(value) {
    this.prereqDiscountInstallFAll.next(value);
  }
  public modifyPrereqDiscountCurrentA(value) {
    this.prereqDiscountCurrentA.next(value);
  }
  public modifyPrereqDiscountCurrentB(value) {
    this.prereqDiscountCurrentB.next(value);
  }
  public modifyPrereqDiscountCurrentCAtleast(value) {
    this.prereqDiscountCurrentCAtleast.next(value);
  }
  public modifyPrereqDiscountCurrentCAll(value) {
    this.prereqDiscountCurrentCAll.next(value);
  }
  public modifyPrereqDiscountCurrentD(value) {
    this.prereqDiscountCurrentD.next(value);
  }
  public modifyPrereqDiscountCurrentE(value) {
    this.prereqDiscountCurrentE.next(value);
  }
  public modifyPrereqDiscountCurrentFAtleast(value) {
    this.prereqDiscountCurrentFAtleast.next(value);
  }
  public modifyPrereqDiscountCurrentFAll(value) {
    this.prereqDiscountCurrentFAll.next(value);
  }
  public modifyPrereqDiscountRetentionA(value) {
    this.prereqDiscountRetentionA.next(value);
  }
  public modifyPrereqDiscountRetentionB(value) {
    this.prereqDiscountRetentionB.next(value);
  }
  public modifyPrereqDiscountRetentionCAtleast(value) {
    this.prereqDiscountRetentionCAtleast.next(value);
  }
  public modifyPrereqDiscountRetentionCAll(value) {
    this.prereqDiscountRetentionCAll.next(value);
  }
  public modifyPrereqDiscountRetentionD(value) {
    this.prereqDiscountRetentionD.next(value);
  }
  public modifyPrereqDiscountRetentionE(value) {
    this.prereqDiscountRetentionE.next(value);
  }
  public modifyPrereqDiscountRetentionFAtleast(value) {
    this.prereqDiscountRetentionFAtleast.next(value);
  }
  public modifyPrereqDiscountRetentionFAll(value) {
    this.prereqDiscountRetentionFAll.next(value);
  }

  public modifyPrereqDiscountSAInstallAIfOne(value) {
    this.prereqDiscountSAInstallAIfOne.next(value);
  }
  public modifyPrereqDiscountSAInstallB(value) {
    this.prereqDiscountSAInstallB.next(value);
  }
  public modifyPrereqDiscountSAInstallD(value) {
    this.prereqDiscountSAInstallD.next(value);
  }
  public modifyPrereqDiscountSARetentionAIfOne(value) {
    this.prereqDiscountSARetentionAIfOne.next(value);
  }
  public modifyPrereqDiscountSARetentionDIfAny(value) {
    this.prereqDiscountSARetentionDIfAny.next(value);
  }

  public modifyPrereqDiscountTECodeIncludeIfOne(value) {
    this.prereqDiscountTECodeIncludeIfOne.next(value);
  }
  public modifyPrereqDiscountTECodeExcludeIfAny(value) {
    this.prereqDiscountTECodeExcludeIfAny.next(value);
  }

  public modifyPrereqDiscountCodeNoOfDays(value) {
    this.prereqDiscountCodeNoOfDays.next(value);
  }
  public modifyPrereqDiscountCodeAIncludeIfOne(value) {
    this.prereqDiscountCodeAIncludeIfOne.next(value);
  }
  public modifyPrereqDiscountCodeDExcludeIfAny(value) {
    this.prereqDiscountCodeDExcludeIfAny.next(value);
  }

  public modifyPrereqDiscountOtherInstructions(value) {
    this.prereqDiscountOtherInstructions.next(value);
  }

  constructor() { }

}