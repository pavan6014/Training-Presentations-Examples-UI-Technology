import { Component, Input, OnChanges, OnInit, SimpleChange, SimpleChanges } from '@angular/core';

import { ConfiguratorDiscountDataService } from '../../services/configurator-discount-data.service';
import { DiscountService } from '../discount.service';
import { GetCampaignCodePricingMethod } from '../discount-interface';

@Component({
  selector: 'plm-campaign-code-creation-pricing-method',
  templateUrl: './campaign-code-creation-pricing-method.component.html',
  styleUrls: ['./campaign-code-creation-pricing-method.component.css']
})
export class CampaignCodeCreationPricingMethodComponent implements OnInit {

  // @Input() masterData: any;
  // @Input() addEditDiscountSubmitData: any;

  private masterData: any;
  private addEditDiscountSubmitData: any;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private Ashow: boolean;
  private Bshow: boolean;
  private Cshow: boolean;
  private Dshow: boolean;
  private Eshow: boolean;
  private Fshow: boolean;
  private Gshow: boolean;
  private Hshow: boolean;
  private Ishow: boolean;
  private Jshow: boolean;
  private pricingMethods: string[];
  private formLoaded: boolean;

  constructor(private configuratorDiscountDataService: ConfiguratorDiscountDataService) {
    this.addEditMode = false;
    this.viewMode = false;
    this.pricingMethods = [];
    this.masterData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.discountMasterData));
    this.initializePricingMethods();
    this.formLoaded = false;
    this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
    // this.updateMethodAttributesForPriceMethod();
    if ((typeof this.masterData != 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
      this.onChange(this.addEditDiscountSubmitData.discMapPriceMethod.methodId);
      this.formLoaded = true;
    }
    this.configuratorDiscountDataService.payPercentToNormalRate = 0;
  }

  ngOnInit() {
    this.configuratorDiscountDataService.copyDiscountAddEditViewOfferFormData.subscribe(
      text => {
        this.configuratorDiscountDataService.addEditDiscountSubmitData = text;
        this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
        this.configuratorDiscountDataService.payPercentToNormalRate = 0;
        this.onChange(this.addEditDiscountSubmitData.discMapPriceMethod.methodId);
        this.formLoaded = true;
      }
    );
  }

  // ngOnChanges(changes: SimpleChanges) {
    // for (let propName in changes) {
    //   let change = changes[propName];
    //   if (propName === 'masterData') {
    //     this.masterData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
    //   } else if (propName === 'addEditDiscountSubmitData') {
    //     this.addEditDiscountSubmitData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
    //   }
    // }
    // if ((typeof this.masterData != 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
    //   this.onChange(this.addEditDiscountSubmitData.discMapPriceMethod.priceMethodId);
    // }
  // }

  // updateMethodAttributesForPriceMethod() {
  //   if ((this.addEditDiscountSubmitData.discMapPriceMethod == null) || (this.addEditDiscountSubmitData.discMapPriceMethod.length == 0) || (typeof this.addEditDiscountSubmitData.discMapPriceMethod == 'undefined')) {

  //   }
  // }

  initializePricingMethods() {
    for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
      this.pricingMethods.push(this.masterData.priceMethodMasterDataList[i]['method']);
      this.masterData.priceMethodMasterDataList[i]['showVal'] = false;
      this.updateQuestionSec(this.masterData.priceMethodMasterDataList[i]['discPriceMethodMasterDetailList']);
    }
    this.updatePageMode();
  }

  updatePageMode() {
    if ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit'))) {
      this.addEditMode = true;
      this.viewMode = false;
    }
    else if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'view') {
      this.addEditMode = false;
      this.viewMode = true;
    }
  }

  updateQuestionSec(quesArray) {
    for (let i = 0; i < quesArray.length; i++) {
      quesArray[i]['value'] = '';
    }
  }

  onChange(selectedValue) {
    this.updateSubmitData('methodId', selectedValue);
    if (selectedValue == null) {
      this.showAllSections();
      for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
        this.disablePricingMethodQuestions(i);
      }
    } else {
      this.hideAllSections();
      this.updateRowShowVal(selectedValue);
    }
  }

  updateRowShowVal(selectedValue) {
    for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
      this.disablePricingMethodQuestions(i);
      if ((this.addEditDiscountSubmitData.discMapPriceMethod.methodId !== null) && (this.addEditDiscountSubmitData.discMapPriceMethod.methodId == this.masterData.priceMethodMasterDataList[i]['discPriceMethodMasterId'])) {
        // this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes = [];
        let resultObj = [];
        
        for (let j = 0; j < this.masterData.priceMethodMasterDataList[i]['discPriceMethodMasterDetailList'].length; j++) {
          let methodAttrValue = this.getMethodAttributeValues(j, this.masterData.priceMethodMasterDataList[i]['discPriceMethodMasterDetailList'][j]['inputType']);
          this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterDetailList[j].value = methodAttrValue;
          let result = {
            'methodAttrId': this.masterData.priceMethodMasterDataList[i]['discPriceMethodMasterDetailList'][j]['methodId'],
            'methodAttrValue': methodAttrValue
          };
          resultObj.push(result);
          // this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.push(result);
          // this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes = resultObj;
        }
        this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes = resultObj;
        this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes = resultObj;
      }

      if (Number(this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterId) === Number(selectedValue)) {
        this.masterData.priceMethodMasterDataList[i]['showVal'] = true;
        this.updatePricingMethodAttributes(selectedValue, i);
      }
      this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod = this.addEditDiscountSubmitData.discMapPriceMethod;
      // this.updatePricingMethodChangesForSubmit(i);
    }
    this.testForDMethodType();
  }

  // updatePricingMethodChangesForSubmit(index) {
  //   for (let i = 0; i < this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList.length; i++) {
  //     if (this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrId'] === this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i]['methodId']) {
  //       this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'] = this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i]['value'];
  //       this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'] = this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i]['value'];
  //     }
  //   }
  // }

  
  testForDMethodType() {
    if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodId === 300) {
      for (let i=0; i<this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.length; i++) {
        if (
          (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrId'] === 5) && 
          (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'] !== '')
        ) {
          this.configuratorDiscountDataService.payPercentToNormalRate = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'];
          this.configuratorDiscountDataService.modifyPercentToNormalRate(this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue']);
        }
      }
    } else {
      return;
    }
  }

  getMethodAttributeValues(index, inputType) {
    if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[index]) {
      return this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[index]['methodAttrValue'];
    } else {
      return this.getDefaultValuesForInputType(inputType);
    }
  }

  getDefaultValuesForInputType(inputType) {
     if (inputType == 'checkbox') {
       return true;
     } else {
        return '';
     }
  }

  updatePricingMethodAttributes(selectedValue, index) {
    if (this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.length > 0) {
      // this.updatePricingMethodQuestions(index);
      this.configuratorDiscountDataService.modifyPricingMethod(selectedValue);
    }
  }

  // updatePricingMethodQuestions(index) {
  //   for (let i = 0; i < this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList.length; i++) {
  //     // if (this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].methodId == this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i].methodAttrId) {
  //     if (this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].inputType == 'checkbox') {
  //       this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].value = true;
  //     } else {
  //       this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].value = (this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]) ? (this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i].methodAttrValue) : '';
  //     }
  //     // }
  //   }
  // }


  disablePricingMethodQuestions(index) {
    for (let i = 0; i < this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList.length; i++) {
      // if (this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].methodId != this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i].methodAttrId) {
      if (this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].inputType === 'checkbox') {
        this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].value = false;
      } else {
        this.masterData.priceMethodMasterDataList[index].discPriceMethodMasterDetailList[i].value = '';
      }
      // }
    }
  }

  hideAllSections() {
    for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
      this.masterData.priceMethodMasterDataList[i]['showVal'] = false;
    }
  }


  showAllSections() {
    for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
      this.masterData.priceMethodMasterDataList[i]['showVal'] = true;
    }
  }

  // getSelectedValueObj(key) {
  //   let result = '';
  //   for (let i = 0; i < this.masterData['DISC_PRICE_METHOD_MASTER'].length; i++) {
  //     if (this.masterData['DISC_PRICE_METHOD_MASTER'][i]['key'] == key) {
  //       result = this.masterData['DISC_PRICE_METHOD_MASTER'][i]['method'];
  //     }
  //   }
  //   return result;
  // }

  // updateMethods(discPriceMethodMasterId) {
  //   for (let i=0; i<this.masterData.priceMethodMasterDataList.length; i++) {
  //     if (this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterId === discPriceMethodMasterId) {
  //       this.updateMethodsQuestions(this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterDetailList);
  //     }
  //   }
  // }

  // updateMethodsQuestions(discPriceMethodMasterDetailList) {
  //   for (let i=0; i<discPriceMethodMasterDetailList.length; i++) {
  //     let quesValue = (discPriceMethodMasterDetailList.inputType == 'checkbox') ? ('Y') : ('');
  //     this.updatePriceMethod(i, discPriceMethodMasterDetailList.methodId, discPriceMethodMasterDetailList.value, discPriceMethodMasterDetailList.inputType);
  //   }
  // }

  updatePriceMethod(j, methodId, methodValue, typeVal) {
    let methodAttrValue = '';
    if (typeVal == 'checkbox') {
      methodAttrValue = (methodValue) ? 'Y' : 'N';
    } else {
      methodAttrValue = methodValue;
    }
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod['methodAttributes'][j] = {
      'methodAttrId': '',
      'methodAttrValue': ''
    };
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod['methodAttributes'][j]['methodAttrId'] = methodId;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod['methodAttributes'][j]['methodAttrValue'] = methodAttrValue;
    this.configuratorDiscountDataService.isAddEditDiscountModified = true;
    if (methodId == 5) {
      this.configuratorDiscountDataService.payPercentToNormalRate = methodAttrValue;
      this.configuratorDiscountDataService.modifyPercentToNormalRate(methodAttrValue);
    }
    this.addEditDiscountSubmitData.discMapPriceMethod = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod;
  }

  updateSubmitData(field, value) {
    this.addEditDiscountSubmitData.discMapPriceMethod[field] = value;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod[field] = value;
    // this.updateMethods(value);
    this.configuratorDiscountDataService.isAddEditDiscountModified = true;
    this.configuratorDiscountDataService.modifyPricingMethod(value);
  }

  // getDisplayValue(discPriceMethodMasterData, methodId, inputType, index){
  //   let result: any;
  //   let methodAttributesIDArray = this.getMethodAttributesMethodIDS();
  //   if ((this.addEditDiscountSubmitData.discMapPriceMethod.methodId == discPriceMethodMasterData.discPriceMethodMasterId) && (methodAttributesIDArray.indexOf(methodId) > -1)) { 
  //     // for (let i=0; i<this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.length; i++) {
  //       // let methodObj: any =  this.getMethodObj(this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i], discPriceMethodMasterData.discPriceMethodMasterDetailList);
  //       if (inputType == 'checkbox') {
  //         result = (this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[index].methodAttrValue == 'Y') ? true : false;
  //         // return result;
  //       } else {
  //         result = this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[index].methodAttrValue;
  //         // return result;
  //       }
  //     //   break;
  //     // }
  //   }
  //   // let priceMethodMasterDataList = this.getPriceMethodMasterDataList(discPriceMethodMasterId);
  //   // let methodObj = this.getMethodObj(priceMethodMasterDataList, methodId);
  //   return result;
  // }

  // getMethodAttributesMethodIDS() {
  //   let result = [];
  //   for (let i=0; i<this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.length; i++) {
  //     result.push(this.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i].methodAttrId);
  //   }
  //   return result;
  // }

  // getMethodObj(methodAttribute, discPriceMethodMasterDetailList) {
  //   let result = '';
  //   for (let i=0; i<discPriceMethodMasterDetailList.length; i++) {
  //     if (discPriceMethodMasterDetailList[i].methodId == methodAttribute.methodAttrId) {
  //       result = discPriceMethodMasterDetailList[i];
  //       break;
  //     }
  //   }
  //   return result;
  // }

  // getPriceMethodMasterDataList(discPriceMethodMasterId) {
  //   let result = '';
  //   for (let i=0; i<this.masterData.priceMethodMasterDataList.length; i++) {
  //     if (this.addEditDiscountSubmitData.discMapPriceMethod.methodId == this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterId) {
  //       result = this.masterData.priceMethodMasterDataList[i];
  //     }
  //   }
  //   return result;
  // }


  isCheckbox(discPriceMethodMasterDetailList, methodId) {
    let result = false;
    for (let i = 0; i < discPriceMethodMasterDetailList.length; i++) {
      if (discPriceMethodMasterDetailList[i].methodId == methodId) {
        result = (discPriceMethodMasterDetailList[i].inputType == 'checkbox') ? true : false;
      }
    }
    return result;
  }

  // getCheckboxValueInUserData(){
  //   let result = '';

  // }

  isOneColumn(value) {
    return (value == 1);
  }

  isTwoColumn(value) {
    return (value == 2);
  }

  isThreeColumn(value) {
    return (value == 3);
  }

  isFourColumn(value) {
    return (value == 4);
  }

  isCheckBox(value) {
    return (value == 'checkbox');
  }

  isTextBox(value) {
    return (value == 'text');
  }

  isDateBox(value) {
    return (value == 'date');
  }

}
