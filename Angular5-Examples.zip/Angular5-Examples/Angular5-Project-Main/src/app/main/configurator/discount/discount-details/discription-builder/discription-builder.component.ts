import { Component, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import { ConfiguratorDiscountDataService } from '../../services/configurator-discount-data.service';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-discription-builder',
  templateUrl: './discription-builder.component.html',
  styleUrls: ['./discription-builder.component.css'],
  providers: [UtilitiesService]
})
export class DiscriptionBuilderComponent implements OnInit, OnChanges {
  // @Input() masterData: any;
  // @Input() addEditDiscountSubmitData: any;

  private masterData: any;
  private addEditDiscountSubmitData: any;
  
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private discountTypeDropDownList = [];
  private discountTypeSelectedItems = [];
  private videoTiersDropDownList = [];
  private videoTiersSelectedItems = [];
  private dataTiersDropDownList = [];
  private dataTiersSelectedItems = [];
  private phoneTiersDropDownList = [];
  private phoneTiersSelectedItems = [];
  private homelifeTiersDropDownList = [];
  private homelifeTiersSelectedItems = [];
  private ancillaryFeaturesDropDownList = [];
  private ancillaryFeaturesSelectedItems = [];
  private equipmentDropDownList = [];
  private equipmentSelectedItems = [];
  private installDropDownList = [];
  private installSelectedItems = [];
  private addEditMode: boolean;
  private viewMode: boolean;
  private showDollar: boolean;
  private showPercentage: boolean;
  private showOff: boolean;
  private monthVal: string;
  private formula: string;

  constructor(
    private configuratorDiscountDataService: ConfiguratorDiscountDataService, 
    private utilitiesService: UtilitiesService
  ) {
    this.addEditMode = true;
    this.viewMode = false;
    this.showDollar = false;
    this.showPercentage = false;
    this.showOff = false;
    this.formula = '';
    this.monthVal = '0';
    this.masterData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.discountMasterData));
    this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
	  this.monthVal = (this.addEditDiscountSubmitData.discMappingEntity.primaryDuration) ? this.addEditDiscountSubmitData.discMappingEntity.primaryDuration : '0'; 
    if ((typeof this.masterData !== 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
      this.updateDropDownList();
      this.updatePageMode();
      this.initializeSelectedItems();
    }
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: 'Select One',
      enableSearchFilter: true
    }; 
    this.multiSelectSettings = {
        singleSelection: false,
        text: 'Select',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: true,
        classes: 'myclass custom-class',
        badgeShowLimit: 3,
        maxHeight: 120
    };
    this.configuratorDiscountDataService.copyDiscountAddEditViewOfferFormData.subscribe(
      text => {
        this.configuratorDiscountDataService.addEditDiscountSubmitData = text;
        this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
        this.initializeSelectedItems();
      }
    ); 
    this.configuratorDiscountDataService.monthVal.subscribe(
      text => {
        this.monthVal = text;
        this.updateFormula();
      }
    ); 
    if (!this.viewMode) {
      this.validateIsModifyDiscount();
    }  
  }

  ngOnChanges(changes: SimpleChanges) {
    // for (let propName in changes) {
    //   let change = changes[propName];
    //   if (propName === 'masterData') {
    //     this.masterData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
    //   } else if (propName === 'addEditDiscountSubmitData') {
    //     this.addEditDiscountSubmitData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
    //   }
    // }
    
    // if ((typeof this.masterData != 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
    //   this.updateDropDownList();
    //   this.updatePageMode();
    //   this.initializeSelectedItems();
    // }
  }


  updateDropDownList() {
    this.discountTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'DISCOUNT_TYPE');
     this.discountTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.videoTiersDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'VIDEO_TIERS');
    this.dataTiersDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'DATA_TIERS');
    this.phoneTiersDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'PHONE_TIERS');
    this.homelifeTiersDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'HOMELIFE_TIERS');
    this.ancillaryFeaturesDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'ANCILLARY');
    this.equipmentDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'EQUIPMENT');
    this.installDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'INSTALL');
    if ((typeof this.masterData !== 'undefined') && (typeof this.addEditDiscountSubmitData !== 'undefined') && (typeof this.configuratorDiscountDataService.addEditViewDiscountMode !== 'undefined') && (this.addEditDiscountSubmitData.discMapDescrBuild !== null)) {
      this.initializeSelectedItems();
    }
  }

  initializeSelectedItems() {
    this.discountTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'DISCOUNT_TYPE', this.addEditDiscountSubmitData.discMapDescrBuild.discountTypeId);
    this.videoTiersSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'VIDEO_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.videoTierIds);
    this.dataTiersSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'DATA_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.dataTierIds);
    this.phoneTiersSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PHONE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.phoneTierIds);
    this.homelifeTiersSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'HOMELIFE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.hmLifeTierIds);
    this.ancillaryFeaturesSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'ANCILLARY', this.addEditDiscountSubmitData.discMapDescrBuild.ancillaryFeatureIds);
    this.equipmentSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'EQUIPMENT', this.addEditDiscountSubmitData.discMapDescrBuild.equipmentIds);
    this.installSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'INSTALL', this.addEditDiscountSubmitData.discMapDescrBuild.installIds);
    if (this.discountTypeSelectedItems) {
      this.modifyDiscountType(this.discountTypeSelectedItems);
    }
  }

  updatePageMode() {
    this.addEditMode = false;
    this.viewMode = false;
    if ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit'))) {
      this.addEditMode = true;
      this.viewMode = false;
    } else if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'view') {
      this.addEditMode = false;
      this.viewMode = true;
    }
  }

  updateAmount(field, value) {
    this.addEditDiscountSubmitData.discMapDescrBuild[field] = value;
    this.updateSubmitData(field, value);
  }

  updateSubmitData(field, value) {
    this.addEditDiscountSubmitData.discMapDescrBuild[field] = value;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild[field] = value;
    this.configuratorDiscountDataService.isAddEditDiscountModified = true;
    if (field === 'amount') {
      this.configuratorDiscountDataService.modifyDescriptionBuilderAmount(value);
    }
    this.updateFormula();
  }

  validateIsModifyDiscount() {
    if (this.configuratorDiscountDataService.isModifyDiscount) {
      this.addEditMode = false;
      this.viewMode = true;
    } else {
      this.addEditMode = true;
      this.viewMode = false;
    }
  }

  triggerHeaderClose() {
    // alert('Closed');
  }
  
  triggerHeaderOpen() {
    // alert('Opened');
  }
  
  onItemSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
    this.modifyDiscountType(item);
  }

onItemDeSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
}

onSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
}

onDeSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
}

updateSelectedVal(key: string, items: any, selectType: string){
    let resultVal = this.getValueBySelectType(items, selectType);
    this.updateSubmitData(key, resultVal);
}

getValueBySelectType(item: any, selectType: string) {
    let result;
    if (selectType === 'single') {
        result = this.utilitiesService.getSingleSelectIDNgSelect(item);
    } else {
        result = this.utilitiesService.getMultiSelectID(item)
    }
    return result;
}

  showTypeVal(index, objLength) {
    return ((parseInt(index)+1) === objLength);
  }

  modifyDiscountType(discountTypeSelectedItems){
    this.showDollar = false;
    this.showPercentage = false;
    this.showOff = false;
    const discountType = discountTypeSelectedItems.name;
    switch(discountType) {
      case 'Fixed Price':
        this.showDollar = true;
        break;
      case 'Dollars Off':
        this.showDollar = true;
        this.showOff = true;
        break;
      case 'Percent Off':
        this.showPercentage = true;
        this.showOff = true;
        break;
      case 'Other':
        break;
    }
    this.updateFormula();
  }

  updateFormula() {
    let result = '';
    result += this.addDollar();
    result += ((typeof this.addEditDiscountSubmitData.discMapDescrBuild.amount !== 'undefined') && (this.addEditDiscountSubmitData.discMapDescrBuild.amount !== null) && (this.addEditDiscountSubmitData.discMapDescrBuild.amount !== '')) ? (this.addEditDiscountSubmitData.discMapDescrBuild.amount) : '';
    result += this.addPercentage();
    result += this.addOff();
    result += this.addVideoTiers();
    result += this.addAncillary();
    result += this.addEquipment();
    result += this.addDataTier();
    result += this.addPhoneTier();
    result += this.addHomeLifeTier();
    result += ' for '+ this.monthVal +' mo. ';
    result += this.addInstall();
    this.formula = result;
    this.addEditDiscountSubmitData.discMapDescrBuild['formula'] = result;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild['formula'] = result;
  }

  addDollar() {
    let result = '';
    if (this.showDollar) {
      result += '$';
    } else {
      result += '';
    }
    return result;
  }

  addPercentage() {
    let result = '';
    if (this.showPercentage) {
      result += '%';
    } else {
      result += '';
    }
    return result;
  }
  
  addOff() {
    let result = '';
    if (this.showOff) {
      result += ' off ';
    } else {
      result += '';
    }
    return result;
  }

  addVideoTiers() {
    let result = ' ';
    const videoTier = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'VIDEO_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.videoTierIds);
    for (let i=0; i<videoTier.length; i++) {
      result += videoTier[i].name;
      if (this.showTypeVal(i,this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'VIDEO_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.videoTierIds).length)) {
        result += ' Video; ';
      } else {
        result += '; ';
      }
    }
    return result;
  }
  
  addAncillary() {
    let result = ' ';
    const ancillaryFeature = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'ANCILLARY', this.addEditDiscountSubmitData.discMapDescrBuild.ancillaryFeatureIds);
    for (let i=0; i<ancillaryFeature.length; i++) {
      result += ancillaryFeature[i].name + ' ;';
    }
    return result;
  }

  addEquipment() {
    let result = ' ';
    const equipmentObj = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'EQUIPMENT', this.addEditDiscountSubmitData.discMapDescrBuild.equipmentIds);
    for (let i=0; i<equipmentObj.length; i++) {
      result += equipmentObj[i].name + ' ;';
    }
    return result;
  }

  addDataTier() {
    let result = ' ';
    const dataTier = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'DATA_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.dataTierIds);
    for (let i=0; i<dataTier.length; i++) {
      result += dataTier[i].name;
      if (this.showTypeVal(i,this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'DATA_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.dataTierIds).length)) {
        result += ' Data; ';
      } else {
        result += '; ';
      }
    }
    return result;
  }
  
  addPhoneTier() {
    let result = ' ';
    const phoneTier = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PHONE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.phoneTierIds);
    for (let i=0; i<phoneTier.length; i++) {
      result += phoneTier[i].name;
      if (this.showTypeVal(i,this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PHONE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.phoneTierIds).length)) {
        result += ' Phone; ';
      } else {
        result += '; ';
      }
    }
    return result;
  }
   
  addHomeLifeTier() {
    let result = ' ';
    const homeLifeTier = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'HOMELIFE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.hmLifeTierIds);
    for (let i=0; i<homeLifeTier.length; i++) {
      result += homeLifeTier[i].name+' ; ';
      // if (this.showTypeVal(i,this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'HOMELIFE_TIERS', this.addEditDiscountSubmitData.discMapDescrBuild.hmLifeTierIds).length)) {
      //   result += 'Phone; ';
      // } else {
      //   result += '; ';
      // }
    }
    return result;
  }
    
  addInstall() {
    let result = '';
    const install = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'INSTALL', this.addEditDiscountSubmitData.discMapDescrBuild.installIds);
    if (install.length > 0) {
      result += ' with ';
    }
    for (let i=0; i<install.length; i++) {
      result += install[i].name;
      if (this.showTypeVal(i,this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'INSTALL', this.addEditDiscountSubmitData.discMapDescrBuild.installIds).length)) {
        result += ' Install; ';
      } else {
        result += '; ';
      }
    }
    return result;
  }

}
