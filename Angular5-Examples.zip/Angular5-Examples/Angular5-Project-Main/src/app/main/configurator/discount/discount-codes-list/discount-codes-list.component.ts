import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { RequestorDataService } from '../../../requestor/services/requestor-data.service';
import { GetDiscountListResponse, Discount, ModifyDiscountList } from './discount--codes-list.interface';
import { DiscountCodesListService } from './discount-codes-list.service';
import { ConfiguratorDiscountDataService } from '../services/configurator-discount-data.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { RequestorService } from '../../../requestor/services/requestor.service';
import { UtilitiesService } from '../../../../shared/services/utilities.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'plm-discount-codes-list',
  templateUrl: './discount-codes-list.component.html',
  styleUrls: ['./discount-codes-list.component.css'],
  providers: [DiscountCodesListService, RequestorDataService, RequestorService, UtilitiesService, DatePipe]
})
export class DiscountCodesListComponent implements OnInit {

  @Output() statusUpdated: EventEmitter<boolean> = new EventEmitter<boolean>();
  @BlockUI() blockUI: NgBlockUI;

  private discountCodeist: Discount[];
  private projectCode: string;
  private discountList: Boolean[];
  private discountListForRelease: number[];
  private discountsSelected: Boolean;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private rowSelected: boolean;

  private filterBydiscountID: string;
  private filterBydiscountCode: string;
  private filterByversion: string;
  private filterBystartDate: string;
  private filterByendDate: string;
  private filterBycreatedDate: string;
  private filterBystatus: string;
  private filterByrequestDescription: string;

  private filterBydiscountIDSearchObj: any;
  private filterBydiscountCodeSearchObj: any;
  private filterByversionSearchObj: any;
  private filterBystartDateSearchObj: any;
  private filterByendDateSearchObj: any;
  private filterBycreatedDateSearchObj: any;
  private filterBystatusSearchObj: any;
  private filterByrequestDescriptionSearchObj: any;
  private updateDiscountListChecked: boolean;
  private sendNotificationFail: boolean;
  private errorDraft: boolean;

  private addEditIntakeRequestMasterData: any;
  private projectData: any;
  private selectedAll: boolean;

  constructor(
    private discountListService: DiscountCodesListService,
    private router: Router,
    private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    public dialog: MatDialog,
    private requestorDataService: RequestorDataService,
    private requestorService: RequestorService,
    private utilitiesService: UtilitiesService,
    public datepipe: DatePipe
  ) {
    this.blockUI.start('Loading Discounts Code List...');
    this.discountList = [];
    this.projectCode = this.configuratorDiscountDataService.discountProjectCode;
    this.getDiscountCodeist();
    this.discountListForRelease = [];
    this.discountsSelected = false;
    this.updateDiscountListChecked = true;
    this.sendNotificationFail = false;
    this.errorDraft = false;
    this.rowSelected = true;
    this.selectedAll = false;

    this.filterBydiscountID = '';
    this.filterBydiscountCode = '';
    this.filterByversion = '';
    this.filterBystartDate = '';
    this.filterByendDate = '';
    this.filterBycreatedDate = '';
    this.filterBystatus = '';
    this.filterByrequestDescription = '';

    this.filterBydiscountIDSearchObj = '';
    this.filterBydiscountCodeSearchObj = '';
    this.filterByversionSearchObj = '';
    this.filterBystartDateSearchObj = '';
    this.filterByendDateSearchObj = '';
    this.filterBycreatedDateSearchObj = '';
    this.filterBystatusSearchObj = '';
    this.filterByrequestDescriptionSearchObj = '';
    this.configuratorDiscountDataService.isModifyDiscount = false;
  }

  ngOnInit() {
    this.initializeFilterContext();
    this.sort('discountId');
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleExtractDialogUpdate, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  getDiscountCodeist() {
    this.discountListService.getDiscountList(this.projectCode)
      .subscribe(
      data => {
        this.discountCodeist = data.discounts;
        if ((typeof this.discountCodeist !== 'undefined') && (this.discountCodeist !== null) && (this.discountCodeist.length > 0)) {
          for (let i = 0; i < this.discountCodeist.length; i++) {
            this.discountList[i] = false;
          }
        }
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }


  submitIcomsUpdate() {
    let discountsArray = [];
    if (this.discountListForRelease.length > 0) {
      this.sendNotificationFail = false;
      this.discountListService.submitDiscountForICOMSExtract(this.discountListForRelease)
        .subscribe(
        data => {
          if (data.actionStatus === "SUCCESS") {
            this.getDiscountCodeist();
            this.openDialog();
          } else {
            this.statusUpdated.emit(false);
            this.sendNotificationFail = true;
          }
        },
        error => {
          this.sendNotificationFail = true;
          console.log("Error :: " + error)
        }
        );
    }
  }
  selectDeselctAll() {
    this.errorDraft = false;
    for (let i = 0; i < this.discountList.length; i++) {
      this.discountCodeist[i].checked = this.selectedAll;
      if (this.discountCodeist[i].statusName === 'Draft') {
        this.discountCodeist[i].checked = false;
      }
    }
    if (this.selectedAll === true) {
      for (let i = 0; i < this.discountCodeist.length; i++) {
        if (this.discountCodeist[i].statusName === 'Draft') {
          this.errorDraft = true;
          this.discountsSelected = false;
        }
        else {
          this.discountListForRelease.push(this.discountCodeist[i].discountId);
          this.errorDraft = false;
        }
      }
    }
    else {
      this.discountListForRelease.splice(0, this.discountListForRelease.length)
    }
    this.checkIfAllSelected();
  }

  checkIfAllSelected() {
    this.selectedAll = this.discountCodeist.every(function (item: any) {
      if (item.statusName === 'Draft') {
        return item.checked === false;
      }
      return item.checked === true;
    })
    let count = 0;
    if (this.discountCodeist.length > 0) {
      for (let i = 0; i < this.discountCodeist.length; i++) {
        if (this.discountCodeist[i].checked) {
          count++;
        }
      }
    }
    if (count > 0) {
      this.discountsSelected = true;
    } else {
      this.discountsSelected = false;
    }
  }

  updateDiscountForRelease(isChecked, discountID) {
    this.checkIfAllSelected();
    if (isChecked) {
      this.discountListForRelease.push(discountID);
    } else {
      this.discountListForRelease.splice(this.discountListForRelease.indexOf(discountID), 1);
    }
  }

  moveToAddDiscountPage(mode, discountId) {
    this.configuratorDiscountDataService.addEditViewDiscountMode = mode;
    this.configuratorDiscountDataService.addEditViewDiscountCode = discountId;
    this.configuratorDiscountDataService.backURL = '/plm-work-flow/configurator/discount/discount-code-list';
    this.configuratorDiscountDataService.isFromBusinessCatalog = 'false';
    this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  }

  // moveToDiscountGrid() {
  //   this.configuratorDiscountDataService.addEditViewDiscountMode = 'add';
  //   this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  // }


  moveToIntakeRequestView() {
    // this.configuratorOfferDataService.offerProjectCode = this.projectCode;
    // localStorage.setItem('mode','view');
    // localStorage.setItem('intakeRequestID', this.projectCode);
    // localStorage.setItem('backURL', 'plm-work-flow/configurator/offer/offer-table');
    // // this.router.navigate(['plm-work-flow/requestor/view-intake-request']);
    // window.open('', 'Discount Intake Request', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1600,height=850, top=100,left=200');
    this.getAddEditIntakeRequestMasterData();
  }


  getAddEditIntakeRequestMasterData() {
    this.blockUI.start('Loading Intake Request Master Data...');
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (let prop in this.addEditIntakeRequestMasterData['mapMarketList']) {
          this.pushMarketsData(this.addEditIntakeRequestMasterData['mapMarketList'][prop]);
        }
        this.fetchEditProjectData();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  fetchEditProjectData() {
    this.blockUI.start('Loading Intake Request Detail...');
    this.requestorService.getEditProjectData(this.projectCode).subscribe(
      data => {
        this.projectData = data;
        this.resetNullValuesInObj(this.projectData.projectMasterModel);
        this.resetNullValuesInObj(this.projectData.projectMasterModel.intakeFormReqTxnDetModel);
        this.projectData.projectMasterModel.projectStartDt = this.converetDate(this.projectData.projectMasterModel.projectStartDt);
        this.projectData.projectMasterModel.projectEndDt = this.converetDate(this.projectData.projectMasterModel.projectEndDt);
        localStorage.setItem('projectCode', this.projectData.projectMasterModel.projectCode);
        localStorage.setItem('uploadIntakeRequestDocId', this.projectData.projectMasterModel.uploadIntakeRequestDocId);
        this.utilitiesService.triggerWindowTab(this.addEditIntakeRequestMasterData, this.projectData);
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  getDateInFormat(date) {
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }

  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }

  converetDate(startDate) {
    return this.getDateInFormat(startDate);
  }

  resetNullValuesInObj(data) {
    for (let prop in data) {
      data[prop] = (data[prop]) ? data[prop] : '';
    }
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
    }
  }


  // editIntakeRequest(discountCode) {
  //   this.configuratorDiscountDataService.addEditViewDiscountMode = 'edit';
  //   this.configuratorDiscountDataService.addEditViewDiscountCode = discountCode;
  //   this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  // }

  // moveToDiscountView(discountCode) {
  //   this.configuratorDiscountDataService.addEditViewDiscountMode = 'view';
  //   this.configuratorDiscountDataService.addEditViewDiscountCode = discountCode;
  //   this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  // }


  releaseDiscountForICOMSExtract() {
    const reqObj = {
      'projectCode': this.projectCode,
      'offersList': this.releaseDiscountForICOMSExtract
    }
    this.discountListService.submitDiscountForICOMSExtract(reqObj)
      .subscribe(
      data => {
        this.router.navigate(['/plm-work-flow/technology-systems/icoms']);
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  initializeFilterContext() {
    this.filterBydiscountIDSearchObj = {
      'discountId': {
        'type': 'text',
        'value': this.filterBydiscountID,
        'matchFullCase': false
      }
    };
    this.filterBydiscountCodeSearchObj = {
      'discountCode': {
        'type': 'text',
        'value': this.filterBydiscountCode,
        'matchFullCase': false
      }
    };
    this.filterByversionSearchObj = {
      'version': {
        'type': 'text',
        'value': this.filterByversion,
        'matchFullCase': false
      }
    };
    this.filterBystartDateSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterBystartDate,
        'matchFullCase': false
      }
    };
    this.filterByendDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByendDate,
        'matchFullCase': false
      }
    };
    this.filterBycreatedDateSearchObj = {
      'createdDate': {
        'type': 'text',
        'value': this.filterBycreatedDate,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'statusName': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
    this.filterByrequestDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByrequestDescription,
        'matchFullCase': false
      }
    };
  }

  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }


  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/discount/project-list']);
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

}

@Component({
  selector: 'icoms-extract-confirmation-dialog',
  templateUrl: './icoms-extract-confirmation-dialog.html'
})
export class DialogOverviewExampleExtractDialogUpdate {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleExtractDialogUpdate>, private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDashboard() {
    this.dialogRef.close();
    this.router.navigate(['/plm-work-flow/configurator/discount/discount-code-list']);
  }

}

