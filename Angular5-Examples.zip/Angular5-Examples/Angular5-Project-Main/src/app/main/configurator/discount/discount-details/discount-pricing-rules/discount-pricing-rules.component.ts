import * as Handsontable from 'handsontable';

import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Input, OnInit, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { ConfiguratorDiscountDataService } from '../../services/configurator-discount-data.service';
import { DiscountService } from '../discount.service';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-discount-pricing-rules',
  templateUrl: './discount-pricing-rules.component.html',
  styleUrls: ['./discount-pricing-rules.component.css'],
  providers: [UtilitiesService]
})
export class DiscountPricingRulesComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private myInnerHeight: any;
  private myTableInnerheight: any;
  private masterData: any;
  private addEditDiscountSubmitData: any;
  private pricingRules: any;

  private noSitesExist: boolean;
  private noPercentOfNormalRate: boolean;
  private noAmountExist: boolean;
  private noPricingMethod: boolean;
  private showConfigurePricingRules: boolean;
  private showConfigurePricingRulesBtn: boolean;
  private hideSaveExit: boolean;

  private marketsSelected: any[];
  private descriptionBuilderAmount: string;
  private pricingMethod: number;
  private percentOfNormalRate: number;

  private addEditMode: Boolean;
  private viewMode: Boolean;

  private pricingRulesList: any[];
  private pricingRulesListFinal: any[];
  private pricingCategoryDropDownList = [];
  private pricingCategorySelectedItems = [];
  private statementPresentationCodeDropDownList = [];
  private statementPresentationCodeSelectedItems = [];
  private priceBookICOMSCodeDropDownList = [];
  private priceBookICOMSCodeSelectedItems = [];

  private totalAmntToFirstBundleDiscount: any;
  private totalFixedPricing: any;
  private totalAmnToMinReqPricingCategory: any;
  private totalDiscountDollarOff: any;
  private totalSiteAmount: any;
  private totalMinRequiredAmountForCalc: any; 
  private totalMinRequiredAmountForCalcForMinReqAmnt: any;

  private showEditPricingRules: boolean;
  
  private excelColHeader: any[];
  private excelColWidths: any[];
  private excelColumns: any[];
  private excelData: any[];

  constructor(
    private discountService: DiscountService, 
    private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    private utilitiesService: UtilitiesService, 
    public dialog: MatDialog
  ) {
    this.noSitesExist = true;
    this.noPercentOfNormalRate = true;
    this.noPricingMethod = true;
    this.noAmountExist = true;
    this.showConfigurePricingRules = false;
    this.showEditPricingRules= false;
    this.showConfigurePricingRulesBtn= false;
    this.addEditMode = false;
    this.viewMode = false;
    this.hideSaveExit = true;
    this.marketsSelected = [];
    this.descriptionBuilderAmount = '0';
    this.pricingMethod = 0;
    this.percentOfNormalRate = 0;
    this.pricingRulesList = [];
    this.pricingRulesListFinal = [];
    this.totalAmntToFirstBundleDiscount = 0;
    this.totalFixedPricing = 0;
    this.totalAmnToMinReqPricingCategory = 0;
    this.totalDiscountDollarOff = 0;
    this.totalMinRequiredAmountForCalc = [];
    this.totalMinRequiredAmountForCalcForMinReqAmnt = [];
    this.totalSiteAmount = {};
    this.blockUI.start('Loading Latest Price Book...');
    this.masterData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.discountMasterData));
    this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
    this.initializePricingRulesMandFields();
    this.getPriceBookData();
    this.updatePageMode();
    this.updatePageVariables();

    this.myInnerHeight = window.innerHeight + "px";
    this.myTableInnerheight = window.innerHeight -180;
  }

  ngOnInit() {
    this.configuratorDiscountDataService.descriptionBuilderAmount.subscribe(
      text => {
        this.descriptionBuilderAmount = text;
        this.resetPricingRulesList();
      }
    );
    this.configuratorDiscountDataService.marketList.subscribe(
      sites => {
        this.marketsSelected = this.getMarketListObj(sites);
        this.resetPricingRulesList();
      }
    );
    this.configuratorDiscountDataService.pricingMethod.subscribe(
      pricingMethodVal => {
        this.pricingMethod = pricingMethodVal;
        this.resetPricingRulesList();
      }
    );
    this.configuratorDiscountDataService.percentToNormalRate.subscribe(
      percentOfNormalRateVal => {
        this.percentOfNormalRate = percentOfNormalRateVal;
        this.resetPricingRulesList();
      }
    );
    this.configuratorDiscountDataService.copyDiscountAddEditViewOfferFormData.subscribe(
      text => {
        this.configuratorDiscountDataService.addEditDiscountSubmitData = text;
        this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
        this.initializePricingRulesMandFields();
        this.getPriceBookData();
        this.updatePageMode();
        this.updatePageVariables();
      }
    );
  }

  getPriceBookData() {
    this.discountService.getPriceBookData()
      .subscribe(
      data => {
        this.pricingRules = data.priceBook;
        this.configuratorDiscountDataService.pricingRules = data.priceBook;
        this.updateDropDownList();
        for (let i=0; i<this.pricingRulesList.length; i++) {
          this.pricingRulesList[i].pricingMethod = this.pricingMethod;
        }
        this.intializePricingRulesList();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  resetPricingRulesList() {
    this.pricingRulesList = [];
    this.excelData = [];
    this.updatePageVariables();
  }

  initializePricingRulesMandFields() {
    this.marketsSelected = this.getMarketListObj(this.configuratorDiscountDataService.addEditDiscountSubmitData.sites);
    this.pricingMethod = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodId;
    this.descriptionBuilderAmount = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild.amount;
    this.updatePercentToNormalRateValue();
  }

  updatePercentToNormalRateValue() {
    if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodId === 300) {
      for (let i=0; i<this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes.length; i++) {
        if (
          (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrId'] === 5) && 
          (this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'] !== '')
        ) {
          this.configuratorDiscountDataService.payPercentToNormalRate = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'];
          this.percentOfNormalRate = this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapPriceMethod.methodAttributes[i]['methodAttrValue'];
        }
      }
    }
  }

  updatePageMode() {
    this.showConfigurePricingRulesBtn = false;
    if ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'edit'))) {
      this.showConfigurePricingRulesBtn = true;
    }
  }
   
  updatePageVariables(){
    this.noSitesExist = (this.marketsSelected.length === 0) ? true : false;
    this.noPricingMethod = ((this.pricingMethod === 0) || (!this.pricingMethod)) ? true : false;
    this.noPercentOfNormalRate = ((this.getPricingMethod(this.pricingMethod) === 'D') && ((this.configuratorDiscountDataService.payPercentToNormalRate === '') || (Number(this.configuratorDiscountDataService.payPercentToNormalRate) === 0) || (typeof this.configuratorDiscountDataService.payPercentToNormalRate === 'undefined'))) ? true : false;
    this.noAmountExist = ((this.descriptionBuilderAmount === null) || (typeof this.descriptionBuilderAmount === 'undefined') || (this.descriptionBuilderAmount === '')) ? true : false;
    this.showConfigurePricingRules = ((!this.noSitesExist) && (!this.noPricingMethod) && (!this.noAmountExist) && (!this.noPercentOfNormalRate)) ? true : false;
  }

  updateDropDownList() {
    this.pricingCategoryDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'PRICING_CATEGORY');
    this.statementPresentationCodeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'PRESENTATION_CODE');
    if ((typeof this.pricingRules !== 'undefined') && (this.pricingRules !== null) && (this.pricingRules.length > 0)) {
      this.priceBookICOMSCodeDropDownList = this.getPricingBookDropDownList();
    }
  }
  
  getPricingBookDropDownList() {
    const result = [];
    if (this.pricingRules) {
      for (let i = 0; i < this.pricingRules.length; i++) {
        const nameValue = this.pricingRules[i]['relatedIcomsCode'];
        result.push({
          'id': this.pricingRules[i]['priceBookId'],
          'name': nameValue
        });
      }
    }
    return result;
  }

  getPricingBookSelectedItemsList(pricebookChrgIcomscodeDesc) {
    const result = [];
    if (this.pricingRules) {
      for (let i = 0; i < this.pricingRules.length; i++) {
        const nameValue = this.pricingRules[i]['relatedIcomsCode'];
        if (pricebookChrgIcomscodeDesc === nameValue) {
          result.push({
            'id': this.pricingRules[i]['priceBookId'],
            'name': nameValue
          });
        }
      }
    }
    return result;
  }

  getICOMSCodeDescription(pricebookChrgIcomscode) {
    let result = '';
    if (this.pricingRules) {
      for (let i = 0; i < this.pricingRules.length; i++) {
        const nameValue = this.pricingRules[i]['relatedIcomsCode'] + ' - ' +
          this.pricingRules[i]['icomsCodeDescription'];
        if (pricebookChrgIcomscode === this.pricingRules[i]['relatedIcomsCode']) {
          result = nameValue;
        }
      }
    }
    return result;
  }

  getMarketListObj(sites){
    const marketsList = this.masterData['MARKETS'];
    const result = [];
    if (marketsList) {
      for (let i=0; i<marketsList.length; i++) {
        if (sites.indexOf(Number(marketsList[i].siteId)) > -1) {
          result.push(marketsList[i]);
        }
      }
    }
    return result;
  }
  
  getPricingMethod(pricingMethod) {
    let result = '';
    if (this.masterData.priceMethodMasterDataList) {
      for (let i = 0; i < this.masterData.priceMethodMasterDataList.length; i++) {
        if (Number(this.masterData.priceMethodMasterDataList[i].discPriceMethodMasterId) === Number(pricingMethod)) {
          result = this.masterData.priceMethodMasterDataList[i].method;
          break;
        } 
      }
    }
    return result;
  }
  
  intializePricingRulesList() {
    this.pricingRulesList = [];
    for (let i=0; i<this.addEditDiscountSubmitData.pricingRules.length; i++) {
      this.pricingRulesList[i] = JSON.parse(JSON.stringify(this.addEditDiscountSubmitData.pricingRules[i]));
      this.pricingRulesList[i]['amtFrstBundleDiscount'] = (this.pricingRulesList[i]['amtFrstBundleDiscount'] === null) ? ('') : (this.getDollarAppended(this.pricingRulesList[i]['amtFrstBundleDiscount']));
      this.pricingRulesList[i]['amtMinReqPricingCatg'] = (this.pricingRulesList[i]['amtMinReqPricingCatg'] === null) ? ('') : (this.getDollarAppended(this.pricingRulesList[i]['amtMinReqPricingCatg']));
      this.pricingRulesList[i]['campaignDollarOff'] = (this.pricingRulesList[i]['campaignDollarOff'] === null) ? ('') : (this.getDollarAppended(this.pricingRulesList[i]['campaignDollarOff']));
      this.pricingRulesList[i]['fixedPricing'] = (this.pricingRulesList[i]['fixedPricing'] === null) ? ('') : (this.getDollarAppended(this.pricingRulesList[i]['fixedPricing']));
      this.pricingRulesList[i].pricingCategorySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRICING_CATEGORY', this.addEditDiscountSubmitData.pricingRules[i].pricingCategoryName);
      this.pricingRulesList[i].statementPresentationCodeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRESENTATION_CODE', this.addEditDiscountSubmitData.pricingRules[i].presentationCodeId);
      this.pricingRulesList[i].priceBookICOMSCodeSelectedItems = this.getPricingBookSelectedItemsList(this.addEditDiscountSubmitData.pricingRules[i].pricebookChrgReltdIcomscode);
      this.pricingRulesList[i]['pricingCategoryNameSelected'] = (Object.keys(this.pricingRulesList[i].pricingCategorySelectedItems).length > 0) ? this.pricingRulesList[i].pricingCategorySelectedItems['name'] : '';
      this.pricingRulesList[i]['presentationCodeIdSelected'] = (Object.keys(this.pricingRulesList[i].statementPresentationCodeSelectedItems).length > 0) ? this.pricingRulesList[i].statementPresentationCodeSelectedItems['name'] : '';
      this.updatePricingRulesListSites(this.pricingRulesList[i], this.marketsSelected);
    }

    if (this.pricingRulesList.length > 0) {
      this.updateTotalAmnToMinReqPricingCategory();
      this.updateTotalDiscountDollarOff();
      this.updateTotalFirstBundleDiscountAmount();
      this.updateTotalFixedPricingAmount();
      for(let i=0; i<this.marketsSelected.length; i++) {
        this.updateTotalSitePricing(this.marketsSelected[i]['siteCode']);
      }
      this.hideSaveExit = this.isAlreadyPricingRulesCalculated();
      this.updateFinalSubmitData();
      this.dialog.closeAll();
    }
  }
  
  updatePricingRulesListSites(pricingRulesList, marketsSelected) {
    for (let i=0; i<marketsSelected.length; i++) {
      const result = this.getPricingRulesSitesAmount(pricingRulesList.pricingRuleSites, marketsSelected[i]['siteCode']);
      pricingRulesList[marketsSelected[i]['siteCode']] = (!result) ? 0 : this.getDollarAppended(result);
      this.updateTotalSitePricing(marketsSelected[i]['siteCode']);
    }
  }

  isAlreadyPricingRulesCalculated() {
    let result = true;
    let count=0;
    for (let i=0; i<this.marketsSelected.length; i++) {
      if (this.pricingRulesList[0][this.marketsSelected[i]['siteCode']]) {
        count++;
      }
      result = (count === this.marketsSelected.length) ? false : true;
    }
    return result;
  }

  getDollarAppended(result) {
    return ((result.toString().indexOf('$') === -1) && (result !== '')) ? ('$'+ result) : (result);
  }
  
  getPricingRulesSitesAmount(pricingRuleSites, market) {
    let result = 0;
    for (let i=0; i<pricingRuleSites.length; i++) {
      if  (pricingRuleSites[i]['site'] === market) {
        result = pricingRuleSites[i]['amount'];
      }
    }
    return result;
  }
  
  showEditPricingRulesDialog() {
    if (this.showConfigurePricingRules) {
    this.blockUI.start('Loading Configure Pricing Rules...');	
      this.hideSaveExit = true;												   
      this.getHotTableInitialValues();
    }
  }
  
  getHotTableInitialValues() {
    this.setInitialExcelHeaders();
    this.setInitialExcelColumnFieldsAndWidth();
    this.setInitialExcelColumnsValues();
  }

  setInitialExcelHeaders() {
    this.excelColHeader = [];
    this.excelColHeader = [
      'Pricing Category', 
      'Statement Presentation Code', 
      'ICOMS Code', 
      'ICOMS Code Description', 
      'Minimum Requirement', 
      'Bundle Discount', 
      'Amount to add to first bundle discount', 
      '# of Occurances to discount', 
      '# of Months', 
      'Active Service', 
      'Absorb', 
      'Other', 
      'Fixed Pricing', 
      'Amount to add to min req in this Pricing Category', 
      'Discount Dollar Off'
    ];
    for (let i=0; i<this.marketsSelected.length; i++) {
      this.excelColHeader.push(this.marketsSelected[i]['siteCode']);
    }
  }

  setInitialExcelColumnFieldsAndWidth() {
    this.excelColumns= [];
    this.excelColWidths = [];
    this.excelColumns= [
      {
        data: 'pricingCategoryNameSelected', 
        type: 'autocomplete',
        source: this.getNamelistFromObj(this.pricingCategoryDropDownList),
        strict: false
      },
      {
        data: 'presentationCodeIdSelected',  
        type: 'autocomplete',
        source: this.getNamelistFromObj(this.statementPresentationCodeDropDownList),
        strict: false
      },
      { 
        data: 'pricebookChrgIcomscode',
        type: 'autocomplete',
        source: this.getNamelistFromObj(this.priceBookICOMSCodeDropDownList),
        strict: false 
      },
      {
        data: 'pricebookChrgIcomscodeDesc'
      },
      {
        data: 'minRequirmnt',
        type: 'checkbox'
      },
      {
        data: 'bundleDiscount',
        type: 'checkbox'
      },
      { data: 'amtFrstBundleDiscount' },
      { data: 'numOccurnceDiscount' },
      { data: 'numOfMnths' },
      {
        data: 'activeService', 
        type: 'autocomplete',
        source: ['Y', 'N'],
        strict: false
      },
      {
        data: 'absorb', 
        type: 'autocomplete',
        source: ['Y', 'N'],
        strict: false
      },
      { data: 'other' },
      { data: 'fixedPricing' },
      { data: 'amtMinReqPricingCatg' },
      { data: 'campaignDollarOff' }
    ];
    this.excelColWidths = [ 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 200, 100];
    for (let j=0; j<this.marketsSelected.length; j++) {
      this.excelColumns.push({
        data: this.marketsSelected[j]['siteCode']
      });
      this.excelColWidths.push(100);
    }
  }

  setInitialExcelColumnsValues() {
    this.excelData = [];
    for (let k=0; k<this.pricingRulesList.length; k++) {
      const result = {};
      result['codepricingRulesId'] = this.pricingRulesList[k]['codepricingRulesId'];
      result['absorb'] = (this.pricingRulesList[k]['absorb']) ? (this.utilitiesService.capitalizeFirstLetter(this.pricingRulesList[k]['absorb'])) : '';
      result['activeService'] = (this.pricingRulesList[k]['activeService']) ? (this.utilitiesService.capitalizeFirstLetter(this.pricingRulesList[k]['activeService'])) : '';
      result['amtFrstBundleDiscount'] = (this.pricingRulesList[k]['amtFrstBundleDiscount'] === null) ? '' : this.getDollarAppended(this.pricingRulesList[k]['amtFrstBundleDiscount']);
      result['amtMinReqPricingCatg'] = (this.pricingRulesList[k]['amtMinReqPricingCatg'] === null) ? '' : this.getDollarAppended(this.pricingRulesList[k]['amtMinReqPricingCatg']);
      result['bundleDiscount'] = this.pricingRulesList[k]['bundleDiscount'];
      result['campaignDollarOff'] = (this.pricingRulesList[k]['campaignDollarOff'] === null) ? '' : this.getDollarAppended(this.pricingRulesList[k]['campaignDollarOff']);
      result['fixedPricing'] = (this.pricingRulesList[k]['fixedPricing'] === null) ? '' : this.getDollarAppended(this.pricingRulesList[k]['fixedPricing']);
      result['minRequirmnt'] = this.pricingRulesList[k]['minRequirmnt'];
      result['numOccurnceDiscount'] = (this.pricingRulesList[k]['numOccurnceDiscount'] === null) ? '' : this.pricingRulesList[k]['numOccurnceDiscount'];
      result['numOfMnths'] = (this.pricingRulesList[k]['numOfMnths'] === null) ? '' : this.pricingRulesList[k]['numOfMnths'];
      result['other'] = this.pricingRulesList[k]['other'];
      result['presentationCodeId'] = (Object.keys(this.pricingRulesList[k]['statementPresentationCodeSelectedItems']).length > 0) ? this.pricingRulesList[k]['statementPresentationCodeSelectedItems']['name'] : '';
      result['pricebookChrgIcomscode'] = this.pricingRulesList[k]['pricebookChrgReltdIcomscode'];
      result['pricebookChrgIcomscodeDesc'] = this.pricingRulesList[k]['pricebookChrgIcomscodeDesc'];
      result['pricingCategoryName'] =  (Object.keys(this.pricingRulesList[k]['pricingCategorySelectedItems']).length > 0) ? this.pricingRulesList[k]['pricingCategorySelectedItems']['name'] : '';
      const pricingCategoryNameSelected = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRICING_CATEGORY',  this.pricingRulesList[k].pricingCategoryName);
      const presentationCodeIdSelected = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRESENTATION_CODE',  this.pricingRulesList[k].presentationCodeId);
      result['pricingCategoryNameSelected'] = (Object.keys(pricingCategoryNameSelected).length > 0) ? pricingCategoryNameSelected['name'] : '';
      result['presentationCodeIdSelected'] = (Object.keys(presentationCodeIdSelected).length > 0) ? presentationCodeIdSelected['name'] : '';
      this.updatePricingRulesSitesObj(result, this.pricingRulesList[k], false);
      this.excelData.push(result);
    }
    this.updateEmptyRows(this.pricingRulesList);
    this.blockUI.stop();
  }

  updateEmptyRows(pricingRulesList) {
    const leftFieldsCount = 150 - pricingRulesList.length;
    for (let j=0; j<leftFieldsCount; j++) {
      const resultObj = {
        'codepricingRulesId': null, 
        'absorb': '', 
        'activeService': '', 
        'amtFrstBundleDiscount': '', 
        'amtMinReqPricingCatg': '', 
        'bundleDiscount': false, 
        'campaignDollarOff': '',
        'fixedPricing': '', 
        'minRequirmnt': false, 
        'numOccurnceDiscount': '', 
        'numOfMnths': '', 
        'other': '', 
        'presentationCodeId': '', 
        'pricebookChrgIcomscodeDesc': '', 
        'pricebookChrgIcomscode': '', 
        'pricingCategoryName': '',
        'pricingCategoryNameSelected': '',
        'presentationCodeIdSelected': ''
      };
      this.updatePricingRulesSitesObj(resultObj, {}, true);
      this.excelData.push(resultObj);
    }
  }

  updatePricingRulesSitesObj(result, pricingRulesSites, defaultValue) {
    for (let i=0; i<this.marketsSelected.length; i++) {
      const sitesAmount = (defaultValue) ? '' : pricingRulesSites[this.marketsSelected[i]['siteCode']];
      result[this.marketsSelected[i]['siteCode']] = sitesAmount;
    }
  }

  getNamelistFromObj(list) {
    const result = [];
    result.push('');
    for(let i=0; i<list.length; i++) {
      result.push(list[i].name);
    }
    return result;
  }

  getNumberDisplayValue(value) {
    const valueObj = Number(value);
    const result = (valueObj === 0) ? '' : value;
    return result;
  }

  getValueswithoutDollar(valueObj) {
    const value = valueObj.toString();
    let result: any;
    if (value !== '') {
      result = (value.indexOf('$') > -1) ? (Number(value.split('$')[1])) : (Number(value));
    } else {
      result = value;
    }
    return result;
  }

  updateTotalSitePricing(siteName) {
    let result = 0;
    this.totalSiteAmount[siteName] = 0;
    for (let i=0; i<this.pricingRulesList.length; i++) {
      const siteAmount = this.getValueswithoutDollar(this.pricingRulesList[i][siteName]);
      if (siteAmount !== '') {
        result += siteAmount;
      }
    }
    this.totalSiteAmount[siteName] = '$' + result.toFixed(2);
  }

  
  calculatePricingRules() {
    this.blockUI.start('Calculating Pricing Rules....');
    this.updatePricingRulesListFromExcel();
  }

  updatePricingRulesListFromExcel() {
    this.updateEmptyRows(this.excelData);
    this.pricingRulesList = [];
    for (let i=0; i<this.excelData.length; i++) {
      if ((Object.keys(this.excelData[i]).length === 0) || (this.excelData[i] === null) || (typeof this.excelData[i] === 'undefined') || (this.excelData[i]['pricebookChrgIcomscode'] === '') || (!this.excelData[i]['pricebookChrgIcomscode'])) {
        continue;
      }
      this.initializePricingRulesListObj(this.pricingRulesList, i);
    }
    this.updateServiceRackRateOnAllSites();
    this.updateSavePricingRules();
  }

  initializePricingRulesListObj(pricingRulesList, i) {
    pricingRulesList[i] = {};
    pricingRulesList[i].pricingCategoryDropDownList = this.pricingCategoryDropDownList;
    pricingRulesList[i].statementPresentationCodeDropDownList = this.statementPresentationCodeDropDownList;
    pricingRulesList[i].priceBookICOMSCodeDropDownList = this.priceBookICOMSCodeDropDownList;
    pricingRulesList[i].pricingCategorySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRICING_CATEGORY', this.getIDUsingData(this.excelData[i]['pricingCategoryNameSelected'], this.pricingCategoryDropDownList));
    pricingRulesList[i].statementPresentationCodeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'PRESENTATION_CODE', this.getIDUsingData(this.excelData[i]['presentationCodeIdSelected'], this.statementPresentationCodeDropDownList));
    this.excelData[i].pricebookChrgIcomscode = this.excelData[i].pricebookChrgIcomscode.trim();
    this.excelData[i].pricebookChrgIcomscodeDesc = this.getICOMSCodeDescription(this.excelData[i].pricebookChrgIcomscode);
    pricingRulesList[i].priceBookICOMSCodeSelectedItems = this.getPricingBookSelectedItemsList(this.excelData[i].pricebookChrgIcomscode);
    pricingRulesList[i].presentationCodeId = this.getIDUsingData(this.excelData[i]['presentationCodeIdSelected'], this.statementPresentationCodeDropDownList);
    pricingRulesList[i].pricingCategoryName = this.getIDUsingData(this.excelData[i]['pricingCategoryNameSelected'], this.pricingCategoryDropDownList);
    pricingRulesList[i].priceBookDetId = this.getIDUsingData(this.excelData[i]['pricebookChrgIcomscodeDesc'], this.priceBookICOMSCodeDropDownList);
    pricingRulesList[i].presentationCodeIdSelected = this.excelData[i]['presentationCodeIdSelected'];
    pricingRulesList[i].pricingCategoryNameSelected = this.excelData[i]['pricingCategoryNameSelected'];
    pricingRulesList[i].pricebookChrgIcomscodeDesc = this.excelData[i].pricebookChrgIcomscodeDesc;
    pricingRulesList[i].pricebookChrgReltdIcomscode = this.excelData[i].pricebookChrgIcomscode;
    pricingRulesList[i].codepricingRulesId = this.excelData[i].codepricingRulesId;
    pricingRulesList[i].minRequirmnt = (this.excelData[i].minRequirmnt !== '') ? this.excelData[i].minRequirmnt : false;
    pricingRulesList[i].codepricingRulesId = this.excelData[i].codepricingRulesId;
    pricingRulesList[i].bundleDiscount = (this.excelData[i].bundleDiscount !== '') ? this.excelData[i].bundleDiscount : false;
    pricingRulesList[i].numOccurnceDiscount = this.excelData[i].numOccurnceDiscount;
    pricingRulesList[i].numOfMnths = this.excelData[i].numOfMnths;
    pricingRulesList[i].activeService = this.excelData[i].activeService;
    pricingRulesList[i].absorb = this.excelData[i].absorb;
    pricingRulesList[i].other = this.excelData[i].other;
    pricingRulesList[i].amtFrstBundleDiscount = this.excelData[i].amtFrstBundleDiscount;
    pricingRulesList[i].fixedPricing = this.excelData[i].fixedPricing;
    pricingRulesList[i].amtMinReqPricingCatg = this.excelData[i].amtMinReqPricingCatg;
    pricingRulesList[i].campaignDollarOff = this.excelData[i].campaignDollarOff;
    pricingRulesList[i].descriptionBuilderAmount = this.descriptionBuilderAmount;
    pricingRulesList[i].markets = this.marketsSelected;
    pricingRulesList[i].pricingMethod = this.pricingMethod;
    for (let j=0; j<this.marketsSelected.length; j++) {
      const siteCharge = (this.excelData[i][this.marketsSelected[j]['siteCode']]) ? (this.getDollarAppended(this.excelData[i][this.marketsSelected[j]['siteCode']])) : (this.excelData[i][this.marketsSelected[j]['siteCode']]);
      pricingRulesList[i][this.marketsSelected[j]['siteCode']] = siteCharge;
      this.updateTotalSitePricing(this.marketsSelected[j]['siteCode']);
    }
    this.blockUI.stop();
  }
  
  getIDUsingData(name, dropDownList) {
    let result = '';
    for (let i=0; i<dropDownList.length; i++) {
      if (dropDownList[i]['name'] === name) {
        result = dropDownList[i]['id']
      }
    }
    return result;
  }
  
  updateServiceRackRateOnAllSites() {
    for (let i=0; i<this.pricingRulesList.length; i++) {
      const valueObj = this.pricingRulesList[i].priceBookICOMSCodeSelectedItems;
      if ((!valueObj) || (!valueObj[0]) || (!valueObj[0]['id'])) {
        return false;
      }
      const pricingRuleObj = this.getPricingRuleObj(valueObj[0]['id']);
      this.executeServiceCodeRackRate(i, pricingRuleObj);
    }
    this.modifyExcelData();
  }

  modifyExcelData() {
    for (let i=0; i<this.pricingRulesList.length; i++) {
      this.executePricingRulesCalculation('', i, this.pricingRulesList[i].priceBookICOMSCodeSelectedItems);
    }
    this.setInitialExcelColumnsValues();
  }

  getPricingRuleObj(pricingRuleID) {
    let result = '';
    if (this.pricingRules) {
      for (let i=0; i< this.pricingRules.length; i++) {
        if (this.pricingRules[i].priceBookId === pricingRuleID) {
          result = this.pricingRules[i];
          break;      
        }
      }
    }
    return result;
  }

  executeServiceCodeRackRate(index, pricingRuleObj){
    for (let i=0; i<this.marketsSelected.length; i++) {
      this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] = this.getDollarAppended(this.getPriceBookSiteAmount(this.marketsSelected[i]['siteCode'], pricingRuleObj));
      this.updateTotalSitePricing(this.marketsSelected[i]['siteCode']);
    }
    this.updateTotalMinReqAmount();
  }

  updateTotalMinReqAmount() {
   for (let i=0; i<this.marketsSelected.length; i++) {
      this.getTotalMinReqPricingCategoryVal(this.marketsSelected[i]['siteCode']);
    }
  }

  getPriceBookSiteAmount(siteName, pricingRuleObj) {
    let result = 0;
    if ((pricingRuleObj) && (pricingRuleObj.priceBookSiteMaps)) {
      for (let i=0; i<pricingRuleObj.priceBookSiteMaps.length; i++) {
        if (pricingRuleObj.priceBookSiteMaps[i].site === siteName) {
          result = Number(pricingRuleObj.priceBookSiteMaps[i].amount);
        }
      }
    }
    return result;
  }

  updateAllSitesTotalAmount() {
    for (let i=0; i<this.marketsSelected.length; i++) {
      this.updateTotalSitePricing(this.marketsSelected[i]['siteCode']);
    }
  }

  executePricingRulesCalculation(key, index, valueObj){
    if ((!valueObj) || (!valueObj[0]) || (!valueObj[0]['id'])) {
      return false;
    }
    const pricingRuleObj = this.getPricingRuleObj(valueObj[0]['id']);
    this.pricingRulesList[index].pricebookChrgReltdIcomscode = pricingRuleObj['relatedIcomsCode'];
    this.pricingRulesList[index].pricingRulesObjAssociated = pricingRuleObj;
    const pricingMethod = this.getPricingMethod(this.pricingMethod);
    if ((pricingMethod === 'A') || (pricingMethod === 'J') || (pricingMethod === 'G') || (pricingMethod === 'H') || (pricingMethod === 'F')) {
      this.executePricingRuleForMethod_AJGHF(index, pricingRuleObj);
    } else if (pricingMethod === 'C') {
      this.executePricingRuleForMethod_C(index, pricingRuleObj);
    } else if (pricingMethod === 'D') {
      this.executePricingRuleForMethod_D(index, pricingRuleObj);
    }
    this.updateAllSitesTotalAmount();
  }

  getBooleanFromString(boolVal) {
    let result = false;
    if ((typeof boolVal === 'string') && (boolVal !== '')) {
      result = ((boolVal === 'TRUE') || (boolVal === 'true')) ? true : false;
    } else {
      result = boolVal;
    }
    return result;
  }
 
  executePricingRuleForMethod_AJGHF(index, pricingRuleObj) {
    const amount = this.descriptionBuilderAmount;
    if ((this.pricingRulesList[index].bundleDiscount) && ((typeof this.pricingRulesList[index].amtMinReqPricingCatg === 'undefined') || (this.pricingRulesList[index].amtMinReqPricingCatg === null) || (this.pricingRulesList[index].amtMinReqPricingCatg === ''))) {
      this.executeBundleDiscountYesRule(index);
    } else if ((typeof this.pricingRulesList[index].fixedPricing !== 'undefined') && (this.pricingRulesList[index].fixedPricing !== null) && (this.pricingRulesList[index].fixedPricing !== '')) {
      this.executeFixedPricingYesRule(index);
    } else if ((typeof this.pricingRulesList[index].amtMinReqPricingCatg !== 'undefined') && (this.pricingRulesList[index].amtMinReqPricingCatg !== null) && (this.pricingRulesList[index].amtMinReqPricingCatg !== '')) {
      this.executeAmntToAddToMinReqInPricingCategory(index);
    }
  }

  executePricingRuleForMethod_C(index, pricingRuleObj) {
    for(let i=0; i<this.marketsSelected.length; i++) {
      const siteCodeVal = this.getValueswithoutDollar(this.pricingRulesList[index][this.marketsSelected[i]['siteCode']]);
      const campaignDollarOff = this.getValueswithoutDollar(this.pricingRulesList[index]['campaignDollarOff']);
      const currentMarketPricing: any = Number((siteCodeVal !== '') ? (siteCodeVal) : 0);
      const discountDollarOffAmnt: any = Number((campaignDollarOff !== '') ? (campaignDollarOff) : 0);
      const result:any = currentMarketPricing - discountDollarOffAmnt;
      this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] = '$' + result.toFixed(2).toString();
    }
  }

  executePricingRuleForMethod_D(index, pricingRuleObj) {
    for(let i=0; i<this.marketsSelected.length; i++) {
      const siteCodeVal = this.getValueswithoutDollar(this.pricingRulesList[index][this.marketsSelected[i]['siteCode']]);
      const percentOfNormalRate = this.getValueswithoutDollar(this.percentOfNormalRate);
      const currentMarketPricing: any = Number((siteCodeVal !== '') ? (siteCodeVal) : 0);
      const payPtcNormalRate: any = Number((percentOfNormalRate !== '') ? (percentOfNormalRate) : 0);
      const result:any = currentMarketPricing * (payPtcNormalRate/100);
      this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] ='$' + result.toFixed(2).toString();
    }
  }

  executeBundleDiscountYesRule(index) {
    for(let i=0; i<this.marketsSelected.length; i++) {
      const descriptionBuilderAmount = this.getValueswithoutDollar(this.descriptionBuilderAmount);
      const amtFrstBundleDiscount = this.getValueswithoutDollar(this.pricingRulesList[index].amtFrstBundleDiscount);
      const currentAmountToFloat: any = Number((descriptionBuilderAmount !== '') ? (descriptionBuilderAmount) : 0);
      const totalAmnToMinReqPricingCategoryToFloat: any = Number(this.totalMinRequiredAmountForCalcForMinReqAmnt[this.marketsSelected[i]['siteCode']]);
      const totalAmntToFirstBundleDiscountToFloat: any = Number((amtFrstBundleDiscount !== '') ? (amtFrstBundleDiscount) : 0);
      const result: any = currentAmountToFloat - totalAmnToMinReqPricingCategoryToFloat + totalAmntToFirstBundleDiscountToFloat;
      this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] = '$' + Number(result).toFixed(2).toString();
    }
  }

  getTotalMinReqPricingCategoryVal(siteName) {
    let amntToMinReqResult = 0;
    for(let i=0; i<this.pricingRulesList.length; i++) {
      this.pricingRulesList[i].bundleDiscount = this.getBooleanFromString(this.pricingRulesList[i].bundleDiscount);
      this.pricingRulesList[i].minRequirmnt = this.getBooleanFromString(this.pricingRulesList[i].minRequirmnt);
      if ((typeof this.pricingRulesList[i].fixedPricing !== 'undefined') && (this.pricingRulesList[i].fixedPricing !== null) && (this.pricingRulesList[i].fixedPricing !== '')) {
        this.pricingRulesList[i][siteName] = this.getDollarAppended(this.pricingRulesList[i]['fixedPricing']);
      }
      if ((this.pricingRulesList[i]['minRequirmnt']) && ((typeof this.pricingRulesList[i].amtMinReqPricingCatg === 'undefined') || (this.pricingRulesList[i].amtMinReqPricingCatg === null) || (this.pricingRulesList[i].amtMinReqPricingCatg === '')) && (!this.pricingRulesList[i]['bundleDiscount'])) {
        const siteNameVal = this.getValueswithoutDollar(this.pricingRulesList[i][siteName]);
        amntToMinReqResult += Number((siteNameVal !== '') ? (siteNameVal) : 0);
      }
    }
    this.totalMinRequiredAmountForCalcForMinReqAmnt[siteName] = amntToMinReqResult;
  }

  executeFixedPricingYesRule(index) {
    for(let i=0; i<this.marketsSelected.length; i++) {
      const fixedPricing = this.getValueswithoutDollar(this.pricingRulesList[index].fixedPricing);
      const result = Number((fixedPricing !== '') ? (fixedPricing) : 0);
      this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] = '$' + result;
    }
  }

  executeAmntToAddToMinReqInPricingCategory(index) {
      for(let i=0; i<this.marketsSelected.length; i++) {
        const pricingRuleObj = this.getPricingRuleObj(this.pricingRulesList[index].priceBookICOMSCodeSelectedItems[0]['id']);
        const siteCodeVal = this.getValueswithoutDollar(this.pricingRulesList[index][this.marketsSelected[i]['siteCode']]);
        const amtMinReqPricingCatg = this.getValueswithoutDollar(this.pricingRulesList[index].amtMinReqPricingCatg);
        const getCurrentSiteRackRateValue: any = Number((siteCodeVal !== '') ? (siteCodeVal) : 0);
        const currentTotalAmnToMinReqToFloat: any = Number((amtMinReqPricingCatg !== '') ? (amtMinReqPricingCatg) : 0);
        const result: any = ( this.totalMinRequiredAmountForCalcForMinReqAmnt[this.marketsSelected[i]['siteCode']] + currentTotalAmnToMinReqToFloat);
        this.pricingRulesList[index][this.marketsSelected[i]['siteCode']] = '$' + result.toFixed(2);
      }
  }

  
  updateTotalFirstBundleDiscountAmount() {
    let result = 0;
    this.totalAmntToFirstBundleDiscount = 0;
    if (this.pricingRulesList) {
      for(let i=0; i<this.pricingRulesList.length; i++) {
        const amtFrstBundleDiscount = this.getValueswithoutDollar(this.pricingRulesList[i].amtFrstBundleDiscount);
        if (amtFrstBundleDiscount !== '') {
          result += amtFrstBundleDiscount;
        }
      }
    }
    this.totalAmntToFirstBundleDiscount = '$' + result.toFixed(2);
  }

  updateTotalFixedPricingAmount() {
    let result = 0;
    this.totalFixedPricing = 0;
    if (this.pricingRulesList) {
      for(let i=0; i<this.pricingRulesList.length; i++) {
        const fixedPricing = this.getValueswithoutDollar(this.pricingRulesList[i].fixedPricing);
        if (fixedPricing !== '') {
          result += fixedPricing;
        }
      }
    }
    this.totalFixedPricing = '$' + result.toFixed(2);
  }

  updateTotalAmnToMinReqPricingCategory() {
    let result = 0;
    this.totalAmnToMinReqPricingCategory = 0;
    if (this.pricingRulesList) {
      for(let i=0; i<this.pricingRulesList.length; i++) {
        const amtMinReqPricingCatg = this.getValueswithoutDollar(this.pricingRulesList[i].amtMinReqPricingCatg);
        if (amtMinReqPricingCatg !== '') {
          result += amtMinReqPricingCatg;
        }
      }
    }
    this.totalAmnToMinReqPricingCategory = '$' + result.toFixed(2);
  }

  updateTotalDiscountDollarOff() {
    let result = 0;
    this.totalDiscountDollarOff = 0;
    if (this.pricingRulesList) {
      for(let i=0; i<this.pricingRulesList.length; i++) {
        const campaignDollarOff = this.getValueswithoutDollar(this.pricingRulesList[i].campaignDollarOff);
        if (campaignDollarOff !== '') {
          result += campaignDollarOff;
        }
      }
    }
    this.totalDiscountDollarOff = '$' + result.toFixed(2);
  }

  
  savePricingRules() {
    this.blockUI.start('Saving Pricing Rules...');
    this.pricingRulesList = [];
    for (let i=0; i<this.excelData.length; i++) {
      if ((Object.keys(this.excelData[i]).length === 0) || (this.excelData[i] === null) || (typeof this.excelData[i] === 'undefined') || (this.excelData[i]['pricebookChrgIcomscode'] === '') || (!this.excelData[i]['pricebookChrgIcomscode'])) {
        continue;
      }
      this.initializePricingRulesListObj(this.pricingRulesList, i);
    }
    if (this.isAlreadyPricingRulesCalculated()) {
      this.calculatePricingRules();
    } else {
      this.updateSavePricingRules();
    }
    
  }

  updateSavePricingRules() {
    this.updateTotalAmnToMinReqPricingCategory();
    this.updateTotalDiscountDollarOff();
    this.updateTotalFirstBundleDiscountAmount();
    this.updateTotalFixedPricingAmount();
    for(let i=0; i<this.marketsSelected.length; i++) {
      this.updateTotalSitePricing(this.marketsSelected[i]['siteCode']);
    }
    this.updateFinalSubmitData();
    this.hideSaveExit = this.isAlreadyPricingRulesCalculated();
    this.dialog.closeAll();
    this.blockUI.stop();
  }

  updateFinalSubmitData() {
    this.configuratorDiscountDataService.addEditDiscountSubmitData.pricingRules = [];
    for (let i=0; i<this.pricingRulesList.length; i++) {
      const result = {};
      result['codepricingRulesId'] = this.pricingRulesList[i]['codepricingRulesId'];
      result['absorb'] = this.pricingRulesList[i]['absorb'];
      result['activeService'] = this.pricingRulesList[i]['activeService'];
      result['amtFrstBundleDiscount'] = this.getValueswithoutDollar(this.pricingRulesList[i]['amtFrstBundleDiscount']);
      result['amtMinReqPricingCatg'] = this.getValueswithoutDollar(this.pricingRulesList[i]['amtMinReqPricingCatg']);
      result['campaignDollarOff'] = this.getValueswithoutDollar(this.pricingRulesList[i]['campaignDollarOff']);
      result['bundleDiscount'] = this.pricingRulesList[i]['bundleDiscount'];
      result['fixedPricing'] = this.getValueswithoutDollar(this.pricingRulesList[i]['fixedPricing']);
      result['minRequirmnt'] = this.pricingRulesList[i]['minRequirmnt'];
      result['numOccurnceDiscount'] = this.pricingRulesList[i]['numOccurnceDiscount'];
      result['numOfMnths'] = this.pricingRulesList[i]['numOfMnths'];
      result['other'] = this.pricingRulesList[i]['other'];
      result['pricebookChrgIcomscodeDesc'] = this.pricingRulesList[i]['pricebookChrgIcomscodeDesc'];
      result['pricebookChrgReltdIcomscode'] = this.pricingRulesList[i].pricebookChrgReltdIcomscode;
      result['presentationCodeId'] = this.getIDUsingData(this.pricingRulesList[i]['presentationCodeIdSelected'], this.statementPresentationCodeDropDownList);
      result['pricingCategoryName'] = this.getIDUsingData(this.pricingRulesList[i]['pricingCategoryNameSelected'], this.pricingCategoryDropDownList);
      result['priceBookDetId'] = this.getIDUsingData(this.pricingRulesList[i]['pricebookChrgIcomscodeDesc'], this.priceBookICOMSCodeDropDownList);
      result['pricingRuleSites'] = this.getPricingRuleSites(this.pricingRulesList[i]);
      this.configuratorDiscountDataService.addEditDiscountSubmitData.pricingRules[i] = result;
    }
  }

  getPricingRuleSites(pricingRuleList) {
    const result = [];
    for (let i=0; i<this.marketsSelected.length; i++) {
      const amountVal = this.getValueswithoutDollar(pricingRuleList[this.marketsSelected[i].siteCode]);
      const pricingRuleSite = {
        'amount': amountVal,
        'site': this.marketsSelected[i].siteCode,
        'siteId': this.marketsSelected[i].siteId
      };
      result.push(pricingRuleSite);
    } 
    return result;
  }

  getFileDownload() {
    const finalSubmitData = [];
    for (let i=0; i<this.pricingRulesList.length; i++) {
      const result = {};
      result['Pricing Category Name'] = this.pricingRulesList[i]['pricingCategorySelectedItems']['name'];
      result['Statement Presentation Code'] = this.pricingRulesList[i]['statementPresentationCodeSelectedItems']['name'];
      result['Price Book - Related ICOMS Code'] = this.pricingRulesList[i]['pricebookChrgReltdIcomscode'];
      result['Price Book - ICOMS Code'] = this.pricingRulesList[i]['priceBookICOMSCodeSelectedItems'][0]['name'];
      result['Minimum Requirement'] = this.pricingRulesList[i]['minRequirmnt'];
      result['Bundle Discount'] = this.pricingRulesList[i]['bundleDiscount'];
      result['Amount to add to first bundle discount'] = this.pricingRulesList[i]['amtFrstBundleDiscount'];
      result['# of Occurances to discount'] = (this.pricingRulesList[i]['numOccurnceDiscount']) ? (this.pricingRulesList[i]['numOccurnceDiscount']) : '';
      result['# of Months'] = (this.pricingRulesList[i]['numOfMnths']) ? (this.pricingRulesList[i]['numOfMnths']) : '';
      result['Active Service'] = (this.pricingRulesList[i]['activeService']) ? (this.pricingRulesList[i]['activeService']) : '';
      result['Absorb'] = (this.pricingRulesList[i]['absorb']) ? (this.pricingRulesList[i]['absorb']) : '';
      result['Other'] = (this.pricingRulesList[i]['other']) ? (this.pricingRulesList[i]['other']) : '';
      result['Fixed Pricing'] = this.pricingRulesList[i]['fixedPricing'];
      result['Amount to add to min req in this Pricing Category'] = this.pricingRulesList[i]['amtMinReqPricingCatg'];
      result['Discount Dollar Off'] = this.pricingRulesList[i]['campaignDollarOff'];
      this.updatePricingRulesSitesObj(result, this.pricingRulesList[i], false);
      finalSubmitData.push(result);
    }
    this.exportToCsv(finalSubmitData, 'pricing_rules');
  }

  exportToCsv(data: any, filename: String) {
    const csvData = this.convertToCSV(data);
    const a: any = document.createElement("a");
    a.setAttribute('style', 'display:none;');
    document.body.appendChild(a);
    const blob = new Blob(["\ufeff", csvData], { type: 'application/octet-stream' });
    const url = window.URL.createObjectURL(blob);
    a.href = url;

    const isIE = /*@cc_on!@*/false || !!(<any>document).documentMode;

    if (isIE) {
        const retVal = navigator.msSaveBlob(blob, filename + '.csv');
    }
    else {
        a.download = filename + '.csv';
        a.click();
    }
  }

  convertToCSV(objArray: any) {
    const array = typeof objArray !== 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row = "";
    for (let index in objArray[0]) {
        //Now convert each value to string and comma-seprated
        row += index + ',';
    }
    row = row.slice(0, -1);
    //append Label row with line break
    str += row + '\r\n';
    for (let i = 0; i < array.length; i++) {
        let line = '';
        for (let index in array[i]) {
            if (line != '') {
              line += ',';
            }
            line += '"' + array[i][index] + '"';
        }
        str += line + '\r\n';
    }
    return str;
  }
  

}

