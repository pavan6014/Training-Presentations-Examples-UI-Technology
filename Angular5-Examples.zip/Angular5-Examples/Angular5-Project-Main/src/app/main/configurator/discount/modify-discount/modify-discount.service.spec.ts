import { TestBed, inject } from '@angular/core/testing';

import { ModifyDiscountService } from './modify-discount.service';

describe('ModifyDiscountService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ModifyDiscountService]
    });
  });

  it('should be created', inject([ModifyDiscountService], (service: ModifyDiscountService) => {
    expect(service).toBeTruthy();
  }));
});
