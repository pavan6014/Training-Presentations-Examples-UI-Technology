export interface DiscountIcomsStatusInterface {
}
