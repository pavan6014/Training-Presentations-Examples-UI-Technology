import 'rxjs/Rx' ;

import {
  DiscMapOscar,
  DiscMapPreRequisite,
  DiscountFormDropDown,
  DiscountFormMasterData,
  DiscountGift,
  GetDisMapMainPage,
  GetDiscMapOnline,
  GetDiscountGeneralInformation,
  GetDiscountIcomsStatus,
  GetMappingTable,
  IcomsStatusModel,
  SubmitDiscountInfo,
  TeCode
} from './discount-interface';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import { catchError, retry } from 'rxjs/operators';

import { AppConfigService } from '../../../../shared/services/app-config.service';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { HttpHeaders } from '@angular/common/http/src/headers';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Injectable()
export class DiscountService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService, private utilitiesService: UtilitiesService) { }



  getAddDiscountMasterData():Observable<any> {
    const getAddDiscountMasterDataUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
    return this.http
      .get(getAddDiscountMasterDataUrl)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const getAddDiscountMasterDataUrl = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_MASTER_DATA'];
    // return this.http
    //   .get(getAddDiscountMasterDataUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  getPriceBookData():Observable<any> {
    const getAddDiscountMasterDataUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_PRICING_RULES'];
    return this.http
      .get(getAddDiscountMasterDataUrl)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const getAddDiscountPricingRulesUrl = this.appConfigService.urlConstants['PLM_ADD_DISCOUNT_PRICING_RULES'];
    // return this.http
    //   .get(getAddDiscountPricingRulesUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  getEditDiscountFormData(discountId):Observable<any> {
     const getEditDiscountFormDataUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_EDIT_DISCOUNT_FORM_DATA'] + '/' +discountId;
      return this.http
      .get(getEditDiscountFormDataUrl)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const getEditDiscountFormDataUrl = this.appConfigService.urlConstants['PLM_EDIT_DISCOUNT_FORM_DATA'];
    // return this.http
    //   .get(getEditDiscountFormDataUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  getIcomsStatus(): Observable<any> {
    const getIcomsStatus = this.appConfigService.urlConstants['PLM_DISCOUNT_MASTER_ICOMS_STATUS']
    return this.http
      .get(getIcomsStatus)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


  postAddDiscountDetails(submitData, file, isSubmitted):Observable<any>{
      const postAddDiscountDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_DISCOUNT_FORM_DATA'];
      let headersVal = new Headers();
      headersVal.append('Content-Type', '');
      return this.http
        .post(postAddDiscountDetailsURL,  this.prepareSave(submitData, file, isSubmitted)) 
        .map((response: Response) => {
          return response;
        })
        .catch(this.handleError);
      // const getAddUpdateProject = this.appConfigService.urlConstants[
      //     'PLM_ADD_UPDATE_PROJECT_RESPONSE'
      // ];
      // return this.http
      //     .get(getAddUpdateProject)
      //     .map((response: Response) => {
      //         return response;
      //     })
      //     .catch(this.handleError);
  }
  
  
  postUpdateDiscountDetails(submitData, file, isSubmitted):Observable<any>{
      // reqObj.projectMasterModel.intakeFormReqTxnDetModel.instltnIncFlg = this.getInstallationIncluded(reqObj.projectMasterModel); 
      const putUpdateDiscountDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_DISCOUNT_FORM_DATA'];
      return this.http
        .put(putUpdateDiscountDetailsURL,  this.prepareSave(submitData, file, isSubmitted))
        .map((response: Response) => {
          return response;
        })
        .catch(this.handleError);
      // const getAddUpdateProject = this.appConfigService.urlConstants[
      //     'PLM_ADD_UPDATE_PROJECT_RESPONSE'
      // ];
      // this.prepareSave(reqObj);
      // return this.http
      //     .get(getAddUpdateProject)
      //     .map((response: Response) => {
      //         return response;
      //     })
  
      //     .catch(this.handleError);
  }
  
  private prepareSave(submitData, file, isSubmitted): any {
      let input = new FormData();
      let submitDataModel = JSON.parse(JSON.stringify(submitData));
      if (file) {
          input.append('file', file, file.name);
      } 
      let dataObj = {
          'discount': submitDataModel,
          'submitted': isSubmitted
      };
      input.append('data', JSON.stringify(dataObj));
      return input;
  }


  submitProject(reqObj): Observable<any> {
    const getDiscountCreationURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNTSTATUS'];
    return this.http
      .post(getDiscountCreationURL, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const submitAddDiscount = this.appConfigService.urlConstants['PLM_SUBMIT_DISCOUNT_FORM_DATA']
    // return this.http
    //   .get(submitAddDiscount)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  getDiscountFormData(): Observable<any> {
    
    const getDiscountFormData = this.appConfigService.urlConstants['PLM_DISCOUNT_ICOMS_STATUS']
    return this.http
      .get(getDiscountFormData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getDownLoad(preReqId){
      const getShowDownLoad = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_ICOMS_TEMPLATE_DOWNLOAD'] + '/'+preReqId;
      return this.utilitiesService.getDownloadUrl(getShowDownLoad);
  }
  

   
  getCopyDiscountSearch(searchKey): Observable<any> {
    const getCopyDiscountSearchURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_SEARCH_DISCOUNT_COPY'];
    const reqObj = {
      'searchKey' : searchKey
    };
    return this.http
      .post(getCopyDiscountSearchURL, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_SEARCH_DISCOUNT_COPY']
    // return this.http
    //   .get(getConfiguratorOfferFromProject)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
 
  addDiscountSearchForCopy(discountID): Observable<any> {
    const addCopDiscountBySearchURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_SEARCH_DISCOUNT_ADD'] + '/' +discountID;
    return this.http
      .get(addCopDiscountBySearchURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_SEARCH_DISCOUNT_ADD']
    // return this.http
    //   .get(getConfiguratorOfferFromProject)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  addProjectName(reqObj){
    const saveProjectName = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_PROJECT_SAVE'] ;
    return this.http
    .post(saveProjectName, reqObj)
    .map((response: Response) => {
      return response;
    })
    .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
