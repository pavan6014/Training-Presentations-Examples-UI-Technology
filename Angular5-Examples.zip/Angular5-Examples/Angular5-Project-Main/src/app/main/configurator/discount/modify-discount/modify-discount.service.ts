import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { AppConfigService } from '../../../../shared/services/app-config.service';



@Injectable()
export class ModifyDiscountService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }



    getModifyDiscountListData(): Observable<any> {
    const getModifyDiscountListDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_MODIFY_SEARCH']+ '/';
    // const getModifyDiscountListDataURL = this.appConfigService.urlConstants['PLM_CONFIGURATOR_DISCOUNT_MODIFY_OFFER_LIST'];
    return this.http
      .get(getModifyDiscountListDataURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


    getSearchDiscountList(searchDiscountVal): Observable<any> {
    const getSearchDiscountList = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_MODIFY_SEARCH'];
    const reqObj = {
      'searchKey': searchDiscountVal
    };
    return this.http
      .post(getSearchDiscountList, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getSearchDiscountList = this.appConfigService.urlConstants['PLM_DISCOUNT_MODIFY_SEARCH'];
    // const reqObj = {
    //   'searchKey': searchDiscountVal
    // };
    // return this.http
    //   .get(getSearchDiscountList)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  // getDiscountModifySearch(): Observable<any> {
  //   // const getDiscountModifyList = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_MODIFY_SEARCH'];
  //   // return this.http
  //   //   .get(getDiscountModifyList)
  //   //   .map((response: Response) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
  //   const getDiscountModifyList = this.appConfigService.urlConstants['PLM_DISCOUNT_MODIFY_SEARCH']
  //   return this.http
  //     .get(getDiscountModifyList)
  //     .map((response: Response) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
  // }


  icomsNotifyDiscount(submitObj) {
    const icomsNotifyDiscountURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_MODIFY_VALIDATE_AND_SUBMIT'];
    return this.http
      .post(icomsNotifyDiscountURL, submitObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const icomsNotifyDiscountURL = this.appConfigService.urlConstants['PLM_MODIFY_VALIDATE_AND_SUBMIT'];
    // return this.http
    //   .get(icomsNotifyDiscountURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

   submitDiscountForICOMSNotify(reqObj): Observable<any>{
    const getDiscountsListForIcoms = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_SEND_NOTIFICATION'];
    return this.http
      .post(getDiscountsListForIcoms, this.prepareSendNotificationData(reqObj))
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getDiscountsListForIcoms = this.appConfigService.urlConstants['PLM_DISCOUNT_SEND_NOTIFICATION'];
    // return this.http
    //   .get(getDiscountsListForIcoms)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

private prepareSendNotificationData(reqObj) {
    return {
      'discountIds': reqObj
    };
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
