import { Injectable } from '@angular/core';

@Injectable()
export class ConfiguratorDiscountService {

  constructor() { }

}
