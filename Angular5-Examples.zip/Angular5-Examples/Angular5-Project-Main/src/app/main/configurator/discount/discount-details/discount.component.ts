import {
  AddDiscountFormMasterData,
  DiscMapOscar,
  DiscMapPreRequisite,
  DiscountFormDropDown,
  DiscountFormMasterData,
  DiscountGift,
  GetCampaignCodePricingMethod,
  GetDisMapMainPage,
  GetDiscMapOnline,
  GetDiscountGeneralInformation,
  GetDiscountIcomsStatus,
  GetDiscriptionBuilder,
  GetMappingTable,
  IcomsStatusModel,
  SubmitDiscountInfo,
  TeCode
} from './discount-interface';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, Input, OnInit, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { ConfiguratorDiscountDataService } from '../services/configurator-discount-data.service';
import { DiscountService } from './discount.service';
import { MatDialogModule } from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'plm-discount',
  templateUrl: './discount.component.html',
  providers: [DiscountService]
})
export class DiscountComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private discountsDescriptionBuilder: GetDiscriptionBuilder;
  private discountIcomsForms: GetDiscountIcomsStatus;
  private DisountsFormsData: string;
  private discountGift: DiscountGift;
  private discMapPreRequisite: DiscMapPreRequisite;
  private discMapOscar: DiscMapOscar;
  private disMapMainPage: GetDisMapMainPage;
  private discMapOnline: GetDiscMapOnline;
  private masterData: AddDiscountFormMasterData;
  private pricingRules: any;
  private addEditDiscountSubmitData: any;
  private discountFormDropDown: DiscountFormDropDown;
  private mappingTable: GetMappingTable;
  private discountGeneralInformation: GetDiscountGeneralInformation;
  private campaignCodePricingMethod: GetCampaignCodePricingMethod;
  private formDataLoaded: boolean;
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private fileToUpload: any;
  private saveAndExitSuccess: Boolean;
  private saveAndExitFail: Boolean;
  private discountAddSubmitFailed: Boolean;
  private saveSubmitResult: string;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private finalSubmitData: any;
  private backURL: string;
  private isFromBusinessCatalog: boolean;
  private isFromTechnologySystems: boolean;
  private isNotFromBusinessOrTechnology: boolean;

  constructor(private discountService: DiscountService, private configuratorDiscountDataService: ConfiguratorDiscountDataService, private router: Router, public dialog: MatDialog) {
    this.isNotFromBusinessOrTechnology = false;
    this.isFromBusinessCatalog = false;
    this.isFromTechnologySystems = false;
    this.resetConfiguratorDiscountDataServiceData();
    this.blockUI.start('Loading Discounts Details...');
    this.updateModeAndDiscountID();
    this.getAddDiscountMasterData();
    this.saveAndExitFail = false;
    this.saveAndExitSuccess = false;
    this.fileToUpload = null;
    this.discountAddSubmitFailed = false;
    this.formDataLoaded = false;
    this.saveSubmitResult = '';
    this.addEditMode = false;
    this.viewMode = false;
    this.finalSubmitData = '';
    this.backURL = this.configuratorDiscountDataService.backURL;
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: 'Select One',
      enableSearchFilter: true
    };
    this.multiSelectSettings = {
      singleSelection: false,
      text: 'Select',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      badgeShowLimit: 3,
      maxHeight: 120
    };
  }

  openSubmitSuccessDialog(): void {
    let dialogRef = this.dialog.open(SubmitSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }


  openSaveSuccessDialog(): void {
    let dialogRef = this.dialog.open(SaveSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  openExitErrorDialog(): void {
    let dialogRef = this.dialog.open(ExitFormErrorDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  } 

  resetConfiguratorDiscountDataServiceData() {
    if ((sessionStorage.getItem('isFromBusinessCatalog') === 'true') || (sessionStorage.getItem('isFromTechnologySystems') === 'true')) {
      this.configuratorDiscountDataService.addEditViewDiscountMode = '';
      this.configuratorDiscountDataService.addEditViewDiscountCode = '';
      this.configuratorDiscountDataService.backURL = '';
      
    }
    
    if (sessionStorage.getItem('isFromBusinessCatalog') === 'true') {
      this.isFromBusinessCatalog = true;
    } else if (sessionStorage.getItem('isFromTechnologySystems') === 'true') { 
      this.isFromTechnologySystems = true;
    }

    this.isNotFromBusinessOrTechnology = (this.isFromBusinessCatalog || this.isFromTechnologySystems) ? false : true;

  }

  updateModeAndDiscountID(){
    if (!this.configuratorDiscountDataService.addEditViewDiscountMode) {
      this.configuratorDiscountDataService.addEditViewDiscountMode = sessionStorage.getItem('mode');
    }
    if (!this.configuratorDiscountDataService.addEditViewDiscountCode) {
      this.configuratorDiscountDataService.addEditViewDiscountCode = sessionStorage.getItem('discountId');
    }
    if (!this.configuratorDiscountDataService.backURL) {
      this.configuratorDiscountDataService.backURL = sessionStorage.getItem('backURL');
    }
    sessionStorage.removeItem('mode');
    sessionStorage.removeItem('discountId');
    sessionStorage.removeItem('backURL');
    sessionStorage.removeItem('isFromBusinessCatalog');
    sessionStorage.removeItem('isFromTechnologySystems');
  }


  updatePageMode() {
    if ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit'))) {
        this.addEditMode = true;
        this.viewMode = false;
    }
    else if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'view') {
        this.addEditMode = false;
        this.viewMode = true;
    }
  }

  getAddDiscountMasterData() {
    this.discountService.getAddDiscountMasterData()
      .subscribe(
      data => {
        this.masterData = data;
        this.initializeDiscountFormSubmitData();
        this.populateFormFieldValues();
        this.updatePageMode();
        this.blockUI.stop();
       if (this.addEditDiscountSubmitData.actionStatus === 'SUCCESS') {
          this.configuratorDiscountDataService.addEditViewDiscountCode = this.configuratorDiscountDataService.addEditDiscountSubmitData;
          this.openDialog();
        } else if (this.addEditDiscountSubmitData.actionStatus === 'FAIL') {
          this.showErrorMessage();
        }

      },
      error => {
        console.log('Error :: ' + error);
        this.showErrorMessage();
        this.blockUI.stop();
      }
      );
  }

  getEditDiscountData() {
    this.discountService.getEditDiscountFormData(this.configuratorDiscountDataService.addEditViewDiscountCode)
      .subscribe(
      data => {
          this.configuratorDiscountDataService.addEditDiscountSubmitData = data.discount;
          this.formDataLoaded = true;
          if(this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild == null){
            const discMapInitialObj = {
              'descrBuildId': '',
              'formula': '',
              'amount': '',
              'discountTypeId': 666,
              'videoTierIds': [],
              'dataTierIds': [],
              'phoneTierIds': [],
              'hmLifeTierIds': [],
              'ancillaryFeatureIds': [],
              'equipmentIds': [],
              'installIds': []
            };
            this.addEditDiscountSubmitData.discMapDescrBuild = discMapInitialObj;
            this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild = discMapInitialObj;
          }
          // this.updateDescriptionBuilderMonth(this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapDescrBuild, this.configuratorDiscountDataService.addEditDiscountSubmitData.discMappingEntity); 
          this.addEditDiscountSubmitData = this.configuratorDiscountDataService.addEditDiscountSubmitData;
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  updateDescriptionBuilderMonth(descBuilder, mappingData) {
    if((mappingData) && (mappingData['primaryDuration'])) {
      descBuilder['monthVal'] = mappingData['primaryDuration'];
    }
  }

  submitProject() {
    this.saveSubmitResult = 'submit';
    this.formDataLoaded = false;
    this.blockUI.start('Submitting Discount...');
    if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'add') {
      this.addNewDiscount('submit');
    } else if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit') {
      this.updateExistingDiscount('submit');
    }
  }

  saveAndExit() {
    this.saveSubmitResult = 'save';
    this.formDataLoaded = false;
    this.blockUI.start('Saving Discount...');
    if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'add') {
      this.addNewDiscount('save');
    } else if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit') {
      this.updateExistingDiscount('save');
    }
  }

  addNewDiscount(mode) {
    this.configuratorDiscountDataService.preReqOfferTemplate = this.fileToUpload;
    this.configuratorDiscountDataService.isSubmitted = (mode == 'submit') ? true : false;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.projectCode = this.configuratorDiscountDataService.discountProjectCode;
    if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discountIcoms) {
      this.configuratorDiscountDataService.addEditDiscountSubmitData.discountIcoms.projectCode = this.configuratorDiscountDataService.discountProjectCode;  
    }
    this.finalSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
    this.finalSubmitData.discMapPreRequisite.teCodes = this.configuratorDiscountDataService.teCodes;
    delete this.finalSubmitData.discMapPreRequisite.preReqOfferTemplate;
    // this.removeInvalidPricingRules();
    this.discountService.postAddDiscountDetails(
      this.finalSubmitData, 
      this.configuratorDiscountDataService.preReqOfferTemplate,
      this.configuratorDiscountDataService.isSubmitted
    ).subscribe(
      data => {
        if (data.actionStatus == 'SUCCESS') {
          this.configuratorDiscountDataService.addEditViewDiscountCode = data.discount.discountId;
          this.showSaveSubmitDialog();
        } else if (data.actionStatus == 'FAIL') {
          this.showErrorMessage();
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.showErrorMessage();
        this.blockUI.stop();
        this.formDataLoaded = true;
      }
    );
  }

  updateExistingDiscount(mode) { 
    this.configuratorDiscountDataService.preReqOfferTemplate = this.fileToUpload;
    this.configuratorDiscountDataService.isSubmitted = (mode == 'submit') ? true : false;
    this.configuratorDiscountDataService.addEditDiscountSubmitData.projectCode = this.configuratorDiscountDataService.discountProjectCode;
     if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discountIcoms) {
      this.configuratorDiscountDataService.addEditDiscountSubmitData.discountIcoms.projectCode = this.configuratorDiscountDataService.discountProjectCode;  
     }
    this.finalSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
    this.finalSubmitData.discMapPreRequisite.teCodes = this.configuratorDiscountDataService.teCodes;
    delete this.finalSubmitData.discMapPreRequisite.preReqOfferTemplate;
    // this.removeInvalidPricingRules();
    this.discountService.postAddDiscountDetails(
      this.finalSubmitData, 
      this.configuratorDiscountDataService.preReqOfferTemplate,
      this.configuratorDiscountDataService.isSubmitted
    ).subscribe(
      data => {
        if (data.actionStatus == 'SUCCESS') {
          this.configuratorDiscountDataService.addEditViewDiscountCode = data.discount.discountId;
          this.showSaveSubmitDialog();
        } else if (data.actionStatus == 'FAIL') {
          this.showErrorMessage();
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.showErrorMessage();
        this.blockUI.stop();
      }
    );
  }  

  populateFormFieldValues() {
    for (let i = 0; i < this.masterData.commonMasterData.length; i++) {
      const currentMasterData = this.masterData.commonMasterData[i];
      const keyName = currentMasterData.name.replace(/\s+/g, '_');
      this.discountFormDropDown[keyName] = currentMasterData.records;
    }
    this.discountFormDropDown['teCodeResponse'] = this.masterData['teCodeResponse'];
    this.discountFormDropDown['campaignCodesList'] = this.masterData['campaignCodesList'];
    this.discountFormDropDown['priceMethodMasterDataList'] = this.masterData['priceMethodMasterDataList'];
    this.discountFormDropDown['marketMasterMap'] = this.masterData.siteCodeMasterMap;
    this.discountFormDropDown['PROJECT'] = this.masterData.projectNamesList[0]['records'];
    this.discountFormDropDown['MARKETS'] = [];
    for (let prop in this.discountFormDropDown['marketMasterMap']) {
      this.pushMarketsData(this.discountFormDropDown['marketMasterMap'][prop]); 
    }
    this.configuratorDiscountDataService.discountMasterData = this.discountFormDropDown;
    if (this.configuratorDiscountDataService.addEditViewDiscountMode === 'add') {
      this.formDataLoaded = true;
    }
  }

  pushMarketsData(markets) {
    for(let i=0; i<markets.length; i++) {
      this.discountFormDropDown['MARKETS'].push(markets[i]);
    }
  }

  removeInvalidPricingRules() {
    this.finalSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
    let result = [];
    // this.finalSubmitData.pricingRules.shift();
    for (let i=0; i<this.finalSubmitData.pricingRules.length; i++) {
      let resultObj = {};
      let currentPricingRule = this.finalSubmitData.pricingRules[i];
      if ((typeof currentPricingRule.pricingCategoryName == 'undefined') || ((currentPricingRule.pricingCategoryName == '') && (currentPricingRule.presentationCodeId == '') && (currentPricingRule.pricebookChrgIcomscodeDesc == ''))) {
        delete this.finalSubmitData.pricingRules[i];
        continue;
      } 
      delete this.finalSubmitData.pricingRules[i].pricingCategoryDropDownList;
      delete this.finalSubmitData.pricingRules[i].statementPresentationCodeDropDownList;
      delete this.finalSubmitData.pricingRules[i].priceBookICOMSCodeDropDownList;
      delete this.finalSubmitData.pricingRules[i].priceBookICOMSCodeDropDownList;
      if ((typeof this.finalSubmitData.pricingRules[i].priceBookICOMSCodeSelectedItems !=='undefined') && (this.finalSubmitData.pricingRules[i].priceBookICOMSCodeSelectedItems.length > 0)) {
        this.finalSubmitData.pricingRules[i].pricebookChrgIcomscodeDesc = JSON.parse(JSON.stringify(this.finalSubmitData.pricingRules[i].priceBookICOMSCodeSelectedItems[0].itemName));
        this.finalSubmitData.pricingRules[i].priceBookDetId = JSON.parse(JSON.stringify(this.finalSubmitData.pricingRules[i].priceBookICOMSCodeSelectedItems[0].id));
      } else {
        this.finalSubmitData.pricingRules[i].pricebookChrgIcomscodeDesc = '';
        this.finalSubmitData.pricingRules[i].priceBookDetId = null;
      }
     
      delete this.finalSubmitData.pricingRules[i].priceBookICOMSCodeSelectedItems;
      delete this.finalSubmitData.pricingRules[i].pricingCategorySelectedItems;
      delete this.finalSubmitData.pricingRules[i].statementPresentationCodeSelectedItems;
      delete this.finalSubmitData.pricingRules[i].pricingRulesObjAssociated;
      delete this.finalSubmitData.pricingRules[i].markets;
      delete this.finalSubmitData.pricingRules[i].descriptionBuilderAmount;
      delete this.finalSubmitData.pricingRules[i].pricingMethod;
      this.finalSubmitData.pricingRules[i]['absorb'] = (this.finalSubmitData.pricingRules[i]['absorb'] === '') ? 'No' : this.finalSubmitData.pricingRules[i]['absorb'];
      this.finalSubmitData.pricingRules[i]['activeService'] = (this.finalSubmitData.pricingRules[i]['activeService'] === '') ? 'No' : this.finalSubmitData.pricingRules[i]['activeService'];
      this.finalSubmitData.pricingRules[i]['fixedPricing'] = Number(this.finalSubmitData.pricingRules[i]['fixedPricing']);
      this.finalSubmitData.pricingRules[i]['amtFrstBundleDiscount'] = Number(this.finalSubmitData.pricingRules[i]['amtFrstBundleDiscount']);
      this.finalSubmitData.pricingRules[i]['amtMinReqPricingCatg'] = Number(this.finalSubmitData.pricingRules[i]['amtMinReqPricingCatg']);
      this.finalSubmitData.pricingRules[i]['campaignDollarOff'] = Number(this.finalSubmitData.pricingRules[i]['campaignDollarOff']);
      this.finalSubmitData.pricingRules[i]['numOccurnceDiscount'] = Number(this.finalSubmitData.pricingRules[i]['numOccurnceDiscount']);
      this.finalSubmitData.pricingRules[i]['numOfMnths'] = Number(this.finalSubmitData.pricingRules[i]['numOfMnths']);
      for (let j=0; j<this.finalSubmitData.pricingRules[i]['pricingRuleSites'].length; j++) {
        const currentPricingRulesSites = JSON.parse(JSON.stringify(this.finalSubmitData.pricingRules[i]['pricingRuleSites'][j]));
        this.finalSubmitData.pricingRules[i]['pricingRuleSites'][j]['site'] = currentPricingRulesSites['site'];
        this.finalSubmitData.pricingRules[i]['pricingRuleSites'][j]['siteId'] = Number(currentPricingRulesSites['siteId']);
        this.finalSubmitData.pricingRules[i]['pricingRuleSites'][j]['amount'] = Number(currentPricingRulesSites['amount']);
      }
      if (this.finalSubmitData.pricingRules[i]) {
        result.push(this.finalSubmitData.pricingRules[i]);
      }
    }
    this.finalSubmitData.pricingRules = [];
    this.finalSubmitData.pricingRules = result;
    this.finalSubmitData.discMapPreRequisite.teCodes = this.configuratorDiscountDataService.teCodes;
    delete this.finalSubmitData.discMapPreRequisite.preReqOfferTemplate;
  }


  onFileUpload(fileUpload: any): void {
    this.fileToUpload = fileUpload;
  }

  showErrorMessage() {
    if (this.saveSubmitResult == 'submit') {
      this.discountAddSubmitFailed = true;
    } else if (this.saveSubmitResult == 'save') {
      this.saveAndExitFail = true;
    }
  }

  showSaveSubmitDialog() {
    if (this.saveSubmitResult  == 'submit') {
      this.openSubmitSuccessDialog();
    } else if (this.saveSubmitResult == 'save') {
      this.openSaveSuccessDialog();
    }
  }

  validateIntakeForm() {
    let disableBtn = true;
    let validFormFields = ['startDate', 'endDate'];
    if (this.configuratorDiscountDataService.addEditViewDiscountMode == 'edit') {
      validFormFields.push('projectCode');
     }
    if (this.configuratorDiscountDataService.addEditDiscountSubmitData.discountCode && this.configuratorDiscountDataService.addEditDiscountSubmitData.description && this.configuratorDiscountDataService.addEditDiscountSubmitData.version && this.configuratorDiscountDataService.addEditDiscountSubmitData.startDate && this.configuratorDiscountDataService.addEditDiscountSubmitData.endDate) {
      disableBtn = false;
    }
    return disableBtn;
    // return true;
  }

  initializeDiscountFormSubmitData() {
    this.discountFormDropDown = {
      'VIDEO_TIERS': [],
      'PHONE_TIERS': [],
      'HOMELIFE_TIERS': [],
      'ANCILLARY': [],
      'EQUIPMENT': [],
      'INSTALL': [],
      'GIFT_VALIDATION_STATUS': [],
      'OFFER_FAMILY': [],
      'FINANCE_BUCKET_CD': [],
      'PROGRAM_NM': [],
      'CUSTOMER_TARGET': [],
      'CAMPAIGN_TYPE': [],
      'CAMPAIGN_SUBTYPE': [],
      'SA_TYPE_REQUIRED': [],
      'INSTALL_INCLUDED': [],
      'PRODUCT': [],
      'OSCAR_STATUS': [],
      'FINANCE_BUCKET_PROG_CD': [],
      'SPCL_HANDLING_INSTRUCTIONS': [],
      'MARGIN_BUCKET': [],
      'MARKETING_ID_DESC': [],
      'MP_NEW_EXISTING': [],
      'MP_OFFER_PRODUCT': [],
      'MP_OFFER_TYPE': [],
      'MP_TARGETED_AUDIENCE': [],
      'MP_INSTALLATION_TPR': [],
      'ONLINE_STATUS': [],
      'PRICING_CATEGORY': [],
      'PRESENTATION_CODE': [],
      'MARKETING_ID': [],
      'ICOMS_STATUS': [],
      'IT_PEER_REVIWED': [],
      'IT_ASSIGNED_TO': [],
      'DISCOUNT_TYPES': [],
      'DATA_TIRES': [],
      'MIN_VIDEO_TIER': [],
      'MIN_DATA_TIER': [],
      'MIN_PHONE_TIER': [],
      'MIN_HOME_LIFE_TIER': [],
      'MARKETS': [],
      'MARKETSObj': [],
      'SITESObj': [],
      'TECODERESPONSE': [],
      'PRICING_METHOD': [],
      'DISCOUNT_SUB_TYPE': [],
      'Parent_Discount_Code': [],
      'Replacing_Discount_Code': [],
      'Project': []
    };
    this.addEditDiscountSubmitData = {
      'discountId': null,
      'createdByUser': '',
      'createdDate': '',
      'description': '',
      'discountCode': '',
      'endDate': '',
      'modifiedDate': '',
      'notes': '',
      'startDate': '',
      'version': '',
      'offerSeries': '',
      'sites': [],
      'projectCode': this.configuratorDiscountDataService.discountProjectCode,
      'type': '',
      'status': 1024,
      'parentCampaignId': null,
      'replacingCampaignId': null,
      'failedSelfInstalledCredit': '',
      'endDateLastChange': '',
      'selfInstallIncentive': '',
      'active': false,
      'future': false,
      'projectId': null,
      'reviewBeforeExpirationStatusId': null,
      'discMapDescrBuild': this.getInitialDescriptionBuilder(),
      'discountGift': this.getIntialGiftCard(),
      'discMapPriceMethod': this.getPricingMethod(),
      'discMappingEntity': this.getMappingEntity(),
      'discMapOscar': this.getOscar(),
      'discMapMainPage': this.getMainPage(),
      'discMapOnline': this.getOnline(),
      'discMapPreRequisite': this.getPreReq(),
      'pricingRules': this.getPricingRules()
    };
    this.configuratorDiscountDataService.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.addEditDiscountSubmitData));
    if ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'edit') || (this.configuratorDiscountDataService.addEditViewDiscountMode === 'view')) {
        this.getEditDiscountData();
    }
  }

  getInitialDescriptionBuilder() {
    return {
      'descrBuildId': '',
      'formula': '',
      'amount': '',
      'discountTypeId': 666,
      'videoTierIds': [],
      'dataTierIds': [],
      'phoneTierIds': [],
      'hmLifeTierIds': [],
      'ancillaryFeatureIds': [],
      'equipmentIds': [],
      'installIds': []
    };
  }

  getIntialGiftCard() {
    return {
      'discountMapGiftId': null,
      'cardId': null,
      'giftcardAmount': '',
      'included': false,
      'validationStatusId': null,
      'notes': ''
    }
  }

  getPricingMethod() {
    return {
      'priceMethodId': null,
      'methodId': null,
      'methodAttributes': []
    };
  }

  getMappingEntity() {
    return {
      'mappingId': null,
      'discount': '',
      'marketName': '',
      'mrc': '',
      'numberOfPsu': '',
      'primaryDuration': '',
      'psuRequired': '',
      'retailRate': '',
      'secondryDuration': '',
      'secondryStepupAmount': '',
      'financeBucketCdId': null,
      'programNmId': null,
      'customerTargetId': null,
      'campaignTypeId': null,
      'campaignSubTypeId': null,
      'minDataTierId': null,
      'minPhoneTierId': null,
      'minHomeLifeTierId': null,
      'productId': null,
      'saTypeRequiredId': null,
      'installIncludeId': null,
      'offerFamilyId': null,
      'minVideoTierId': null
    };
  }

  getOscar() {
    return {
      'oscarId': null,
      'statusId': null,
      'createdDate': '',
      'financeBucketProgCdId': null,
      'salesAdvise': '',
      'adviceFormula': '',
      'saRequired': '',
      'mrktId': null
    };
  }

  getMainPage() {
    return {
      'mainPageId': null,
      'mpMarkets': '',
      'mpNotes': '',
      'mpOffer': '',
      'mpOfferDetailsRestrict': '',
      'mpSalesChannel': '',
      'showMainpageFlg': false,
      'mpOfferProductId': null,
      'mpTargetedAudienceId': null,
      'mpInstallationTprId': null,
      'mpNewExistingId': null,
      'mpOfferTypeId': null,
      'channelIds': [],
      'tacticIds': []
    }
  }

  getOnline() {
    return {
      'discOnlineMapId': null,
      'disclaimer': '',
      'ecomPromoCode': '',
      'savingsSticker': '',
      'uptierValues': '',
      'onlineStatusId': null
    };
  }


  getPreReq() {
    return {
      'preReqId': null,
      'cmpgnCdAIncIfOne': '',
      'cmpgnCdDExcIfAny': '',
      'cmpgnCdNumOfDays': '',
      'cmpgnLongDescr': '',
      'curntSrvcAIncIfOne': '',
      'curntSrvcBIncIfAll': '',
      'curntSrvcCIncIfAtlst': '',
      'curntSrvcCOfThese': '',
      'curntSrvcDExcIfAny': '',
      'curntSrvcEExcIfAll': '',
      'curntSrvcFExcIfAtlst': '',
      'curntSrvcFOfThese': '',
      'icomsAccessList1': '',
      'icomsAccessList2': '',
      'icomsAccessList3': '',
      'icomsAccessList4': '',
      'icomsAccessList5': '',
      'icomsAccessList6': '',
      'instlSrvcAIncIfOne': '',
      'instlSrvcBIncIfAll': '',
      'instlSrvcCIncIfAtlst': '',
      'instlSrvcCOfThese': '',
      'instlSrvcDExcIfAny': '',
      'instlSrvcEExcIfAll': '',
      'instlSrvcFExcIfAtlst': '',
      'instlSrvcFOfThese': '',
      'mrktIdAIncIfOne': '',
      'mrktIdDExcIfAny': '',
      'otherInsrct': '',
      'plgInstlAIncIfOne': '',
      'plgInstlBIncIfAll': '',
      'plgInstlDExcIfAny': '',
      'plgRetnAIncIfOne': '',
      'plgRetnDExcIfAny': '',
      'retnSrvcAIncIfOne': '',
      'retnSrvcBIncIfAll': '',
      'retnSrvcCIncIfAtlst': '',
      'retnSrvcCOfThese': '',
      'retnSrvcDExcIfAny': '',
      'retnSrvcEExcIfAll': '',
      'retnSrvcFExcIfAtlst': '',
      'retnSrvcFOfThese': '',
      'preReqIcomsDataBlob': null,
      'teCodes': []
    };
  }

  getPricingRules() {
    return [{
      'codepricingRulesId': null,
      'absorb': 'No',
      'activeService': 'No',
      'amtFrstBundleDiscount': 0,
      'amtMinReqPricingCatg': 0,
      'bundleDiscount': false,
      'campaignDollarOff': 0,
      'fixedPricing': 0,
      'minRequirmnt': false,
      'numOccurnceDiscount': 0,
      'numOfMnths': 0,
      'other': '',
      'pricebookChrgIcomscodeDesc': '',
      'pricebookChrgReltdIcomscode': '',
      'pricebookEndDate': '',
      'pricebookStartDate': '',
      'presentationCodeId': '',
      'pricingCategoryName': '',
      'pricingRuleSites': []
    }];
  }

  returnBack() {
    
    if (((this.configuratorDiscountDataService.addEditViewDiscountMode === 'add') || (this.configuratorDiscountDataService.addEditViewDiscountMode === 'edit')) && (this.configuratorDiscountDataService.isAddEditDiscountModified)) {
      this.openExitErrorDialog();
    } else {
      this.configuratorDiscountDataService.addEditViewDiscountCode = null;
    this.configuratorDiscountDataService.addEditViewDiscountMode= null;
    this.configuratorDiscountDataService.backURL = null;
      this.router.navigate([this.backURL]);
    }
  }


  redirectTo(url) {
    if (this.configuratorDiscountDataService.isAddEditDiscountModified) {
      this.openExitErrorDialog();
    } else {
      this.configuratorDiscountDataService.addEditViewDiscountCode = null;
      this.configuratorDiscountDataService.addEditViewDiscountMode= null;
      this.configuratorDiscountDataService.backURL = null;
      this.router.navigate([url]);
    }
  }

}

@Component({
  selector: 'plm-discount-confirmation-dialog',
  templateUrl: './discount-confirmation-dialog.html'
})
export class DialogOverviewExampleDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialogComponent>,
    private configuratorDiscountDataService: ConfiguratorDiscountDataService,  
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      dialogRef.disableClose = true;
     }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDashboard() {
    this.dialogRef.close();
    this.router.navigate([this.configuratorDiscountDataService.backURL]);
  }

}



@Component({
  selector: 'plm-discount-submit-success-dialog',
  templateUrl: '../discount-details/discount-submit-success-dialog.html'
})
export class SubmitSuccessDialogComponent {
  private discountCode: String;
  constructor(
    public dialogRef: MatDialogRef<SubmitSuccessDialogComponent>, private router: Router, private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.discountCode = this.configuratorDiscountDataService.addEditViewDiscountCode;
    dialogRef.disableClose = true;

  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorDiscountDataService.addEditViewDiscountCode = '';
    this.configuratorDiscountDataService.addEditViewDiscountMode = '';
    this.configuratorDiscountDataService.isAddEditDiscountModified = false;
    this.router.navigate([this.configuratorDiscountDataService.backURL]);
  }

}


@Component({
  selector: 'plm-discount-save-success-dialog',
  templateUrl: '../discount-details/discount-save-success-dialog.html'
})
export class SaveSuccessDialogComponent {
  private discountCode: String;
  constructor(
    public dialogRef: MatDialogRef<SaveSuccessDialogComponent>, private router: Router, private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.discountCode = this.configuratorDiscountDataService.addEditViewDiscountCode;
    dialogRef.disableClose = true;
  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorDiscountDataService.addEditViewDiscountCode = '';
    this.configuratorDiscountDataService.addEditViewDiscountMode = '';
    this.configuratorDiscountDataService.isAddEditDiscountModified = false;
    this.router.navigate([this.configuratorDiscountDataService.backURL]);
  }

}

@Component({
  selector: 'plm-discount-exit-form-error-dialog',
  templateUrl: '../discount-details/discount-exit-form-error-dialog.html'
})
export class ExitFormErrorDialogComponent {
  private discountCode: String;
  constructor(
    public dialogRef: MatDialogRef<ExitFormErrorDialogComponent>, private router: Router, private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.discountCode = this.configuratorDiscountDataService.addEditViewDiscountCode;
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorDiscountDataService.addEditViewDiscountCode = '';
    this.configuratorDiscountDataService.addEditViewDiscountMode = '';
    this.configuratorDiscountDataService.isAddEditDiscountModified = false;
    this.configuratorDiscountDataService.addEditViewDiscountCode = null;
    this.configuratorDiscountDataService.addEditViewDiscountMode= null;
    let backUrl = this.configuratorDiscountDataService.backURL;
    this.configuratorDiscountDataService.backURL = null;
    this.router.navigate([backUrl]);
  }

  cancelExit() {
    this.dialogRef.close();
  }



}
