import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyDiscountComponent } from './modify-discount.component';

describe('ModifyDiscountComponent', () => {
  let component: ModifyDiscountComponent;
  let fixture: ComponentFixture<ModifyDiscountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyDiscountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyDiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
