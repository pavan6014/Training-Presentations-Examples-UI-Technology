import {
  AddProjectMasterData,
  IntakeRequestForm,
  IntakeRequestFormIntakeForm,
  IntakeRequestMasterData,
  ProjectMasterModel
} from '../../../requestor/requestor.interface';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';

import { ConfiguratorDiscountDataService } from '../../discount/services/configurator-discount-data.service';
import { RequestorDataService } from '../../../requestor/services/requestor-data.service';
import { RequestorService } from '../../../requestor/services/requestor.service'
import { Router } from '@angular/router';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-intake-request-details',
  templateUrl: './intake-request-details.component.html',
  styleUrls: ['./intake-request-details.component.css'],
    providers: [RequestorService, UtilitiesService]
})
export class IntakeRequestDetailsComponent implements OnInit {
  private addEditMode: string;
  private capitalizedAddEdiitMode: string;
  private addEditIntakeRequestProjectID: String;
  private discountProjectCode: String;
  private intakeRequestSubmitFailed: Boolean;
  private saveAndExitSuccess: Boolean;
  private saveAndExitFail: Boolean;
  private addEditIntakeRequestForm: IntakeRequestForm;
  private addEditIntakeRequestMasterData: IntakeRequestMasterData;
  private fileToUpload: any;

  constructor(private configuratorDiscountDataService:ConfiguratorDiscountDataService, private router: Router, private requestorService: RequestorService, private requestorDataService: RequestorDataService, private utilitiesService: UtilitiesService) {
    this.getAddEditIntakeRequestMasterData();
    this.addEditMode = 'view';
    this.discountProjectCode = this.configuratorDiscountDataService.discountProjectCode;
    this.addEditIntakeRequestProjectID = this.configuratorDiscountDataService.discountProjectCode;
    this.capitalizedAddEdiitMode = this.utilitiesService.capitalizeFirstLetter(this.addEditMode);
    this.intakeRequestSubmitFailed = false;
    this.saveAndExitFail = false;
    this.saveAndExitSuccess = false;
    this.intializeIntakeRequestForm();
    // if (this.addEditMode != 'add') {
      this.fetchEditProjectData();
    // }
    this.fileToUpload = null;
   }

  ngOnInit() {
  }

   getAddEditIntakeRequestMasterData() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.requestorDataService.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (let prop in this.addEditIntakeRequestMasterData['marketMasterMap']) {
          this.pushMarketsData(this.addEditIntakeRequestMasterData['marketMasterMap'][prop]); 
        }
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }


  pushMarketsData(markets) {
    for(let i=0; i<markets.length; i++) {
      this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
    }
  }

  intializeIntakeRequestForm() {
    this.addEditIntakeRequestForm = {
      'isSubmitted': 0,
      'projectMasterModel': this.intializeIntakeProjectMasterModel()
    }
    this.requestorDataService.addEditIntakeRequestForm = this.addEditIntakeRequestForm;
  }
  
  intializeIntakeProjectMasterModel() {
    let intakeRequestMasterForm: any;
    intakeRequestMasterForm = {
      'projectCode': '',
      'projectTypeId': '',
      'projectStartDt': '',
      'projectEndDt': '',
      'intakeReqName': '',
      'intakeRequestStatusId': '',
      'pricingOwnerId': [],
      'requesterName': '',
      'pricingOwnerNotes': '',
      'requesterEmail': '',
      'trgtAudienceId': '',
      'popsNotes': '',
      'channelIds': [],
      'categoryId': '',
      'addUptierPaths': '',
      'productIds': [],
      'priorityId': '',
      'sites': [],
      'description': '',
      'uploadIntakeRequestDoc': null,
      'uploadIntakeRequestDocId': '',
      'uploadIntakeRequestDocName': '',
      'intakeFormReqTxnDetModel': this.intializeIntakeRequestFormIntakeForm()
    };
    return intakeRequestMasterForm;
  }

  intializeIntakeRequestFormIntakeForm() {
    let intakeRequestIntakeForm: IntakeRequestFormIntakeForm;
    intakeRequestIntakeForm = {
      'campCodeIds': [],
      'stepupDuratnId': '',
      'stepupAmount': '',
      'discountStartDate': '',
      'discountExpireDate': '',
      'durationMonths': '',
      'requirePlgId': '',
      'prodMustInc': '',
      'prodMustExc': '',
      'prodMustRetainInc': '',
      'prodMustRetainExc': '',
      'instltnIncFlg': false,
      'instltnIncFlgVal': false,
      'instltnPricing': '',
      'prodMustInstlExc': '',
      'tireqIds': []
    };
    return intakeRequestIntakeForm
  }

  fetchEditProjectData() {
    this.requestorService.getEditProjectData(this.addEditIntakeRequestProjectID).subscribe(
      data => {
        this.addEditIntakeRequestForm = data;
        this.requestorDataService.addEditIntakeRequestForm = this.addEditIntakeRequestForm;
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  redirectBack(url) {
    if (this.requestorDataService.isAddEditIntakeRequestFormModified) {
      
      return;
    }
    this.router.navigate([url]);
  }

  showErrorMessage(mode) {
    if (mode == 'submit') {
      this.intakeRequestSubmitFailed = true;
    } else if (mode == 'save') {
      this.saveAndExitFail = true;
    }
  }

  
  validateIntakeForm() {
  
    let disableBtn = true;
    let validFormFields = ['projectStartDt', 'projectEndDt'];
    if (this.requestorDataService.addEditViewIntakeRequestMode == 'edit') {
     validFormFields.push('projectCode');
    }
    if (this.requestorDataService.addEditIntakeRequestForm.projectMasterModel.projectStartDt && this.requestorDataService.addEditIntakeRequestForm.projectMasterModel.projectEndDt) {
      disableBtn = false
    }
    return disableBtn;
  }
  onFileUpload(fileUpload: any): void{
    this.fileToUpload = fileUpload;
 }

}

