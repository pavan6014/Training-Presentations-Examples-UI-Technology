import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';
import { FetchAllIntakeRequest, IntakeRequestMasterData } from '../../../requestor/requestor.interface';
import { GetDiscountProjectList, GetDiscountProjectListResponse } from '../discount-project-list/discount-project-list';

import { ConfiguratorDiscountDataService } from '../services/configurator-discount-data.service';
import { DiscountProjectListService } from '../discount-project-list/discount-project-list.service';
import { DiscountService } from '../discount-details/discount.service';
import { NgForm } from '@angular/forms';
import { RequestorService } from '../../../requestor/services/requestor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'plm-discount-project-list',
  templateUrl: './discount-project-list.component.html',
  styleUrls: ['./discount-project-list.component.css'],
  providers: [RequestorService, DiscountProjectListService, DiscountService]
})

export class DiscountProjectListComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private addEditIntakeRequestMasterData: IntakeRequestMasterData;
  private filterContext: any;
  private filterByProjectCode: string;
  private filterByRequestName: string;
  private filterByProjectType: string;
  private filterByPricingOwnerName: string;
  private filterByDescription: string;
  private filterByRequesterName: string;
  private filterByStatus: string;
  private filterBypriority:string;
  private filterByCreatedDate: string;
  private filterByProjectCodeSearchObj: any;
  private filterByRequestNameSearchObj: any;
  private filterByProjectTypeSearchObj: any;
  private filterByPricingOwnerNameSearchObj: any;
  private filterByDescriptionSearchObj: any;
  private filterByRequesterNameSearchObj: any;
  private filterByStatusSearchObj: any;
  private filterByprioritySearchObj: any;
  private filterByCreatedDateSearchObj: any;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private showIntakeRequestList: Boolean;
  private intakeRequestDetails: FetchAllIntakeRequest[];
  private popstatusForRelease: number[];
  private discountList: any[];
  private selectedAll: boolean;
  private discountIdSelected: Boolean;
  private isNotPopsChecked: boolean;
  private popsSaveFailed: boolean;
  private popstatusForReleaseString: string;

  constructor(
    private requestorService: RequestorService, 
    private createDiscountService: DiscountProjectListService, 
    private router: Router, 
    private configuratorDiscountDataService: ConfiguratorDiscountDataService, 
    public dialog: MatDialog
  ) {
    this.blockUI.start('Loading Discount Project List...');
    this.intakeRequestDetails = [];
    this.getDiscountProjectList();
    this.getAddEditIntakeRequestMasterData();
    this.filterContext = '';
    this.filterByProjectCode = '';
    this.filterByRequestName = '';
    this.filterByProjectType = '';
    this.filterByPricingOwnerName = '';
    this.filterByDescription = '';
    this.filterByRequesterName = '';
    this.filterByStatus = '';
    this.filterBypriority= '';
    this.filterByCreatedDate = '';
    this.filterByProjectCodeSearchObj = '';
    this.filterByRequestNameSearchObj = '';
    this.filterByProjectTypeSearchObj = '';
    this.filterByPricingOwnerNameSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    this.filterByRequesterNameSearchObj = '';
    this.filterByStatusSearchObj = '';
    this.filterByprioritySearchObj = '';
    this.filterByCreatedDateSearchObj = '';
    this.showIntakeRequestList = false;
    this.popstatusForRelease = [];
    this.discountList = [];
    this.selectedAll = false;
    this.discountIdSelected = false;
    this.isNotPopsChecked = true;
    this.popsSaveFailed = false;
    this.popstatusForReleaseString = '';
  }

  ngOnInit() {
    this.getDiscountProjectList();
  }

  getDiscountProjectList() {
    this.createDiscountService.getDiscountProjectList()
      .subscribe(
      data => {
        this.intakeRequestDetails = data.projectMasterFetchAll;
        this.initializeFilterContext();
        this.checkToShowIntakeRequestList();
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }


  getAddEditIntakeRequestMasterData() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.checkToShowIntakeRequestList();
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  checkToShowIntakeRequestList() {
    if ((typeof this.addEditIntakeRequestMasterData !== 'undefined') && (typeof this.intakeRequestDetails !== 'undefined')) {
      this.showIntakeRequestList = true;
      this.blockUI.stop();
    } else {
      this.showIntakeRequestList = false;
    }
  }

  initializeFilterContext() {
    this.filterByProjectCodeSearchObj = {
      'projectCode': {
        'type': 'text',
        'value': this.filterByProjectCode,
        'matchFullCase': false
      }
    };
    this.filterByProjectTypeSearchObj = {
      'projectType': {
        'type': 'text',
        'value': this.filterByProjectType,
        'matchFullCase': true
      }
    };
    this.filterByPricingOwnerNameSearchObj = {
      'pricingOwners': {
        'type': 'array',
        'value': this.filterByPricingOwnerName,
        'matchFullCase': false
      }
    };
    this.filterByDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByDescription,
        'matchFullCase': false
      }
    };
    this.filterByRequesterNameSearchObj = {
      'requesterName': {
        'type': 'text',
        'value': this.filterByRequesterName,
        'matchFullCase': false
      }
    };
    this.filterByStatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterByStatus,
        'matchFullCase': true
      }
    };
    this.filterByCreatedDateSearchObj = {
      'createdDate': {
        'type': 'date',
        'value': this.filterByCreatedDate,
        'matchFullCase': true
      }
    };
    this.filterByprioritySearchObj = {
      'priority': {
        'type': 'text',
        'value': this.filterBypriority,
        'matchFullCase': false
      }
    };
    this.filterByRequestNameSearchObj = {
      'intakeReqName': {
        'type': 'text',
        'value': this.filterByRequestName,
        'matchFullCase': false
      }
    };
  }
 
  redirectTo(url) {
    this.router.navigate([url]);
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  getDateInFormat(date) {
    const currentDate = new Date(date);
    const result = ("0" + (currentDate.getDate() + 1)).slice(-2) + '/' + ("0" + (currentDate.getMonth() + 1)).slice(-2) + '/' + currentDate.getFullYear();
    return result;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  
  // selectDeselctAllPopstatus(isChecked) {
  //   this.popstatusForRelease = [];
  //   for (let i = 0; i < this.configuratorProjectList.length; i++) {
  //    // this.discountList[i]['checked'] = false;
  //     if ((isChecked) && (this.configuratorProjectList[i]['status'] === 'Submitted')) {
  //       this.discountList[i]['checked'] = isChecked;
  //       this.popstatusForRelease.push(this.configuratorProjectList[i]['projectCode']);
  //     }
  //   }
  //   this.updateDiscountTable(isChecked);
  // }

  popstatusForModify(isChecked, projectCode) {
    for (let i = 0; i < this.intakeRequestDetails.length; i++) {
      if ((this.intakeRequestDetails[i]['projectCode'] === projectCode)){
        this.intakeRequestDetails[i]['checked'] = isChecked;
        this.updatePopstatusForRelease(isChecked, projectCode);
      }
    }
    this.showHideSaveButton();
  }

  updatePopstatusForRelease(isChecked, projectCode) {
    if (isChecked) {
      this.popstatusForRelease.push(projectCode);
    } else {
      let result = [];
      for (let i=0; i<this.popstatusForRelease.length; i++) {
        if (this.popstatusForRelease[i] !== projectCode) {
          result.push(this.popstatusForRelease[i]);
        }
      }
      this.popstatusForRelease = result;
    }
    this.isNotPopsChecked = this.showHideSaveButton();
  }

  showHideSaveButton() {
    let result = true;
    result = (this.popstatusForRelease.length > 0) ? false : true;
    return result;
  }

  submitPopupProjects() {
    this.blockUI.start('Submitting Pops Projects...');
    let reqObj = {
      'discPopStatus': true,
      'offerPopStatus': false,
      'projectCode': this.popstatusForRelease
    };
    this.popsSaveFailed = false;
    this.createDiscountService.savePopsProjects(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus == 'SUCCESS') {
            this.popstatusForReleaseString = data.projectCode.join(', ');
            this.configuratorDiscountDataService.discountListForSavePop = this.popstatusForReleaseString;
            this.openSaveSuccessDialog();
            this.blockUI.stop();
          } else if (data.actionStatus == 'FAIL') {
            this.showPopSaveError();
          }
        },
        error => {
          this.showPopSaveError();
          console.log("Error :: " + error)
        }
      );
  }

  showPopSaveError() {
    this.popsSaveFailed = true;
    this.blockUI.stop();
  }


  // moveToDiscountCodeGrid(projectCode, projectStatus) {
  //   this.configuratorDiscountDataService.discountProjectCode = projectCode;
  //   this.configuratorDiscountDataService.projectStatus = projectStatus;
  //   this.router.navigate(['/plm-work-flow/configurator/discount/discount-code-list']);
  // }

  
  moveToDiscountCodeGrid(projectCode,projectType) {
    this.configuratorDiscountDataService.discountProjectCode = projectCode;
    this.configuratorDiscountDataService.projectType = projectType;
    if  ((projectType  ==  'New Offer Creation') || (projectType  ==  'New TE Code Creation')) {
      this.router.navigate(['/plm-work-flow/configurator/discount/discount-code-list']);
    } else  if  (projectType  ==  'Offer Modification') {
      this.router.navigate(['/plm-work-flow/configurator/discount/modify-discount']);
    }
  }

  returnBack() {
    this.router.navigate(['']);
  }

  openSaveSuccessDialog(): void {
    let dialogRef = this.dialog.open(PopsSaveSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.popstatusForRelease = [];
      this.popstatusForReleaseString = '';
      this.blockUI.start('Loading Discount Project List...');
      this.intakeRequestDetails = [];
      this.getDiscountProjectList();
    });
  }


}

@Component({
  selector: 'plm-discount-save-success-dialog',
  templateUrl: './discount-submit-success-dialog.html'
})
export class PopsSaveSuccessDialogComponent {
  private discountCodes: string;
  constructor(
    public dialogRef: MatDialogRef<PopsSaveSuccessDialogComponent>,
    private router: Router,
    private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.discountCodes = this.configuratorDiscountDataService.discountListForSavePop;
    dialogRef.disableClose = true;
  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorDiscountDataService.discountListForSavePop = '';
  }

}



