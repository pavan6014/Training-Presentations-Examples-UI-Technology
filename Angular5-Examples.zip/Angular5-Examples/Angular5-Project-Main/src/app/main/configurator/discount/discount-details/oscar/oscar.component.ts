import { Component, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import { ConfiguratorDiscountDataService } from '../../services/configurator-discount-data.service';
import { DiscMapOscar } from '../discount-interface';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';

@Component({
    selector: 'plm-oscar',
    templateUrl: './oscar.component.html',
    styleUrls: ['./oscar.component.css'],
    providers: [UtilitiesService]
})
export class OscarComponent implements OnInit, OnChanges {

    // @Input() masterData: any;
    // @Input() addEditDiscountSubmitData: any;

    private masterData: any;
    private addEditDiscountSubmitData: any;

    private addEditMode: Boolean;
    private viewMode: Boolean;
    private singleSelectSettings = {};
    private multiSelectSettings = {};
    private oscarStatusDropDownList = [];
    private financeBucketProgramCodeDropDownList = [];
    private marketingIDDropDownList = [];
    private oscarStatusSelectedItems = [];
    private financeBucketProgramCodeSelectedItems = [];
    private marketingIDSelectedItems = [];
    private marketingIDs: string;
    private ccSalesAdviceFormula: string;

    private prereqDiscountLongInstruction: string;
    private prereqDiscountInstallA: string;
    private prereqDiscountInstallB: string;
    private prereqDiscountInstallCAtleast: string;
    private prereqDiscountInstallCAll: string;
    private prereqDiscountInstallD: string;
    private prereqDiscountInstallE: string;
    private prereqDiscountInstallFAtleast: string;
    private prereqDiscountInstallFAll: string;

    private prereqDiscountCurrentA: string;
    private prereqDiscountCurrentB: string;
    private prereqDiscountCurrentCAtleast: string;
    private prereqDiscountCurrentCAll: string;
    private prereqDiscountCurrentD: string;
    private prereqDiscountCurrentE: string;
    private prereqDiscountCurrentFAtleast: string;
    private prereqDiscountCurrentFAll: string;

    private prereqDiscountRetentionA: string;
    private prereqDiscountRetentionB: string;
    private prereqDiscountRetentionCAtleast: string;
    private prereqDiscountRetentionCAll: string;
    private prereqDiscountRetentionD: string;
    private prereqDiscountRetentionE: string;
    private prereqDiscountRetentionFAtleast: string;
    private prereqDiscountRetentionFAll: string;

    private prereqDiscountSAInstallAIfOne: string;
    private prereqDiscountSAInstallB: string;
    private prereqDiscountSAInstallD: string;
    private prereqDiscountSARetentionAIfOne: string;
    private prereqDiscountSARetentionDIfAny: string;

    private prereqDiscountTECodeIncludeIfOne: string;
    private prereqDiscountTECodeExcludeIfAny: string;

    private prereqDiscountCodeNoOfDays: string;
    private prereqDiscountCodeAIncludeIfOne: string;
    private prereqDiscountCodeDExcludeIfAny: string;

    private prereqDiscountOtherInstructions: string;

    constructor(
        private configuratorDiscountDataService: ConfiguratorDiscountDataService,
        private utilitiesService: UtilitiesService
    ) {
        this.addEditMode = true;
        this.viewMode = false;
        this.ccSalesAdviceFormula = '';
        this.masterData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.discountMasterData));
        this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
        this.ccSalesAdviceFormula = this.addEditDiscountSubmitData.discMapOscar['adviceFormula'];
        this.initializePreReqData();
        if ((typeof this.masterData !== 'undefined') && (this.masterData !== null) && (Object.keys(this.masterData).length > 0)) {
            this.updateDropDownList();
            this.updatePageMode();
            this.initializeSelectedItems();
        }
        this.marketingIDs = this.configuratorDiscountDataService.marketIDsVal;
    }

    ngOnInit() {
        this.singleSelectSettings = {
            singleSelection: true,
            text: 'Select One',
            enableSearchFilter: true
        };
        this.multiSelectSettings = {
            singleSelection: false,
            text: 'Select',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            classes: 'myclass custom-class',
            badgeShowLimit: 3,
            maxHeight: 120
        };
        this.configuratorDiscountDataService.marketingIDs.subscribe(
            text => {
                this.marketingIDs = text;
            }
        );
        this.configuratorDiscountDataService.copyDiscountAddEditViewOfferFormData.subscribe(
            text => {
                this.configuratorDiscountDataService.addEditDiscountSubmitData = text;
                this.addEditDiscountSubmitData = JSON.parse(JSON.stringify(this.configuratorDiscountDataService.addEditDiscountSubmitData));
                this.initializeSelectedItems();
            }
        );

        this.configuratorDiscountDataService.prereqDiscountLongInstruction.subscribe(
            text => {
                this.prereqDiscountLongInstruction = text;
                this.updateFormula();
            }
        );

        this.configuratorDiscountDataService.prereqDiscountInstallA.subscribe(
            text => {
                this.prereqDiscountInstallA = text;
                this.updateFormula();
            }
        );

        this.configuratorDiscountDataService.prereqDiscountInstallB.subscribe(
            text => {
                this.prereqDiscountInstallB = text;
                this.updateFormula();
            }
        );

        this.configuratorDiscountDataService.prereqDiscountInstallCAtleast.subscribe(
            text => {
                this.prereqDiscountInstallCAtleast = text;
                this.updateFormula();
            }
        );

        this.configuratorDiscountDataService.prereqDiscountInstallCAll.subscribe(
            text => {
                this.prereqDiscountInstallCAll = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountInstallD.subscribe(
            text => {
                this.prereqDiscountInstallD = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountInstallE.subscribe(
            text => {
                this.prereqDiscountInstallE = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountInstallFAtleast.subscribe(
            text => {
                this.prereqDiscountInstallFAtleast = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountInstallFAll.subscribe(
            text => {
                this.prereqDiscountInstallFAll = text;
                this.updateFormula();
            }
        );
        
        this.configuratorDiscountDataService.prereqDiscountCurrentA.subscribe(
            text => {
                this.prereqDiscountCurrentA = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentB.subscribe(
            text => {
                this.prereqDiscountCurrentB = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentCAtleast.subscribe(
            text => {
                this.prereqDiscountCurrentCAtleast = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentCAll.subscribe(
            text => {
                this.prereqDiscountCurrentCAll = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentD.subscribe(
            text => {
                this.prereqDiscountCurrentD = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentE.subscribe(
            text => {
                this.prereqDiscountCurrentE = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentFAtleast.subscribe(
            text => {
                this.prereqDiscountCurrentFAtleast = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCurrentFAll.subscribe(
            text => {
                this.prereqDiscountCurrentFAll = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionA.subscribe(
            text => {
                this.prereqDiscountRetentionA = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionB.subscribe(
            text => {
                this.prereqDiscountRetentionB = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionCAtleast.subscribe(
            text => {
                this.prereqDiscountRetentionCAtleast = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionCAll.subscribe(
            text => {
                this.prereqDiscountRetentionCAll = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionD.subscribe(
            text => {
                this.prereqDiscountRetentionD = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionE.subscribe(
            text => {
                this.prereqDiscountRetentionE = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionFAtleast.subscribe(
            text => {
                this.prereqDiscountRetentionFAtleast = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountRetentionFAll.subscribe(
            text => {
                this.prereqDiscountRetentionFAll = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountSAInstallAIfOne.subscribe(
            text => {
                this.prereqDiscountSAInstallAIfOne = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountSAInstallB.subscribe(
            text => {
                this.prereqDiscountSAInstallB = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountSAInstallD.subscribe(
            text => {
                this.prereqDiscountSAInstallD = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountSARetentionAIfOne.subscribe(
            text => {
                this.prereqDiscountSARetentionAIfOne = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountSARetentionDIfAny.subscribe(
            text => {
                this.prereqDiscountSARetentionDIfAny = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountTECodeIncludeIfOne.subscribe(
            text => {
                this.prereqDiscountTECodeIncludeIfOne = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountTECodeExcludeIfAny.subscribe(
            text => {
                this.prereqDiscountTECodeExcludeIfAny = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCodeNoOfDays.subscribe(
            text => {
                this.prereqDiscountCodeNoOfDays = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCodeAIncludeIfOne.subscribe(
            text => {
                this.prereqDiscountCodeAIncludeIfOne = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountCodeDExcludeIfAny.subscribe(
            text => {
                this.prereqDiscountCodeDExcludeIfAny = text;
                this.updateFormula();
            }
        );
        this.configuratorDiscountDataService.prereqDiscountOtherInstructions.subscribe(
            text => {
                this.prereqDiscountOtherInstructions = text;
                this.updateFormula();
            }
        );
    }

    ngOnChanges(changes: SimpleChanges) {
        // for (let propName in changes) {
        //     let change = changes[propName];
        //     if (propName === 'masterData') {
        //         this.masterData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
        //     } else if (propName === 'addEditDiscountSubmitData') {
        //         this.addEditDiscountSubmitData = ((typeof change.currentValue != 'undefined') && (change.currentValue != null) && (Object.keys(change.currentValue).length > 0)) ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
        //     }
        // }
        // if ((typeof this.masterData != 'undefined') && (this.masterData != null) && (Object.keys(this.masterData).length > 0)) {
        //     this.updateDropDownList();
        //     this.updatePageMode();
        //     this.initializeSelectedItems();
        // }
    }

    initializePreReqData() {
        this.prereqDiscountLongInstruction = (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnLongDescr']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnLongDescr']) : '';
        this.prereqDiscountInstallA =  (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcAIncIfOne']) : '';
        this.prereqDiscountInstallB =  (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcBIncIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcBIncIfAll']) : '';
        this.prereqDiscountInstallCAtleast =  (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcCIncIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcCIncIfAtlst']) : '';
        this.prereqDiscountInstallCAll = (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcCOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcCOfThese']) : '';
        this.prereqDiscountInstallD = (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcDExcIfAny']) : '';
        this.prereqDiscountInstallE = (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcEExcIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcEExcIfAll']) : '';
        this.prereqDiscountInstallFAtleast = (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcFExcIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcFExcIfAtlst']) : '';
        this.prereqDiscountInstallFAll = (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcFOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['instlSrvcFOfThese']) : '';
        this.prereqDiscountCurrentA = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcAIncIfOne']) : '';
        this.prereqDiscountCurrentB = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcBIncIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcBIncIfAll']) : '';
        this.prereqDiscountCurrentCAtleast = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcCIncIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcCIncIfAtlst']) : '';
        this.prereqDiscountCurrentCAll = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcCOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcCOfThese']) : '';
        this.prereqDiscountCurrentD = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcDExcIfAny']) : '';
        this.prereqDiscountCurrentE = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcEExcIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcEExcIfAll']) : '';
        this.prereqDiscountCurrentFAtleast = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcFExcIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcFExcIfAtlst']) : '';
        this.prereqDiscountCurrentFAll = (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcFOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['curntSrvcFOfThese']) : '';
        this.prereqDiscountRetentionA = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcAIncIfOne']) : '';
        this.prereqDiscountRetentionB = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcBIncIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcBIncIfAll']) : '';
        this.prereqDiscountRetentionCAtleast = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcCIncIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcCIncIfAtlst']) : '';
        this.prereqDiscountRetentionCAll = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcCOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcCOfThese']) : '';
        this.prereqDiscountRetentionD = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcDExcIfAny']) : '';
        this.prereqDiscountRetentionE = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcEExcIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcEExcIfAll']) : '';
        this.prereqDiscountRetentionFAtleast = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcFExcIfAtlst']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcFExcIfAtlst']) : '';
        this.prereqDiscountRetentionFAll = (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcFOfThese']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['retnSrvcFOfThese']) : '';
        this.prereqDiscountSAInstallAIfOne = (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlAIncIfOne']) : '';
        this.prereqDiscountSAInstallB = (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlBIncIfAll']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlBIncIfAll']) : '';
        this.prereqDiscountSAInstallD = (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['plgInstlDExcIfAny']) : '';
        this.prereqDiscountSARetentionAIfOne = (this.addEditDiscountSubmitData.discMapPreRequisite['plgRetnAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['plgRetnAIncIfOne']) : '';
        this.prereqDiscountSARetentionDIfAny = (this.addEditDiscountSubmitData.discMapPreRequisite['plgRetnDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['plgRetnDExcIfAny']) : '';
        this.prereqDiscountTECodeIncludeIfOne = (this.addEditDiscountSubmitData.discMapPreRequisite['mrktIdAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['mrktIdAIncIfOne']) : '';
        this.prereqDiscountTECodeExcludeIfAny = (this.addEditDiscountSubmitData.discMapPreRequisite['mrktIdDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['mrktIdDExcIfAny']) : '';
        this.prereqDiscountCodeNoOfDays = (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdNumOfDays']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdNumOfDays']) : '';
        this.prereqDiscountCodeAIncludeIfOne = (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdAIncIfOne']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdAIncIfOne']) : '';
        this.prereqDiscountCodeDExcludeIfAny = (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdDExcIfAny']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['cmpgnCdDExcIfAny']) : '';
        this.prereqDiscountOtherInstructions = (this.addEditDiscountSubmitData.discMapPreRequisite['otherInsrct']) ? (this.addEditDiscountSubmitData.discMapPreRequisite['otherInsrct']) : '';
        this.updateFormula();
    }

    updatePageMode() {
        if ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'add') || ((this.configuratorDiscountDataService.addEditViewDiscountMode === 'edit'))) {
            this.addEditMode = true;
            this.viewMode = false;
        }
        else if (this.configuratorDiscountDataService.addEditViewDiscountMode === 'view') {
            this.addEditMode = false;
            this.viewMode = true;
        }
    }

    updateDropDownList() {
        this.oscarStatusDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'OSCAR_STATUS');
        this.oscarStatusDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.financeBucketProgramCodeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'FINANCE_BUCKET_PROG_CD');
        this.financeBucketProgramCodeDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.marketingIDDropDownList = this.utilitiesService.getDropDownListNgSelect(this.masterData, 'MARKETING_ID');
        this.marketingIDDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        if ((typeof this.masterData !== 'undefined') && (typeof this.addEditDiscountSubmitData !== 'undefined') && (typeof this.configuratorDiscountDataService.addEditViewDiscountMode !== 'undefined') && (this.addEditDiscountSubmitData.discMapDescrBuild !== null)) {
            this.initializeSelectedItems();
        }
    }

    initializeSelectedItems() {
        this.oscarStatusSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'OSCAR_STATUS', this.addEditDiscountSubmitData.discMapOscar.statusId);
        this.financeBucketProgramCodeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'FINANCE_BUCKET_PROG_CD', this.addEditDiscountSubmitData.discMapOscar.financeBucketProgCdId);
        this.marketingIDSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.masterData, 'MARKETING_ID', this.addEditDiscountSubmitData.discMapOscar.mrktId);

    }

    onItemSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onItemDeSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    onDeSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    updateSelectedVal(key: string, items: any, selectType: string) {
        const resultVal = this.getValueBySelectType(items, selectType);
        this.updateSubmitData(key, resultVal);
    }

    getValueBySelectType(item: any, selectType: string) {
        let result;
        if (selectType === 'single') {
            result = this.utilitiesService.getSingleSelectIDNgSelect(item);
        } else {
            result = this.utilitiesService.getMultiSelectID(item)
        }
        return result;
    }

    convertTextAreaContentWithBreaks(field, value) {
        this.updateSubmitData(field, value.split('\n').join('<br />'));
    }

    convertBreakTagToLineBreak(value) {
        const result = '';
        if (value != null) {
            return value.split('<br />').join('\n');
        }
        return value;
    }

    updateSubmitData(field, value) {
        this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapOscar[field] = value;
        this.configuratorDiscountDataService.isAddEditDiscountModified = true;
    }

    updateFormula() {
        let result = '';
        result += this.prereqDiscountLongInstruction + '\n\n';
        result += 'Must Install [ Include if one: ' + this.prereqDiscountInstallA +' ; Include if all: ' + this.prereqDiscountInstallB +' ; Include if at least ' +this.prereqDiscountInstallCAtleast +': ' +this.prereqDiscountInstallCAll +' ; Exclude if any: ' +this.prereqDiscountInstallD +' Exclude if all: ' +this.prereqDiscountInstallE +' ; Exclude if at least ' +this.prereqDiscountInstallFAtleast +': ' +this.prereqDiscountInstallFAll +' ]\n\n';
        result += 'Must Currently Have [ Include if one: ' + this.prereqDiscountCurrentA +' ; Include if all: ' + this.prereqDiscountCurrentB +' ; Include if at least  ' + this.prereqDiscountCurrentCAtleast +' : ' + this.prereqDiscountCurrentCAll +'  ; Exclude if any: ' + this.prereqDiscountCurrentD +' ; Exclude if all: ' + this.prereqDiscountCurrentE +' ; Exclude if at least  ' + this.prereqDiscountCurrentFAtleast +' :  ' + this.prereqDiscountCurrentFAll +' ]\n\n';
        result += 'Must Retain [ Include if one: ' + this.prereqDiscountRetentionA +' ; Include if all: ' + this.prereqDiscountRetentionB +' ; Include if at least ' + this.prereqDiscountRetentionCAtleast +' : ' + this.prereqDiscountRetentionCAll +' ; Exclude if any: ' + this.prereqDiscountRetentionD +' ; Exclude if all: ' + this.prereqDiscountRetentionE +' ; Exclude if at least  ' + this.prereqDiscountRetentionFAtleast +' : ' + this.prereqDiscountRetentionFAll +' ]\n\n';
        result += 'Requires One SA: ' + this.prereqDiscountSAInstallAIfOne +' ; Exclude These SA: ' + this.prereqDiscountSAInstallD +' ; \n\n';
        result += 'TE Code Include if one: ' + this.prereqDiscountTECodeIncludeIfOne +' ; TE Code Exclude if any: ' + this.prereqDiscountTECodeExcludeIfAny +' ; \n\n';
        result += 'Discount Code Number of Days: ' + this.prereqDiscountCodeNoOfDays +' ; Discount Code include if one: ' + this.prereqDiscountCodeAIncludeIfOne +' ; Discount Code exclude if any: ' + this.prereqDiscountCodeDExcludeIfAny +' ; \n\n';
        result += 'Other Instructions: ' + this.prereqDiscountOtherInstructions +' ;'; 
        this.ccSalesAdviceFormula = result;
        this.addEditDiscountSubmitData.discMapOscar['adviceFormula'] = result;
        this.configuratorDiscountDataService.addEditDiscountSubmitData.discMapOscar['adviceFormula'] = result;
    }

}
