import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Discount, ModifyDiscountList } from '../discount-codes-list/discount--codes-list.interface';

import { ConfiguratorDiscountDataService } from '../services/configurator-discount-data.service';
import { DatePipe } from '@angular/common';
import { DiscountCodesListService } from '../discount-codes-list/discount-codes-list.service';
import { ModifyDiscountService } from '../modify-discount/modify-discount.service';
import { RequestorDataService } from '../../../requestor/services/requestor-data.service';
import { RequestorService } from '../../../requestor/services/requestor.service';
import { Router } from '@angular/router';
import { SearchDiscount } from '../modify-discount/modify-discount-interface';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-modify-discount',
  templateUrl: './modify-discount.component.html',
  styleUrls: ['./modify-discount.component.css'],
  providers: [ModifyDiscountService, RequestorService, UtilitiesService, DiscountCodesListService]
})
export class ModifyDiscountComponent implements OnInit {
  @Output() statusUpdateds: EventEmitter<boolean> = new EventEmitter<boolean>();

  @BlockUI() blockUI: NgBlockUI;
  private searchList: Discount[];
  private searchDiscountVal: string;
  private discountsList: SearchDiscount[];
  private duplicateOfferToAdd: boolean;
  private duplicateOffersList: number[];
  private discountList: any[];
  private discountListForIcomsNotify: number[];
  private sendNotificationFail: boolean;
  private sendNotificationSuccess: boolean;
  private errorDraft: boolean;
  private errorDrafts: boolean;
  private discountIdSelected: Boolean;
  private icomsNotifyFailed: boolean;
  private errorMessageShow: boolean;
  private errorMessage: string;
  private addEditIntakeRequestMasterData: any;
  private projectCode: string;
  private projectData: any;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private selectedAll: boolean;
  private selectedAllId: boolean;
  private discountSearchSelectAll: boolean;


  private filterByDiscountID: string;
  private fiterByDiscountCode: string;
  private fiterByDescription: string;
  private fiterByVersion: string;
  private filterByAmount: string;
  private filterByStartDate: string;
  private filterByEndDate: string;
  private filterByStatus: string;

   private filterByDiscountIDSearchObj: any;
   private fiterByDiscountCodeSearchObj: any;
   private fiterByDescriptionSearchObj: any;
   private fiterByVersionSearchObj: any;
   private filterByAmountSearchObj: any;
   private filterByStartDateSearchObj: any;
   private filerByEndDateSearchObj: any;
   private filterByStatusSearchObj: any;

  
  private discountListForRelease: number[];
  private discountsSelected: Boolean;
  private noDiscountSelectedToAdd: boolean;

  private offerValidateSubmitSuccessList: any[];
  private offerValidateSubmitFailList: any[];
  private showDiscountICOMSSubmitSuccess: boolean;
  private showDiscountICOMSSubmitFail: boolean;

  constructor(
    private router: Router,
    private configuratorDiscountDataService: ConfiguratorDiscountDataService,
    public modifyDiscountService: ModifyDiscountService,
    private requestorService: RequestorService,
    private utilitiesService: UtilitiesService,
    private discountListService: DiscountCodesListService
  ) {
    this.projectCode = this.configuratorDiscountDataService.discountProjectCode;
    this.searchDiscountVal = '';
    this.duplicateOfferToAdd = false;
    this.duplicateOffersList = [];
    this.discountList = [];
    this.discountListForIcomsNotify = [];
    this.sendNotificationFail = false;
    this.sendNotificationSuccess = false;
    this.errorDraft = false;
    this.errorDrafts = false;
    this.selectedAll = false;
    this.selectedAllId = false;
    this.discountIdSelected = false;
    this.discountSearchSelectAll = false;



    this.filterByDiscountID= '';
  this.fiterByDiscountCode= '';
  this.fiterByDescription= '';
  this.fiterByVersion= '';
  this.filterByAmount= '';
  this.filterByStartDate= '';
  this.filterByEndDate= '';
  this.filterByStatus= '';

   this.filterByDiscountIDSearchObj= '';
  this.fiterByDiscountCodeSearchObj= '';
   this.fiterByDescriptionSearchObj= '';
   this.fiterByVersionSearchObj= '';
   this.filterByAmountSearchObj= '';
   this.filterByStartDateSearchObj= '';
   this.filerByEndDateSearchObj= '';
   this.filterByStatusSearchObj= '';

    
    this.discountListForRelease = [];
    this.discountsSelected = false;
    this.noDiscountSelectedToAdd = false;
    this.configuratorDiscountDataService.isModifyDiscount = true;
    this.discountList = [];
    this.resetErrorFields();
  }

  ngOnInit() {
    this.initializeFilterContext();
    this.blockUI.start('Loading Discounts List...');
    this.getDiscountCodeList();
     this.resetDiscountSearch(); 
  }

  getDiscountCodeList() {
    this.discountListService.getDiscountList(this.projectCode)
      .subscribe(
      data => {
        if (data.discounts) {
          this.discountList = data.discounts;
          this.updateDiscountList();
        }
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }

  updateDiscountList() {
    for (let i = 0; i < this.discountList.length; i++) {
      this.discountList[i]['discountStatus'] = this.discountList[i]['statusName'];
      this.discountList[i]['discountVersion'] = this.discountList[i]['version'];
      this.discountList[i]['intakeRequest'] = this.discountList[i]['projectCode'];
      if (this.discountList[i]['discountStatus'] === 'Submitted') {
        this.discountList[i]['enableNotify'] = true;
      } else {
        this.discountList[i]['enableNotify'] = false;
      }
    }
  }


  // Search Functionality
  getSearchDiscount() {
    this.blockUI.start('Loading Search Offers...');
    this.searchList = [];
    this.modifyDiscountService.getSearchDiscountList(this.searchDiscountVal)
      .subscribe(
      data => {
     const discountModifyList = data.discountSearchList;
    // const discountModifyList = [
    //   { "discountId": 38, "discountCode": "111", "description": "vipultest", "discountStatus": "Completed", "discountVersion": "V1", "primary": null, "site": null, "intakeRequest": null, "startDate": "06/29/2018", "endDate": "07/04/2018", "srvcAgreementRequired": null, "marketingCode": null, "amount": 0, "statusId": null },
    //   { "discountId": 39, "discountCode": "112", "description": "vipultest", "discountStatus": "Submitted", "discountVersion": "V1", "primary": null, "site": null, "intakeRequest": null, "startDate": "06/29/2018", "endDate": "07/04/2018", "srvcAgreementRequired": null, "marketingCode": null, "amount": 0, "statusId": null },
    //   { "discountId": 40, "discountCode": "113", "description": "vipultest", "discountStatus": "Completed", "discountVersion": "V1", "primary": null, "site": null, "intakeRequest": null, "startDate": "06/29/2018", "endDate": "07/04/2018", "srvcAgreementRequired": null, "marketingCode": null, "amount": 0, "statusId": null }
    // ];
    for (let i = 0; i < discountModifyList.length; i++) {
      discountModifyList[i]['checked'] = false;
      discountModifyList[i]['enableNotify'] = false;
      if (discountModifyList[i]['discountStatus'] === 'Submitted') {
        discountModifyList[i]['enableNotify'] = true;
      }
      this.searchList.push(discountModifyList[i]);
    }
    this.blockUI.stop();
    },
    error => {
      console.log("Error :: " + error);
      this.blockUI.stop();
    }
    );
  }

  updateSearchListSelectAll(isChecked) {
    for (let i = 0; i < this.searchList.length; i++) {
      this.searchList[i]['checked'] = isChecked;
    }
    this.noDiscountSelectedToAdd = (this.getSelectedCount(this.searchList) > 0);
  }

  updateSearchListSelect(discountId, isChecked) {
    for (let i = 0; i < this.searchList.length; i++) {
      if (this.searchList[i]['discountId'] === discountId) {
        this.searchList[i]['checked'] = isChecked;
      }
    }
    this.discountSearchSelectAll = false;
    if (this.getSelectedCount(this.searchList) === this.searchList.length) {
      this.discountSearchSelectAll = true;
    }
    this.noDiscountSelectedToAdd = (this.getSelectedCount(this.searchList) > 0);
  }

  getSelectedCount(searchVal) {
    let count = 0;
    for (let i = 0; i < searchVal.length; i++) {
      if (searchVal[i]['checked']) {
        count++;
      }
    }
    return count;
  }


  getConfiguratorOfferList() {
    this.blockUI.start('Loading Offer List...');
    this.modifyDiscountService.getModifyDiscountListData()
      .subscribe(
      data => {
        if (data) {
          this.discountsList = JSON.parse(JSON.stringify(data));
          this.configuratorDiscountDataService.modifyDiscountList = JSON.parse(JSON.stringify(data));
          for (let i = 0; i < this.configuratorDiscountDataService.modifyDiscountList.length; i++) {
            this.discountsList[i]['validationStatus'] = '';
            this.configuratorDiscountDataService.modifyDiscountList[i]['checked'] = false;
            this.discountsList[i]['discountsEndDate'] = new Date(this.discountsList[i]['endDate']);
            this.configuratorDiscountDataService.modifyDiscountList[i]['discountsEndDate'] = new Date(this.configuratorDiscountDataService.modifyDiscountList[i]['endDate']);
          }
        }
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error);
        this.blockUI.stop();
      }
      );
  }

  // Add Functionality
  addSearchDiscount() {
    for (let i = 0; i < this.searchList.length; i++) {
      if (this.searchList[i]['checked']) {
        this.searchList[i]['checked'] = false;
        this.searchList[i]['EndDate'] = (this.searchList[i]['endDate']) ? new Date(this.searchList[i]['endDate']) : this.searchList[i]['endDate'];
        this.discountList.push(JSON.parse(JSON.stringify(this.searchList[i])));
      } 
    }
    console.log(this.discountList);
  }

  checkIfDiscountAlreadyAdded(discountId) {
    let result = false; 
    const discountsList = this.getDiscountListDiscountIDs();
    if (discountsList.indexOf(discountId) !== -1) {
      result = true;
    }
    return result;
  }

  getDiscountListDiscountIDs() {
    const result = [];
    // for (let i = 0; i < this.discountsList.length; i++) {
    //   result.push(this.discountsList[i].discountId);
    // }
    return result;
  }

  resetDiscountSearch() {
    this.searchList = [];
  }

  moveToEditDiscountPage(mode, discountId) {
    this.configuratorDiscountDataService.addEditViewDiscountMode = mode;
    this.configuratorDiscountDataService.addEditViewDiscountCode = discountId;
    this.configuratorDiscountDataService.backURL = '/plm-work-flow/configurator/discount/modify-discount';
    this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  }

 

  removeDiscount(discountId) {
    const discountIDVal = discountId;
    this.getOtherElementsInDiscounts(discountIDVal);
    this.configuratorDiscountDataService.modifyDiscountList = this.discountList;
    console.log(this.configuratorDiscountDataService.modifyDiscountList);
  } 

  getOtherElementsInDiscounts(discountIDVal) {
    for (let i = 0; i < this.discountList.length; i++) {
      if (this.discountList[i].discountId === discountIDVal) {
        this.discountList.splice(i, 1);
      }
    }
  }


  moveToAddDiscountPage(mode, discountId) {
    this.configuratorDiscountDataService.addEditViewDiscountMode = mode;
    this.configuratorDiscountDataService.addEditViewDiscountCode = discountId;
    this.configuratorDiscountDataService.backURL = '/plm-work-flow/configurator/discount/discount-code-list';
    this.router.navigate(['/plm-work-flow/configurator/discount/add-discount']);
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/discount/project-list']);
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  

  resetErrorFields() {
    this.offerValidateSubmitSuccessList = [];
    this.offerValidateSubmitFailList = [];
    this.showDiscountICOMSSubmitSuccess = false;
    this.showDiscountICOMSSubmitFail = false;
    this.sendNotificationFail = false;
    this.sendNotificationSuccess = false;
    this.icomsNotifyFailed = false;
    this.errorMessageShow = false;
    this.errorMessage = '';
  }


  submitIcomsNotify() {
    this.blockUI.start('Submitting Discount for ICOMS!!!');
    const discountsArray = [];
    if (this.discountListForRelease.length > 0) {
      this.resetErrorFields();
      this.modifyDiscountService.submitDiscountForICOMSNotify(this.discountListForRelease)
        .subscribe(
        data => {
          if (data.actionStatus === "SUCCESS") {
            // this.showDiscountICOMSSubmitSuccess = true;
            this.sendNotificationSuccess = true;
          } else if (data.actionStatus === "FAIL") {
            // this.showDiscountICOMSSubmitFail = true;
            this.sendNotificationFail = true;
          }
          this.blockUI.stop();
        },
        error => {
          this.sendNotificationFail = true;
          this.blockUI.stop();
          console.log("Error :: " + error)
        }
        );
    }
  }

  selectDeselctAllDiscountId(isChecked) {
    this.discountListForRelease = [];
    for (let i = 0; i < this.discountList.length; i++) {
      this.discountList[i]['checked'] = false;
      if ((isChecked) && (this.discountList[i]['discountStatus'] === 'Submitted')) {
        this.discountList[i]['checked'] = isChecked;
        this.discountListForRelease.push(this.discountList[i]['discountId']);
      }
    }
    this.updateDiscountTable(isChecked);
  }

  updateDiscountForModify(isChecked, discountID) {
    this.discountListForRelease = [];
    for (let i = 0; i < this.discountList.length; i++) {
      this.discountList[i]['checked'] = false;
      if ((this.discountList[i]['discountId'] === discountID) && (isChecked) && (this.discountList[i]['discountStatus'] === 'Submitted')) {
        this.discountList[i]['checked'] = isChecked;
        this.discountListForRelease.push(discountID);
      }
    }
    this.updateDiscountTable(isChecked);
  }

  updateDiscountTable(isChecked) {
    this.selectedAll = (this.discountListForRelease.length === this.discountList.length);
    this.discountIdSelected = (this.discountListForRelease.length > 0);
  }

  moveToIntakeRequestView() {
    this.getAddEditIntakeRequestMasterData();
  }

  getAddEditIntakeRequestMasterData() {
    this.blockUI.start('Loading Intake Request Master Data...');
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (const prop in this.addEditIntakeRequestMasterData['mapMarketList']) {
          if (this.addEditIntakeRequestMasterData['mapMarketList'][prop]) {
            this.pushMarketsData(this.addEditIntakeRequestMasterData['mapMarketList'][prop]);
          }
          
        }
        this.fetchEditProjectData();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
    }
  }



  fetchEditProjectData() {
    this.blockUI.start('Loading Intake Request Detail...');
    this.requestorService.getEditProjectData(this.projectCode).subscribe(
      data => {
        this.projectData = data;
        this.resetNullValuesInObj(this.projectData.projectMasterModel);
        this.resetNullValuesInObj(this.projectData.projectMasterModel.intakeFormReqTxnDetModel);
        this.projectData.projectMasterModel.projectStartDt = this.converetDate(this.projectData.projectMasterModel.projectStartDt);
        this.projectData.projectMasterModel.projectEndDt = this.converetDate(this.projectData.projectMasterModel.projectEndDt);
        localStorage.setItem('projectCode', this.projectData.projectMasterModel.projectCode);
        localStorage.setItem('uploadIntakeRequestDocId', this.projectData.projectMasterModel.uploadIntakeRequestDocId);
        this.utilitiesService.triggerWindowTab(this.addEditIntakeRequestMasterData, this.projectData);
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  resetNullValuesInObj(data) {
    for (let prop in data) {
      data[prop] = (data[prop]) ? data[prop] : '';
    }
  }

  converetDate(startDate) {
    return this.getDateInFormat(startDate);
  }

  getDateInFormat(date) {
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }
  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

 


  initializeFilterContext() {
    this.filterByDiscountIDSearchObj = {
      'discountId': {
        'type': 'text',
        'value': this.filterByDiscountID,
        'matchFullCase': false
      }
    };
    this.fiterByDiscountCodeSearchObj = {
      'discountCode': {
        'type': 'text',
        'value': this.fiterByDiscountCode,
        'matchFullCase': false
      }
    };
    this.fiterByDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.fiterByDescription,
        'matchFullCase': false
      }
    };
    this.fiterByVersionSearchObj = {
      'version': {
        'type': 'text',
        'value': this.fiterByVersion,
        'matchFullCase': false
      }
    };
    this.filterByAmountSearchObj = {
      'amount': {
        'type': 'text',
        'value': this.filterByAmount,
        'matchFullCase': false
      }
    };
    this.filterByStartDateSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterByStartDate,
        'matchFullCase': false
      }
    };
    this.filerByEndDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByEndDate,
        'matchFullCase': false
      }
    };
    
     this.filterByStatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterByStatus,
        'matchFullCase': false
      }
    };
  }


   updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

   sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

 

 



}
