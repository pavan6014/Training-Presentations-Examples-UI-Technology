export interface DiscountSitesInterface {
    discountSiteIds: discountSiteIds[];
    DiscountMasterData: DiscountMasterData[];
}

export interface discountSiteIds {
    discountSiteIds: string;
}

export interface DiscountMasterData {
    actionResult: string;
    actionStatus: string;
    discountMasterDropDown: {

    },
}
