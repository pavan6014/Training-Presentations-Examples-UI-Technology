import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../shared';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
    // { path: 'discount', component: DiscountComponent },
    { 
      path: 'discount', 
      loadChildren: './discount/configurator-discount.module#ConfiguratorDiscountModule', 
      canActivate: [AuthGuard],
      data: { path : 'plm-work-flow/configurator/discount'}
    },
    { 
      path: 'offer', 
      loadChildren: './offer/configurator-offer.module#ConfiguratorOfferModule', 
      canActivate: [AuthGuard],
      data: { path : 'plm-work-flow/configurator/offer'}
    },
    { 
      path: 'tecode', 
      loadChildren: './tecodes/tecodes.module#TecodesModule', 
      canActivate: [AuthGuard],
      data: { path : 'plm-work-flow/configurator/tecode'}
    },
    { 
      path: 'pricebook', 
      loadChildren: './pricebook/pricebook.module#PricebookModule', 
      canActivate: [AuthGuard],
      data: { path : 'plm-work-flow/configurator/pricebook'}
    },
    { path: 'product', component: ProductComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfiguratorRoutingModule { }
