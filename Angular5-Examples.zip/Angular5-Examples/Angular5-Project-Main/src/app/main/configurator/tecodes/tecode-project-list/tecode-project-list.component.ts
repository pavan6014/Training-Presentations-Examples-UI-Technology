import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { TecodeDataService } from '../services/tecode-data.service';
import { TecodeService } from '../services/tecode.service';

@Component({
  selector: 'plm-tecode-project-list',
  templateUrl: './tecode-project-list.component.html',
  styleUrls: ['./tecode-project-list.component.css'],
  providers: [TecodeService]
})
export class TecodeProjectListComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private filterContext: any;
  private filterByProjectCode: string;
  private filterByProjectType: string;
  private filterByPricingOwnerName: string;
  private filterByDescription: string;
  private filterByRequesterName: string;
  private filterByCreatedDate: string;
  private filterBypriority: string;
  private filterBystatus: string;

  private filterByProjectCodeSearchObj: any;
  private filterByProjectTypeSearchObj: any;
  private filterByPricingOwnerNameSearchObj: any;
  private filterByDescriptionSearchObj: any;
  private filterByRequesterNameSearchObj: any;
  private filterByprioritySearchObj: any;
  private filterByCreatedDateSearchObj: any;
  private filterBystatusSearchObj: any;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private showIntakeRequestList: Boolean;
  private intakeRequestDetails: any[];

  constructor(
    private tecodeService: TecodeService, 
    private tecodeDataService: TecodeDataService, 
    private router: Router
  ) { 
    this.filterContext = '';
    this.filterByProjectCode = '';
    this.filterByProjectType = 'New TE Code Creation';
    this.filterByPricingOwnerName = '';
    this.filterByDescription = '';
    this.filterByRequesterName = '';
    this.filterByCreatedDate = '';
    this.filterBypriority= '';
    this.filterBystatus= '';

    this.filterByProjectCodeSearchObj = '';
    this.filterByProjectTypeSearchObj = '';
    this.filterByPricingOwnerNameSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    this.filterByRequesterNameSearchObj = '';
    this.filterByprioritySearchObj= '';
    this.filterByCreatedDateSearchObj = '';
    this.filterBystatusSearchObj = '';
    this.showIntakeRequestList = false;
  }

  ngOnInit() {
    this.blockUI.start('Loading TE Code Project List...');
    this.getTECodeProjectList();
  }

  getTECodeProjectList() {
    this.tecodeService.getTECodeProjectList()
      .subscribe(
      data => {
        this.intakeRequestDetails = data.projectMasterFetchAll;
        this.updatePricingOwnerName();
        this.initializeFilterContext();
        this.checkToShowIntakeRequestList();
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error)
        this.blockUI.stop();
      }
      );
  }

  updatePricingOwnerName() {
    for (let i=0; i<this.intakeRequestDetails.length; i++) {
      this.intakeRequestDetails[i]['pricingOwnersList'] = this.intakeRequestDetails[i]['pricingOwners'].join(' , ');
    }
  }

  initializeFilterContext() {
    this.filterByProjectCodeSearchObj = {
      'projectCode': {
        'type': 'text',
        'value': this.filterByProjectCode,
        'matchFullCase': false
      }
    };
    this.filterByProjectTypeSearchObj = {
      'projectType': {
        'type': 'text',
        'value': this.filterByProjectType,
        'matchFullCase': true
      }
    };
    this.filterByPricingOwnerNameSearchObj = {
      'pricingOwners': {
        'type': 'text',
        'value': this.filterByPricingOwnerName,
        'matchFullCase': false
      }
    };
    this.filterByprioritySearchObj = {
      'priority': {
        'type': 'text',
        'value': this.filterBypriority,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
    this.filterByDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByDescription,
        'matchFullCase': false
      }
    };
    this.filterByRequesterNameSearchObj = {
      'requesterName': {
        'type': 'text',
        'value': this.filterByRequesterName,
        'matchFullCase': false
      }
    };
    this.filterByCreatedDateSearchObj = {
      'createdDate': {
        'type': 'date',
        'value': this.filterByCreatedDate,
        'matchFullCase': true
      }
    };
  }

  checkToShowIntakeRequestList() {
    if (this.intakeRequestDetails) {
      this.showIntakeRequestList = true;
      this.blockUI.stop();
    } else {
      this.showIntakeRequestList = false;
    }
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  moveToTECodeGrid(projectCode) {
    this.tecodeDataService.projectCode = projectCode;
    this.router.navigate(['/plm-work-flow/configurator/tecode/tecode-code-list']);
  }

  returnBack() {
    this.router.navigate(['']);
  }

}
