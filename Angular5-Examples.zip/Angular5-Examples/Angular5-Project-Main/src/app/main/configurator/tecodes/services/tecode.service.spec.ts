import { TestBed, inject } from '@angular/core/testing';

import { TecodeService } from './tecode.service';

describe('TecodeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TecodeService]
    });
  });

  it('should be created', inject([TecodeService], (service: TecodeService) => {
    expect(service).toBeTruthy();
  }));
});
