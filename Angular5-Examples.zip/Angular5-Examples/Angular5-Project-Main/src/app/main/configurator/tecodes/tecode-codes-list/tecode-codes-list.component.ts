import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { RequestorService } from '../../../requestor/services/requestor.service';
import { Router } from '@angular/router';
import { TecodeDataService } from './../services/tecode-data.service';
import { TecodeService } from '../services/tecode.service';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-tecode-codes-list',
  templateUrl: './tecode-codes-list.component.html',
  styleUrls: ['./tecode-codes-list.component.css'],
  providers: [TecodeService, RequestorService, UtilitiesService]
})
export class TecodeCodesListComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private masterData: any;
  private teCodesList: any[];
  private teCodesListForSubmit: any[];
  private teCodesAPIResponse: any[];
  private teCodeSaveRemoveResult: string;
  private projectCode: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private showTECodesList: boolean;
  private selectedAll: boolean;
  private teCodeSelected: boolean;
  private projectData: any;
  private addEditIntakeRequestMasterData: any;

  private filterByTECodeCode: string;
  private filterByTECodeDescription: string;
  private filterByTECodeType: string;
  private filterByOwner: string;
  private filterByNotes: string;
  private filterByCreatedDate: string;
  private filterByModifiedBy: string;
  private filterByModifiedDate: string;
  private filterByTECodeSearchObj: any;
  private filterByTECodeDescriptionSearchObj: any;
  private filterByTECodeTypeSearchObj: any;
  private filterByOwnerSearchObj: any;
  private filterByNotesSearchObj: any;
  private filterByCreatedDateSearchObj: any;
  private filterByModifiedBySearchObj: any;
  private filterByModifiedDateSearchObj: any;

  private teCodeTypeDropDownList = [];
  private teCodeTypeSelectedItems = [];

  private searchMarkets: string;
  private saveTECodeSuccess: boolean;
  private saveTECodeFail: boolean;
  private removeTECodeSuccess: boolean;
  private removeTECodeFail: boolean;
  private teCodeSaveError: string;

  constructor(
    private router: Router,
    private tecodeService: TecodeService,
    private tecodeDataService: TecodeDataService,
    private requestorService: RequestorService,
    private utilitiesService: UtilitiesService
  ) {
    this.masterData = '';
    this.filterByTECodeCode = '';
    this.filterByTECodeDescription = '';
    this.filterByTECodeType = '';
    this.filterByOwner = '';
    this.filterByNotes = '';
    this.filterByCreatedDate = '';
    this.filterByModifiedBy = '';
    this.filterByModifiedDate = '';
    this.filterByTECodeSearchObj = '';
    this.filterByTECodeDescriptionSearchObj = '';
    this.filterByTECodeTypeSearchObj = '';
    this.filterByOwnerSearchObj = '';
    this.filterByNotesSearchObj = '';
    this.filterByCreatedDateSearchObj = '';
    this.filterByModifiedBySearchObj = '';
    this.filterByModifiedDateSearchObj = '';
    this.searchMarkets = '';
    this.showTECodesList = false;
    this.projectCode = this.tecodeDataService.projectCode;
    this.selectedAll = false;
    this.teCodeSelected = false;
    this.teCodesList = [];
    this.teCodesListForSubmit = [];
    this.teCodesAPIResponse = [];
    this.teCodeSaveRemoveResult = '';
    this.teCodeSaveError = '';
    this.setTECodeSaveError('');
    this.initializeErrorFields();
  }

  initializeErrorFields() {
    this.saveTECodeSuccess = false;
    this.saveTECodeFail = false;
    this.removeTECodeFail = false;
    this.removeTECodeSuccess = false;
    this.teCodesAPIResponse = [];
    this.teCodeSaveRemoveResult = '';
  }

  setTECodeSaveError(value) {
    this.teCodeSaveError = (value !== '') ? value : 'Save TE Code Failed!!!';
  }

  ngOnInit() {
    this.blockUI.start('Loading TE Codes Master Data...');
    this.getTECodesMasterData();
  }


  getTECodesMasterData() {
    this.tecodeService.getTECodesMasterData()
    .subscribe(
      data => {
        this.masterData = data.intakeFormMasterDropDown;
        this.blockUI.stop();
        this.blockUI.start('Loading TE Codes List...');
        this.getTECodesList();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  getTECodesList() {
    this.tecodeService.getTECodeProjectDetails(this.projectCode)
      .subscribe(
        data => {
          this.teCodesList = data.teCodeRequestList;
          this.initializeFilterContext();
          this.updateTECodeDropDownList();
          this.checkToShowTECodesList();
          this.blockUI.stop();
        },
        error => {
          console.log('Error :: ' + error);
          this.blockUI.stop();
        }
      );
  }

  updateTECodeDropDownList() {
    this.teCodeTypeDropDownList = this.getTECodeTypeDropDownList(this.masterData, 'TE_CODE');
    this.teCodeTypeDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    for (let i = 0; i < this.teCodesList.length; i++) {
      this.teCodesList[i]['teCodeIndex'] = i;
      this.teCodesList[i]['viewMode'] = true;
      this.teCodesList[i]['editMode'] = false;
      this.teCodesList[i]['showEdit'] = true;
      this.teCodesList[i]['showSave'] = false;
      this.teCodesList[i]['checked'] = false;
      this.teCodesList[i]['disable'] = false;
      this.teCodesList[i]['isUniqueCode'] = true;
      this.teCodesList[i]['isCodeExist'] = true;
      this.updateDropDownList(this.teCodesList[i]);
    }
  }

  checkToShowTECodesList() {
    if (this.teCodesList) {
      this.showTECodesList = true;
      this.blockUI.stop();
    } else {
      this.showTECodesList = false;
    }
  }

  addNewTECode() {
    this.teCodesList.unshift(this.getTECodeInitialModel());
    this.updateTECodeIndex();
    this.updateTECodesForSubmit();
  }

  editTECode(teCodeIndex) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList[i]['viewMode'] = false;
        this.teCodesList[i]['editMode'] = true;
        this.teCodesList[i]['showEdit'] = false;
        this.teCodesList[i]['showSave'] = true;
        this.teCodesList[i]['disable'] = true;
        this.teCodesList[i]['checked'] = false;
      }
    }
    this.updateTECodesForSubmit();
  }

  saveTECode(teCodeIndex, teCode) {
    this.teCodesList[teCodeIndex]['isCodeExist'] = true;
    if (this.teCodesList[teCodeIndex]['code'] === '') {
      this.teCodesList[teCodeIndex]['isCodeExist'] = false;
      return false;
    } 
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList[i]['viewMode'] = true;
        this.teCodesList[i]['editMode'] = false;
        this.teCodesList[i]['showEdit'] = true;
        this.teCodesList[i]['showSave'] = false;
        this.teCodesList[i]['disable'] = false;
      }
    }
    this.saveTECodeRow(teCodeIndex, teCode);
  }

  enableTECodeRow(teCodeObj) {
    if (teCodeObj['teCodeIndex']) {
      teCodeObj['disable'] = false;
    } else {
      teCodeObj['disable'] = true;
    }
  }

  checkForTECodeUniqueness(teCodeIndex, field, value) {
    const result = this.checkIsTECodeExist(teCodeIndex, value);
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.checkForEmptyTECode(i, result, field, value);
      } 
    }
  }

  checkForEmptyTECode(index, result, field, value) {
    this.teCodesList[index]['isCodeExist'] = true;
    this.teCodesList[index]['showEdit'] = false;
    this.teCodesList[index]['showSave'] = true;
    if (value === '') {
      this.teCodesList[index]['isCodeExist'] = false;
      this.teCodesList[index]['showEdit'] = false;
      this.teCodesList[index]['showSave'] = false;
    } else {
      this.teCodesList[index][field] = value;
      this. updateTECodeVal(index, result, field, value);
    }
  }

  updateTECodeVal(index, result, field, value) {
    this.teCodesList[index]['isUniqueCode'] = true;
    this.teCodesList[index]['showEdit'] = false;
    this.teCodesList[index]['showSave'] = true;
    if (result) {
      this.teCodesList[index]['isUniqueCode'] = false;
      this.teCodesList[index]['showEdit'] = false;
      this.teCodesList[index]['showSave'] = false;
    } else {
      this.teCodesList[index][field] = value;
    }
  }

  checkIsTECodeExist(teCodeIndex, teCodeVal) {
    let result = false
    for (let i = 0; i < this.teCodesList.length; i++) {
      if ((this.teCodesList[i]['teCodeIndex'] !== teCodeIndex) && (this.teCodesList[i]['code'] === teCodeVal)) {
        result = true;
      }
    }
    return result;
  }

  updateSubmitData(teCodeIndex, field, value) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList[i][field] = value;
      }
    }
  }

  getTECodeInitialModel() {
    return {
      'teCodeIndex': 0,
      'teCodeId': null,
      'code': '',
      'description': '',
      'owner': null,
      'createdDate': '',
      'modifiedBy': null,
      'modifiedDate': '',
      'notes': '',
      'recordId': null,
      'recordOwner': null,
      'type': '',
      'intakeRequestId': this.projectCode,
      'viewMode': false,
      'editMode': true,
      'showEdit': false,
      'showSave': true,
      'checked': false,
      'disable': true,
      'isUniqueCode': true, 
      'isCodeExist': true
    };
  }

  updateTECodeIndex() {
    for (let i = 0; i < this.teCodesList.length; i++) {
      this.teCodesList[i]['teCodeIndex'] = i;
    }
  }

  convertTextAreaContentWithBreaks(teCodeIndex, field, value) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList[i][field] = value.split('\n').join('<br />');
      }
    }
  }

  convertBreakTagToLineBreak(value) {
    if (value != null) {
      return value.split('<br />').join('\n');
    }
    return value;

  }

  updateDropDownList(teCode) {
    teCode['teCodeTypeSelectedItems'] = this.getTECodeTypeSelectedItemsObject(this.teCodeTypeDropDownList, Number(teCode.type));
  }


  onTECodeTypeItemSelect(teCodeIndex, field, item) {
    this.updateSubmitData(teCodeIndex, field, this.getTECodeTypeSelectedItemsObject(this.teCodeTypeDropDownList, item).id);
  }


  getTECodeTypeDropDownList(masterData, dropDownKey) {
    const result = [];
    if (!masterData[dropDownKey]) {
        return result;
    }
    for (let i = 0; i < masterData[dropDownKey].length; i++) {
        result.push({
            'id': masterData[dropDownKey][i]['intakeFormDrpdwnDetailId'],
            'name': masterData[dropDownKey][i]['objectName']
        });
    }
    return result;
  }


  getTECodeTypeSelectedItemsObject(dropDownListObj, dropDownVal) {
    let result: any = [];
    for (let i = 0; i < dropDownListObj.length; i++) {
      if (dropDownListObj[i]['id'] === dropDownVal) {
        result = {};
        result = {
          'id': dropDownListObj[i]['id'],
          'name': dropDownListObj[i]['name']
        };
      }
    }
    return result;
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  returnBack() {
    this.router.navigate(['plm-work-flow/configurator/tecode/project-list']);
  }
  
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  selectAllTECodes(isChecked) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (isChecked) {
        this.teCodesList[i]['checked'] = true;
      } else {
        this.teCodesList[i]['checked'] = false;
      }
    }
    this.updateTECodesForSubmit();
  }

  updateTECodesForSubmit() {
    this.teCodesListForSubmit = [];
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['checked']) {
        const result = {};
        result['teCodeId'] = this.teCodesList[i]['teCodeId'];
        result['code'] = this.teCodesList[i]['code'];
        result['description'] = this.teCodesList[i]['description'];
        result['owner'] = this.teCodesList[i]['owner'];
        result['modifiedBy'] = this.teCodesList[i]['modifiedBy'];
        result['createdDate'] = this.teCodesList[i]['createdDate'];
        result['modifiedDate'] = this.teCodesList[i]['modifiedDate'];
        result['notes'] = this.teCodesList[i]['notes'];
        result['recordId'] = this.teCodesList[i]['recordId'];
        result['recordOwner'] = this.teCodesList[i]['recordOwner'];
        result['type'] = this.teCodesList[i]['type'];
        result['intakeRequestId'] = this.teCodesList[i]['intakeRequestId'];
        this.teCodesListForSubmit.push(result);
      }
    }
    this.selectedAll = (this.teCodesListForSubmit.length === this.teCodesList.length);
    this.teCodeSelected = (this.teCodesListForSubmit.length > 0);
  }

  updateTECodeForSaveRemove(isChecked, teCodeIndex, isSubmit) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList[i]['checked'] = isChecked;
      }
    }
    this.updateTECodesForSubmit();
    if (isSubmit) {
      this.saveTECodes();
    }
  }

  saveTECodeRow(teCodeIndex, teCode) {
    this.blockUI.start('Saving TE Code...');
    const result = {};
    result['teCodeId'] = teCode['teCodeId'];
    result['code'] = teCode['code'];
    result['description'] = teCode['description'];
    result['owner'] = teCode['owner'];
    result['modifiedBy'] = teCode['modifiedBy'];
    result['createdDate'] = teCode['createdDate'];
    result['modifiedDate'] = teCode['modifiedDate'];
    result['notes'] = teCode['notes'];
    result['recordId'] = teCode['recordId'];
    result['recordOwner'] = teCode['recordOwner'];
    result['type'] = teCode['type'];
    result['intakeRequestId'] = teCode['intakeRequestId'];
    const reqObj = {
      'teCodeRequest': result
    };
    this.initializeErrorFields();
    this.tecodeService.saveTECodeRow(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus === 'SUCCESS') {
            this.teCodesAPIResponse = data.teCodeRequest;
            const resultObj = [];
            for (let i = 0; i < this.teCodesAPIResponse.length; i++) {
              resultObj.push(this.teCodesAPIResponse[i]['code']);
            }
            this.teCodeSaveRemoveResult = resultObj.join(', ');
            this.saveTECodeSuccess = true;
          } else if (data.actionStatus === 'FAIL') {
            let errorVal = '';
            if ((data.actionResult) && (data.actionResult.errors) && (data.actionResult.errors.length > 0) && (data.actionResult.errors[0].description)) {
              errorVal = data.actionResult.errors[0].description;
            }
            this.setTECodeSaveError(errorVal);
            this.saveTECodeFail = true;
            this.blockUI.stop();
          }
          this.getTECodesList();
          this.selectedAll = false;
          this.blockUI.stop();
          
        },
        error => {
          console.log('Error :: ' + error);
          this.saveTECodeFail = true;
          this.blockUI.stop();
        }
      );
  }

  removeTECode(teCodeIndex) {
    for (let i = 0; i < this.teCodesList.length; i++) {
      if (this.teCodesList[i]['teCodeIndex'] === teCodeIndex) {
        this.teCodesList.splice(i, 1);
      }
    }
  }

  saveTECodes() {
    this.blockUI.start('Saving TE Code...');
    const reqObj = {
      'teCodeRequestList': this.teCodesListForSubmit
    };
    this.initializeErrorFields();
    this.tecodeService.saveTECodes(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus === 'SUCCESS') {
            this.teCodesAPIResponse = data.teCodeRequestList;
            const result = [];
            for (let i = 0; i < this.teCodesAPIResponse.length; i++) {
              result.push(this.teCodesAPIResponse[i]['code']);
            }
            this.teCodeSaveRemoveResult = result.join(', ');
            this.saveTECodeSuccess = true;
          } else if (data.actionStatus === 'FAIL') {
            this.saveTECodeFail = true;
            this.blockUI.stop();
          }
          this.getTECodesList();
          this.selectedAll = false;
          this.blockUI.stop();
          
        },
        error => {
          console.log('Error :: ' + error);
          this.saveTECodeFail = true;
          this.blockUI.stop();
        }
      );
  }

  removeTECodes() {
    this.blockUI.start('Removing TE Codes...');
    const teCodesListIDs = [];
    for (let i = 0; i < this.teCodesListForSubmit.length; i++) {
      if (this.teCodesListForSubmit[i]['teCodeId']) {
        teCodesListIDs.push(this.teCodesListForSubmit[i]['teCodeId']);
      }
    }
    const reqObj = {
      'teCodeIds': teCodesListIDs
    };
    this.initializeErrorFields();
    this.tecodeService.removeTECodes(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus === 'SUCCESS') {
            this.teCodeSaveRemoveResult = teCodesListIDs.join(', ');
            this.removeTECodeSuccess = true;
          } else if (data.actionStatus === 'FAIL') {
            this.removeTECodeFail = true;
            this.blockUI.stop();
          }
          this.getTECodesList();
          this.selectedAll = false;
          this.blockUI.stop();
          
        },
        error => {
          console.log('Error :: ' + error);
          this.removeTECodeFail = true;
          this.blockUI.stop();
        }
      );
  }


  initializeFilterContext() {
    this.filterByTECodeSearchObj = {
      'code': {
        'type': 'text',
        'value': this.filterByTECodeCode,
        'matchFullCase': false
      }
    };
    this.filterByTECodeDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByTECodeDescription,
        'matchFullCase': false
      }
    };
    this.filterByTECodeTypeSearchObj = {
      'type': {
        'type': 'text',
        'value': this.filterByTECodeType,
        'matchFullCase': false
      }
    };
    this.filterByOwnerSearchObj = {
      'owner': {
        'type': 'text',
        'value': this.filterByOwner,
        'matchFullCase': false
      }
    };
    this.filterByNotesSearchObj = {
      'notes': {
        'type': 'text',
        'value': this.filterByNotes,
        'matchFullCase': false
      }
    };
    this.filterByCreatedDateSearchObj = {
      'createdDate': {
        'type': 'text',
        'value': this.filterByCreatedDate,
        'matchFullCase': false
      }
    };
    this.filterByModifiedBySearchObj = {
      'modifiedBy': {
        'type': 'text',
        'value': this.filterByModifiedBy,
        'matchFullCase': false
      }
    };
    this.filterByModifiedDateSearchObj = {
      'modifiedDate': {
        'type': 'text',
        'value': this.filterByModifiedDate,
        'matchFullCase': false
      }
    };
  }

  moveToIntakeRequestView() {
    this.getAddEditIntakeRequestMasterData();
  }

  getAddEditIntakeRequestMasterData() {
    this.blockUI.start('Loading Intake Request Master Data...');
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (const prop in this.addEditIntakeRequestMasterData['mapMarketList']) {
          if (this.addEditIntakeRequestMasterData['mapMarketList'][prop]) {
            this.pushMarketsData(this.addEditIntakeRequestMasterData['mapMarketList'][prop]);
          }
          
        }
        this.fetchEditProjectData();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
    }
  }



  fetchEditProjectData() {
    this.blockUI.start('Loading Intake Request Detail...');
    this.requestorService.getEditProjectData(this.projectCode).subscribe(
      data => {
        this.projectData = data;
        this.resetNullValuesInObj(this.projectData.projectMasterModel);
        this.resetNullValuesInObj(this.projectData.projectMasterModel.intakeFormReqTxnDetModel);
        this.projectData.projectMasterModel.projectStartDt = this.converetDate(this.projectData.projectMasterModel.projectStartDt);
        this.projectData.projectMasterModel.projectEndDt = this.converetDate(this.projectData.projectMasterModel.projectEndDt);
        localStorage.setItem('projectCode', this.projectData.projectMasterModel.projectCode);
        localStorage.setItem('uploadIntakeRequestDocId', this.projectData.projectMasterModel.uploadIntakeRequestDocId);
        this.utilitiesService.triggerWindowTab(this.addEditIntakeRequestMasterData, this.projectData);
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  resetNullValuesInObj(data) {
    for (let prop in data) {
      data[prop] = (data[prop]) ? data[prop] : '';
    }
  }

  converetDate(startDate) {
    return this.getDateInFormat(startDate);
  }

  getDateInFormat(date) {
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }
  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }
}