import { MatAutocompleteModule, MatButtonModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatExpansionModule, MatInputModule, MatSelectModule } from '@angular/material';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { KeysPipe } from '../../configurator/pipes/keys.pipe';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2PaginationModule } from 'ng2-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../../../shared/shared.module';
import { TecodeCodesListComponent } from './tecode-codes-list/tecode-codes-list.component';
import { TecodeDataService } from './services/tecode-data.service';
import { TecodeProjectListComponent } from './tecode-project-list/tecode-project-list.component';
import { TecodesRoutingModule } from './tecodes-routing.module';

@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    Ng2PaginationModule,
    Ng2OrderModule,
    SharedModule,
    MatDialogModule,
    Ng2SearchPipeModule,  
    SharedModule, 
    TecodesRoutingModule,
    NgSelectModule, 
    FormsModule,
    MatButtonModule, 
    MatCheckboxModule, 
    MatExpansionModule, 
    MatAutocompleteModule, 
    MatInputModule, 
    MatSelectModule, 
    MatDatepickerModule, 
    MatDialogModule
  ],
  declarations: [TecodeProjectListComponent, TecodeCodesListComponent], 
  providers: [TecodeDataService]
})
export class TecodesModule { }
