import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';

import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';

import { AppConfigService } from '../../../../shared/services/app-config.service';
import { BreadCrumb } from '../../../../shared/services/bread-crumb';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class TecodeService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }


  getTECodeProjectList(): Observable<any> {

    const getTECodeProjectListURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODE_PROJECT_LIST'];
     return this.http
       .get(getTECodeProjectListURL)
       .map((response: any) => {
         return response;
       })
       .catch(this.handleError);

  //  const getTECodeProjectListURL = this.appConfigService.urlConstants['PLM_TECODE_PROJECT_LIST'];
  //  return this.http
  //    .get(getTECodeProjectListURL)
  //    .map((response: Response) => {
  //      return response;
  //    })
  //    .catch(this.handleError);
 }

 
 getTECodesMasterData(): Observable<any> {

  const getTECodeProjectListURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODE_MASTER_DATA'];
   return this.http
     .get(getTECodeProjectListURL)
     .map((response: any) => {
       return response;
     })
     .catch(this.handleError);

    //  const getTECodeProjectListURL = this.appConfigService.urlConstants['PLM_TECODE_PROJECT_LIST'];
    //  return this.http
    //    .get(getTECodeProjectListURL)
    //    .map((response: Response) => {
    //      return response;
    //    })
    //    .catch(this.handleError);
  }
 
 getTECodeProjectDetails(projectCode): Observable<any> {

  const getTECodeProjectDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODE_PROJECT_DETAILS'] + '/' + projectCode + '/teCodes';
   return this.http
     .get(getTECodeProjectDetailsURL)
     .map((response: any) => {
       return response;
     })
     .catch(this.handleError);

//  const getTECodeProjectDetailsURL = this.appConfigService.urlConstants['PLM_TECODE_PROJECT_DETAILS'];
//  return this.http
//    .get(getTECodeProjectDetailsURL)
//    .map((response: Response) => {
//      return response;
//    })
//    .catch(this.handleError);
}

saveTECodes(reqObj): Observable<any>{
  const getDiscountsListForIcoms = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODES_SAVE'];
  return this.http
    .post(getDiscountsListForIcoms, reqObj)
    .map((response: Response) => {
      return response;
    })
    .catch(this.handleError);
  // const getDiscountsListForIcoms = this.appConfigService.urlConstants['PLM_DISCOUNT_SEND_NOTIFICATION'];
  // return this.http
  //   .get(getDiscountsListForIcoms)
  //   .map((response: Response) => {
  //     return response;
  //   })
  //   .catch(this.handleError);
}

saveTECodeRow(reqObj): Observable<any>{
  const getDiscountsListForIcoms = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODE_SAVE'];
  return this.http
    .post(getDiscountsListForIcoms, reqObj)
    .map((response: Response) => {
      return response;
    })
    .catch(this.handleError);
  // const getDiscountsListForIcoms = this.appConfigService.urlConstants['PLM_DISCOUNT_SEND_NOTIFICATION'];
  // return this.http
  //   .get(getDiscountsListForIcoms)
  //   .map((response: Response) => {
  //     return response;
  //   })
  //   .catch(this.handleError);
}


removeTECodes(reqObj): Observable<any>{
  const getDiscountsListForIcoms = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_TECODE_REMOVE'];
  return this.http
    .post(getDiscountsListForIcoms, reqObj)
    .map((response: Response) => {
      return response;
    })
    .catch(this.handleError);
  // const getDiscountsListForIcoms = this.appConfigService.urlConstants['PLM_DISCOUNT_SEND_NOTIFICATION'];
  // return this.http
  //   .get(getDiscountsListForIcoms)
  //   .map((response: Response) => {
  //     return response;
  //   })
  //   .catch(this.handleError);
}

 private handleError(error: Response) {
   return Observable.throw(error.statusText);
 }


}
