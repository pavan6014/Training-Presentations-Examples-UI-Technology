import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TecodeProjectListComponent } from './tecode-project-list.component';

describe('TecodeProjectListComponent', () => {
  let component: TecodeProjectListComponent;
  let fixture: ComponentFixture<TecodeProjectListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TecodeProjectListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TecodeProjectListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
