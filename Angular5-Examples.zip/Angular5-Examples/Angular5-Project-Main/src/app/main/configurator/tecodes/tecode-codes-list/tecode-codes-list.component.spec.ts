import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TecodeCodesListComponent } from './tecode-codes-list.component';

describe('TecodeCodesListComponent', () => {
  let component: TecodeCodesListComponent;
  let fixture: ComponentFixture<TecodeCodesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TecodeCodesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TecodeCodesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
