import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../shared';
import { TecodeProjectListComponent } from './tecode-project-list/tecode-project-list.component';
import { TecodeCodesListComponent } from './tecode-codes-list/tecode-codes-list.component';

const routes: Routes = [
  { 
    path: '', 
    redirectTo: 'project-list', 
    pathMatch: 'full' 
  },
  { 
    path: 'project-list', 
    component: TecodeProjectListComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/tecode/project-list'}  
  },
  { 
    path: 'tecode-code-list', 
    component: TecodeCodesListComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/tecode/tecode-code-list'}  
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class TecodesRoutingModule { }
