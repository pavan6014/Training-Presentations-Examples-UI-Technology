import { TestBed, inject } from '@angular/core/testing';

import { TecodeDataService } from './tecode-data.service';

describe('TecodeDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TecodeDataService]
    });
  });

  it('should be created', inject([TecodeDataService], (service: TecodeDataService) => {
    expect(service).toBeTruthy();
  }));
});
