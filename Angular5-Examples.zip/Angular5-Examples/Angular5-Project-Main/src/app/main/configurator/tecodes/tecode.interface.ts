export interface Tecode {
}
