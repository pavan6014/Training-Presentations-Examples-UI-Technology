import { TestBed, inject } from '@angular/core/testing';

import { ConfiguratorOfferService } from './configurator-offer.service';

describe('ConfiguratorOfferService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConfiguratorOfferService]
    });
  });

  it('should be created', inject([ConfiguratorOfferService], (service: ConfiguratorOfferService) => {
    expect(service).toBeTruthy();
  }));
});
