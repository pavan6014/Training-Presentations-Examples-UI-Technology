export interface Offer {
  projectCode: string;
  offerId: number;
  startDt: string;
  releaseDt: string;
  statusId: number;
  status: string;
  releaseCode: string;
  psu: string;
  offerName: string;
  offerDescription: string;
  offerCategory: string;
  endDt: string;
  offerBundleName: string;
  salesAdvise: string;
  lastUpdateDate: string;
  primaryDiscountCode: string;
  sites: string[];
  checked: boolean;
}

export interface ModifyOffer {
  projectCode: string;
  offerId: number;
  startDt: string;
  releaseDt: string;
  statusId: number;
  status: string;
  releaseCode: string;
  psu: string;
  offerName: string;
  offerDescription: string;
  offerCategory: string;
  endDt: string;
  offerBundleName: string;
  salesAdvise: string;
  lastUpdateDate: string;
  primaryDiscountCode: string;
  sites: string[];
  checked: boolean;
  channels: number[];
}

export interface MoveToDistributor {
  offersList: string[];
}

export interface RequstDistributor{
  projectCode: string;
  offerId: number;
}

