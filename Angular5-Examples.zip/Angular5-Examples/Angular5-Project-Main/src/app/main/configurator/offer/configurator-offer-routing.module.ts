import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../shared';
import { OfferComponent } from './offer.component';
import { ConfiguratorProjectListComponent } from './configurator-project-list/configurator-project-list.component';
import { OfferBucketGridViewComponent } from './offer-bucket-grid-view/offer-bucket-grid-view.component';
import { AddOfferComponent } from './add-offer/add-offer.component';
import { IntakeRequestDetailsComponent }  from '../../configurator/offer/intake-request-details/intake-request-details.component';
import { ModifyOfferComponent } from '../offer/modify-offer/modify-offer.component';

const routes: Routes = [
  { 
    path: '', 
    redirectTo: 'project-list', 
    pathMatch: 'full' 
  },
  { 
    path: 'modify-offer', 
    component: ModifyOfferComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/modify-offer'}  
  },
  { 
    path: 'project-list', 
    component: ConfiguratorProjectListComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/project-list'}  
  },
  { 
    path: 'offer-table', 
    component: OfferBucketGridViewComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/offer-table'}  
  },
  { 
    path: 'intake-request', 
    component: IntakeRequestDetailsComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/intake-request'}  
  },
  { 
    path: 'add-offer', 
    component: AddOfferComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/add-offer'}  
  },
  { 
    path: 'edit-offer', 
    component: AddOfferComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/edit-offer'}  
  },
  { 
    path: 'view-offer', 
    component: AddOfferComponent, 
    canActivate: [AuthGuard],
    data: { path : 'plm-work-flow/configurator/offer/view-offer'}  
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfiguratorOfferRoutingModule { }
