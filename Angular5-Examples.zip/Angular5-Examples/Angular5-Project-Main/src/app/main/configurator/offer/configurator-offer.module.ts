import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule, MatCheckboxModule,MatExpansionModule,MatAutocompleteModule,MatInputModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';
import { Ng2PaginationModule } from 'ng2-pagination'; 
import { OrderModule } from 'ngx-order-pipe';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { SharedModule } from '../../../shared/shared.module';
import {MatDatepickerModule} from '@angular/material/datepicker';
// import { KeysPipe } from '../pipes/keys.pipe';
import {MatDialogModule} from '@angular/material/dialog';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';

import { ConfiguratorOfferRoutingModule } from './configurator-offer-routing.module';

import { OfferComponent } from './offer.component';
import { OfferBucketGridViewComponent } from './offer-bucket-grid-view/offer-bucket-grid-view.component';
import { AddOfferComponent } from './add-offer/add-offer.component';
import { ConfiguratorProjectListComponent, PopsSaveSuccessDialogComponent } from './configurator-project-list/configurator-project-list.component';
import { ReadyToOfferListComponent } from './offer-bucket-grid-view/ready-to-offer-list/ready-to-offer-list.component';
import { GeneralInfoComponent } from './add-offer/general-info/general-info.component';
import { ProductAssociationComponent } from './add-offer/product-association/product-association.component';
import { DiscountAssociationComponent } from './add-offer/discount-association/discount-association.component';
import { RelevancyRulesComponent } from './add-offer/relevancy-rules/relevancy-rules.component';
import { EligiblityRulesComponent } from './add-offer/eligiblity-rules/eligiblity-rules.component';
import { PricingPinpointComponent } from './add-offer/pricing-pinpoint/pricing-pinpoint.component';
import { EcommPinpointComponent } from './add-offer/ecomm-pinpoint/ecomm-pinpoint.component';
import { OfferFromProjectComponent } from './add-offer/offer-from-project/offer-from-project.component';
import { DialogOverviewExampleDialogComponent, SubmitSuccessDialogComponent, SaveSuccessDialogComponent, ExitFormErrorDialogComponent } from './add-offer/add-offer.component';
import { SaveOfferListSuccessDialogComponent } from './offer-bucket-grid-view/ready-to-offer-list/ready-to-offer-list.component'
// import { ElgibilityRulesComponent } from './add-offer/elgibility-rules/elgibility-rules.component';
import { IntakeRequestDetailsComponent } from './intake-request-details/intake-request-details.component';
import { IntakeRequestDetailIntakeFormComponent } from './intake-request-details/intake-request-detail-intake-form/intake-request-detail-intake-form.component';
import { IntakeRequestDetailMasterFormComponent } from './intake-request-details/intake-request-detail-master-form/intake-request-detail-master-form.component';

import { ConfiguratorOfferDataService } from './configurator-offer-data.service';
import { ModifyOfferComponent, OfferReleaseDistributionSuccessDialogComponent, OfferValidateSubmitSuccessDialogComponent } from './modify-offer/modify-offer.component';
import { ServiceAgreementComponent } from './add-offer/service-agreement/service-agreement.component';
import { OfferBucketGridVewService } from './offer-bucket-grid-view/offer-bucket-grid-vew.service';





@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatSelectModule,
    Ng2PaginationModule,
    Ng2OrderModule,
    OrderModule,
    SharedModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatInputModule,
    MatDialogModule,
    Ng2SearchPipeModule,
    AngularMultiSelectModule,
    NgSelectModule, 
    ConfiguratorOfferRoutingModule
  ],
  declarations: [
    OfferComponent,
    OfferBucketGridViewComponent,
    AddOfferComponent,
    ConfiguratorProjectListComponent,
    ReadyToOfferListComponent,
    GeneralInfoComponent,
    ProductAssociationComponent,
    DiscountAssociationComponent,
    RelevancyRulesComponent,
    EligiblityRulesComponent,
    PricingPinpointComponent,
    EcommPinpointComponent,
    OfferFromProjectComponent,
    DialogOverviewExampleDialogComponent, 
    SubmitSuccessDialogComponent, 
    SaveSuccessDialogComponent, 
    PopsSaveSuccessDialogComponent, 
    ExitFormErrorDialogComponent, 
    IntakeRequestDetailsComponent,
    IntakeRequestDetailIntakeFormComponent,
    IntakeRequestDetailMasterFormComponent,
    SaveOfferListSuccessDialogComponent,
    ModifyOfferComponent, 
    OfferReleaseDistributionSuccessDialogComponent, 
    OfferValidateSubmitSuccessDialogComponent, ServiceAgreementComponent
    // KeysPipe
  ],
  entryComponents: [DialogOverviewExampleDialogComponent, SubmitSuccessDialogComponent, SaveSuccessDialogComponent, ExitFormErrorDialogComponent, SaveOfferListSuccessDialogComponent, OfferReleaseDistributionSuccessDialogComponent, OfferValidateSubmitSuccessDialogComponent, PopsSaveSuccessDialogComponent],
  providers: [ConfiguratorOfferDataService,OfferBucketGridViewComponent,OfferBucketGridVewService]
})
export class ConfiguratorOfferModule { }
