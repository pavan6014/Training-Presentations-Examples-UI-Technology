export interface ModifyOfferInterface {
}


export interface SearchOffer {
  offerId: number;
  offerName: string;
  offerDescription: string;
  salesAdvice: string;
  webDisplayName: string;
  estimatedmrc: string;
  offerStartDate: any;
  offerEndDate: any;
  primaryDiscount: string;
  offerStatus: string;
  changeRemarks: string;
  offerCategory: string;
  offerBundle: string;
  offerType: string;
  markets: string;
  channels: string;
  marketsSelectedItems: any;
  channelsSelectedItems: any;
  intakeRequestId: string;
  projectCode: string;
  status: string;
}
