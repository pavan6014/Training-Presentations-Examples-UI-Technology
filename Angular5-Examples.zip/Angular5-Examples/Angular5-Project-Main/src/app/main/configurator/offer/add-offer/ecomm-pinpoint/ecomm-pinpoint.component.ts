import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown, OffrEcommPinpntTxnDets } from '../add-offer-interface';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';

@Component({
  selector: 'plm-ecomm-pinpoint',
  templateUrl: './ecomm-pinpoint.component.html',
  providers: [UtilitiesService]
})

export class EcommPinpointComponent implements OnInit {

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerECOMMPinPointInfo: OffrEcommPinpntTxnDets;

  private addEditMode: Boolean;
  private viewMode: Boolean;
  private offerFormDropDown: any;
  private offerECOMMPinPointInfo: any;
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private ecomPinPointDropDownList = [];
  private ecomPinPointSelectedItems = [];

  constructor(
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    private utilitiesService: UtilitiesService
  ) {
    this.addEditMode = false;
    this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.offerECOMMPinPointInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet));
    if ((typeof this.offerFormDropDown != 'undefined') && (this.offerFormDropDown != null) && (Object.keys(this.offerFormDropDown).length > 0)) {
      this.updateDropDownList();
      this.updatePageMode();
      this.initializeSelectedItems();
    }
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: 'Select One',
      enableSearchFilter: true
    };
    this.multiSelectSettings = {
      singleSelection: false,
      text: 'Select',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      badgeShowLimit: 3,
      maxHeight: 120
    };
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        this.configuratorOfferDataService.addEditViewOfferFormData = text;
        this.offerECOMMPinPointInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet));
        this.initializeSelectedItems();
      }
    );
  }

  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
      this.addEditMode = true;
      this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
      this.addEditMode = false;
      this.viewMode = true;
    }
  }

  updateDropDownList() {
    this.ecomPinPointDropDownList = this.utilitiesService.getDropDownList(this.offerFormDropDown, 'ECOM_PINPOINT_STATUS');
    if ((typeof this.offerFormDropDown !== 'undefined') && (typeof this.offerECOMMPinPointInfo !== 'undefined')) {
      this.initializeSelectedItems();
    }
  }

  initializeSelectedItems() {
    this.ecomPinPointSelectedItems = this.utilitiesService.getSelectedItemsObject(this.offerFormDropDown, 'ECOM_PINPOINT_STATUS', this.offerECOMMPinPointInfo.statusId);
  }

  onItemSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
  }

  onItemDeSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
  }

  onSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
  }

  onDeSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
  }

  updateSelectedVal(key: string, items: any, selectType: string) {
    let resultVal = this.getValueBySelectType(items, selectType);
    this.updateSubmitData(key, resultVal);
  }

  getValueBySelectType(item: any, selectType: string) {
    let result;
    if (selectType === 'single') {
      result = this.utilitiesService.getSingleSelectID(item);
    } else {
      result = this.utilitiesService.getMultiSelectID(item)
    }
    return result;
  }

  convertTextAreaContentWithBreaks(field, value) {
    this.updateSubmitData(field, value.split('\n').join('<br />'));
  }

  updateSubmitData(field, value) {
    this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet[field] = value;
    this.configuratorOfferDataService.isAddEditOfferModified = true;
  }
  
}
