import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { RelevancyRules } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'plm-relevancy-rules',
  templateUrl: './relevancy-rules.component.html'
})
export class RelevancyRulesComponent implements OnInit {

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerRelevancyRulesInfo: OfferRelRuleTxnDets[];
  @BlockUI() blockUI: NgBlockUI;
  private offerFormDropDown: any;
  private offerRelevancyRulesInfo: any;
  private selectedRelevancyRules: RelevancyRules;
  private relevancyRulesList: RelevancyRules[];
  private relevancyRulesAssociate: any;
  private searchRelevancyRulesVal: string;
  private isRelevancyRulesExists: Boolean;
  private relevancyRules: RelevancyRules[];
  private showAddRelevancyRules: boolean;
  private relRulePrimaryFormula: string;
  private relRuleSecondaryFormula: string;
  private showAssociatedRelRules: boolean;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  selectedAll: any;

  constructor(
    private addOfferService: AddOfferService, 
    private configuratorOfferDataService: ConfiguratorOfferDataService
  ) {
    this.relevancyRulesList = [];
     this.relevancyRulesAssociate = [];
    this.searchRelevancyRulesVal = '';
    this.relRulePrimaryFormula= '';
    this.relRuleSecondaryFormula = '';
    this.isRelevancyRulesExists = false;
    this.showAddRelevancyRules = false;
    this.showAssociatedRelRules= false;
    this.addEditMode = false;
        this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.offerRelevancyRulesInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets));
    this.relevancyRulesAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets)); 
    if (this.relevancyRulesAssociate.rules.length > 0) {
      this.showAssociatedRelRules = true;
      this.resetRelevancyRulesID();
    }
    this.relRulePrimaryFormula= this.relevancyRulesAssociate.relRulePrimaryFormula;
    this.relRuleSecondaryFormula = this.relevancyRulesAssociate.relRuleSecondaryFormula;
    this.updatePageMode();
  }

  ngOnInit() {
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        this.offerRelevancyRulesInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets));
        this.relevancyRulesAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets)); 
        if (this.relevancyRulesAssociate.rules.length > 0) {
          this.showAssociatedRelRules = true;
          this.resetRelevancyRulesID();
        }
        this.relRulePrimaryFormula= this.relevancyRulesAssociate.relRulePrimaryFormula;
        this.relRuleSecondaryFormula = this.relevancyRulesAssociate.relRuleSecondaryFormula;
      }
    );
  }

  
  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
        this.addEditMode = true;
        this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
        this.addEditMode = false;
        this.viewMode = true;
    }
}
  removeRelevancyRules(index){
    this.relevancyRulesAssociate.rules.splice(index, 1);
    this.updateSubmitData();
    this.resetRelevancyRulesID();
    this.showHideAddRelevancyRules();
  }

  searchRelevancyRules() {
    this.blockUI.start('Loading Search Relevancy Rules...');
    this.relevancyRulesList = [];
    this.addOfferService.searchRelevancyRules(this.searchRelevancyRulesVal).subscribe(
      data => {
        this.relevancyRules = data.relevancySearchList;
        for(let i=0; i< this.relevancyRules.length; i++) {
          this.relevancyRules[i].primaryFlag = false;
          this.relevancyRules[i].secondaryFlag = false;
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  selectAllRelevancyRules(isChecked) {
    this.relevancyRulesList = [];
    if (isChecked) {
      for(let i=0; i<this.relevancyRules.length; i++) {
        this.relevancyRulesList.push(this.relevancyRules[i]);
        this.relevancyRulesList[i] = JSON.parse(JSON.stringify(this.relevancyRulesList[i]));
        //this.eligiblityRulesList.push(this.eligiblityRules[i]);
        this.relevancyRulesList[i].checked = true;
        this.relevancyRules[i].checked = true;
      }
    }
    else {
      for(let i=0; i<this.relevancyRules.length; i++) {
        this.relevancyRules[i].checked = false;
      }
    }
    this.checkIfAllSelected();
    this.showHideAddRelevancyRules();
  }

  checkIfAllSelected() {
    if (this.relevancyRulesList.length === this.relevancyRules.length) {
      this.selectedAll = true;
    } else {
      this.selectedAll = false;
    }
  }


  selectRelevancyRulesForAssociation(isChecked, relId) {
    if (isChecked) {
      this.relevancyRulesList.push(this.getProductByrelId(relId));
    } else {
      this.relevancyRulesList.splice(this.getrelevancyRulesListIndexByrelId(relId), 1);
    }
    this.checkIfAllSelected();
    this.showHideAddRelevancyRules();
  }

  getProductByrelId(relId) {
    let result: any;
    for (let i=0; i<this.relevancyRules.length; i++) {
      if (Number(this.relevancyRules[i].relId) === Number(relId))  {
        result = this.relevancyRules[i];
        break;
      }
    }
    return result;
  }

  getrelevancyRulesListIndexByrelId(relId) {
    let result: any;
    for (let i=0; i<this.relevancyRulesList.length; i++) {
      if (Number(this.relevancyRulesList[i].relId) === Number(relId))  {
        result = i;
        break;
      }
    }
    return result;
  }

  showHideAddRelevancyRules() {
    if (this.relevancyRulesList.length > 0) {
      this.showAddRelevancyRules = true;
    } else  {
      this.showAddRelevancyRules = false;
    }
  }

  addRelevancyRulesForAssociation() {
    for (let i=0; i<this.relevancyRulesList.length; i++) {
      if (!this.checkIsProductAlreadyAssociated(this.relevancyRulesList[i].relId)) {
        this.relevancyRulesAssociate.rules.push(this.relevancyRulesList[i]);
      }
    }
    this.updateSubmitData();
    this.showAssociatedRelRules = true;
    this.resetRelevancyRulesID();
    this.showHideAddRelevancyRules()
  }

  checkIsProductAlreadyAssociated(relId) {
    let result = false;
    for (let i=0; i<this.relevancyRulesAssociate.rules.length; i++) {
      if (Number(this.relevancyRulesAssociate.rules[i].relId) === Number(relId)) {
        result = true;
        break;
      }
    }
    return result;
  }

  removeProduct(index){
    this.relevancyRulesAssociate.rules.splice(index, 1);
    this.updateSubmitData();
    this.resetRelevancyRulesID();
    this.showHideAddRelevancyRules()
  }

  updatePrimaryFlag(isChecked, relId){
    for (let i=0; i<this.relevancyRulesAssociate.rules.length; i++) {
      if((Number(this.relevancyRulesAssociate.rules[i].relId) === Number(relId)) && (isChecked)) {
        this.relevancyRulesAssociate.rules[i].primaryFlag = true;
      } else if((Number(this.relevancyRulesAssociate.rules[i].relId) === Number(relId)) && (!isChecked)) {
        this.relevancyRulesAssociate.rules[i].primaryFlag = false;
      }
    }
    this.updateSubmitData();
  }

  updateSecondaryFlag(isChecked, relId){
    for (let i=0; i<this.relevancyRulesAssociate.rules.length; i++) {
      if((Number(this.relevancyRulesAssociate.rules[i].relId) === Number(relId)) && (isChecked)) {
        this.relevancyRulesAssociate.rules[i].secondaryFlag = true;
      } else if((Number(this.relevancyRulesAssociate.rules[i].relId) === Number(relId)) && (!isChecked)) {
        this.relevancyRulesAssociate.rules[i].secondaryFlag = false;
      }
    }
    this.updateSubmitData();
  }

  
  resetRelevancyRulesID(){
    for (let i=0; i<this.relevancyRulesAssociate.rules.length; i++) {
      this.relevancyRulesAssociate.rules[i]['relruleId'] = 'RR'+(Number(i)+1);
    }
  }

  updateSubmitData() {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets.rules = [];
    for (let i=0; i < this.relevancyRulesAssociate.rules.length; i++) {
      this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets.rules.push({
        'offrRelRruleMapId':null,
  			'relId': this.relevancyRulesAssociate.rules[i].relId,
  			'createdDate':'',
  			'modifiedDate':'',
  			'modifiedOwner':null,
  			'primaryFlag': this.relevancyRulesAssociate.rules[i].primaryFlag,
  			'secondaryFlag': this.relevancyRulesAssociate.rules[i].secondaryFlag,
  			'relruleId': this.relevancyRulesAssociate.rules[i].relruleId
      });
    }
    this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets.relRulePrimaryFormula = this.relRulePrimaryFormula;
    this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets.relRuleSecondaryFormula = this.relRuleSecondaryFormula;
  }

  updateFormula(key, value) {
    this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet[key] = value;
  }

  resetRelevancyRules() {
    this.searchRelevancyRulesVal = '';
    this.relevancyRules = [];
  }

}
