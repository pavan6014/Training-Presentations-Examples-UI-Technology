import { Component, OnInit, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SearchOffer } from './modify-offer-interface'
import { ModifyOffer, Offer } from '../offer-bucket-grid-view/offer-bucket-grid-vew-interface';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { ModifyOfferService } from './modify-offer.service';
import { ConfiguratorOfferDataService } from '../configurator-offer-data.service';
import { OfferBucketGridVewService } from '../offer-bucket-grid-view/offer-bucket-grid-vew.service';
import { UtilitiesService } from '../../../../shared/services/utilities.service';
import { RequestorService } from '../../../requestor/services/requestor.service';

@Component({
  selector: 'plm-modify-offer',
  templateUrl: './modify-offer.component.html',
  styleUrls: ['./modify-offer.component.css'],
  providers: [ModifyOfferService, OfferBucketGridVewService, UtilitiesService, RequestorService]
})
export class ModifyOfferComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;

  private masterData: any;
  private offerFormDropDown: any;
  private projectCode: string;
  private offersList: SearchOffer[];
  private offersReadyToRelease: Offer[];
  private addEditIntakeRequestMasterData: any;
  private projectData: any;
  private checkBoxEnable: boolean;

  private searchList: SearchOffer[];
  private offers: SearchOffer[];
  private searchOfferVal: string;
  private showHideValidateSubmitBtn: boolean;
  private isOfferListSelectAll: boolean;
  private offerReadyToTestSelectAll: boolean;
  private offerSearchSelectAll: boolean;
  private noOfferSelectedForRelease: boolean;
  private noOfferSelectedToAdd: boolean;
  private duplicateOfferToAdd: boolean;
  private duplicateOffersList: number[];

  private validateSubmitFailed: boolean;
  private testReleaseFailed: boolean;
  private errorMessageShow: boolean;
  private errorMessage: string;

  private multiSelectSettings = {};
  private marketDropDownList = [];
  private channelsListDropDownList = [];
  private marketSelectedItems = [];
  private channelsListSelectedItems = [];

  private key: string;
  private reverse: boolean;
  private showSearch: boolean;

  private offerId: string;
  private name: string;
  private type: string;
  private description: string;
  private estimatedMRC: string;
  private offerCategory: string;
  private startDate: string;
  private endDate: string;
  private bundle: string;
  private salesAdvice: string;
  private primaryDiscount: string;
  private lastModify: string;
  private status: string;
  private offerValidateSubmitSuccessList: any[];
  private offerValidateSubmitFailList: any[];
  private showOfferValidateSuccessDialog: boolean;
  private showOfferValidateFailDialog: boolean;

  private filterByofferId: string;
  private filterByname: string;
  private filterBytype: string;
  private filterBydescription: string;
  private filterByestimatedMRC: string;
  private filterByofferCategory: string;
  private filterBystartDate: string;
  private filterByendDate: string;
  private filterBybundle: string;
  private filterBysalesAdvice: string;
  private filterByprimaryDiscount: string;
  private filterBylastModify: string;
  private filterBystatus: string;
  private filterByValidationStatus: string;
  private filterBywebDisplay: string;
  private filterBymarkets: string;
  private filterBychannels: string;
  private filterBychangeRemarks: string;


  // private filterByprojectCode: string;
  // private filterByofferIds: string;
  // private filterByofferName: string;
  // private filterByofferDescription: string;
  // private filterBysites: string;
  // private filterBystartDt: string;
  // private filterByendDt: string;
  // private filterByreleaseDt: string;
  // private filterByreleaseCode: string;


  private filterByofferIdSearchObj: any;
  private filterBynameSearchObj: any;
  private filterBytypeSearchObj: any;
  private filterBydescriptionSearchObj: any;
  private filterByestimatedMRCSearchObj: any;
  private filterByofferCategorySearchObj: any;
  private filterBystartDateSearchObj: any;
  private filterByendDateSearchObj: any;
  private filterBybundleSearchObj: any;
  private filterBysalesAdviceSearchObj: any;
  private filterByprimaryDiscountSearchObj: any;
  private filterBylastModifySearchObj: any;
  private filterBystatusSearchObj: any;
  private filterByValidationStatusSearchObj: any;
  private filterBywebDisplaySearchObj: any;
  private filterBymarketsSearchObj: any;
  private filterBychannelsSearchObj: any;
  private filterBychangeRemarksSearchObj: any;



  // private filterByprojectCodeSearchObj: any;
  // private filterByofferIdsSearchObj: any;
  // private filterByofferNameSearchObj: any;
  // private filterByofferDescriptionSearchObj: any;
  // private filterBysitesSearchObj: any;
  // private filterBystartDtSearchObj: any;
  // private filterByendDtSearchObj: any;
  // private filterByreleaseDtSearchObj: any;
  // private filterByreleaseCodeSearchObj: any;


  private filterByofferIdInRelease: string;
  private filterBynameInRelease: string;
  private filterBytypeInRelease: string;
  private filterBydescriptionInRelease: string;
  private filterByestimatedMRCInRelease: string;
  private filterByofferCategoryInRelease: string;
  private filterBystartDateInRelease: string;
  private filterByendDateInRelease: string;
  private filterBybundleInRelease: string;
  private filterBysalesAdviceInRelease: string;
  private filterByprimaryDiscountInRelease: string;
  private filterBylastModifyInRelease: string;
  private filterBystatusInRelease: string;

  private filterByofferIdInReleaseSearchObj: any;
  private filterBynameInReleaseSearchObj: any;
  private filterBytypeInReleaseSearchObj: any;
  private filterBydescriptionInReleaseSearchObj: any;
  private filterByestimatedMRCInReleaseSearchObj: any;
  private filterByofferCategoryInReleaseSearchObj: any;
  private filterBystartDateInReleaseSearchObj: any;
  private filterByendDateInReleaseSearchObj: any;
  private filterBybundleInReleaseSearchObj: any;
  private filterBysalesAdviceInReleaseSearchObj: any;
  private filterByprimaryDiscountInReleaseSearchObj: any;
  private filterBylastModifyInReleaseSearchObj: any;
  private filterBystatusInReleaseSearchObj: any;


  constructor(
    private offerBucketGridViewService: OfferBucketGridVewService,
    private modifyOfferService: ModifyOfferService,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    private router: Router,
    public dialog: MatDialog,
    private utilitiesService: UtilitiesService,
    private requestorService: RequestorService
  ) {
    this.intializeOfferTestPage();
    this.resetValidateMessage();
    dialog.afterAllClosed
      .subscribe(() => {
        this.resetValidateMessage();
        this.onDialogClosed();
      }
      );
  }

  ngOnInit() {
    this.multiSelectSettings = {
      singleSelection: false,
      text: 'Select',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      badgeShowLimit: 3,
      maxHeight: 120
    };
  }

  intializeOfferTestPage() {
    this.offersList = [];
    this.configuratorOfferDataService.modifyOfferList = [];
    this.offersReadyToRelease = [];
    this.offerFormDropDown = {};
    this.showHideValidateSubmitBtn = false;
    this.searchOfferVal = '';
    this.resetErrorFields();
    this.isOfferListSelectAll = false;
    this.offerReadyToTestSelectAll = false;
    this.offerSearchSelectAll = false;
    this.noOfferSelectedForRelease = false;
    this.noOfferSelectedToAdd = false;
    this.duplicateOfferToAdd = false;
    this.duplicateOffersList = [];
    this.projectCode = this.configuratorOfferDataService.offerProjectCode;
    this.getOfferMasterData();
  }

  onDialogClosed() {
    this.intializeOfferTestPage();
    this.offerId = '';
    this.name = '';
    this.type = '';
    this.description = '';
    this.estimatedMRC = '';
    this.offerCategory = '';
    this.startDate = '';
    this.endDate = '';
    this.bundle = '';
    this.salesAdvice = '';
    this.primaryDiscount = '';
    this.lastModify = '';
    this.status = '';

    this.filterBybundle = '';
    this.filterBydescription = '';
    this.filterByendDate = '';
    this.filterByestimatedMRC = '';
    this.filterBylastModify = '';
    this.filterByname = '';
    this.filterByofferCategory = '';
    this.filterByofferId = '';
    this.filterByprimaryDiscount = '';
    this.filterBysalesAdvice = '';
    this.filterBystartDate = '';
    this.filterBystatus = '';
    this.filterByValidationStatus = '';
    this.filterBytype = '';
    this.filterBywebDisplay = '';
    this.filterBymarkets = '';
    this.filterBychannels = '';
    this.filterBychangeRemarks = '';


    this.filterByofferIdSearchObj = '';
    this.filterBynameSearchObj = '';
    this.filterBytypeSearchObj = '';
    this.filterBydescriptionSearchObj = '';
    this.filterByestimatedMRCSearchObj = '';
    this.filterByofferCategorySearchObj = '';
    this.filterBystartDateSearchObj = '';
    this.filterByendDateSearchObj = '';
    this.filterBybundleSearchObj = '';
    this.filterBysalesAdviceSearchObj = '';
    this.filterByprimaryDiscountSearchObj = '';
    this.filterBylastModifySearchObj = '';
    this.filterBystatusSearchObj = '';
    this.filterByValidationStatusSearchObj = '';
    this.filterBywebDisplaySearchObj = '';
    this.filterBymarketsSearchObj = '';
    this.filterBychannelsSearchObj = '';
    this.filterBychangeRemarksSearchObj = '';


    // this.filterByprojectCode = '';
    // this.filterByofferIds = '';
    // this.filterByofferName = '';
    // this.filterByofferDescription = '';
    // this.filterBysites = '';
    // this.filterBystartDt = '';
    // this.filterByendDt = '';
    // this.filterByreleaseDt = '';
    // this.filterByreleaseCode = '';


    // this.filterByprojectCodeSearchObj = '';
    // this.filterByofferIdsSearchObj = '';
    // this.filterByofferNameSearchObj = '';
    // this.filterByofferDescriptionSearchObj = '';
    // this.filterBysitesSearchObj = '';
    // this.filterBystartDtSearchObj = '';
    // this.filterByendDtSearchObj = '';
    // this.filterByreleaseDtSearchObj = '';
    // this.filterByreleaseCodeSearchObj = '';

    this.filterByofferIdInRelease = '';
    this.filterBynameInRelease = '';
    this.filterBytypeInRelease = '';
    this.filterBydescriptionInRelease = '';
    this.filterByestimatedMRCInRelease = '';
    this.filterByofferCategoryInRelease = '';
    this.filterBystartDateInRelease = '';
    this.filterByendDateInRelease = '';
    this.filterBybundleInRelease = '';
    this.filterBysalesAdviceInRelease = '';
    this.filterByprimaryDiscountInRelease = '';
    this.filterBylastModifyInRelease = '';
    this.filterBystatusInRelease = '';

    this.filterByofferIdInReleaseSearchObj = '';
    this.filterBynameInReleaseSearchObj = '';
    this.filterBytypeInReleaseSearchObj = '';
    this.filterBydescriptionInReleaseSearchObj = '';
    this.filterByestimatedMRCInReleaseSearchObj = '';
    this.filterByofferCategoryInReleaseSearchObj = '';
    this.filterBystartDateInReleaseSearchObj = '';
    this.filterByendDateInReleaseSearchObj = '';
    this.filterBybundleInReleaseSearchObj = '';
    this.filterBysalesAdviceInReleaseSearchObj = '';
    this.filterByprimaryDiscountInReleaseSearchObj = '';
    this.filterBylastModifyInReleaseSearchObj = '';
    this.filterBystatusInReleaseSearchObj = '';
  }

  resetErrorFields() {
    this.validateSubmitFailed = false;
    this.testReleaseFailed = false;
    this.errorMessageShow = false;
    this.errorMessage = '';
  }

  resetValidateMessage() {
    this.offerValidateSubmitSuccessList = [];
    this.offerValidateSubmitFailList = [];
    this.showOfferValidateSuccessDialog = false;
    this.showOfferValidateFailDialog = false;
  }

  getOfferMasterData() {
    this.blockUI.start('Loading Master Data...');
    this.modifyOfferService.getModifyOfferMasterData()
      .subscribe(
      data => {
        this.masterData = data;
        this.populateFormFieldValues();
        this.blockUI.stop();
        this.getConfiguratorOfferList();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
      );
  }

  getConfiguratorOfferList() {
    this.blockUI.start('Loading Offer List...');
    this.modifyOfferService.getModifyOfferListData(this.projectCode)
      .subscribe(
      data => {
        if (data.offersModify) {
          this.offersList = JSON.parse(JSON.stringify(data.offersModify));
          this.configuratorOfferDataService.modifyOfferList = JSON.parse(JSON.stringify(data.offersModify));
          for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
            this.offersList[i]['validationStatus'] = '';
            this.configuratorOfferDataService.modifyOfferList[i]['checked'] = false;
            this.offersList[i]['offerEndDate'] = new Date(this.offersList[i]['endDt']);
            this.configuratorOfferDataService.modifyOfferList[i]['offerEndDate'] = new Date(this.configuratorOfferDataService.modifyOfferList[i]['endDt']);
          }
          this.offersReadyToRelease = data.completedOffers;
          for (let j = 0; j < this.offersReadyToRelease.length; j++) {
            this.offersReadyToRelease[j]['checked'] = false;
          }
          this.initializeSelectedItems();
        }
        this.blockUI.stop();
        // this.offerEditEnable();
      },
      error => {
        console.log("Error :: " + error);
        this.blockUI.stop();
      }
      );
  }

  getSearchOffer() {
    this.blockUI.start('Loading Search Offers...');
    this.searchList = [];
    this.modifyOfferService.getSearchOfferList(this.searchOfferVal)
      .subscribe(
      data => {
        let offerModifySearchList = data.offerModifyModelList;
        for (let i = 0; i < offerModifySearchList.length; i++) {
          offerModifySearchList[i]['checked'] = false;
          this.searchList.push(offerModifySearchList[i]);
        }
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error);
        this.blockUI.stop();
      }
      );
  }

  addSearchOffer() {
    this.duplicateOfferToAdd = false;
    this.duplicateOffersList = [];
    for (let i = 0; i < this.searchList.length; i++) {
      if ((this.searchList[i]['checked']) && (!this.checkIfOfferAlreadyAdded(this.searchList[i].offerId))) {
        this.searchList[i]['checked'] = false;
        this.searchList[i]['offerEndDate'] = (this.searchList[i]['endDt']) ? new Date(this.searchList[i]['endDt']) : this.searchList[i]['endDt'];
        this.offersList.push(JSON.parse(JSON.stringify(this.searchList[i])));
        // if (((this.configuratorOfferDataService.offerProjectCode) === (this.searchList[i].intakeRequestId)) && (this.searchList[i].status === 'Production Published')) {
        //   this.checkBoxEnable = true;
        // }
        this.initializeSelectedItems();
        this.configuratorOfferDataService.modifyOfferList.push(JSON.parse(JSON.stringify(this.searchList[i])));
        this.dialog.closeAll();
      } else if ((this.searchList[i]['checked']) && (this.checkIfOfferAlreadyAdded(this.searchList[i].offerId))) {
        this.duplicateOffersList.push(this.searchList[i].offerId);
        this.duplicateOfferToAdd = true;
      }
    }
    // this.offerEditEnable();
  }

  checkIfOfferAlreadyAdded(offerId) {
    let result = false, offersList = this.getOfferListOfferIDs();
    if (offersList.indexOf(offerId) != -1) {
      result = true;
    }
    return result;
  }

  getOfferListOfferIDs() {
    let result = [];
    for (let i = 0; i < this.offersList.length; i++) {
      result.push(this.offersList[i].offerId);
    }
    return result;
  }

  // offerEditEnable() {
  //   for (let i = 0; i < this.offersList.length; i++) {
  //     this.checkBoxEnable = false;
  //     if(((this.configuratorOfferDataService.offerProjectCode) === (this.offersList[i].intakeRequestId)) && (this.offersList[i].status === 'Production Published')){
  //       this.checkBoxEnable = true;
  //     }
  //   }
  // }

  removeOffer(offerID) {
    let offerIDVal = offerID;
    this.offersList = this.getOtherElementsInOffers(offerIDVal);
    this.configuratorOfferDataService.modifyOfferList = this.offersList;
  }

  getOtherElementsInOffers(offerIDVal) {
    let result = [];
    for (let i = 0; i < this.offersList.length; i++) {
      if (this.offersList[i].offerId != offerIDVal) {
        result.push(this.offersList[i]);
      }
    }
    return result;
  }

  updateSearchListSelect(offerId, isChecked) {
    for (let i = 0; i < this.searchList.length; i++) {
      if (this.searchList[i]['offerId'] == offerId) {
        this.searchList[i]['checked'] = isChecked;
      }
    }
    this.offerSearchSelectAll = this.checkIsSearchListSelectedAll(this.searchList);
    this.noOfferSelectedToAdd = (this.getSelectedCount(this.searchList) > 0);
  }

  convertTextAreaContentWithBreaks(offerId, field, value) {
    this.updateSubmitData(offerId, field, value.split('\n').join('<br />'));
  }

  convertBreakTagToLineBreak(value) {
    let result = '';
    if (value != null) {
      return value.split('<br />').join('\n');
    }
    return value;
  }


  getDateInFormat(date) {
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth()) + 1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
  }

  getDateMonthInTwoDigits(value) {
    return (value < 10 ? '0' : '') + value;
  }

  updateMarketsList(offerId, field, value) {
    let markets = this.getSelectedIDs(value);
    this.updateSubmitData(offerId, field, markets);
  }

  getSelectedIDs(value) {
    let result = [];
    for (let i = 0; i < value.length; i++) {
      result.push(value[i].id);
    }
    return result;
  }

  updateChannelsList(offerId, field, value) {
    let channels = this.getSelectedIDs(value);
    this.updateSubmitData(offerId, field, channels);
  }

  updateOfferListSelectAll(isChecked) {
    for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
      this.configuratorOfferDataService.modifyOfferList[i]['checked'] = isChecked;
      this.offersList[i]['checked'] = isChecked;
      // if(this.configuratorOfferDataService.modifyOfferList[i].status === 'Production Published'){
      //   this.offersList[i]['checked'] = false;
      // }
    }
    this.showHideValidateBtn();
  }

  updateOfferReadyToTestSelectAll(isChecked) {
    for (let i = 0; i < this.offersReadyToRelease.length; i++) {
      this.offersReadyToRelease[i]['checked'] = isChecked;
    }
    this.noOfferSelectedForRelease = (this.getSelectedCount(this.offersReadyToRelease) > 0);
  }

  updateSearchListSelectAll(isChecked) {
    for (let i = 0; i < this.searchList.length; i++) {
      this.searchList[i]['checked'] = isChecked;
    }
    this.noOfferSelectedToAdd = (this.getSelectedCount(this.searchList) > 0);
  }

  checkIsSearchListSelectedAll(searchVal) {
    let count = this.getSelectedCount(searchVal);
    return (count == searchVal.length);
  }

  getSelectedCount(searchVal) {
    let count = 0;
    for (let i = 0; i < searchVal.length; i++) {
      if (searchVal[i]['checked']) {
        count++;
      }
    }
    return count;
  }

  updateOfferReadyToRelease(offerId, isChecked) {
    for (let i = 0; i < this.offersReadyToRelease.length; i++) {
      if (this.offersReadyToRelease[i]['offerId'] == offerId) {
        this.offersReadyToRelease[i]['checked'] = isChecked;
      }
    }
    this.offerReadyToTestSelectAll = this.checkIsSearchListSelectedAll(this.offersReadyToRelease);
    this.noOfferSelectedForRelease = (this.getSelectedCount(this.offersReadyToRelease) > 0);
  }

  updateSubmitData(offerId, field, value) {
    for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
      if (this.configuratorOfferDataService.modifyOfferList[i]['offerId'] == offerId) {
        this.configuratorOfferDataService.modifyOfferList[i][field] = value;
      }
    }
    this.showHideValidateBtn();
    this.isOfferListSelectAll = this.checkIsSearchListSelectedAll(this.configuratorOfferDataService.modifyOfferList);
  }


  updateEndDate(offerId, field, endDate) {
    let dateInFormat = this.getDateInFormat(JSON.parse(JSON.stringify(endDate)));
    for (let i = 0; i < this.offersList.length; i++) {
      if (this.offersList[i]['offerId'] == offerId) {
        this.offersList[i]['offerEndDate'] = new Date(endDate);
      }
    }
    this.updateSubmitData(offerId, 'offerEndDate', dateInFormat);
  }

  getSites(arr) {
    return arr.join(', ');
  }

  showHideValidateBtn() {
    let count = 0;
    for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
      if (this.configuratorOfferDataService.modifyOfferList[i]['checked']) {
        count++;
      }
    }
    if (count > 0) {
      this.showHideValidateSubmitBtn = true;
    } else {
      this.showHideValidateSubmitBtn = false;
    }
  }

  validateandsubmit() {
    let submitObj = this.getValidateAndSubmitData();
    this.blockUI.start('Submitting Offers...');
    this.showOfferValidateFailDialog = false;
    this.showOfferValidateSuccessDialog = false;
    this.modifyOfferService.validateAndSubmitOffer(submitObj)
      .subscribe(
      data => {
        this.resetErrorFields();
        if (data.omcPinpointInterfaceResponseLst) {
          this.updateModifyOfferValidateMessages(data.omcPinpointInterfaceResponseLst);
        } else {
          this.validateSubmitFailed = true;
        }
        this.updateErrorMessages(data);
        this.onDialogClosed();
        this.showHideValidateBtn();
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error);
        this.blockUI.stop();
      }
      );
  }

  updateModifyOfferValidateMessages(releaseList) {
    for (let i = 0; i < releaseList.length; i++) {
      let currentReleaseObj = releaseList[i];
      let offerObj = {
        'offerID': currentReleaseObj['vwOmcPinpntInterfaceDefnModel']['EXTERNAL_ID'],
        'errorMessage': currentReleaseObj['error_details']['error_desc']
      };
      if (currentReleaseObj['actionStatus'] === 'SUCCESS') {
        this.offerValidateSubmitSuccessList.push(offerObj);
      } else if (currentReleaseObj['actionStatus'] === 'FAIL') {
        this.offerValidateSubmitFailList.push(offerObj);
      }
      this.updateValidationStatus(currentReleaseObj['vwOmcPinpntInterfaceDefnModel']['EXTERNAL_ID'], currentReleaseObj['actionStatus']);
    }
  }

  updateValidationStatus(offerID, status) {
    for (let i = 0; i < this.offersList.length; i++) {
      if (this.offersList[i].offerId === Number(offerID)) {
        this.offersList[i]['validationStaus'] = status;
      }
    }
  }

  updateErrorMessages(data) {
    if ((!data.omcPinpointInterfaceResponseLst) || (!data.offerModifyModelList)) {
      return false;
    }
    if ((this.offerValidateSubmitSuccessList.length === data.omcPinpointInterfaceResponseLst.length)) {
      this.configuratorOfferDataService.offerListSuccessAfterSubmit = this.getOfferListAfterSuccessfulSubmit(data.offerModifyModelList);
      // this.openOfferValidateSubmitSuccessDialog();
      this.showOfferValidateSuccessDialog = true;
    } else if (this.offerValidateSubmitSuccessList.length !== data.omcPinpointInterfaceResponseLst.length) {
      this.validateSubmitFailed = true;

      setTimeout(function () {
        this.showOfferValidateFailDialog = true;
      }.bind(this), 5000);
      // this.errorMessageShow = true;
      // this.errorMessage = data.actionResult.errors[0]['description'];
      for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
        this.configuratorOfferDataService.modifyOfferList[i]['checked'] = false;
        this.offersList[i]['checked'] = false;
      }
    }
  }

  getOfferListAfterSuccessfulSubmit(arr) {
    let result = [];
    for (let i = 0; i < arr.length; i++) {
      result.push(arr[i]['offerId']);
    }
    return result.join(', ');
  }

  getValidateAndSubmitData() {
    let result = {};
    result['offerModifyModelList'] = [];
    for (let i = 0; i < this.configuratorOfferDataService.modifyOfferList.length; i++) {
      if (this.configuratorOfferDataService.modifyOfferList[i]['checked']) {
        let resultObj = {};
        resultObj['offerId'] = this.configuratorOfferDataService.modifyOfferList[i]['offerId'];
        resultObj['salesAdvice'] = this.configuratorOfferDataService.modifyOfferList[i]['salesAdvice'];
        resultObj['offerDescription'] = this.configuratorOfferDataService.modifyOfferList[i]['offerDescription'];
        resultObj['markets'] = this.configuratorOfferDataService.modifyOfferList[i]['markets'];
        resultObj['channels'] = this.configuratorOfferDataService.modifyOfferList[i]['channels'];
        resultObj['endDt'] = this.getDateInFormat(this.configuratorOfferDataService.modifyOfferList[i]['offerEndDate']);
        resultObj['webDisplayName'] = this.configuratorOfferDataService.modifyOfferList[i]['webDisplayName'];
        resultObj['changeRemarks'] = this.configuratorOfferDataService.modifyOfferList[i]['changeRemarks'];
        resultObj['intakeRequestId'] = this.projectCode;
        result['offerModifyModelList'].push(resultObj);
      }
    }
    return result;
  }

  releaseOffersForDistribution() {
    this.blockUI.start('Submitting Offers...');
    let offerForDistributionList = this.getOfferForDistributionList();
    const reqObj = {
      'projectCode': this.configuratorOfferDataService.offerProjectCode,
      'offersList': offerForDistributionList
    }
    this.offerBucketGridViewService.submitOfferForRelease(reqObj)
      .subscribe(
      data => {
        this.resetErrorFields();
        if (data.actionStatus === 'SUCCESS') {
          this.configuratorOfferDataService.offerListSuccessAfterSubmit = offerForDistributionList.join(', ');
          this.openOfferReleaseDistributionSuccessDialog();
        } else if (data.actionStatus === 'FAIL') {
          this.testReleaseFailed = true;
          this.errorMessageShow = true;
          this.errorMessage = data.actionResult.errors[0]['description'];
          for (let i = 0; i < this.offersReadyToRelease.length; i++) {
            this.offersReadyToRelease[i]['checked'] = false;
          }
          this.noOfferSelectedForRelease = false;
        }
        this.blockUI.stop();
      },
      error => {
        console.log("Error :: " + error);
        this.blockUI.stop();
      }
      );
  }

  getOfferForDistributionList() {
    let result = [];
    for (let i = 0; i < this.offersReadyToRelease.length; i++) {
      if (this.offersReadyToRelease[i]['checked']) {
        result.push(this.offersReadyToRelease[i]['offerId']);
      }
    }
    return result;
  }

  populateFormFieldValues() {
    for (let i = 0; i < this.masterData.commonMasterData.length; i++) {
      const currentMasterData = this.masterData.commonMasterData[i];
      this.offerFormDropDown[currentMasterData.name] = currentMasterData.records;
    }
    this.offerFormDropDown['campaignCodesList'] = this.masterData.campaignCodesList;
    this.offerFormDropDown['marketMasterMap'] = this.masterData.marketMasterMap;
    this.offerFormDropDown['MARKETS'] = [];
    for (let prop in this.offerFormDropDown['marketMasterMap']) {
      this.pushMarketsData(this.offerFormDropDown['marketMasterMap'][prop]);
    }
    this.configuratorOfferDataService.masterFormData = this.offerFormDropDown;
    this.updateDropDownList();
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.offerFormDropDown['MARKETS'].push(markets[i]);
    }
  }

  updateDropDownList() {
    this.marketDropDownList = this.getMarketsDropDownList(this.offerFormDropDown, 'MARKETS');
    this.channelsListDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'CHANNELSLABEL');
    if ((typeof this.offersList !== 'undefined') && (this.offersList !== null) && (this.offersList.length > 0)) {
      this.initializeSelectedItems();
    }
  }

  initializeSelectedItems() {
    for (let i = 0; i < this.offersList.length; i++) {
      this.offersList[i].marketsSelectedItems = this.getSelectedMarketsList(this.offersList[i].markets);
      this.offersList[i].channelsSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'CHANNELSLABEL', this.offersList[i].channels);
    }
  }

  getMarketsDropDownList(masterData, dropDownKey) {
    let result = [];
    for (let i = 0; i < masterData[dropDownKey].length; i++) {
      result.push({
        'id': Number(masterData[dropDownKey][i]['siteId']),
        'name': masterData[dropDownKey][i]['siteCodeName']
      });
    }
    return result;
  }

  getSelectedMarketsList(markets) {
    let result = [];
    for (let i = 0; i < this.marketDropDownList.length; i++) {
      if (markets.indexOf(this.marketDropDownList[i].id) > -1) {
        result.push(this.marketDropDownList[i]);
      }
    }
    return result;
  }

  resetOfferSearch() {
    this.searchList = [];
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }


  openOfferValidateSubmitSuccessDialog(): void {
    let dialogRef = this.dialog.open(OfferValidateSubmitSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      //this.getProjectOfferTestList();
    });
  }

  openOfferReleaseDistributionSuccessDialog(): void {
    let dialogRef = this.dialog.open(OfferReleaseDistributionSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      //this.getProjectOfferTestList();
    });
  }

  viewOffer(offerCode) {
    this.configuratorOfferDataService.offerAddEditViewMode = 'view';
    this.configuratorOfferDataService.offerCodeForEditView = offerCode;
    this.configuratorOfferDataService.backURL = '/plm-work-flow/configurator/offer/modify-offer';
    this.router.navigate(['/plm-work-flow/configurator/offer/view-offer']);
  }



  moveToIntakeRequestView() {
    // this.configuratorOfferDataService.offerProjectCode = this.projectCode;
    // localStorage.setItem('mode','view');
    // localStorage.setItem('intakeRequestID', this.projectCode);
    // localStorage.setItem('backURL', 'plm-work-flow/configurator/offer/offer-table');
    // // this.router.navigate(['plm-work-flow/requestor/view-intake-request']);
    // window.open('', 'Discount Intake Request', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1600,height=850, top=100,left=200');
    this.getAddEditIntakeRequestMasterData();
  }


  getAddEditIntakeRequestMasterData() {
    this.blockUI.start('Loading Intake Request Master Data...');
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (let prop in this.addEditIntakeRequestMasterData['mapMarketList']) {
          this.pushMarketsData(this.addEditIntakeRequestMasterData['mapMarketList'][prop]);
        }
        this.fetchEditProjectData();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  fetchEditProjectData() {
    this.blockUI.start('Loading Intake Request Detail...');
    this.requestorService.getEditProjectData(this.projectCode).subscribe(
      data => {
        this.projectData = data;
        this.resetNullValuesInObj(this.projectData.projectMasterModel);
        this.resetNullValuesInObj(this.projectData.projectMasterModel.intakeFormReqTxnDetModel);
        this.projectData.projectMasterModel.projectStartDt = this.converetDate(this.projectData.projectMasterModel.projectStartDt);
        this.projectData.projectMasterModel.projectEndDt = this.converetDate(this.projectData.projectMasterModel.projectEndDt);
        localStorage.setItem('projectCode', this.projectData.projectMasterModel.projectCode);
        localStorage.setItem('uploadIntakeRequestDocId', this.projectData.projectMasterModel.uploadIntakeRequestDocId);
        this.utilitiesService.triggerWindowTab(this.addEditIntakeRequestMasterData, this.projectData);
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  resetNullValuesInObj(data) {
    for (let prop in data) {
      data[prop] = (data[prop]) ? data[prop] : '';
    }
  }

  converetDate(startDate) {
    return this.getDateInFormat(startDate);
  }


  // pushMarketsData(markets) {
  //   for(let i=0; i<markets.length; i++) {
  //     this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
  //   }
  // }

  initializeFilterContext() {
    this.filterBybundleSearchObj = {
      'offerBundleName': {
        'type': 'text',
        'value': this.filterBybundle,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionSearchObj = {
      'offerDescription': {
        'type': 'text',
        'value': this.filterBydescription,
        'matchFullCase': false
      }
    };
    this.filterByendDateSearchObj = {
      'endDt': {
        'type': 'text',
        'value': this.filterByendDate,
        'matchFullCase': false
      }
    };
    this.filterByestimatedMRCSearchObj = {
      'estimatedMrc': {
        'type': 'text',
        'value': this.filterByestimatedMRC,
        'matchFullCase': false
      }
    };
    this.filterBylastModifySearchObj = {
      'lastUpdateDate': {
        'type': 'text',
        'value': this.filterBylastModify,
        'matchFullCase': false
      }
    };
    this.filterBynameSearchObj = {
      'offerName': {
        'type': 'text',
        'value': this.filterByname,
        'matchFullCase': false
      }
    };
    this.filterByofferCategorySearchObj = {
      'offerCategory': {
        'type': 'text',
        'value': this.filterByofferCategory,
        'matchFullCase': false
      }
    };
    this.filterByofferIdSearchObj = {
      'offerId': {
        'type': 'text',
        'value': String('' + this.filterByofferId),
        'matchFullCase': false
      }
    };
    this.filterByprimaryDiscountSearchObj = {
      'primaryDiscountCode': {
        'type': 'text',
        'value': this.filterByprimaryDiscount,
        'matchFullCase': false
      }
    };
    this.filterBysalesAdviceSearchObj = {
      'salesAdvise': {
        'type': 'text',
        'value': this.filterBysalesAdvice,
        'matchFullCase': false
      }
    };
    this.filterBystartDateSearchObj = {
      'startDt': {
        'type': 'text',
        'value': this.filterBystartDate,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
    this.filterByValidationStatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterByValidationStatus,
        'matchFullCase': false
      }
    };
    this.filterBytypeSearchObj = {
      'psu': {
        'type': 'text',
        'value': this.filterBytype,
        'matchFullCase': false
      }
    };
    this.filterBywebDisplaySearchObj = {
      'webDisplay': {
        'type': 'text',
        'value': this.filterBywebDisplay,
        'matchFullCase': false
      }
    };

    this.filterBymarketsSearchObj = {
      'markets': {
        'type': 'text',
        'value': this.filterBymarkets,
        'matchFullCase': false
      }
    };

    this.filterBychannelsSearchObj = {
      'channels': {
        'type': 'text',
        'value': this.filterBychannels,
        'matchFullCase': false
      }
    };

    this.filterBychangeRemarksSearchObj = {
      'changeRemarks': {
        'type': 'text',
        'value': this.filterBychangeRemarks,
        'matchFullCase': false
      }
    };
    this.filterByofferIdInReleaseSearchObj = {
      'offerId': {
        'type': 'text',
        'value': this.filterByofferIdInRelease,
        'matchFullCase': false
      }
    };
    this.filterBynameInReleaseSearchObj = {
      'offerName': {
        'type': 'text',
        'value': this.filterBynameInRelease,
        'matchFullCase': false
      }
    };
    this.filterBytypeInReleaseSearchObj = {
      'psu': {
        'type': 'text',
        'value': this.filterBytypeInRelease,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionInReleaseSearchObj = {
      'offerDescription': {
        'type': 'text',
        'value': this.filterBydescriptionInRelease,
        'matchFullCase': false
      }
    };
    this.filterByestimatedMRCInReleaseSearchObj = {
      'estimatedMrc': {
        'type': 'text',
        'value': this.filterByestimatedMRCInRelease,
        'matchFullCase': false
      }
    };
    this.filterByofferCategoryInReleaseSearchObj = {
      'offerCategory': {
        'type': 'text',
        'value': this.filterByofferCategoryInRelease,
        'matchFullCase': false
      }
    };
    this.filterBystartDateInReleaseSearchObj = {
      'startDt': {
        'type': 'text',
        'value': this.filterBystartDateInRelease,
        'matchFullCase': false
      }
    };
    this.filterByendDateInReleaseSearchObj = {
      'endDt': {
        'type': 'text',
        'value': this.filterByendDateInRelease,
        'matchFullCase': false
      }
    };
    this.filterBybundleInReleaseSearchObj = {
      'offerBundleName': {
        'type': 'text',
        'value': this.filterBybundleInRelease,
        'matchFullCase': false
      }
    };
    this.filterBysalesAdviceInReleaseSearchObj = {
      'salesAdvise': {
        'type': 'text',
        'value': this.filterBysalesAdviceInRelease,
        'matchFullCase': false
      }
    };
    this.filterByprimaryDiscountInReleaseSearchObj = {
      'primaryDiscountCode': {
        'type': 'text',
        'value': this.filterByprimaryDiscountInRelease,
        'matchFullCase': false
      }
    };
    this.filterBylastModifyInReleaseSearchObj = {
      'lastUpdateDate': {
        'type': 'text',
        'value': this.filterBylastModifyInRelease,
        'matchFullCase': false
      }
    };
    this.filterBystatusInReleaseSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatusInRelease,
        'matchFullCase': false
      }
    };
  }


  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }


}


@Component({
  selector: 'offer-validate-submit-success',
  templateUrl: './validate-submit-success-dialog.html'
})
export class OfferValidateSubmitSuccessDialogComponent {
  private offerList: string;
  constructor(
    public dialogRef: MatDialogRef<OfferValidateSubmitSuccessDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerList = this.configuratorOfferDataService.offerListSuccessAfterSubmit;
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onCloseButtonClick() {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
  }

}


@Component({
  selector: 'plm-offer-release-distribution-submit-success',
  templateUrl: './release-distribution-success-dialog.html'
})
export class OfferReleaseDistributionSuccessDialogComponent {
  private offerList: string;
  constructor(
    public dialogRef: MatDialogRef<OfferReleaseDistributionSuccessDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerList = this.configuratorOfferDataService.offerListSuccessAfterSubmit;
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onCloseButtonClick() {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
  }
}

