import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { EligiblityRules } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'plm-eligiblity-rules',
  templateUrl: './eligiblity-rules.component.html'
})
export class EligiblityRulesComponent implements OnInit {

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerEligiblityRulesInfo: offerEligRuleTxnDets[];
  
  @BlockUI() blockUI: NgBlockUI;
  private offerFormDropDown: any;
  private offerEligiblityRulesInfo: any;
  private selectedEligiblityRules: EligiblityRules;
  private eligiblityRulesList: EligiblityRules[];
  private eligiblityRulesAssociate: any;
  private searchEligiblityRulesVal: string;
  private isEligiblityRulesExists: Boolean;
  private eligiblityRules: EligiblityRules[];
  private showAddEligiblityRules: boolean;
  private eligRulePrimaryFormula: string;
  private eligRuleSecondaryFormula: string;
  private showAssociatedEligRules: boolean;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  selectedAll: any;

  constructor(
    private addOfferService: AddOfferService, 
    private configuratorOfferDataService: ConfiguratorOfferDataService
  ) {
    this.eligiblityRulesList = [];
    // this.eligiblityRulesAssociate = [];
    this.searchEligiblityRulesVal = '';
    this.eligRulePrimaryFormula = '';
    this.eligRuleSecondaryFormula = '';
    this.isEligiblityRulesExists = false;
    this.showAddEligiblityRules = false;
    this.showAssociatedEligRules = false;
    this.addEditMode = false;
        this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    // this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet = this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet;
    this.offerEligiblityRulesInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet));
    this.eligiblityRulesAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet)); 
    if (this.eligiblityRulesAssociate.rules.length > 0) {
      this.showAssociatedEligRules = true;
    }
    this.eligRulePrimaryFormula= this.eligiblityRulesAssociate.eligRulePrimaryFormula;
    this.eligRuleSecondaryFormula = this.eligiblityRulesAssociate.eligRuleSecondaryFormula;
    this.updatePageMode();
  }

  ngOnInit() {
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        this.offerEligiblityRulesInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet));
        this.eligiblityRulesAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet)); 
        if (this.eligiblityRulesAssociate.rules.length > 0) {
          this.showAssociatedEligRules = true;
        }
        this.eligRulePrimaryFormula= this.eligiblityRulesAssociate.eligRulePrimaryFormula;
        this.eligRuleSecondaryFormula = this.eligiblityRulesAssociate.eligRuleSecondaryFormula;
      }
    );
  }

  removeEligiblityRules(index){
    this.eligiblityRulesAssociate.rules.splice(index, 1);
    this.resetEligiblityRulesID();
    this.updateSubmitData();
    this.showHideAddEligiblityRules();
  }
  
  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
        this.addEditMode = true;
        this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
        this.addEditMode = false;
        this.viewMode = true;
    }
}

  searchEligiblityRules() {
    this.blockUI.start('Loading Search Relevancy Rules...');
    this.eligiblityRulesList = [];
    this.addOfferService.searchEligiblityRules(this.searchEligiblityRulesVal).subscribe(
      data => {
        this.eligiblityRules = data.eligibilitySearchList;
        for(let i=0; i< this.eligiblityRules.length; i++) {
          this.eligiblityRules[i].primaryFlag = false;
          this.eligiblityRules[i].secondaryFlag = false;
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  selectAllEligiblityRules(isChecked) {
    this.eligiblityRulesList = [];
    if (isChecked) {
      for(let i=0; i<this.eligiblityRules.length; i++) {
        this.eligiblityRulesList[i] = JSON.parse(JSON.stringify(this.eligiblityRules[i]));
        //this.eligiblityRulesList.push(this.eligiblityRules[i]);
        this.eligiblityRulesList[i].checked = true;
        this.eligiblityRules[i].checked = true;
      }
    }
    else {
      for(let i=0; i<this.eligiblityRules.length; i++) {
        this.eligiblityRules[i].checked = false;
      }
    }
    this.checkIfAllSelected();
    this.showHideAddEligiblityRules();
  }

  checkIfAllSelected() {
    if (this.eligiblityRulesList.length === this.eligiblityRules.length) {
      this.selectedAll = true;
    } else {
      this.selectedAll = false;
    }
  }

  selectEligiblityRulesForAssociation(isChecked, eligiId) {
    if (isChecked) {
      this.eligiblityRulesList.push(this.getProductByeligiId(eligiId));
    } else {
      this.eligiblityRulesList.splice(this.geteligiblityRulesListIndexByeligiId(eligiId), 1);
    }
    this.checkIfAllSelected();
    this.showHideAddEligiblityRules();
  }

  getProductByeligiId(eligiId) {
    let result: any;
    for (let i=0; i<this.eligiblityRules.length; i++) {
      if (Number(this.eligiblityRules[i].eligiId) === Number(eligiId))  {
        result = this.eligiblityRules[i];
        break;
      }
    }
    return result;
  }

  geteligiblityRulesListIndexByeligiId(eligiId) {
    let result: any;
    for (let i=0; i<this.eligiblityRulesList.length; i++) {
      if (Number(this.eligiblityRulesList[i].eligiId) === Number(eligiId))  {
        result = i;
        break;
      }
    }
    return result;
  }

  showHideAddEligiblityRules() {
    if (this.eligiblityRulesList.length > 0) {
      this.showAddEligiblityRules = true;
    } else  {
      this.showAddEligiblityRules = false;
    }
  }

  addEligiblityRulesForAssociation() {
    for (let i=0; i<this.eligiblityRulesList.length; i++) {
      if (!this.checkIsProductAlreadyAssociated(this.eligiblityRulesList[i].eligiId)) {
        this.eligiblityRulesAssociate.rules.push(this.eligiblityRulesList[i]);
      }
    }
    this.resetEligiblityRulesID();
    this.updateSubmitData();
    this.showAssociatedEligRules = true;
    this.showHideAddEligiblityRules();
  }

  resetEligiblityRulesID(){
    for (let i=0; i<this.eligiblityRulesAssociate.rules.length; i++) {
      this.eligiblityRulesAssociate.rules[i]['eligruleId'] = 'ER'+(Number(i)+1);
    }
  }

  checkIsProductAlreadyAssociated(eligiId) {
    let result = false;
    for (let i=0; i<this.eligiblityRulesAssociate.rules.length; i++) {
      if (Number(this.eligiblityRulesAssociate.rules[i].eligiId) === Number(eligiId)) {
        result = true;
        break;
      }
    }
    return result;
  }

  removeEligibilityRules(index){
    this.eligiblityRulesAssociate.rules.splice(index, 1);
    this.resetEligiblityRulesID();
    this.updateSubmitData();
    this.showHideAddEligiblityRules();
  }

  updatePrimaryFlag(isChecked, eligiId){
    for (let i=0; i<this.eligiblityRulesAssociate.rules.length; i++) {
      if((Number(this.eligiblityRulesAssociate.rules[i].eligiId) === Number(eligiId)) && (isChecked)) {
        this.eligiblityRulesAssociate.rules[i].primaryFlag = true;
      } else if((Number(this.eligiblityRulesAssociate.rules[i].eligiId) === Number(eligiId)) && (!isChecked)) {
        this.eligiblityRulesAssociate.rules[i].primaryFlag = false;
      }
    }
    this.updateSubmitData();
  }

  updateSecondaryFlag(isChecked, eligiId){
    for (let i=0; i<this.eligiblityRulesAssociate.rules.length; i++) {
      if((Number(this.eligiblityRulesAssociate.rules[i].eligiId) === Number(eligiId)) && (isChecked)) {
        this.eligiblityRulesAssociate.rules[i].secondaryFlag = true;
      } else if((Number(this.eligiblityRulesAssociate.rules[i].eligiId) === Number(eligiId)) && (!isChecked)) {
        this.eligiblityRulesAssociate.rules[i].secondaryFlag = false;
      }
    }
    this.updateSubmitData();
  }

  updateSubmitData() {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet.rules = [];
    for (let i=0; i < this.eligiblityRulesAssociate.rules.length; i++) {
      this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet.rules.push({
        'offrRelEruleMapId':this.eligiblityRulesAssociate.rules[i].offrRelEruleMapId,
        'eligiId': this.eligiblityRulesAssociate.rules[i].eligiId,
  			'createdDate': '',
  			'modifiedDate': '',
  			'primaryFlag': this.eligiblityRulesAssociate.rules[i].primaryFlag,
  			'secondaryFlag': this.eligiblityRulesAssociate.rules[i].secondaryFlag,
  			'eligruleId': this.eligiblityRulesAssociate.rules[i].eligruleId
      });
    }
    this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet.eligRulePrimaryFormula = this.eligRulePrimaryFormula;
    this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet.eligRuleSecondaryFormula = this.eligRuleSecondaryFormula;
  }
  
  updateFormula(key, value) {
    this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet[key] = value;
  }

  resetEligiblityRules() {
    this.searchEligiblityRulesVal = '';
    this.eligiblityRules = [];
  }

}
