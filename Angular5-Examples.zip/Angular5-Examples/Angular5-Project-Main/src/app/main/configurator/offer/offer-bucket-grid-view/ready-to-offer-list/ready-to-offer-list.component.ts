import { Component, OnInit, Input, OnChanges, SimpleChange, SimpleChanges, Inject, Output, EventEmitter } from '@angular/core';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Offer } from '../offer-bucket-grid-vew-interface';
import { OfferBucketGridVewService } from '../offer-bucket-grid-vew.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OfferBucketGridViewComponent } from '../offer-bucket-grid-view.component';


@Component({
  selector: 'plm-ready-to-offer-list',
  templateUrl: './ready-to-offer-list.component.html',
  providers: [OfferBucketGridVewService,OfferBucketGridViewComponent]
})
export class ReadyToOfferListComponent implements OnInit, OnChanges {
  @BlockUI() blockUI: NgBlockUI;

  @Input() offersReadyToRelease: Offer[];
  @Output() onOfferRelease = new EventEmitter<boolean>();
  private offerList: Boolean[];
  private offersList: Boolean[];
  private projectCode: string;
  private offerListForRelease: number[];
  private showHideReleaseToDistribution: boolean;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private updateUsersChecked: boolean;
  private offerReadyToTestSelectAll: boolean;
  private noOfferSelectedForRelease: boolean;
  
  private filterByofferId: string;
  private filterByname: string;
  private filterBytype: string;
  private filterBydescription: string;
  private filterByestimatedMRC: string;
  private filterByofferCategory: string;
  private filterBystartDate: string;
  private filterByendDate: string;
  private filterBybundle: string;
  private filterBysalesAdvice: string;
  private filterByprimaryDiscount: string;
  private filterBylastModify: string;
  private filterBystatus: string;

  private filterByofferIdSearchObj: any;
  private filterBynameSearchObj: any;
  private filterBytypeSearchObj: any;
  private filterBydescriptionSearchObj: any;
  private filterByestimatedMRCSearchObj: any;
  private filterByofferCategorySearchObj: any;
  private filterBystartDateSearchObj: any;
  private filterByendDateSearchObj: any;
  private filterBybundleSearchObj: any;
  private filterBysalesAdviceSearchObj: any;
  private filterByprimaryDiscountSearchObj: any;
  private filterBylastModifySearchObj: any;
  private filterBystatusSearchObj: any;

  constructor(
    private router: Router,  
    private offerBucketGridVewService: OfferBucketGridVewService, 
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    private offerBucketGridViewComponent: OfferBucketGridViewComponent,
    public dialog: MatDialog,
    private OfferBucketGridViewService:OfferBucketGridVewService
  ) {
    this.offerList = [];
    this.offersList = [];
    this.offersReadyToRelease = [];
    this.projectCode = '';
    this.offerListForRelease = [];
    this.showHideReleaseToDistribution = false;
    this.updateUsersChecked = true;
    this.offerReadyToTestSelectAll = false;
    this.noOfferSelectedForRelease = false;

    this.filterByofferId= '';
    this.filterByname= '';
    this.filterBytype= '';
    this.filterBydescription= '';
    this.filterByestimatedMRC= '';
    this.filterByofferCategory= '';
    this.filterBystartDate= '';
    this.filterByendDate= '';
    this.filterBybundle= '';
    this.filterBysalesAdvice= '';
    this.filterByprimaryDiscount= '';
    this.filterBylastModify= '';
    this.filterBystatus= '';

    this.filterByofferIdSearchObj = '';
    this.filterBynameSearchObj = '';
    this.filterBytypeSearchObj = '';
    this.filterBydescriptionSearchObj = '';
    this.filterByestimatedMRCSearchObj = '';
    this.filterByofferCategorySearchObj = '';
    this.filterBystartDateSearchObj = '';
    this.filterByendDateSearchObj = '';
    this.filterBybundleSearchObj = '';
    this.filterBysalesAdviceSearchObj = '';
    this.filterByprimaryDiscountSearchObj = '';
    this.filterBylastModifySearchObj = '';
    this.filterBystatusSearchObj = '';
  }

  ngOnInit() {
    this.initializeFilterContext();
  }

  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      let change = changes[propName];
      if (propName === 'offersReadyToRelease') {
          this.offersReadyToRelease = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : [];
      }
    }
  }

  addOffer() {
    this.triggerEditViewOfferConstruct('add', '');
  }

  viewOffer(offerCode) {
    this.triggerEditViewOfferConstruct('view', offerCode);
  }

  editOffer(offerCode) {
    this.triggerEditViewOfferConstruct('edit', offerCode);
  }

  triggerEditViewOfferConstruct(mode, offerCode) {
    this.configuratorOfferDataService.offerAddEditViewMode = mode;
    this.configuratorOfferDataService.offerCodeForEditView = offerCode;
    this.configuratorOfferDataService.backURL = '/plm-work-flow/configurator/offer/offer-table';
    this.configuratorOfferDataService.isFromBusinessCatalog = 'false';
    this.router.navigate(['/plm-work-flow/configurator/offer/view-offer']);
  }

  updateOfferForRelease(isChecked, offerID){
    for (let i=0; i<this.offersReadyToRelease.length; i++) {
      if (this.offersReadyToRelease[i]['offerId'] == offerID) {
        this.offersReadyToRelease[i]['checked'] = isChecked;
      }
    }
    this.offerReadyToTestSelectAll = this.checkIsSearchListSelectedAll(this.offersReadyToRelease);
    this.noOfferSelectedForRelease = (this.getSelectedCount(this.offersReadyToRelease) > 0);
  }

  checkIsSearchListSelectedAll(searchVal) {
    let count = this.getSelectedCount(searchVal);
    return (count == searchVal.length);
   }

  showHideReleaseForDistributionButton(){
    if (this.offerListForRelease.length > 0) {
      this.showHideReleaseToDistribution = true;
    } else {
      this.showHideReleaseToDistribution = false;
    }
  }

  enableDisableUpdateButton() {
    if (this.offerListForRelease.length > 0) {
      this.updateUsersChecked = false;
    } else {
      this.updateUsersChecked = true;
    }
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(SaveOfferListSuccessDialogComponent, {
      width: 'auto'
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  getConfiguratorOfferList(){
    this.blockUI.start('Loading Offers...');
    this.OfferBucketGridViewService.getConfiguratorOfferList()
        .subscribe(
            data => {
                this.offersList = data.offers;
                this.offersReadyToRelease = data.completedOffers;
                this.blockUI.stop();
                this.initializeFilterContext();
            },
            error => {
                console.log("Error :: " + error)
            }
        );
  }

  releaseOffersForDistribution(){
    this.blockUI.start('Submitting Offers...');
    let offerForDistributionList = this.getOfferForDistributionList();
    const reqObj = {
      'projectCode': this.configuratorOfferDataService.offerProjectCode,
      'offersList': offerForDistributionList
    }

    
    this.offerBucketGridVewService.submitOfferForRelease(reqObj)
        .subscribe(
            data => {
              if (data.actionStatus === 'SUCCESS') {
                this.openDialog();
                this.getConfiguratorOfferList(); 
                this.onOfferRelease.emit(true);
              }
              else if (data.actionStatus === 'FAIL') {
              }
              this.blockUI.stop();
            },
            error => {
                console.log("Error :: " + error);
                this.blockUI.stop();
            }
        );
  }

  
  getOfferForDistributionList() {
    let result = [];
    for (let i=0; i<this.offersReadyToRelease.length; i++) {
      if (this.offersReadyToRelease[i]['checked']) {
        result.push(this.offersReadyToRelease[i]['offerId']);
      }
    }
    return result;
  }

  initializeFilterContext() {
    this.filterByofferIdSearchObj = {
      'offerId': {
        'type': 'text',
        'value': this.filterByofferId,
        'matchFullCase': false
      }
    };
    this.filterBynameSearchObj = {
      'offerName': {
        'type': 'text',
        'value': this.filterByname,
        'matchFullCase': false
      }
    };
    this.filterBytypeSearchObj = {
      'psu': {
        'type': 'text',
        'value': this.filterBytype,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionSearchObj = {
      'offerDescription': {
        'type': 'text',
        'value': this.filterBydescription,
        'matchFullCase': false
      }
    };
    this.filterByestimatedMRCSearchObj = {
      'estimatedMrc': {
        'type': 'text',
        'value': this.filterByestimatedMRC,
        'matchFullCase': false
      }
    };
    this.filterByofferCategorySearchObj = {
      'offerCategory': {
        'type': 'text',
        'value': this.filterByofferCategory,
        'matchFullCase': false
      }
    };
    this.filterBystartDateSearchObj = {
      'startDt': {
        'type': 'text',
        'value': this.filterBystartDate,
        'matchFullCase': false
      }
    };
    this.filterByendDateSearchObj = {
      'endDt': {
        'type': 'text',
        'value': this.filterByendDate,
        'matchFullCase': false
      }
    };
    this.filterBybundleSearchObj = {
      'offerBundleName': {
        'type': 'text',
        'value': this.filterBybundle,
        'matchFullCase': false
      }
    };
    this.filterBysalesAdviceSearchObj = {
      'salesAdvise': {
        'type': 'text',
        'value': this.filterBysalesAdvice,
        'matchFullCase': false
      }
    };
    this.filterByprimaryDiscountSearchObj = {
      'primaryDiscountCode': {
        'type': 'text',
        'value': this.filterByprimaryDiscount,
        'matchFullCase': false
      }
    };
    this.filterBylastModifySearchObj = {
      'lastUpdateDate': {
        'type': 'text',
        'value': this.filterBylastModify,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  convertBreakTagToLineBreak(value) {
      let result = '';
      if (value != null) {
          return value.split('<br />').join('\n');
      }
      return value;  
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/offer/project-list']);
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }


  updateOfferReadyToTestSelectAll(isChecked) {
    for (let i=0; i<this.offersReadyToRelease.length; i++) {
      this.offersReadyToRelease[i]['checked'] = isChecked;
    }
    this.noOfferSelectedForRelease = (this.getSelectedCount(this.offersReadyToRelease) > 0);
  }

  getSelectedCount(searchVal) {
    let count = 0;
    for (let i=0; i<searchVal.length; i++) {
       if (searchVal[i]['checked']) {
         count++;
       }
     }
     return count;
   }

}


@Component({
  selector: 'plm-offer-list-success-dialog',
  templateUrl: './offer-list-success-dialog.html',
  providers: [OfferBucketGridVewService]
})
export class SaveOfferListSuccessDialogComponent {
  private offerCode: string;
  constructor(
    public dialogRef: MatDialogRef<SaveOfferListSuccessDialogComponent>, 
    private router: Router, 
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerCode = this.configuratorOfferDataService.offerCodeForEditView;
    dialogRef.disableClose = true; 
  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  

  moveToDiscountList() {
    this.dialogRef.close();
    this.router.navigate(['plm-work-flow/configurator/offer/offer-table']);
  }

 

}


