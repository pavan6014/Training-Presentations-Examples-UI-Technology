import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../../../shared/services/bread-crumb';
import { AppConfigService } from '../../../../shared/services/app-config.service';
import { GetGeneralInfoInterfaceResponse, Records, OfferFormDropDown, OfferFormMasterData, GetTxnHistory } from './add-offer-interface';
import { ConfiguratorDataService } from '../../configurator-data.service';

@Injectable()
export class AddOfferService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService, private configuratorDataService: ConfiguratorDataService) { }



 getTxnHistoryData(offerID): Observable<any>{
    const getTxnData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_OFFER_TXN_HISTORY']+ '/'+ offerID + '/history';
    return this.http
      .get(getTxnData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


  
  getConfiguratorMasterFormDropDown(): Observable<any>{
    const getConfiguratorMasterData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION_MASETR_DROPDOWN'];
    // const getConfiguratorMasterData = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION_MASETR_DROPDOWN'];
    return this.http
      .get(getConfiguratorMasterData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getConfiguratorOfferFromProject(offerID): Observable<any>{
    // let getConfiguratorOfferFromProjectUrl = '';
    // if (this.configuratorDataService.isAddoffer) {
    //   getConfiguratorOfferFromProjectUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_ADD_OFFER'] + '/' + this.configuratorDataService.marketingOfferIDToAddOffer ;
    // } else if (this.configuratorDataService.isModifyOffer) {
    //   getConfiguratorOfferFromProjectUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_MODIFY_OFFER'] + '/' + this.configuratorDataService.offerIDToModify ;
    // } 
    // return this.http
    //   .get(getCreateUpdateProjectFormDataURL)
    //   .map((response: any) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getConfiguratorOfferFromProjectUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION']+ '/' +offerID;
    // const getConfiguratorOfferFromProjectUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION'];
    return this.http
      .get(getConfiguratorOfferFromProjectUrl)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  searchProduct(searchProductVal): Observable<any> {
    const searchProductUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_PRODUCT'];
    const reqObj = {
      'searchKey' : searchProductVal
    };
    return this.http
      .post(searchProductUrl, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const searchProductUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_PRODUCT']
    // return this.http
    //   .get(searchProductUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  addProduct(productList): Observable<any> {
    const addProductUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_ADD_PRODUCT'];
    const reqObj = {
      'productIds' : productList
    };
    return this.http
      .post(addProductUrl, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const addProductUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_ADD_PRODUCT']
    // return this.http
    //   .get(addProductUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
  
  searchDiscount(searchDiscountVal): Observable<any> {
    const searchDiscountUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_DISCOUNT'];
    const reqObj = {
      'searchKey' : searchDiscountVal
    };
    return this.http
      .post(searchDiscountUrl, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const searchDiscountUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_DISCOUNT']
    // return this.http
    //   .get(searchDiscountUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
    
  searchRelevancyRules(searchRelevancyRulesVal): Observable<any> {
    const searchRelevancyRulesUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_RELEVANCY_RULES'];
    const reqObj = {
      'searchKey' : searchRelevancyRulesVal
    };
    return this.http
      .post(searchRelevancyRulesUrl, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const searchRelevancyRulesUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_RELEVANCY_RULES']
    // return this.http
    //   .get(searchRelevancyRulesUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
    
  searchEligiblityRules(searchEligiblityRulesVal): Observable<any> {
    const searchEligiblityRulesUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_ELIGIBLITY_RULES'];
    const reqObj = {
      'searchKey' : searchEligiblityRulesVal
    };
    return this.http
      .post(searchEligiblityRulesUrl, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const searchEligiblityRulesUrl = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_ELIGIBLITY_RULES']
    // return this.http
    //   .get(searchEligiblityRulesUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }


  postAddOfferDetails(submitData):Observable<any>{
    const postAddDiscountDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_OFFER_FORM_DATA'];
    let headersVal = new Headers();
    headersVal.append('Content-Type', '');
    return this.http
      .post(postAddDiscountDetailsURL, submitData) 
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getAddUpdateProject = this.appConfigService.urlConstants[
    //     'PLM_ADD_UPDATE_PROJECT_RESPONSE'
    // ];
    // return this.http
    //     .get(getAddUpdateProject)
    //     .map((response: Response) => {
    //         return response;
    //     })
    //     .catch(this.handleError);
}


postUpdateOfferDetails(submitData):Observable<any>{
    // reqObj.projectMasterModel.intakeFormReqTxnDetModel.instltnIncFlg = this.getInstallationIncluded(reqObj.projectMasterModel); 
    const putUpdateDiscountDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_OFFER_FORM_DATA'];
    return this.http
      .post(putUpdateDiscountDetailsURL, submitData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getAddUpdateProject = this.appConfigService.urlConstants[
    //     'PLM_ADD_UPDATE_PROJECT_RESPONSE'
    // ];
    // this.prepareSave(reqObj);
    // return this.http
    //     .get(getAddUpdateProject)
    //     .map((response: Response) => {
    //         return response;
    //     })

    //     .catch(this.handleError);
}

// private prepareSave(submitData, isSubmitted): any {
//     let input = new FormData();
//     let submitDataModel = JSON.parse(JSON.stringify(submitData));
//     // if (file) {
//     //     input.append('file', file, file.name);
//     // } 
//     let dataObj = {
//         'discount': submitDataModel,
//         'submitted': isSubmitted
//     };
//     input.append('data', JSON.stringify(dataObj));
//     return input;
// }

  submitProject(): Observable<any> {
    // const getDiscountCreationURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_OFFER'];
    const reqObj = this.configuratorDataService.configuratorOfferModel;
    // return this.http
    //   .post(getDiscountCreationURL, reqObj)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION']
    return this.http
      .get(getConfiguratorOfferFromProject)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }
  
  saveExitProject(): Observable<any> {
    // const getDiscountCreationURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SAVE_EXIT_OFFER'];
    const reqObj = this.configuratorDataService.configuratorOfferModel;
    // return this.http
    //   .post(getDiscountCreationURL, reqObj)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION']
    return this.http
      .get(getConfiguratorOfferFromProject)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }
  
  getCopyOfferSearch(searchKey): Observable<any> {
    const getCopyOfferSearchURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_OFFER_COPY'];
    const reqObj = {
      'searchKey' : searchKey
    };
    return this.http
      .post(getCopyOfferSearchURL, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION']
    // return this.http
    //   .get(getConfiguratorOfferFromProject)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
 
  addOfferSearchForCopy(offerID): Observable<any> {
    const addCopOfferBySearchURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_SEARCH_OFFER_ADD'] + '/' +offerID;
    return this.http
      .get(addCopOfferBySearchURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getConfiguratorOfferFromProject = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION']
    // return this.http
    //   .get(getConfiguratorOfferFromProject)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}