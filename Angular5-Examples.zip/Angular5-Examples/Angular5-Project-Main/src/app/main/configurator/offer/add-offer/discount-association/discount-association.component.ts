import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Input, OnInit } from '@angular/core';
import { Discounts, OfferDiscMapTxnDets, OfferFormDropDown } from '../add-offer-interface';

import { AddOfferService } from '../add-offer.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { startWith } from 'rxjs/operators/startWith';

@Component({
  selector: 'plm-discount-association',
  templateUrl: './discount-association.component.html'
})
export class DiscountAssociationComponent implements OnInit {

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerDiscountAssInfo: OfferDiscMapTxnDets[];
  @BlockUI() blockUI: NgBlockUI;
  private offerFormDropDown: any;
  private offerDiscountAssInfo: any;
  private selectedDiscount: Discounts;
  private discountList: Discounts[];
  private discountAssociate: Discounts[];
  private searchDiscountVal: string;
  private filteredOptions2: Observable<string[]>;
  private discounts: Discounts[];
  private isDiscountExists: Boolean;
  private discountPrimary: Boolean[];
  private showAddDiscounts: boolean;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  selectedAll: any;

  constructor(
    private addOfferService: AddOfferService, 
    private configuratorOfferDataService: ConfiguratorOfferDataService
  ) {
    this.discountList = [];
    this.discountAssociate = [];
    this.searchDiscountVal = '';
    this.isDiscountExists = false;
    this.showAddDiscounts = false;
    this.discountPrimary = [];
    this.addEditMode = false;
        this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.offerDiscountAssInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets));
    this.discountAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets)); 
    this.updatePageMode();
  }

  ngOnInit() {
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        this.configuratorOfferDataService.addEditViewOfferFormData = text;
        this.offerDiscountAssInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets));
        this.discountAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets));
      }
    );
  }

  
  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
        this.addEditMode = true;
        this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
        this.addEditMode = false;
        this.viewMode = true;
    }
}

  searchDiscount() {
    this.blockUI.start('Loading Search Discounts...');
    this.discountList = [];
    this.addOfferService.searchDiscount(this.searchDiscountVal).subscribe(
      data => {
        this.discounts = data.discountSearchList;
        for(let i=0; i<this.discounts.length; i++) {
          this.discounts[i].checked = false;
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  selectAllDiscounts(isChecked) {
    this.discountList = [];
    if (isChecked) {
      for(let i=0; i<this.discounts.length; i++) {
        this.discountList[i] = JSON.parse(JSON.stringify(this.discounts[i]));
        this.discountList[i].checked = true;
        this.discounts[i].checked = true;
        this.discountList.push(this.discounts[i]);
      }
    } else {
      for(let i=0; i<this.discounts.length; i++) {
        this.discounts[i].checked = false;
      }
    }
    this.checkIfAllSelected();
    this.showHideAdddiscounts();
  }

  checkIfAllSelected() {
    if (this.discountList.length === this.discounts.length) {
      this.selectedAll = true;
    } else {
      this.selectedAll = false;
    }
  }

  selectDiscountsForAssociation(isChecked, discountId) {
    if (isChecked) {
      this.discountList.push(this.getProductBydiscountId(discountId));
    } else {
      this.discountList.splice(this.getdiscountListIndexBydiscountId(discountId), 1);
    }
    this.checkIfAllSelected();
    this.showHideAdddiscounts();
  }

  updatePrimaryForDiscount(isChecked, discountId){
    for (let i=0; i<this.discountAssociate.length; i++) {
      this.discountAssociate[i].checked = false;
      this.discountAssociate[i].primary = false;
      if ((Number(this.discountAssociate[i].discountId) === Number(discountId)) && (isChecked)) {
        this.discountAssociate[i].checked = true;
         this.discountAssociate[i].primary = true;
      }
    }
    this.updateSubmitData();
  }

  getProductBydiscountId(discountId) {
    let result: any;
    for (let i=0; i<this.discounts.length; i++) {
      if (Number(this.discounts[i].discountId) === Number(discountId))  {
        result = this.discounts[i];
        break;
      }
    }
    return result;
  }

  getdiscountListIndexBydiscountId(discountId) {
    let result: any;
    for (let i=0; i<this.discountList.length; i++) {
      if (Number(this.discountList[i].discountId) === Number(discountId))  {
        result = i;
        break;
      }
    }
    return result;
  }

  showHideAdddiscounts() {
    if (this.discountList.length > 0) {
      this.showAddDiscounts = true;
    } else  {
      this.showAddDiscounts = false;
    }
  }

  addDiscountsForAssociation() {
    for (let i=0; i<this.discountList.length; i++) {
      if (!this.checkIsProductAlreadyAssociated(this.discountList[i].discountId)) {
        this.discountList[i]['primary'] = false;
        this.discountList[i]['checked'] = false;
        this.discountAssociate.push(this.discountList[i]);
      }
    }
    this.updateSubmitData();
  }

  checkIsProductAlreadyAssociated(discountId) {
    let result = false;
    for (let i=0; i<this.discountAssociate.length; i++) {
      if (Number(this.discountAssociate[i].discountId) === Number(discountId)) {
        result = true;
        break;
      }
    }
    return result;
  }

  removeDiscount(index){
    this.discountAssociate.splice(index, 1);
    this.updateSubmitData();
  }

  updateSubmitData() {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets = [];
    //let result = false;
    for (let i=0; i < this.discountAssociate.length; i++) {
      // if(this.discountAssociate[i].checked){
      //   result = true;
      // }
      this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets.push({
          'discountId': this.discountAssociate[i].discountId,
          'offrDiscountMapId':null,
          'primary': this.discountAssociate[i].checked 
      });
      //console.log(this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets);
    }
    // if(!result){
    //   this.discountAssociate[0].checked = true;
    // }
  }

  resetDiscounts() {
    this.searchDiscountVal = '';
    this.discounts = [];
  }

}
