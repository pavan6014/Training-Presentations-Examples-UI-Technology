import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, OnInit } from '@angular/core';
import { Discounts, EligiblityRules, GetGeneralInfoInterfaceResponse, GetofferFromProjectResponse, OfferCreationResponse, OfferDiscMapTxnDets, OfferEligRuleTxnDets, OfferFormDropDown, OfferFormMasterData, OfferPinpointTxnDets, OfferProdMapTxnDets, OfferRelRuleTxnDets, OffrEcommPinpntTxnDets, Products, Records, RelevancyRules } from './add-offer-interface';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { AddOfferService } from './add-offer.service';
import { ConfiguratorOfferDataService } from '../configurator-offer-data.service';
import { FormControl } from '@angular/forms';
import { GeneralInfoComponent }  from '../add-offer/general-info/general-info.component';
import { Router } from '@angular/router';
import { UtilitiesService } from '../../../../shared/services/utilities.service';

@Component({
  selector: 'plm-add-offer',
  templateUrl: './add-offer.component.html',
  providers: [AddOfferService, UtilitiesService]
})
export class AddOfferComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private masterData: any;
  private offerFormDropDown: any;
  private addEditViewOfferFormData: any;
  private showAddOfferSection: Boolean;
  private saveSubmitResult: string;
  private finalSubmitData: any;
  private addOfferSubmitFailed: boolean;
  private addOfferSaveAndExitFail: boolean;
  private showButton: Boolean;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private failResponseFromApi: boolean;
  private errorMessagefailResponse: string;
  private backURL: string;
  private isFromBusinessCatalog: boolean;
  private lastDate: string;

  constructor(private addOfferService: AddOfferService, private router: Router, public dialog: MatDialog, private configuratorOfferDataService: ConfiguratorOfferDataService, private utilitiesService: UtilitiesService) {
    this.isFromBusinessCatalog = false;
    this.resetConfiguratorOfferDataServiceData();
    this.blockUI.start('Loading Add Offer...');
    this.updateModeAndDiscountID();
    this.showAddOfferSection = false;
    this.configuratorOfferDataService.masterFormData = {};
    this.configuratorOfferDataService.addEditViewOfferFormData = {};
    this.offerFormDropDown = {};
    this.addEditViewOfferFormData = {};
    this.saveSubmitResult = '';
    this.finalSubmitData = {};
    this.showButton = false;
    this.addEditMode = true;
    this.viewMode = false;
    this.failResponseFromApi = false;
    this.errorMessagefailResponse = 'Save and Submit is faild';
    this.initializeOfferFormDropDown();
    this.getConfiguratorFormData();
    this.backURL = this.configuratorOfferDataService.backURL;
  }

  resetConfiguratorOfferDataServiceData() {
    if (sessionStorage.getItem('isFromBusinessCatalog') === 'true') {
      this.configuratorOfferDataService.offerAddEditViewMode = '';
      this.configuratorOfferDataService.offerCodeForEditView = '';
      this.configuratorOfferDataService.backURL = '';
      this.isFromBusinessCatalog = true;
    }
  }

  getConfiguratorFormData() {
    this.addOfferService.getConfiguratorMasterFormDropDown()
      .subscribe(
        data => {
          this.masterData = data;
          this.populateFormFieldValues();
          if (this.configuratorOfferDataService.offerAddEditViewMode !== 'add') {
            this.getConfiguratorOfferFromProject();
            this.showButton = ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) ? true : false;
          } else {
            this.showHideAddOfferSection();
            this.showButton = true;
          }
        },
        error => {
          console.log('Error :: ' + error)
        }
      );
  }

  getConfiguratorOfferFromProject() {
    this.addOfferService.getConfiguratorOfferFromProject(this.configuratorOfferDataService.offerCodeForEditView)
      .subscribe(
        data => {
          this.addEditViewOfferFormData = data.offerModel;
          this.configuratorOfferDataService.addEditViewOfferFormData = data.offerModel;
          if (this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet == null) {
            const offrEcommPinpntTxnDet = this.getInitialEcommPinPnt();
            this.addEditViewOfferFormData.offrEcommPinpntTxnDet = offrEcommPinpntTxnDet;
            this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet = offrEcommPinpntTxnDet;
          }
          if (this.configuratorOfferDataService.addEditViewOfferFormData.serviceAgreement == null) {
            const serviceAgreement = this.getIntialServiceAgreement();
            this.addEditViewOfferFormData.serviceAgreement = serviceAgreement;
            this.configuratorOfferDataService.addEditViewOfferFormData.serviceAgreement = serviceAgreement;
          }
          this.showHideAddOfferSection();
        },
        error => {
          console.log('Error :: ' + error)
        }
      );
  }




  ngOnInit() {

  }

  //  updatePageMode() {
  //       if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
  //           this.addEditMode = true;
  //           this.showButton = true;
  //           this.viewMode = false;
  //       }
  //       else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
  //           this.addEditMode = false;
  //           this.showButton = false;
  //           this.viewMode = true;
  //       }
  //   }

  updateModeAndDiscountID() {
    if (!this.configuratorOfferDataService.offerAddEditViewMode) {
      this.configuratorOfferDataService.offerAddEditViewMode = sessionStorage.getItem('mode');
    }
    if (!this.configuratorOfferDataService.offerCodeForEditView) {
      this.configuratorOfferDataService.offerCodeForEditView = sessionStorage.getItem('offerId');
    }
    if (!this.configuratorOfferDataService.backURL) {
      this.configuratorOfferDataService.backURL = sessionStorage.getItem('backURL');
    }
    sessionStorage.removeItem('mode');
    sessionStorage.removeItem('offerId');
    sessionStorage.removeItem('backURL');
    sessionStorage.removeItem('isFromBusinessCatalog');
  }

  populateFormFieldValues() {
    for (let i = 0; i < this.masterData.commonMasterData.length; i++) {
      const currentMasterData = this.masterData.commonMasterData[i];
      this.offerFormDropDown[currentMasterData.name] = currentMasterData.records;
    }
    this.offerFormDropDown['campaignCodesList'] = this.masterData.campaignCodesList;
    this.offerFormDropDown['marketMasterMap'] = this.masterData.marketMasterMap;
    this.offerFormDropDown['MARKETS'] = [];
    for (let prop in this.offerFormDropDown['marketMasterMap']) {
      this.pushMarketsData(this.offerFormDropDown['marketMasterMap'][prop]);
    }
    for (let prop in this.offerFormDropDown) {
      if (this.offerFormDropDown[prop]) {
        this.updateDropDownValueUsingCode(this.offerFormDropDown[prop]);
      }
    }
    // this.offerFormDropDown['discounts'] = this.masterData.discounts;
    // for (let j = 0; j < this.offerFormDropDown['discounts'].length; j++) {
    //   this.offerFormDropDown['discounts'][j].campaignCode = this.getCampaignCodes(this.offerFormDropDown['discounts'][j]['discountCode']);
    // }
    // this.offerFormDropDown['eligibilityRules'] = this.masterData.eligibilityRules;
    // this.offerFormDropDown['relevancyRules'] = this.masterData.relevancyRules;
    this.configuratorOfferDataService.masterFormData = this.offerFormDropDown;
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.offerFormDropDown['MARKETS'].push(markets[i]);
    }
  }

  updateDropDownValueUsingCode(dropDownValue) {
    for (let i = 0; i < dropDownValue.length; i++) {
      if (dropDownValue[i].value == null) {
        dropDownValue[i].value = dropDownValue[i].code;
      }
    }
  }

  getCampaignCodes(discountCode) {
    let result = '';
    for (let z = 0; z < this.offerFormDropDown.campaignCodesList.length; z++) {
      if (this.offerFormDropDown.campaignCodesList[z].key == discountCode) {
        result = this.offerFormDropDown.campaignCodesList[z].value;
        break;
      }
    }
    return result;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  showHideAddOfferSection() {
    if ((typeof this.masterData != 'undefined') &&
      (this.masterData != null) &&
      (typeof this.addEditViewOfferFormData != 'undefined') &&
      (this.addEditViewOfferFormData != null)) {
      this.showAddOfferSection = true;
      this.blockUI.stop();
    }
  }

  // submitOffer() {
  //   this.addOfferService.submitProject().subscribe(
  //     data => {
  //       this.openDialog();
  //     },
  //     error => {
  //       console.log('Error :: ' + error)
  //     }
  //   );
  // }

  // saveExitOffer() {
  //   this.addOfferService.saveExitProject().subscribe(
  //     data => {
  //       this.openDialogs();
  //     },
  //     error => {
  //       console.log('Error :: ' + error)
  //     }
  //   );
  // }


  submitOffer() {
    this.saveSubmitResult = 'submit';
    //this.showAddOfferSection = false;
    this.blockUI.start('Submitting Offer...');
    if (this.configuratorOfferDataService.offerAddEditViewMode == 'add') {
      this.addNewOffer('submit');

    } else if (this.configuratorOfferDataService.offerAddEditViewMode == 'edit') {
      this.updateExistingOffer('submit');
    }
  }

  saveAndExitOffer() {
    //this.showAddOfferSection = false;
    this.saveSubmitResult = 'save';
    this.blockUI.start('Saving Offer...');
    if (this.configuratorOfferDataService.offerAddEditViewMode == 'add') {
      this.addNewOffer('save');
    } else if (this.configuratorOfferDataService.offerAddEditViewMode == 'edit') {
      this.updateExistingOffer('save');
    }
  }

  addNewOffer(mode) {
    this.configuratorOfferDataService.isSubmitted = (mode == 'submit') ? true : false;
    this.finalSubmitData = {
      'offerModel': this.getOfferModelSubmitData(),
      'isSubmitted': this.configuratorOfferDataService.isSubmitted
    }
    // this.finalSubmitData = this.getOfferModelSubmitData();
    // this.removeInvalidPricingRules();
    this.addOfferService.postAddOfferDetails(
      this.finalSubmitData
    ).subscribe(
      data => {
        if (data.actionStatus == 'SUCCESS') {
          this.configuratorOfferDataService.offerCodeForEditView = data.offerModel.generalInfoMapTxnDet.offerId;
          this.showSaveSubmitDialog();
          this.failResponseFromApi = false;
          this.showAddOfferSection = false;
        } else if (data.actionStatus == 'FAIL') {
          this.showErrorMessage();
          this.errorMessagefailResponse = this.utilitiesService.getServerMessage(data, this.errorMessagefailResponse);
          this.failResponseFromApi = true;
          this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerId = data.offerModel.generalInfoMapTxnDet.offerId;
          this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.version = data.offerModel.generalInfoMapTxnDet.version;
          this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.lastUpdateDate = data.offerModel.generalInfoMapTxnDet.lastUpdateDate;
          
          this.lastDate = this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.lastUpdateDate;
          //this.configuratorOfferDataService.modifyCopyOfferData(this.configuratorOfferDataService.addEditViewOfferFormData);
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.showErrorMessage();
        this.blockUI.stop();
      }
    );
  }

  updateExistingOffer(mode) {
    this.configuratorOfferDataService.isSubmitted = (mode == 'submit') ? true : false;
    this.finalSubmitData = {
      'offerModel': this.getOfferModelSubmitData(),
      'isSubmitted': this.configuratorOfferDataService.isSubmitted
    };
    // this.finalSubmitData = this.getOfferModelSubmitData();
    this.addOfferService.postUpdateOfferDetails(
      this.finalSubmitData
    ).subscribe(
      data => {
        if (data.actionStatus == 'SUCCESS') {
          this.configuratorOfferDataService.offerCodeForEditView = data.offerModel.generalInfoMapTxnDet.offerId;
          this.showSaveSubmitDialog();
          this.showAddOfferSection = false;
        } else if (data.actionStatus == 'FAIL') {
          this.showErrorMessage();
          this.errorMessagefailResponse = this.utilitiesService.getServerMessage(data, this.errorMessagefailResponse);
          this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.version = data.offerModel.generalInfoMapTxnDet.version;
          this.failResponseFromApi = true;
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.showErrorMessage();
        this.blockUI.stop();
      }
    );
  }

  getOfferModelSubmitData() {
    this.updateDiscountAssociationPrimary();
    let offerModel = {
      'projectCode': this.configuratorOfferDataService.offerProjectCode,
      'projectType': this.configuratorOfferDataService.offerProjectType,
      'generalInfoMapTxnDet': this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet,
      'serviceAgreement': this.configuratorOfferDataService.addEditViewOfferFormData.serviceAgreement,
      'offerRelRuleTxnDets': this.configuratorOfferDataService.addEditViewOfferFormData.offerRelRuleTxnDets,
      'offerEligRuleTxnDet': this.configuratorOfferDataService.addEditViewOfferFormData.offerEligRuleTxnDet,
      'offerProdMapTxnDets': this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets,
      'offerDiscMapTxnDets': this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets,
      'offerPinpointTxnDet': this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet,
      'offrEcommPinpntTxnDet': this.configuratorOfferDataService.addEditViewOfferFormData.offrEcommPinpntTxnDet
    };

    return offerModel;
  }

  updateDiscountAssociationPrimary() {
    let result = false;
    for (let i = 0; i < this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets.length; i++) {
      if (this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets[i].primary) {
        result = true;
      }
    }

    if (!result) {
      if (this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets.length > 0) {
        this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets[0].primary = true;
      }

    }
  }

  primaryCheck() {
    let result = false;
    if (this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets.length === 0) {
      return true;
    }
    for (let i = 0; i < this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets.length; i++) {
      if (this.configuratorOfferDataService.addEditViewOfferFormData.offerDiscMapTxnDets[i].primary) {
      result = true;
      }
    }
    return result;
  }

  validateIntakeForm() {
    let disableBtn = true;
    if (this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerStartDate && this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerEndDate && this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerCategory && this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offertypeid && this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.sites.length > 0 && this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet.pinPointMultiselectDropdowns.pinpnt_channelslbl.length > 0 && this.primaryCheck()) {
      disableBtn = false
    }
    return disableBtn;
  }

  showErrorMessage() {
    if (this.saveSubmitResult == 'submit') {
      this.addOfferSubmitFailed = true;
    } else if (this.saveSubmitResult == 'save') {
      this.addOfferSaveAndExitFail = true;
    }
  }

  showSaveSubmitDialog() {
    if (this.saveSubmitResult == 'submit') {
      this.openSubmitSuccessDialog();
    } else if (this.saveSubmitResult == 'save') {
      this.openSaveSuccessDialog();
    }
  }


  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }


  openSubmitSuccessDialog(): void {
    let dialogRef = this.dialog.open(SubmitSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  openSaveSuccessDialog(): void {
    let dialogRef = this.dialog.open(SaveSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  openExitErrorDialog(): void {
    let dialogRef = this.dialog.open(ExitFormErrorDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }





  returnBack() {
    if (((this.configuratorOfferDataService.offerAddEditViewMode === 'add') || (this.configuratorOfferDataService.offerAddEditViewMode === 'edit')) && (this.configuratorOfferDataService.isAddEditOfferModified)) {
   // if (this.configuratorOfferDataService.isAddEditOfferModified) {
      this.openExitErrorDialog();
    } else {
      this.configuratorOfferDataService.offerCodeForEditView = null;
    this.configuratorOfferDataService.backURL = null;
    this.configuratorOfferDataService.offerAddEditViewMode = null;
      this.router.navigate([this.backURL]);
    }
  }


  redirectTo(url) {
    this.configuratorOfferDataService.offerCodeForEditView = null;
    this.configuratorOfferDataService.backURL = null;
    this.configuratorOfferDataService.offerAddEditViewMode = null;
    if (this.configuratorOfferDataService.isAddEditOfferModified) {
      this.openExitErrorDialog();
    } else {
      this.router.navigate([url]);
    }
  }


  initializeOfferFormDropDown() {
    this.addEditViewOfferFormData = {
      'projectCode': this.configuratorOfferDataService.offerProjectCode,
      'generalInfoMapTxnDet': this.getIntialGeneralInfoData(),
      'serviceAgreement': this.getIntialServiceAgreement(),
      'offerRelRuleTxnDets': {
        'rules': [],
        'relRulePrimaryFormula': '',
        'relRuleSecondaryFormula': ''
      },
      'offerEligRuleTxnDet': {
        'rules': [],
        'eligRulePrimaryFormula': '',
        'eligRuleSecondaryFormula': ''
      },
      'offerProdMapTxnDets': [],
      'offerDiscMapTxnDets': [],
      'offerPinpointTxnDet': this.getInitialPinPointData(),
      'offrEcommPinpntTxnDet': this.getInitialEcommPinPnt()
    }
    this.configuratorOfferDataService.addEditViewOfferFormData = JSON.parse(JSON.stringify(this.addEditViewOfferFormData));
  }

  getIntialGeneralInfoData() {
    return {
      'offerId': null,
      'offerName': '',
      'offertypeid': null,
      'offerDescription': '',
      'offerBundle': null,
      'offerCategory': null,
      'offerStartDate': '',
      'offerEndDate': '',
      'lastUpdateDate': '',
      'createdBy': null,
      'createdDate': '',
      'salesAdvise': '',
      'offerStatus': null,
      'psu': '',
      'version': null,
      'inactive': false,
      'defaultOffer': false,
      'sites': [],
      'releaseId': null,
      'price': null,
      'statusComments': '',
      'modifiedBy': null,
      'releaseDate': '',
      'webDisplayName': '',
      'offerPrice': null,
      'copiedFromOfferId': null
    }
  }

  getIntialServiceAgreement() {
    return {
      'data': false,
      'homeLife': false,
      'phone': false,
      'video': false,
      'serviceAgrementIds': []
    }
  }

  getInitialRelRules() {
    return [{
      'offrRelRruleMapId': null,
      'relId': null,
      'createdDate': '',
      'modifiedDate': '',
      'modifiedOwner': null,
      'primaryFlag': false,
      'secondaryFlag': false,
      'relruleId': ''
    }]
  }

  getInitialEligRules() {
    return [{
      'offrRelEruleMapId': null,
      'eligiId': null,
      'primaryFlag': false,
      'secondaryFlag': false,
      'createdDate': '',
      'modifiedDate': '',
      'eligruleId': ''

    }]
  }

  getInitialProdMap() {
    return [{
      'offrPrdMapId': null,
      'prodId': null
    }]
  }

  getInitialDiscMap() {
    return [{
      'discountId': null,
      'offrDiscountMapId': null,
      'primaryFlag': false
    }]
  }

  getInitialPinPointData() {
    return {
      'offrPinpointMapId': null,
      'agenttypelist': '',
      'anypakFlag': false,
      'anypremiumFlag': false,
      'mandatoryflag': false,
      'proactivecode': '',
      'proactiveofferFlag': false,
      'isBaseOfferFlag': false,
      'isSearchonly': false,
      'discExcIds': [],
      'discIncIds ': [],
      'dataequipOptnl': '',
      'dvrOptional': '',
      'estimatedmrc': '',
      'adjustedmrc': '',
      'instalOptnlId': '',
      'billingElig': null,
      'phoneInstalType': null,
      'hmlifeInstalType': null,
      'dataInstalType': null,
      'videoInstalType': null,
      'ratefrpExclusion': null,
      'staticintentlist': null,
      'subStaticintentlist': null,
      'paymode': null,
      'status': null,
      'addonType': null,
      'dvr': null,
      'dataEquip': null,
      'videoEquip': null,
      'coxCompleteCare': null,
      'teCodeExec': '',
      'addonService': '',
      'receiver': '',
      'pylabel': '',
      'ofrlevelTecodes': [],
      'pinPointMultiselectDropdowns': {
        'pinpnt_baseofr_data': [],
        'pinpnt_baseofr_hmlife': [],
        'pinpnt_baseofr_phone': [],
        'pinpnt_baseofr_video': [],
        'pinpnt_custdata_eligiexc': [],
        'pinpnt_custdata_eligiinc': [],
        'pinpnt_custhmlife_eligiexc': [],
        'pinpnt_custhmlife_eligiinc': [],
        'pinpnt_custphone_eligiexc': [],
        'pinpnt_custphone_eligiinc': [],
        'pinpnt_custvideo_eligiexc': [],
        'pinpnt_custvideo_eligiinc': [],
        'pinpnt_channelslbl': []
      }
    }
  }

  getInitialEcommPinPnt() {
    return {
      'offrEcomMapId': null,
      'ecomOfferId': '',
      'statActionprimary': '',
      'statActionurlfeatured': '',
      'statActurlCompGrp': '',
      'statImageurlCompGroup': '',
      'statImageurlfeatur': '',
      'statImageurlprimary': '',
      'statMsgtxtCompGrp': '',
      'statMsgtxtfeatur': '',
      'statMsgtxtprimary': '',
      'statProductlist': '',
      'statThemlist': '',
      'statTreatmentlist': '',
      'createdDate': '',
      'statusId': null
    }
  }

}

@Component({
  selector: 'plm-offer-confirmation-dialog',
  templateUrl: './offer-confirmation-dialog.html'
})
export class DialogOverviewExampleDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDashboard() {
    this.dialogRef.close();
    this.router.navigate([this.configuratorOfferDataService.backURL]);
  }

}



@Component({
  selector: 'plm-offer-submit-success-dialog',
  templateUrl: './offer-submit-success-dialog.html'
})
export class SubmitSuccessDialogComponent {
  private offerCode: String;
  constructor(
    public dialogRef: MatDialogRef<SubmitSuccessDialogComponent>,
    private router: Router, private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerCode = this.configuratorOfferDataService.offerCodeForEditView;
    dialogRef.disableClose = true;

  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorOfferDataService.offerCodeForEditView = '';
    this.configuratorOfferDataService.offerAddEditViewMode = '';
    this.configuratorOfferDataService.isAddEditOfferModified = false;
    this.router.navigate([this.configuratorOfferDataService.backURL]);
  }

}


@Component({
  selector: 'plm-offer-save-success-dialog',
  templateUrl: './offer-save-success-dialog.html'
})
export class SaveSuccessDialogComponent {
  private offerCode: string;
  constructor(
    public dialogRef: MatDialogRef<SaveSuccessDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerCode = this.configuratorOfferDataService.offerCodeForEditView;
    dialogRef.disableClose = true;
  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorOfferDataService.offerCodeForEditView = '';
    this.configuratorOfferDataService.offerAddEditViewMode = '';
    this.configuratorOfferDataService.isAddEditOfferModified = false;
    this.router.navigate([this.configuratorOfferDataService.backURL]);
  }

}

@Component({
  selector: 'plm-offer-exit-form-error-dialog',
  templateUrl: './offer-exit-form-error-dialog.html'
})
export class ExitFormErrorDialogComponent {
  private offerCode: String;
  constructor(
    public dialogRef: MatDialogRef<SaveSuccessDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerCode = this.configuratorOfferDataService.offerCodeForEditView;
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
     this.configuratorOfferDataService.offerCodeForEditView = null;
    this.configuratorOfferDataService.backURL = null;
    this.configuratorOfferDataService.offerAddEditViewMode = null;
    this.configuratorOfferDataService.offerCodeForEditView = '';
    this.configuratorOfferDataService.offerAddEditViewMode = '';
    this.configuratorOfferDataService.isAddEditOfferModified = false;
    let backUrl = this.configuratorOfferDataService.backURL;
    this.configuratorOfferDataService.backURL = null;
    this.router.navigate([this.configuratorOfferDataService.backURL]);
  }


  cancelExit() {
    this.dialogRef.close();
  }



}


