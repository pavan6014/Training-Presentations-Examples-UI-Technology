
export interface ProjectDetail {
  projectCode: string;
  projectType: string;
  intakeFormId: number;
  createdDate: string;
  requesterName: string;
  description: string;
  pricingOwner: string[];
  status: string;
}

export interface ProjectList {
  actionResult: string;
  actionStatus: string;
  projectMasterFetchAll: ProjectDetail[];
  projectCode: string;

}