import { Injectable } from '@angular/core';
import {Subject} from "rxjs/Subject";

@Injectable()
export class ConfiguratorOfferDataService {
  public offerProjectCode: string;
  public offerProjectType: string;
  public offerCodeForEditView: string;
  public offerAddEditViewMode: string;
  public masterFormData: any;
  public addEditViewOfferFormData: any;
  public isAddEditOfferModified: boolean;
  public modifyOfferList: any;
  public isSubmitted: boolean;
  public offerListSuccessAfterSubmit: string;
  public backURL: string;
  public isFromBusinessCatalog: string;
  public offerListForSavePop: string;
  constructor() { }

  public copyOfferAddEditViewOfferFormData: Subject<any>  = new Subject<any>();
  public offerPrice: Subject<any>  = new Subject<any>();
  public modifyCopyOfferData(value) {
      this.copyOfferAddEditViewOfferFormData.next(value);
  }
  
  public modifyOfferPrice(value) {
      this.offerPrice.next(value);
  }

}
