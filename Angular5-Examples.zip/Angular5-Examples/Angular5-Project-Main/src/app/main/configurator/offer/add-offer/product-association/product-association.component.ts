import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Input, OnInit } from '@angular/core';

import { AddOfferService } from '../add-offer.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Products } from '../add-offer-interface';
import { map } from 'rxjs/operators/map';
import { startWith } from 'rxjs/operators/startWith';

@Component({
  selector: 'plm-product-association',
  templateUrl: './product-association.component.html'
})
export class ProductAssociationComponent implements OnInit {

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerProductAssInfo: OfferProdMapTxnDets[];
  @BlockUI() blockUI: NgBlockUI;
  private offerFormDropDown: any;
  private offerProductAssInfo: any;
  private selectedProduct: Products;
  private productList: Products[];
  private productAssociate: Products[];
  private searchProductVal: string;
  private isProductExists: Boolean;
  private products: Products[];
  private showAddProducts: boolean;
  private addProductList: number[];
  private addEditMode: Boolean;
  private viewMode: Boolean;
  selectedAll: any;

  constructor(
    private addOfferService: AddOfferService, 
    private configuratorOfferDataService: ConfiguratorOfferDataService
  ) {
    this.productList = [];
    this.productAssociate = [];
    this.addProductList = [];
    this.searchProductVal = '';
    this.isProductExists = false;
    this.showAddProducts = false;
    this.addEditMode = false;
    this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.initiateProductAsscData(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets);
    // this.offerProductAssInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets));
    // this.productAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets));
    // let associatedProducts = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets));
    //this.fetchAssociatedProducts();
    this.updatePageMode();
  }

  ngOnInit() {
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        if (this.validProducts(text.offerProdMapTxnDets)) {
          this.configuratorOfferDataService.addEditViewOfferFormData = JSON.parse(JSON.stringify(text));
          this.initiateProductAsscData(text.offerProdMapTxnDets);
        }
        // this.offerProductAssInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets));
        // this.productAssociate = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets));
      }
    );
  }

  initiateProductAsscData(text) {
        this.offerProductAssInfo = JSON.parse(JSON.stringify(text));
        this.productAssociate = JSON.parse(JSON.stringify(text));
        if (this.productAssociate.length > 0) {
          this.updateSubmitData();
        }
  }

  validProducts(offerProdMapTxnDets) {
    let result = true;
    for (let i=0; i<offerProdMapTxnDets.length; i++) {
      if ((!offerProdMapTxnDets[i]['name']) && (!offerProdMapTxnDets[i]['icomsCd']) && (!offerProdMapTxnDets[i]['description']) && (!offerProdMapTxnDets[i]['productType'])) {
        result = false;
      }
    }
    return result;
  }
  
  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
        this.addEditMode = true;
        this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
        this.addEditMode = false;
        this.viewMode = true;
    }
}

  searchProduct() {
    this.blockUI.start('Loading Search Products...');
    this.productList = [];
    this.addProductList = [];
    this.addOfferService.searchProduct(this.searchProductVal).subscribe(
      data => {
        this.products = data.productSearchList;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  selectAllProducts(isChecked) {
    this.productList = [];
    this.addProductList = [];
    if (isChecked) {
      for(let i=0; i<this.products.length; i++) {
        this.productList[i] = JSON.parse(JSON.stringify(this.products[i]));
        //this.productList.push(this.products[i]);
        this.productList[i].checked = true;
        this.products[i].checked = true;
      }
    }
    else {
      for(let i=0; i<this.products.length; i++) {
        this.products[i].checked = false;
      }
    }
    this.checkIfAllSelected();
    this.showHideAddProducts();
  }

  checkIfAllSelected() {
    if (this.productList.length === this.products.length) {
      this.selectedAll = true;
    } else {
      this.selectedAll = false;
    }
  }

  selectProductsForAssociation(isChecked, prodId) {
    if (isChecked) {
      this.productList.push(this.getProductByProdId(prodId));
    } else {
      this.productList.splice(this.getProductListIndexByProdId(prodId), 1);
    }
    this.checkIfAllSelected();
    this.showHideAddProducts();
  }

  getProductByProdId(prodId) {
    let result: any;
    for (let i=0; i<this.products.length; i++) {
      if (Number(this.products[i].prodId) === Number(prodId))  {
        result = this.products[i];
        break;
      }
    }
    return result;
  }

  getProductListIndexByProdId(prodId) {
    let result: any;
    for (let i=0; i<this.productList.length; i++) {
      if (Number(this.productList[i].prodId) === Number(prodId))  {
        result = i;
        break;
      }
    }
    return result;
  }

  showHideAddProducts() {
    if (this.productList.length > 0) {
      this.showAddProducts = true;
    } else  {
      this.showAddProducts = false;
    }
  }

  fetchAssociatedProducts() {
    for (let i=0; i<this.offerProductAssInfo.length; i++) {
      this.addProductList.push(this.offerProductAssInfo[i].prodId);
    }
    if (this.addProductList.length > 0) {
      this.addProductsForAssociation();
    }
  }
  

  addProductsForAssociation() {
    this.getAddProductList();
    this.blockUI.start('Associating Products...');
    if(this.addProductList.length > 0) {
      this.addOfferService.addProduct(this.addProductList).subscribe(
        data => {
          let productSearchList = data.productSearchList;
          for (let i=0; i<productSearchList.length; i++) {
            this.productAssociate.push(productSearchList[i]);
          }
          // this.productAssociate = data.productSearchList;
          this.blockUI.stop();
          this.updateSubmitData();
        },
        error => {
          console.log('Error :: ' + error)
        }
      );
    } else {
      this.blockUI.stop();
    }
    
  }

  getAddProductList() {
    for (let i=0; i<this.productList.length; i++) {
      if (!this.checkIsProductAlreadyAssociated(this.productList[i].prodId)) {
        // this.productAssociate.push(this.productList[i]);
        this.addProductList.push(this.productList[i].prodId);
      }
    }
  }

  resetProducts() {
    this.searchProductVal = '';
    this.products = [];
  }

  checkIsProductAlreadyAssociated(prodId) {
    let result = false;
    for (let i=0; i<this.productAssociate.length; i++) {
      if ((Number(this.productAssociate[i].prodId) === Number(prodId)) && (!this.productAssociate[i].parentId)) {
        result = true;
        break;
      }
    }
    return result;
  }

  removeProduct(prodId){
    let prodIdVal = prodId;
    this.productAssociate = this.getOtherElementsInProducts(prodIdVal);
    this.updateSubmitData();
  }

  getOtherElementsInProducts(prodIdVal){
    let result = [];
    for (let i=0; i < this.productAssociate.length; i++) {
      if (this.productAssociate[i].association != prodIdVal) {
        result.push(this.productAssociate[i]);
      }
    }
    return result;
  }  

  isChildProd(prodId, parentIds) {
    let result = false;
    if (parentIds.indexOf(Number(prodId)) > -1) {
      result = true;
    }
    return result;
  }

  updateSubmitData() {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets = [];
    for (let i=0; i < this.productAssociate.length; i++) {
      if (this.productAssociate[i].parentId == null) {
        this.configuratorOfferDataService.addEditViewOfferFormData.offerProdMapTxnDets.push({
          'offrPrdMapId':null,
          'prodId':this.productAssociate[i].prodId
        });
      }
      
    }
  }

}

