import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { ProjectDetail, ProjectList } from './configurator-project-list-interface';

import { ConfiguratorOfferDataService } from '../configurator-offer-data.service';
import { ConfiguratorProjectListService } from './configurator-project-list.service';
import { Router } from '@angular/router';

@Component({
  selector: 'plm-configurator-project-list',
  templateUrl: './configurator-project-list.component.html',
  providers: [ConfiguratorProjectListService]
})
export class ConfiguratorProjectListComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private filterByCode: string;
  private filterByRequestName: string;
  private filterByType: string;
  private filterPricingOwner: string;
  private filterByDescription: string;
  private filterByResqustorName: string;
  private filterByCreatedDate: string;
  private filterBypriority: string;
  private filterBystatus: string;
  private filterByCodeSearchObj: any;
  private popstatusForRelease: number[];
  private discountList: any[];
  private selectedAll: boolean;
  private discountIdSelected: Boolean;
  private filterByRequestNameSearchObj: any;
  private filterByTypeSearchObj: any;
  private filterPricingOwnerSearchObj: any;
  private filterByDescriptionSearchObj: any;
  private filterByResqustorNameSearchObj: any;
  private filterByprioritySearchObj: any;
  private filterByCreatedDateSearchObj: any;
  private filterBystatusSearchObj: any;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private isNotPopsChecked: boolean;
  private popsSaveFailed: boolean;
  private popstatusForReleaseString: string;

  private configuratorProjectList: any[];

  constructor(private configuratorProjectListService: ConfiguratorProjectListService, private router: Router, private configuratorOfferDataService: ConfiguratorOfferDataService, public dialog: MatDialog) {
    
  } 

  ngOnInit() {
    this.filterByCode = '';
    this.filterByType = '';
    this.filterByRequestName= '';
    this.filterPricingOwner = '';
    this.filterByDescription = '';
    this.filterByResqustorName = '';
    this.filterByCreatedDate = '';
    this.filterBypriority= '';
    this.filterByCodeSearchObj = '';
    this.filterByTypeSearchObj = '';
    this.filterByRequestNameSearchObj = '';
    this.filterPricingOwnerSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    this.filterByResqustorNameSearchObj = '';
    this.popstatusForRelease = [];
    this.discountList = [];
    this.selectedAll = false;
    this.discountIdSelected = false;
    this.filterByprioritySearchObj= '';
    this.filterByCreatedDateSearchObj = '';
    this.filterBystatusSearchObj = '';
    this.configuratorOfferDataService.offerProjectCode = '';
    this.isNotPopsChecked = true;
    this.popsSaveFailed = false;
    this.popstatusForReleaseString = '';
    this.blockUI.start('Loading Project List...');
    this.configuratorProjectList = [];
    this.getConfiguratorProjectList();
  }

  getConfiguratorProjectList() {
    this.configuratorProjectListService.getConfiguratorProjectList()
      .subscribe(
        data => {
          this.configuratorProjectList = data.projectMasterFetchAll;
          this.initializeFilterContext();
          this.blockUI.stop();
        },
        error => {
          console.log("Error :: " + error)
        }
      );
  }


  initializeFilterContext() {
    this.filterByCodeSearchObj = {
      'projectCode': {
        'type': 'text',
        'value': this.filterByCode,
        'matchFullCase': false
      }
    };
    this.filterByRequestNameSearchObj = {
      'intakeReqName': {
        'type': 'text',
        'value': this.filterByRequestName,
        'matchFullCase': false
      }
    };
    this.filterByCreatedDateSearchObj = {
      'createdDate': {
        'type': 'date',
        'value': this.filterByCreatedDate,
        'matchFullCase': true
      }
    };
    this.filterByDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByDescription,
        'matchFullCase': false
      }
    };
    this.filterByResqustorNameSearchObj = {
      'requesterName': {
        'type': 'text',
        'value': this.filterByResqustorName,
        'matchFullCase': false
      }
    };
    this.filterByprioritySearchObj = {
      'priority': {
        'type': 'text',
        'value': this.filterBypriority,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
    this.filterByTypeSearchObj = {
      'projectType': {
        'type': 'text',
        'value': this.filterByType,
        'matchFullCase': false
      }
    };
    this.filterPricingOwnerSearchObj = {
      'pricingOwners': {
        'type': 'array',
        'value': this.filterPricingOwner,
        'matchFullCase': false
      }
    };
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  getDateInFormat(date) {
    const currentDate = new Date(date);
    const result = ("0" + (currentDate.getDate() + 1)).slice(-2) + '/' + ("0" + (currentDate.getMonth() + 1)).slice(-2) + '/' + currentDate.getFullYear();
    return result;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  

moveToConfiguratorGrid(projectCode,projectType) {
    this.configuratorOfferDataService.offerProjectCode = projectCode;
    this.configuratorOfferDataService.offerProjectType  = projectType;
    if  ((projectType  ==  'New Offer Creation') || (projectType  ==  'New TE Code Creation')) {
      this.router.navigate(['/plm-work-flow/configurator/offer/offer-table']);
    } else  if  (projectType  ==  'Offer Modification') {
      this.router.navigate(['/plm-work-flow/configurator/offer/modify-offer']);
    }
  }

  // selectDeselctAllPopstatus(isChecked) {
  //   this.popstatusForRelease = [];
  //   for (let i = 0; i < this.configuratorProjectList.length; i++) {
  //    // this.discountList[i]['checked'] = false;
  //     if ((isChecked) && (this.configuratorProjectList[i]['status'] === 'Submitted')) {
  //       this.discountList[i]['checked'] = isChecked;
  //       this.popstatusForRelease.push(this.configuratorProjectList[i]['projectCode']);
  //     }
  //   }
  //   this.updateDiscountTable(isChecked);
  // }

  popstatusForModify(isChecked, projectCode) {
    for (let i = 0; i < this.configuratorProjectList.length; i++) {
      if ((this.configuratorProjectList[i]['projectCode'] === projectCode)){
        this.configuratorProjectList[i]['checked'] = isChecked;
        this.updatePopstatusForRelease(isChecked, projectCode);
      }
    }
    this.showHideSaveButton();
  }

  updatePopstatusForRelease(isChecked, projectCode) {
    if (isChecked) {
      this.popstatusForRelease.push(projectCode);
    } else {
      let result = [];
      for (let i=0; i<this.popstatusForRelease.length; i++) {
        if (this.popstatusForRelease[i] !== projectCode) {
          result.push(this.popstatusForRelease[i]);
        }
      }
      this.popstatusForRelease = result;
    }
    this.isNotPopsChecked = this.showHideSaveButton();
  }

  showHideSaveButton() {
    let result = true;
    result = (this.popstatusForRelease.length > 0) ? false : true;
    return result;
  }

  submitPopupProjects() {
    this.blockUI.start('Submitting Pops Projects...');
    let reqObj = {
      'discPopStatus': false,
      'offerPopStatus': true,
      'projectCode': this.popstatusForRelease
    };
    this.popsSaveFailed = false;
    this.configuratorProjectListService.savePopsProjects(reqObj)
      .subscribe(
        data => {
          if (data.actionStatus == 'SUCCESS') {
            this.popstatusForReleaseString = data.projectCode.join(', ');
            this.configuratorOfferDataService.offerListForSavePop = this.popstatusForReleaseString;
            this.openSaveSuccessDialog();
            this.blockUI.stop();
          } else if (data.actionStatus == 'FAIL') {
            this.showPopSaveError();
          }
        },
        error => {
          this.showPopSaveError();
          console.log("Error :: " + error)
        }
      );
  }

  showPopSaveError() {
    this.popsSaveFailed = true;
    this.blockUI.stop();
  }

  returnBack() {
    this.router.navigate(['']);
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

  openSaveSuccessDialog(): void {
    let dialogRef = this.dialog.open(PopsSaveSuccessDialogComponent, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.popstatusForRelease = [];
      this.popstatusForReleaseString = '';
      this.blockUI.start('Loading Project List...');
      this.configuratorProjectList = [];
      this.getConfiguratorProjectList();
    });
  }

}

@Component({
  selector: 'plm-offer-save-success-dialog',
  templateUrl: './offer-save-success-dialog.html'
})
export class PopsSaveSuccessDialogComponent {
  private offerList: string;
  constructor(
    public dialogRef: MatDialogRef<PopsSaveSuccessDialogComponent>,
    private router: Router,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.offerList = this.configuratorOfferDataService.offerListForSavePop;
    dialogRef.disableClose = true;
  }

  onCloseButtonClick(): void {
    this.dialogRef.close();
  }

  moveToDiscountList() {
    this.dialogRef.close();
    this.configuratorOfferDataService.offerListForSavePop = '';
  }

}
