import { Component, OnInit, OnChanges, Input, SimpleChange, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { RequestorService } from '../../../../requestor/services/requestor.service';
import { RequestorDataService } from '../../../../requestor/services/requestor-data.service';
import { IntakeRequestMasterData, FetchAllIntakeRequest, RequestorRequestInterface, RequestorResponseInterface, IntakeFormReq, IntakeRequestForm, IntakeRequestFormIntakeForm } from '../../../../requestor/requestor.interface';
import { AppConfigService } from '../../../../../shared/services/app-config.service';


@Component({
  selector: 'plm-intake-request-detail-master-form',
  templateUrl: './intake-request-detail-master-form.component.html',
  styleUrls: ['./intake-request-detail-master-form.component.css'],
  providers: [RequestorDataService]
})
export class IntakeRequestDetailMasterFormComponent implements OnInit {

  @Input() addEditIntakeRequestForm: IntakeRequestForm;
  @Input() addEditIntakeRequestMasterData: IntakeRequestMasterData;
  @Output() fileUpload: EventEmitter<any> = new EventEmitter<any>();
  private formDataLoaded: Boolean;
  private isAllSitesSelected: Boolean;
  private sitesSelected: Boolean;
  private selectSite: Object;
  private selectedAll: Boolean;
  private sites: number[];
  private projectStartMinDate: Date;
  private projectEndMinDate: Date;
  private showDownloadUrl: Boolean;
  private viewMode: Boolean;
  private fileToUpload: File = null;
  private intakeRequestStatusIdDropDownList = [];
  private intakeRequestStatusIdSelectedItems = [];
  private intakeRequestTypeDropDownList = [];
  private intakeRequestTypeSelectedItems = [];
  private pricingOwnerIdDropDownList = [];
  private pricingOwnerIdSelectedItems = [];
  private trgtAudienceIdDropDownList = [];
  private trgtAudienceIdSelectedItems = [];
  private channelIdsDropDownList = [];
  private channelIdsSelectedItems = [];
  private categoryIdDropDownList = [];
  private categoryIdSelectedItems = [];
  private productIdsDropDownList = [];
  private productIdsSelectedItems = [];
  private priorityIdDropDownList = [];
  private priorityIdSelectedItems = [];
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private noIntakeRequestType: Boolean;
  private showIntakeRequestForm: Boolean;
  private downloadFileUrl: string;
  private fileSizeExceeded: Boolean;

  constructor(private requestorService: RequestorService, private requestorDataService: RequestorDataService, private appConfigService: AppConfigService) {
    this.formDataLoaded = false;
    this.showDownloadUrl = true;
    this.viewMode = true;
    this.isAllSitesSelected = false;
    this.sitesSelected = true;
    this.selectSite = {};
    this.selectedAll = false;
    this.showIntakeRequestForm = false;
    this.downloadFileUrl = '';
    this.fileSizeExceeded = false;
  }

  ngOnInit() {

  }


  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      let change = changes[propName];
      if (propName === 'addEditIntakeRequestForm') {
        this.addEditIntakeRequestForm = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      } else if (propName === 'addEditIntakeRequestMasterData') {
        this.addEditIntakeRequestMasterData = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      }
    }
    if ((typeof this.addEditIntakeRequestForm !== 'undefined') && (typeof this.addEditIntakeRequestMasterData !== 'undefined')) {
      this.checkIsFormDataLoaded();
      for (let i = 0; i < this.addEditIntakeRequestForm.projectMasterModel.sites.length; i++) {
        const currentSite = this.addEditIntakeRequestForm.projectMasterModel.sites[i];
        this.selectSite[currentSite] = this.isSitesExist(currentSite);
      }
      this.showIntakeRequestForm = true;
      this.downloadFileUrl = this.appConfigService.url + '/plm-engine/requester/v0/project/' + this.addEditIntakeRequestForm.projectMasterModel.projectCode +'/files/'+ this.addEditIntakeRequestForm.projectMasterModel.uploadIntakeRequestDocId;
    }
  }


  getAddEditIntakeRequestMasterData() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }




  getDropDownList(masterData, dropDownKey) {
    let result = [];
    if ((typeof masterData.intakeFormMasterDropDown !== 'undefined') && (masterData.intakeFormMasterDropDown !== null)) {
      for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
        result.push({
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        });
      }
    }
    return result;
  }

  getPricingOwnerDropDownList(masterData) {
    let result = [];
    if ((typeof masterData.pricingOwners !== 'undefined') && (masterData.pricingOwners !== null)) {
      for (let i = 0; i < masterData.pricingOwners.length; i++) {
        result.push({
          "id": masterData.pricingOwners[i]['userId'],
          "itemName": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
        });
      }
    }
    return result;
  }

  getproductIdsDropDownList(masterData) {
    let result = [];
    if ((typeof masterData.products !== 'undefined') && (masterData.products !== null)) {
      for (let i = 0; i < masterData.products.length; i++) {
        result.push({
          "id": masterData.products[i]['psuTypeId'],
          "itemName": masterData.products[i]['psuName']
        });
      }
    }
    return result;
  }

  getSelectedItemsObject(masterData, dropDownKey, dropDownList) {
    let result = [];
    if ((typeof masterData.intakeFormMasterDropDown !== 'undefined') && (masterData.intakeFormMasterDropDown !== null)) {
      for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
        if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId']) > -1)) {
          result.push({
            "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
            "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
          });
        } else if (masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'] == dropDownList) {
          result.push({
            "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
            "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
          });
        }
      }
    }
    return result;
  }

  getproductIdsSelectedItemsObject(masterData, dropDownListVal) {
    let result = [], dropDownList = [];
    for (let j = 0; j < dropDownListVal.length; j++) {
      dropDownList.push(dropDownListVal[j].toString());
    }
    if ((typeof masterData.products !== 'undefined') && (masterData.products !== null)) {
      for (let i = 0; i < masterData.products.length; i++) {
        if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.products[i]['psuTypeId']) > -1)) {
          result.push({
            "id": masterData.products[i]['psuTypeId'],
            "itemName": masterData.products[i]['psuName']
          });
        } else if (masterData.products[i]['psuTypeId'] == dropDownList) {
          result.push({
            "id": masterData.products[i]['psuTypeId'],
            "itemName": masterData.products[i]['psuName']
          });
        }
      }
    }
    return result;
  }

  getPricingOwnerSelectedItemsObject(masterData, dropDownList) {
    let result = [];
    if ((typeof masterData.pricingOwners !== 'undefined') && (masterData.pricingOwners !== null)) {
      for (let i = 0; i < masterData.pricingOwners.length; i++) {
        if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.pricingOwners[i]['userId']) > -1)) {
          result.push({
            "id": masterData.pricingOwners[i]['userId'],
            "itemName": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
          });
        } else if (masterData.pricingOwners[i]['userId'] == dropDownList) {
          result.push({
            "id": masterData.pricingOwners[i]['userId'],
            "itemName": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
          });
        }
      }
    }
    return result;
  }


  checkIsFormDataLoaded() {
    if (typeof this.addEditIntakeRequestMasterData != 'undefined') {
      this.formDataLoaded = true;
    } else {
      this.formDataLoaded = false;
    }
  }

  updatePageMode() {
    if (this.requestorDataService.addEditViewIntakeRequestMode == 'view') {
      this.showDownloadUrl = true;
      this.viewMode = true;
    }
  }





  isAllSitesSelectedCheck() {

  }

  isSitesExist(site) {

  }



  handleFileInput(files: FileList, event: any) {
    this.fileSizeExceeded = false;
    this.fileToUpload = files.item(0);
    const fileSizeInMB = (this.fileToUpload.size / (1024 * 1024)).toFixed(2);
    if (parseFloat(fileSizeInMB) > parseFloat(Number(20).toFixed(2))) {
      event.target.value = null;
      this.fileSizeExceeded = true;
      return false;
    }

    this.fileUpload.emit(this.fileToUpload);
  }

  downloadDECFile() {
    window.open('C:/Users/tkannan/eclipse-workspace/PLM_Docs/Requester_configrator_changesv0.5.pptx');
  }

  convertArrayElementsToString(arrayEl) {
    let result = [];
    for (let i = 0; i < arrayEl.length; i++) {
      result.push(arrayEl[i].toString());
    }
    return result;
  }
}
