import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { OfferFormDropDown, OfferPinpointTxnDets } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';

@Component({
  selector: 'plm-pricing-pinpoint',
  templateUrl: './pricing-pinpoint.component.html',
  providers: [UtilitiesService]
})
export class PricingPinpointComponent implements OnInit {

  // dropdownList = [];
  // selectedItems = [];
  // dropdownSettings = {};
  // CustomerdropdownSettings = {};
  // CustomerdropdownList = [];
  // customerselectedItems = [];
  // CustomerhomedropdownSettings = {};
  // CustomerhomedropdownList = [];
  // customerhomeselectedItems = [];

  // OfferLeveldropdownSettings = {};
  // OfferLeveldropdownList = [];
  // OfferLevelselectedItems = [];

  // @Input() offerFormDropDown: OfferFormDropDown;
  // @Input() offerPricingPinPointInfo: OfferPinpointTxnDets;

  private offerFormDropDown: any;
  private offerPricingPinPointInfo: any;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private optionalAnyDropDownList = [];
  private installationTypeDropDownList = [];
  private channelsLabelDropDownList = [];
  private channelsLabelSelectedItems = [];
  private addonTypeDropDownList = [];
  private addonTypeSelectedItems = [];
  private receiverDropDownList = [];
  private receiverSelectedItems = [];
  private dvrDropDownList = [];
  private dvrSelectedItems = [];
  private dvrOptionalDropDownList = [];
  private dvrOptionalSelectedItems = [];
  private dataEquipDropDownList = [];
  private dataEquipSelectedItems = [];
  private dataEquipOptionalDropDownList = [];
  private dataEquipOptionalSelectedItems = [];
  private videoEquipDropDownList = [];
  private videoEquipSelectedItems = [];
  private homelifeInslTypeDropDownList = [];
  private homelifeInslTypeSelectedItems = [];
  private phoneInslTypeDropDownList = [];
  private phoneInslTypeSelectedItems = [];
  private dataInslTypeDropDownList = [];
  private dataInslTypeSelectedItems = [];
  private videoInslTypeDropDownList = [];
  private videoInslTypeSelectedItems = [];
  private instlOptionalDropDownList = [];
  private instlOptionalSelectedItems = [];
  private billingElgibilityDropDownList = [];
  private billingElgibilitySelectedItems = [];
  private baseOfferHomeLifeDropDownList = [];
  private baseOfferHomeLifeSelectedItems = [];
  private customerHomelifeDropDownList = [];
  private customerHomelifeSelectedItems  = [];
  private customerHomelifeExcDropDownList = [];
  private customerHomelifeExcSelectedItems  = [];
  private baseOfferVideoEligiblityDropDownList = [];
  private baseOfferVideoEligiblitySelectedItems  = [];
  private customerVideoEligibilityIncDropDownList = [];
  private customerVideoEligibilityIncSelectedItems  = [];
  private customerVideoEligibilityExcDropDownList = [];
  private customerVideoEligibilityExcSelectedItems  = [];
  private baseOfferPhoneEligiblityDropDownList = [];
  private baseOfferPhoneEligiblitySelectedItems  = [];
  private customerPhoneEligibilityDropDownList = [];
  private customerPhoneEligibilitySelectedItems  = [];
  private customerPhoneEligibilityExDropDownList = [];
  private customerPhoneEligibilityExSelectedItems  = [];
  private baseOfferDataDropEligiblityDownList = [];
  private baseOfferDataEligiblitySelectedItems  = [];
  private customerDataEligibilityInDropDownList = [];
  private customerDataEligibilityInSelectedItems  = [];
  private customerDataEligibilityExDropDownList = [];
  private customerDataEligibilityExSelectedItems  = [];
  private campaignCodeIncludeDropDownList = [];
  private campaignCodeIncludeSelectedItems  = [];
  private campaignCodeExcludeDropDownList = [];
  private campaignCodeExcludeSelectedItems  = [];
  private staticIntentDropDownList = [];
  private staticIntentSelectedItems  = [];
  private staticSubIntentDropDownList = [];
  private staticSubIntentSelectedItems  = [];
  private coxCompleteCareDropDownList = [];
  private coxCompleteCareSelectedItems  = [];
  private ratefrpExclusionDropDownList = [];
  private ratefrpExclusionSelectedItems  = [];
  private offerLevelTECodesDropDownList = [];
  private offerLevelTECodesSelectedItems = [];

  constructor(
    private addOfferService: AddOfferService,
    private configuratorOfferDataService: ConfiguratorOfferDataService,
    private utilitiesService: UtilitiesService
  ) {
    this.addEditMode = false;
    this.viewMode = false;
    this.optionalAnyDropDownList = [
      { 'id':  '', 'name':  'Select One'},
      {'id': 'any','name': 'ANY'}
    ];
    this.installationTypeDropDownList = [
      { 'id':  '', 'name':  'Select One'},
      {'id': 'Y','name':'Y'},
      {'id': 'N','name':'N'}
    ];
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.offerPricingPinPointInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet));
    if ((typeof this.offerFormDropDown != 'undefined') && (this.offerFormDropDown != null) && (Object.keys(this.offerFormDropDown).length > 0)) {
      this.updateDropDownList();
      this.updatePageMode();
      this.initializeSelectedItems();
    }
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: 'Select One',
      enableSearchFilter: true
    };
    this.multiSelectSettings = {
      singleSelection: false,
      text: 'Select',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      badgeShowLimit: 3,
      maxHeight: 120
    };
    this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
      text => {
        this.offerPricingPinPointInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet));
        this.initializeSelectedItems();
      }
    );
    this.configuratorOfferDataService.offerPrice.subscribe(
      text => {
        this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet.estimatedmrc = text;
        this.offerPricingPinPointInfo.estimatedmrc = text;
      }
    );
  }

    ngOnChanges(changes: SimpleChanges) {

    }


  updatePageMode() {
    if ((this.configuratorOfferDataService.offerAddEditViewMode == 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode == 'edit'))) {
      this.addEditMode = true;
      this.viewMode = false;
    }
    else if (this.configuratorOfferDataService.offerAddEditViewMode == 'view') {
      this.addEditMode = false;
      this.viewMode = true;
    }
  }

  updateDropDownList() {
    this.ratefrpExclusionDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'RATEGRP_EXCLUSIONLIST');
     this.ratefrpExclusionDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.channelsLabelDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'CHANNELSLABEL');
    this.addonTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'ADDON_TYPE');
     this.addonTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.dvrDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'DVR');
     this.dvrDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.dvrOptionalDropDownList = this.optionalAnyDropDownList;
    this.dataEquipDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'DATAEQUIP');
     this.dataEquipDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.dataEquipOptionalDropDownList = this.optionalAnyDropDownList;
    this.videoEquipDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'VIDEOEQUIP');
    this.videoEquipDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.homelifeInslTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE');
     this.homelifeInslTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.phoneInslTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE');
     this.phoneInslTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.dataInslTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE');
     this.dataInslTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.videoInslTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE');
      this.videoInslTypeDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.baseOfferHomeLifeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerHomelifeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerHomelifeExcDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.baseOfferVideoEligiblityDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerVideoEligibilityIncDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerVideoEligibilityExcDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.baseOfferPhoneEligiblityDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerPhoneEligibilityDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerPhoneEligibilityExDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.baseOfferDataDropEligiblityDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerDataEligibilityInDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.customerDataEligibilityExDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI');
    this.campaignCodeIncludeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'campaignCodesList');
    this.campaignCodeExcludeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'campaignCodesList');
    this.staticIntentDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'STATICINTENTLIST');
     this.staticIntentDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.staticSubIntentDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'STATICSUBINTENTLIST');
     this.staticSubIntentDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.coxCompleteCareDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'COX_COMPLETE_CARE');
     this.coxCompleteCareDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.offerLevelTECodesDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'TE_CODES');
    this.billingElgibilityDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'ELIGIBLE_BILLING_TYPE')
     this.billingElgibilityDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.receiverDropDownList = this.installationTypeDropDownList;
    this.instlOptionalDropDownList = this.optionalAnyDropDownList;
    if ((typeof this.offerFormDropDown !== 'undefined') && (typeof this.offerPricingPinPointInfo !== 'undefined')) {
      this.initializeSelectedItems();
    }
  }

  initializeSelectedItems() {
    this.ratefrpExclusionSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'RATEGRP_EXCLUSIONLIST', this.offerPricingPinPointInfo.ratefrpExclusion);
    this.channelsLabelSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'CHANNELSLABEL', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_channelslbl);
    this.addonTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'ADDON_TYPE', this.offerPricingPinPointInfo.addonType);
    this.dvrSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'DVR', this.offerPricingPinPointInfo.dvr);
    this.offerPricingPinPointInfo.dvrOptional = (this.offerPricingPinPointInfo.dvrOptional) ? (this.offerPricingPinPointInfo.dvrOptional) : '';
    this.offerPricingPinPointInfo.dataequipOptnl = (this.offerPricingPinPointInfo.dataequipOptnl) ? (this.offerPricingPinPointInfo.dataequipOptnl) : '';
    this.offerPricingPinPointInfo.instalOptnlId = (this.offerPricingPinPointInfo.instalOptnlId) ? (this.offerPricingPinPointInfo.instalOptnlId) : '';
    this.dvrOptionalSelectedItems = this.getOptionalAnySelectedItems(this.offerPricingPinPointInfo.dvrOptional.toLowerCase());

    this.offerPricingPinPointInfo.dvrOptional = (this.offerPricingPinPointInfo.dvrOptional) ? (this.offerPricingPinPointInfo.dvrOptional) : '';
    this.offerPricingPinPointInfo.dataequipOptnl = (this.offerPricingPinPointInfo.dataequipOptnl) ? (this.offerPricingPinPointInfo.dataequipOptnl) : '';
    this.offerPricingPinPointInfo.instalOptnlId = (this.offerPricingPinPointInfo.instalOptnlId) ? (this.offerPricingPinPointInfo.instalOptnlId) : '';

    this.dataEquipSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'DATAEQUIP', this.offerPricingPinPointInfo.dataEquip);
    this.dataEquipOptionalSelectedItems = this.getOptionalAnySelectedItems(this.offerPricingPinPointInfo.dataequipOptnl.toLowerCase());
    this.videoEquipSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'VIDEOEQUIP', this.offerPricingPinPointInfo.videoEquip);
    this.homelifeInslTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE', this.offerPricingPinPointInfo.hmlifeInstalType);
    this.phoneInslTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE', this.offerPricingPinPointInfo.phoneInstalType);
    this.dataInslTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE', this.offerPricingPinPointInfo.phoneInstalType);
    this.videoInslTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_INSTL_TYPE', this.offerPricingPinPointInfo.videoInstalType);
    this.billingElgibilitySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'ELIGIBLE_BILLING_TYPE', this.offerPricingPinPointInfo.billingElig);
    this.baseOfferHomeLifeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_baseofr_hmlife);
    this.customerHomelifeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custhmlife_eligiinc);
    this.customerHomelifeExcSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custphone_eligiexc);
    this.baseOfferVideoEligiblitySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_baseofr_video);
    this.customerVideoEligibilityIncSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custvideo_eligiinc);
    this.customerVideoEligibilityExcSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custvideo_eligiexc);
    this.baseOfferPhoneEligiblitySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_baseofr_phone);
    this.customerPhoneEligibilitySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custphone_eligiinc);
    this.customerPhoneEligibilityExSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custphone_eligiexc);
    this.baseOfferDataEligiblitySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_baseofr_data);
    this.customerDataEligibilityInSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custdata_eligiinc);
    this.customerDataEligibilityExSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_BASE_OFFER_ELIGI', this.offerPricingPinPointInfo.pinPointMultiselectDropdowns.pinpnt_custdata_eligiexc);
    this.campaignCodeIncludeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'campaignCodesList', this.offerPricingPinPointInfo.discIncIds );
    this.campaignCodeExcludeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'campaignCodesList', this.offerPricingPinPointInfo.discExcIds);
    this.staticIntentSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'STATICINTENTLIST', this.offerPricingPinPointInfo.staticintentlist);
    this.staticSubIntentSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'STATICSUBINTENTLIST', this.offerPricingPinPointInfo.subStaticintentlist);
    this.coxCompleteCareSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'COX_COMPLETE_CARE', this.offerPricingPinPointInfo.coxCompleteCare);
    this.offerLevelTECodesSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'TE_CODES', this.offerPricingPinPointInfo.ofrlevelTecodes);
    this.receiverSelectedItems = this.getInstallationTypeSelectedItems(this.offerPricingPinPointInfo.receiver);
    this.instlOptionalSelectedItems = this.getOptionalAnySelectedItems(this.offerPricingPinPointInfo.instalOptnlId.toLowerCase());
  }

  getInstallationTypeSelectedItems(itemValue){
    let result = [];
    for (let i=0; i<this.installationTypeDropDownList.length; i++) {
      if (this.installationTypeDropDownList[i].id === itemValue) {
        result = this.installationTypeDropDownList[i];
        break;
      }
    }
    return result;
  }
  
  getOptionalAnySelectedItems(itemValue){
    let result=[];
    for (let i=0; i<this.optionalAnyDropDownList.length; i++) {
      if (this.optionalAnyDropDownList[i].id === itemValue) {
        result = this.optionalAnyDropDownList[i];
        break;
      }
    }
    return result;
  }

  onItemSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
  }

  onItemDeSelect(key: string, item: any, selectType: string) {
    this.updateSelectedVal(key, item, selectType);
  }

  onSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
  }

  onDeSelectAll(key: string, items: any, selectType: string) {
    this.updateSelectedVal(key, items, selectType);
  }

  updateSelectedVal(key: string, items: any, selectType: string) {
    let pinPointMultiSelectList = [
      'pinpnt_baseofr_data',
      'pinpnt_baseofr_hmlife',
      'pinpnt_baseofr_phone',
      'pinpnt_baseofr_video',
      'pinpnt_custdata_eligiexc',
      'pinpnt_custdata_eligiinc',
      'pinpnt_custhmlife_eligiexc',
      'pinpnt_custhmlife_eligiinc',
      'pinpnt_custphone_eligiexc',
      'pinpnt_custphone_eligiinc',
      'pinpnt_custvideo_eligiexc',
      'pinpnt_custvideo_eligiinc',
      'pinpnt_channelslbl'
    ];
    let resultVal = this.getValueBySelectType(items, selectType);
    if (pinPointMultiSelectList.indexOf(key) > -1) {
      this.updatePinPointMultiSelectSubmitData(key, resultVal);
    } else {
      this.updateSubmitData(key, resultVal);
    }
    
  }

  getValueBySelectType(item: any, selectType: string) {
    let result;
    if (selectType === 'single') {
      result = this.utilitiesService.getSingleSelectIDNgSelect(item);
    } else {
      result = this.utilitiesService.getMultiSelectID(item)
    }
    return result;
  }

  convertTextAreaContentWithBreaks(field, value) {
    this.updateSubmitData(field, value.split('\n').join('<br />'));
  }

  convertBreakTagToLineBreak(value) {
      let result = '';
      if (value != null) {
          return value.split('<br />').join('\n');
      }
      return value;
      
  }

  updateSubmitData(field, value) {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet[field] = value;
    this.configuratorOfferDataService.isAddEditOfferModified = true;
  }

  
  updatePinPointMultiSelectSubmitData(field, value) {
    this.configuratorOfferDataService.addEditViewOfferFormData.offerPinpointTxnDet.pinPointMultiselectDropdowns[field] = value;
    this.configuratorOfferDataService.isAddEditOfferModified = true;
  }

  
  setTwoNumberDecimal($event, field, value) {
    let finalValue = parseFloat($event.target.value).toFixed(2);
    $event.target.value = finalValue;
    this.updateSubmitData(field, finalValue);
  }

}
