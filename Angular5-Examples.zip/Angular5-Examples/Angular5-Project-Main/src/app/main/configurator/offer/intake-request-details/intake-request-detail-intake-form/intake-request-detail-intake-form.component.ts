import { Component, OnInit, OnChanges, Input, SimpleChange, SimpleChanges } from '@angular/core';
import { RequestorService } from '../../../../requestor/services/requestor.service';
import { RequestorDataService } from '../../../../requestor/services/requestor-data.service';

import { IntakeRequestMasterData, FetchAllIntakeRequest, RequestorRequestInterface, RequestorResponseInterface, IntakeFormReq, IntakeRequestForm, 
  IntakeRequestFormIntakeForm } from '../../../../requestor/requestor.interface';



@Component({
  selector: 'plm-intake-request-detail-intake-form',
  templateUrl: './intake-request-detail-intake-form.component.html',
  styleUrls: ['./intake-request-detail-intake-form.component.css'],
  providers: [RequestorDataService]
})
export class IntakeRequestDetailIntakeFormComponent implements OnInit {


  @Input() addEditIntakeRequestForm: IntakeRequestForm;
  @Input() addEditIntakeRequestMasterData: IntakeRequestMasterData;
  private showIntakeFormHeader: Boolean;

  private viewMode: Boolean;
  private discountStartMinDate: Date;
  private discountEndMinDate: Date;
  private campaignCodesToChangeDropDownList = [];
  private campaignCodesToChangeSelectedItems = [];
  private stepupDuratnIdDropDownList = [];
  private stepupDuratnIdSelectedItems = [];
  private requirePLGDropDownList = [];
  private requirePLGSelectedItems = [];
  private tierRequirementsDropDownList = [];
  private tierRequirementsSelectedItems = [];
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private discountExpireDate: any;

  constructor(private requestorService: RequestorService, private requestorDataService: RequestorDataService) {
    this.addEditIntakeRequestMasterData = this.requestorDataService.addEditIntakeRequestMasterData;
    this.showIntakeFormHeader = false;

    this.viewMode = true;
  }

  ngOnInit() {
  }

  ngOnChanges() {
  
  }

  getAddEditIntakeRequestMasterDataObj() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.requestorDataService.addEditIntakeRequestMasterData = data;
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  getDropDownList(masterData, dropDownKey) {
    let result = [];
    if ((typeof masterData.intakeFormMasterDropDown !== 'undefined') && (masterData.intakeFormMasterDropDown !== null)) {
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      result.push({
        "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
        "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
      });
    }
  }
    return result;
  }

  getCampaignCodesForChangeDropDownList(masterData) {
    let result = [];
    if ((typeof masterData.campaignCodesList !== 'undefined') && (masterData.campaignCodesList !== null)) {
      if ((typeof masterData.campaignCodesList !== 'undefined') && (masterData.campaignCodesList !== null) && (masterData.campaignCodesList.length > 0)) {
        for (let i = 0; i < masterData.campaignCodesList.length; i++) {
          result.push({
            "id": masterData.campaignCodesList[i]['key'],
            "itemName": masterData.campaignCodesList[i]['value']
          });
        }
      }
    }
    return result;
  }

  getSelectedItemsObject(masterData, dropDownKey, dropDownList) {
    let result = [];
    if ((typeof masterData.intakeFormMasterDropDown !== 'undefined') && (masterData.intakeFormMasterDropDown !== null)) {
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      if((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId']) > -1)){
        result.push({
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        });
      } else if (masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'] == dropDownList) {
        result.push({
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "itemName": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        });
      }
    }
  }
    return result;
  }

  getCampaignCodesListSelectedItemsObject(masterData, dropDownListVal) {
    let result = [], dropDownList = [];
    for (let j=0; j<dropDownListVal.length; j++) {
      dropDownList.push(dropDownListVal[j].toString());
    }
    if ((typeof masterData.campaignCodesList !== 'undefined') && (masterData.campaignCodesList !== null)) {
      for (let i = 0; i < masterData.campaignCodesList.length; i++) {
        if((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.campaignCodesList[i]['key']) > -1)){
          result.push({
            "id": masterData.campaignCodesList[i]['key'],
            "itemName": masterData.campaignCodesList[i]['value']
          });
        } else if (masterData.campaignCodesList[i]['key'] == dropDownList) {
          result.push({
            "id": masterData.campaignCodesList[i]['key'],
            "itemName": masterData.campaignCodesList[i]['value']
          });
        }
      }
    }
    return result;
  }

  isInstallationIncludedTrue(data) {
    if (data) {
      return true;
    } else {
      return false;
    }
  }

}


