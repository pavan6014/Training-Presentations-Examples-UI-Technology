import { TestBed, inject } from '@angular/core/testing';

import { ModifyOfferService } from './modify-offer.service';

describe('ModifyOfferService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ModifyOfferService]
    });
  });

  it('should be created', inject([ModifyOfferService], (service: ModifyOfferService) => {
    expect(service).toBeTruthy();
  }));
});
