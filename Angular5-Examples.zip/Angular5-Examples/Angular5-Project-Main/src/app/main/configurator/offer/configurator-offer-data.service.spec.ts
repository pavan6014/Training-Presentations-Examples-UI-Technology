import { TestBed, inject } from '@angular/core/testing';

import { ConfiguratorOfferDataService } from './configurator-offer-data.service';

describe('ConfiguratorOfferDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConfiguratorOfferDataService]
    });
  });

  it('should be created', inject([ConfiguratorOfferDataService], (service: ConfiguratorOfferDataService) => {
    expect(service).toBeTruthy();
  }));
});
