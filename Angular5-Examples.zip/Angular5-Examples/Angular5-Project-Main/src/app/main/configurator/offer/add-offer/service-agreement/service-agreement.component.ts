import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { OfferFormDropDown, GetGeneralInfoInterfaceResponse, GetTxnHistory, OfferSearchObj } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'plm-service-agreement',
  templateUrl: './service-agreement.component.html',
  styleUrls: ['./service-agreement.component.css'],
  providers: [UtilitiesService]
})
export class ServiceAgreementComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private offerFormDropDown: any;
  private serviceAgreement: any;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private serviceAgreementDropDownList = [];
  private serviceAgreementSelectedItems = [];
  private singleSelectSettings = {};
  private singleSelectSetting = {};
  private multiSelectSettings = {};
  constructor(
        private addOfferService: AddOfferService, 
        private configuratorOfferDataService: ConfiguratorOfferDataService, 
        private utilitiesService: UtilitiesService
  ) { 
    this.addEditMode = false;
    this.viewMode = false;
    this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
    this.serviceAgreement = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.serviceAgreement));
    if ((typeof this.offerFormDropDown !== 'undefined') && (this.offerFormDropDown != null) && (Object.keys(this.offerFormDropDown).length > 0)) {
        this.updatePageMode();
        this.updateDropDownList();
        this.initializeSelectedItems();
    }
  }

  ngOnInit() {
    this.singleSelectSettings = {
        singleSelection: true,
        text: 'Select One',
        enableSearchFilter: true
    };
    this.multiSelectSettings = {
        singleSelection: false,
        text: 'Select',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: true,
        classes: 'myclass custom-class',
        badgeShowLimit: 3,
        maxHeight: 120
    };
  }

    ngOnChanges(changes: SimpleChanges) {

    }

  updateDropDownList() {
    this.serviceAgreementDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'SERVICE_AGREEMENT');
  }

  initializeSelectedItems(){
      this.serviceAgreementSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'SERVICE_AGREEMENT', this.serviceAgreement.serviceAgrementIds);
  }

  updatePageMode() {
      if ((this.configuratorOfferDataService.offerAddEditViewMode === 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode === 'edit'))) {
          this.addEditMode = true;
          this.viewMode = false;
      }
      else if (this.configuratorOfferDataService.offerAddEditViewMode === 'view') {
          this.addEditMode = false;
          this.viewMode = true;
      }
  }

  updateSubmitData(field, value) {
      this.configuratorOfferDataService.addEditViewOfferFormData.serviceAgreement[field] = value;
  }

  onItemSelect(key: string, item: any, selectType: string) {
      this.updateSelectedVal(key, item, selectType);
  }

  onItemDeSelect(key: string, item: any, selectType: string) {
      this.updateSelectedVal(key, item, selectType);
  }

  onSelectAll(key: string, items: any, selectType: string) {
      this.updateSelectedVal(key, items, selectType);
  }

  onDeSelectAll(key: string, items: any, selectType: string) {
      this.updateSelectedVal(key, items, selectType);
  }

  updateSelectedVal(key: string, items: any, selectType: string){
      let resultVal = this.getValueBySelectType(items, selectType);
      this.updateSubmitData(key, resultVal);
  }

  getValueBySelectType(item: any, selectType: string) {
      let result;
      if (selectType === 'single') {
          result = this.utilitiesService.getSingleSelectIDNgSelect(item);
      } else {
          result = this.utilitiesService.getMultiSelectID(item)
      }
      return result;
  }


}
