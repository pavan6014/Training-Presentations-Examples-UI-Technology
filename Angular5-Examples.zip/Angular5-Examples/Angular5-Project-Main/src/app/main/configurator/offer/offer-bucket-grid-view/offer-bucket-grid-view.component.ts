import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { Offer } from './offer-bucket-grid-vew-interface';
import { OfferBucketGridVewService } from './offer-bucket-grid-vew.service';
import { ConfiguratorOfferDataService } from '../configurator-offer-data.service';
import { UtilitiesService } from '../../../../shared/services/utilities.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RequestorService } from '../../../requestor/services/requestor.service';

@Component({
  selector: 'plm-offer-bucket-grid-view',
  templateUrl: './offer-bucket-grid-view.component.html',
  providers: [OfferBucketGridVewService, RequestorService]
})
export class OfferBucketGridViewComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private projectCode: string;
  private offersList: Offer[];
  private offersReadyToRelease: Offer[];
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  
  private offerId: string;
  private name: string;
  private type: string;
  private description: string;
  private estimatedMRC: string;
  private offerCategory: string;
  private startDate: string;
  private endDate: string;
  private bundle: string;
  private salesAdvice: string;
  private primaryDiscount: string;
  private lastModify: string;
  private status: string;
  private addEditIntakeRequestMasterData: any;
  private projectData: any;

  private filterByofferId: string;
  private filterByname: string;
  private filterBytype: string;
  private filterBydescription: string;
  private filterByestimatedMRC: string;
  private filterByofferCategory: string;
  private filterBystartDate: string;
  private filterByendDate: string;
  private filterBybundle: string;
  private filterBysalesAdvice: string;
  private filterByprimaryDiscount: string;
  private filterBylastModify: string;
  private filterBystatus: string;

  private filterByofferIdSearchObj: any;
  private filterBynameSearchObj: any;
  private filterBytypeSearchObj: any;
  private filterBydescriptionSearchObj: any;
  private filterByestimatedMRCSearchObj: any;
  private filterByofferCategorySearchObj: any;
  private filterBystartDateSearchObj: any;
  private filterByendDateSearchObj: any;
  private filterBybundleSearchObj: any;
  private filterBysalesAdviceSearchObj: any;
  private filterByprimaryDiscountSearchObj: any;
  private filterBylastModifySearchObj: any;
  private filterBystatusSearchObj: any;

  constructor(private OfferBucketGridViewService:OfferBucketGridVewService, private router: Router, private configuratorOfferDataService: ConfiguratorOfferDataService, private utilitiesService: UtilitiesService, 
    private requestorService: RequestorService){
    this.blockUI.start('Loading Offers...');
    this.offersList = [];
    this.offersReadyToRelease = [];

    this.offerId = '';
    this.name = '';
    this.type = '';
    this.description = '';
    this.estimatedMRC = '';
    this.offerCategory = '';
    this.startDate = '';
    this.endDate = '';
    this.bundle = '';
    this.salesAdvice = '';
    this.primaryDiscount = '';
    this.lastModify = '';
    this.status = '';

    this.filterBybundle = '';
    this.filterBydescription = '';
    this.filterByendDate = '';
    this.filterByestimatedMRC = '';
    this.filterBylastModify = '';
    this.filterByname = '';
    this.filterByofferCategory = '';
    this.filterByofferId = '';
    this.filterByprimaryDiscount = '';
    this.filterBysalesAdvice = '';
    this.filterBystartDate = '';
    this.filterBystatus = '';
    this.filterBytype = '';

    this.filterByofferIdSearchObj = '';
    this.filterBynameSearchObj = '';
    this.filterBytypeSearchObj = '';
    this.filterBydescriptionSearchObj = '';
    this.filterByestimatedMRCSearchObj = '';
    this.filterByofferCategorySearchObj = '';
    this.filterBystartDateSearchObj = '';
    this.filterByendDateSearchObj = '';
    this.filterBybundleSearchObj = '';
    this.filterBysalesAdviceSearchObj = '';
    this.filterByprimaryDiscountSearchObj = '';
    this.filterBylastModifySearchObj = '';
    this.filterBystatusSearchObj = '';
  }

  ngOnInit() {
    this.sort('lastUpdateDate');
    this.getConfiguratorOfferList();
    this.projectCode = this.configuratorOfferDataService.offerProjectCode;
    this.configuratorOfferDataService.offerCodeForEditView = '';
  }

  getConfiguratorOfferList(){
    this.OfferBucketGridViewService.getConfiguratorOfferList()
        .subscribe(
            data => {
                this.offersList = data.offers;
                this.offersReadyToRelease = data.completedOffers;
                this.blockUI.stop();
                this.initializeFilterContext();
            },
            error => {
                console.log("Error :: " + error)
            }
        );
  }

  onOfferRelease(isReleased) {
    if (isReleased) {
      this.getConfiguratorOfferList();
    }
  }

  initializeFilterContext() {
    this.filterBybundleSearchObj = {
      'offerBundleName': {
        'type': 'text',
        'value': this.filterBybundle,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionSearchObj = {
      'offerDescription': {
        'type': 'text',
        'value': this.filterBydescription,
        'matchFullCase': false
      }
    };
    this.filterByendDateSearchObj = {
      'endDt': {
        'type': 'text',
        'value': this.filterByendDate,
        'matchFullCase': false
      }
    };
    this.filterByestimatedMRCSearchObj = {
      'estimatedMrc': {
        'type': 'text',
        'value': this.filterByestimatedMRC,
        'matchFullCase': false
      }
    };
    this.filterBylastModifySearchObj = {
      'lastUpdateDate': {
        'type': 'text',
        'value': this.filterBylastModify,
        'matchFullCase': false
      }
    };
    this.filterBynameSearchObj = {
      'offerName': {
        'type': 'text',
        'value': this.filterByname,
        'matchFullCase': false
      }
    };
    this.filterByofferCategorySearchObj = {
      'offerCategory': {
        'type': 'text',
        'value': this.filterByofferCategory,
        'matchFullCase': false
      }
    };
    this.filterByofferIdSearchObj = {
      'offerId': {
        'type': 'text',
        'value': String(''+this.filterByofferId),
        'matchFullCase': false
      }
    };
    this.filterByprimaryDiscountSearchObj = {
      'primaryDiscountCode': {
        'type': 'text',
        'value': this.filterByprimaryDiscount,
        'matchFullCase': false
      }
    };
    this.filterBysalesAdviceSearchObj = {
      'salesAdvise': {
        'type': 'text',
        'value': this.filterBysalesAdvice,
        'matchFullCase': false
      }
    };
    this.filterBystartDateSearchObj = {
      'startDt': {
        'type': 'text',
        'value': this.filterBystartDate,
        'matchFullCase': false
      }
    };
    this.filterBystatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };
    this.filterBytypeSearchObj = {
      'psu': {
        'type': 'text',
        'value': this.filterBytype,
        'matchFullCase': false
      }
    };
  }

  convertBreakTagToLineBreak(value) {
      let result = '';
      if (value != null) {
          return value.split('<br />').join('\n');
      }
      return value;  
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  addOffer() {
    this.triggerEditViewOfferConstruct('add', '');
  }

  viewOffer(offerCode) {
    this.triggerEditViewOfferConstruct('view', offerCode);
  }

  editOffer(offerCode) {
    this.triggerEditViewOfferConstruct('edit', offerCode);
  }

  triggerEditViewOfferConstruct(mode, offerCode) {
    this.configuratorOfferDataService.offerAddEditViewMode = mode;
    this.configuratorOfferDataService.offerCodeForEditView = offerCode;
    this.configuratorOfferDataService.backURL = '/plm-work-flow/configurator/offer/offer-table';
    this.configuratorOfferDataService.isFromBusinessCatalog = 'false';
    this.router.navigate(['plm-work-flow/configurator/offer/view-offer']);
  }

  moveToIntakeRequestView() {
    // this.configuratorOfferDataService.offerProjectCode = this.projectCode;
    // localStorage.setItem('mode','view');
    // localStorage.setItem('intakeRequestID', this.projectCode);
    // localStorage.setItem('backURL', 'plm-work-flow/configurator/offer/offer-table');
    // // this.router.navigate(['plm-work-flow/requestor/view-intake-request']);
    // window.open('', 'Discount Intake Request', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1600,height=850, top=100,left=200');
    this.getAddEditIntakeRequestMasterData();
  }


  getAddEditIntakeRequestMasterData() {
    this.blockUI.start('Loading Intake Request Master Data...');
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.addEditIntakeRequestMasterData['MARKETS'] = [];
        for (let prop in this.addEditIntakeRequestMasterData['mapMarketList']) {
          this.pushMarketsData(this.addEditIntakeRequestMasterData['mapMarketList'][prop]); 
        }
        this.fetchEditProjectData();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  fetchEditProjectData() {
    this.blockUI.start('Loading Intake Request Detail...');
    this.requestorService.getEditProjectData(this.projectCode).subscribe(
      data => {
        this.projectData = data;
        this.resetNullValuesInObj(this.projectData.projectMasterModel);
        this.resetNullValuesInObj(this.projectData.projectMasterModel.intakeFormReqTxnDetModel);
        this.projectData.projectMasterModel.projectStartDt = this.converetDate(this.projectData.projectMasterModel.projectStartDt);
        this.projectData.projectMasterModel.projectEndDt = this.converetDate(this.projectData.projectMasterModel.projectEndDt);
        localStorage.setItem('projectCode', this.projectData.projectMasterModel.projectCode);
        localStorage.setItem('uploadIntakeRequestDocId', this.projectData.projectMasterModel.uploadIntakeRequestDocId);
        this.utilitiesService.triggerWindowTab(this.addEditIntakeRequestMasterData, this.projectData);
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  resetNullValuesInObj(data) {
    for (let prop in data) {
      data[prop] = (data[prop]) ? data[prop] : '';
    }
  }

  getDateInFormat(date){
    const dateObj = new Date(date);
    const dateInFormatVal = Number(dateObj.getDate());
    const monthInFormatVal = Number(dateObj.getMonth())+1;
    const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
    const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
    const yearInFormat = dateObj.getFullYear();
    return (monthInFormat+'-'+dateInFormat+'-'+yearInFormat);
  }
   
  getDateMonthInTwoDigits(value){
    return (value < 10 ? '0' : '') + value;
  }

  converetDate(startDate){
    return this.getDateInFormat(startDate);
   }


  pushMarketsData(markets) {
    for(let i=0; i<markets.length; i++) {
      this.addEditIntakeRequestMasterData['MARKETS'].push(markets[i]);
    }
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }

}