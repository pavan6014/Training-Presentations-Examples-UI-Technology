import { Injectable } from '@angular/core';
import { AppConfigService } from '../../../../shared/services/app-config.service';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../../../shared/services/bread-crumb';


@Injectable()
export class ModifyOfferService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }
  
  getModifyOfferListData(projectCode): Observable<any> {
    const getModifyOfferListDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_MODIFY_OFFER_LIST']+ '/' + projectCode;
    // const getModifyOfferListDataURL = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_MODIFY_OFFER_LIST'];
    return this.http
      .get(getModifyOfferListDataURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getModifyOfferMasterData(): Observable<any> {
    const getConfiguratorMasterData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_MODIFY_MASETR_DROPDOWN'];
    // const getConfiguratorMasterData = this.appConfigService.urlConstants['PLM_CONFIGURATOR_OFFER_CREATION_MASETR_DROPDOWN'];
    return this.http
      .get(getConfiguratorMasterData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getSearchOfferList(searchOfferVal): Observable<any> {
    const getSearchOfferList = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_MODIFY_OFFER_SEARCH'];
    const reqObj = {
      'searchKey': searchOfferVal
    };
    return this.http
      .post(getSearchOfferList, reqObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getSearchOfferList = this.appConfigService.urlConstants['PLM_MODIFY_OFFER_SEARCH'];
    // const reqObj = {
    //   'searchKey': searchOfferVal
    // };
    // return this.http
    //   .get(getSearchOfferList)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  validateAndSubmitOffer(submitObj) {
    const validateAndSubmitOfferURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_MODIFY_VALIDATE_AND_SUBMIT'];
    return this.http
      .post(validateAndSubmitOfferURL, submitObj)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const validateAndSubmitOfferURL = this.appConfigService.urlConstants['PLM_MODIFY_VALIDATE_AND_SUBMIT'];
    // return this.http
    //   .get(validateAndSubmitOfferURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
