import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { GetGeneralInfoInterfaceResponse, GetTxnHistory, OfferFormDropDown, OfferSearchObj } from '../add-offer-interface';

import { AddOfferService } from '../add-offer.service';
import { ConfiguratorOfferDataService } from '../../configurator-offer-data.service';
import { UtilitiesService } from '../../../../../shared/services/utilities.service';

@Component({
    selector: 'plm-general-info',
    templateUrl: './general-info.component.html',
    providers: [UtilitiesService]
})
export class GeneralInfoComponent implements OnInit {

    // @Input() offerFormDropDown: OfferFormDropDown;
    // @Input() offerGeneralInfo: GetGeneralInfoInterfaceResponse;
   	@Input('parentData') incomingData: string;
    @BlockUI() blockUI: NgBlockUI;
    public formData: any;
    private selectedAll: Boolean;
    private sites: number[];
    private isSelectAll: Boolean;
    private selectSite: Boolean[];
    private getTxnHistory: GetTxnHistory;
    private offerFormDropDown: any;
    private offerGeneralInfo: any;
    private addEditMode: Boolean;
    private viewMode: Boolean;
    private singleSelectSettings = {};
    private singleSelectSetting = {};
    private multiSelectSettings = {};
    private startMinDate: Date;
    private endMinDate: Date;
    private lastUpdateMinDate: Date;
    private offerTypeDropDownList = [];
    private offerTypeSelectedItems = [];
    private offerCategoryDropDownList = [];
    private offerCategorySelectedItems = [];
    private psuCategoryDropDownList = [];
    private psuCategorySelectedItems = [];
    private bundleDropDownList = [];
    private bundleSelectedItems = [];
    private statusDropDownList = [];
    private statusSelectedItems = [];
    private offerStartMinDate: Date;
    private offerEndMinDate: Date;
    private noSubmitOffer: Boolean;
    private showButton: Boolean;
    private searchOfferVal: string;
    private offerSearchList: OfferSearchObj[];
    private offerIDForSearch: number;
    private copyOfferFormData: any;
    private showCopyOfferAddButton: boolean;

    private filterByDate: string;
    private key: string;
    private reverse: boolean;

    constructor(
        private addOfferService: AddOfferService,
        private configuratorOfferDataService: ConfiguratorOfferDataService,
        private utilitiesService: UtilitiesService
    ) {
        // this.getTxnHistoryDatas();
        this.selectedAll = false;
        this.isSelectAll = false;
        this.sites = [];
        this.formData = {};
        this.selectSite = [];
        this.addEditMode = false;
        this.viewMode = false;
        this.showButton = false;
        this.showCopyOfferAddButton = false;
        this.searchOfferVal = '';
       // this.lastDate = '';
        this.offerFormDropDown = JSON.parse(JSON.stringify(this.configuratorOfferDataService.masterFormData));
        // this.initializeMarketsByRegion();
        this.offerGeneralInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet));
        this.offerGeneralInfo.offerStartDate = new Date(this.offerGeneralInfo.offerStartDate);
        this.offerGeneralInfo.offerEndDate = new Date(this.offerGeneralInfo.offerEndDate);
        this.sites = this.offerGeneralInfo.sites;

        this.filterByDate = '';
        this.updateMarkets();
        this.isAllSitesSelectedCheck();
        if ((typeof this.offerFormDropDown !== 'undefined') && (this.offerFormDropDown != null) && (Object.keys(this.offerFormDropDown).length > 0)) {
            this.updateDropDownList();
            this.updatePageMode();
            this.intializeProjectDate();
            this.initializeSelectedItems();
        }
    }

    ngOnInit() {

        this.sort('date');
        this.singleSelectSettings = {
            singleSelection: true,
            text: 'Select One',
            enableSearchFilter: true
        };
        this.singleSelectSetting = {
            singleSelection: true,
            disabled: true,
            text: 'Select One',
            enableSearchFilter: true
        };
        this.multiSelectSettings = {
            singleSelection: false,
            text: 'Select',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            classes: 'myclass custom-class',
            badgeShowLimit: 3,
            maxHeight: 120
        };
        this.sites = this.offerGeneralInfo.sites;
        this.configuratorOfferDataService.copyOfferAddEditViewOfferFormData.subscribe(
            text => {
                this.configuratorOfferDataService.addEditViewOfferFormData = text;
                this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerId = null;
                this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.offerStatus = null;
                this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.lastUpdateDate = '';
                this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet.createdDate = '';
                this.offerGeneralInfo = JSON.parse(JSON.stringify(this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet));
                this.offerGeneralInfo.offerStartDate = new Date(this.offerGeneralInfo.offerStartDate);
                this.offerGeneralInfo.offerEndDate = new Date(this.offerGeneralInfo.offerEndDate);
                this.sites = this.offerGeneralInfo.sites;
                this.updateMarkets();
                this.isAllSitesSelectedCheck();
                this.intializeProjectDate();
                this.initializeSelectedItems();
            }
        );
    }

    initializeMarketsByRegion() {
        for (const prop in this.offerFormDropDown.marketMasterMap) {
            if (this.offerFormDropDown.marketMasterMap[prop]) {
                this.initializeMarketsChecked(this.offerFormDropDown.marketMasterMap[prop]);
            }
        }
    }

    initializeMarketsChecked(regionSites) {
        for (let i = 0; i < regionSites.length; i++) {
            regionSites[i]['checked'] = false;
        }
    }

    getTxnHistoryDatas() {
        this.addOfferService.getTxnHistoryData(this.configuratorOfferDataService.offerCodeForEditView)
            .subscribe(
            data => {
                this.getTxnHistory = data.offerTxnHistoryModellist;
            },
            error => {
                console.log("Error :: " + error)
            }
            );

    }


    updatePageMode() {
        if ((this.configuratorOfferDataService.offerAddEditViewMode === 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode === 'edit'))) {
            this.addEditMode = true;
            this.showButton = ((this.configuratorOfferDataService.offerAddEditViewMode === 'add') || ((this.configuratorOfferDataService.offerAddEditViewMode === 'edit'))) ? true : false;
            this.viewMode = false;
        }
        else if (this.configuratorOfferDataService.offerAddEditViewMode === 'view') {
            this.addEditMode = false;
            this.showButton = false;
            this.viewMode = true;
        }
    }

    updateDropDownList() {
        this.offerTypeDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'OFFER_TYPE');
        this.offerTypeDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.offerCategoryDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'OFFER_CATEGORY_MASTER');
        this.offerCategoryDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.psuCategoryDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'PSU_TYPE_CATEGORY');
        this.psuCategoryDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.bundleDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'BUNDLE_MASTER');
        this.bundleDropDownList.unshift({
            'id': '',
            'name': 'Select One'
        });
        this.statusDropDownList = this.utilitiesService.getDropDownListNgSelect(this.offerFormDropDown, 'STATUS_MASTER');
        if ((typeof this.offerFormDropDown !== 'undefined') && (typeof this.offerGeneralInfo !== 'undefined')) {
            this.initializeSelectedItems();
        }
    }

    initializeSelectedItems() {
        this.offerTypeSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'OFFER_TYPE', this.offerGeneralInfo.offertypeid);
        this.offerCategorySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'OFFER_CATEGORY_MASTER', this.offerGeneralInfo.offerCategory);
        this.psuCategorySelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'PSU_TYPE_CATEGORY', this.offerGeneralInfo.psu);
        this.bundleSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'BUNDLE_MASTER', this.offerGeneralInfo.offerBundle);
        this.statusSelectedItems = this.utilitiesService.getSelectedItemsObjectNgSelect(this.offerFormDropDown, 'STATUS_MASTER', this.offerGeneralInfo.offerStatus);
    }

    intializeProjectDate() {
        const today = new Date();
        const todayDate = today.getDate();
        const todayMonth = today.getMonth();
        const todayYear = today.getFullYear();
        this.offerStartMinDate = new Date(todayYear, todayMonth, todayDate);
        this.offerEndMinDate = new Date(todayYear, todayMonth, todayDate);
    }

    startDateChanged(key, offerStartDate) {
        const startDateObj = new Date(offerStartDate);
        const endMinDate = Number(startDateObj.getDate()) + 1;
        const endMinMonth = startDateObj.getMonth();
        const endMinYear = startDateObj.getFullYear();
        this.updateSubmitData(key, this.getDateInFormat(offerStartDate));
        if (key === 'offerStartDate') {
            this.offerEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
            this.offerGeneralInfo.offerEndDate = '';
        }
    }

    getDateInFormat(date) {
        const dateObj = new Date(date);
        const dateInFormatVal = Number(dateObj.getDate());
        const monthInFormatVal = Number(dateObj.getMonth()) + 1;
        const dateInFormat = this.getDateMonthInTwoDigits(dateInFormatVal);
        const monthInFormat = this.getDateMonthInTwoDigits(monthInFormatVal);
        const yearInFormat = dateObj.getFullYear();
        return (monthInFormat + '-' + dateInFormat + '-' + yearInFormat);
    }

    getDateMonthInTwoDigits(value) {
        return (value < 10 ? '0' : '') + value;
    }

    updateDateInFormat(key, date) {
        const dateObj = new Date(date);
        const endMinDate = Number(dateObj.getDate());
        const endMinMonth = dateObj.getMonth();
        const endMinYear = dateObj.getFullYear();
        this.updateSubmitData(key, endMinMonth + '-' + endMinDate + '-' + endMinYear);
    }


    updateMarkets() {
        for (const prop in this.offerFormDropDown.marketMasterMap) {
            if (this.offerFormDropDown.marketMasterMap[prop]) {
                this.updateMarketsChecked(this.offerFormDropDown.marketMasterMap[prop]);
            }
        }
    }

    updateMarketsChecked(regionSites) {
        for (let i = 0; i < regionSites.length; i++) {
            if (this.sites.indexOf(Number(regionSites[i].siteId)) > -1) {
                regionSites[i]['checked'] = true;
            } else {
                regionSites[i]['checked'] = false;
            }
        }
    }

    isAllSitesSelectedCheck() {
        const marketSitesLength = Object.keys(this.offerFormDropDown.MARKETS).length;
        if (this.sites.length === marketSitesLength) {
            this.isSelectAll = true;
            return true;
        } else {
            this.isSelectAll = false;
            return false;
        }
    }

    isSitesExist(site, index) {
        if (this.sites.indexOf(Number(site)) > -1) {
            setTimeout(() => { this.selectSite[index] = true; }, 0)
            return true;
        } else {
            return false;
        }
    }

    selectAllSites(selectedAll) {
        if (selectedAll) {
            this.sites = [];
            for (let i = 0; i < this.offerFormDropDown.MARKETS.length; i++) {
                this.sites.push(Number(this.offerFormDropDown.MARKETS[i]['siteId']));
            }
            this.isSelectAll = true;
        } else {
            this.sites = [];
            this.isSelectAll = false;
        }
        this.updateMarkets();
        this.isAllSitesSelectedCheck();
        this.updateSubmitData('sites', this.sites);
    }

    addSite(selectSite, siteValue) {
        if (selectSite) {
            this.sites.push(Number(siteValue));
        } else {
            this.sites.splice(this.sites.indexOf(Number(siteValue)), 1);
        }
        this.updateMarkets();
        this.isAllSitesSelectedCheck();
        this.updateSubmitData('sites', this.sites);
    }

    onItemSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onItemDeSelect(key: string, item: any, selectType: string) {
        this.updateSelectedVal(key, item, selectType);
    }

    onSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    onDeSelectAll(key: string, items: any, selectType: string) {
        this.updateSelectedVal(key, items, selectType);
    }

    updateSelectedVal(key: string, items: any, selectType: string) {
        const resultVal = this.getValueBySelectType(items, selectType);
        this.updateSubmitData(key, resultVal);
    }

    getValueBySelectType(item: any, selectType: string) {
        let result;
        if (selectType === 'single') {
            result = this.utilitiesService.getSingleSelectIDNgSelect(item);
        } else {
            result = this.utilitiesService.getMultiSelectID(item)
        }
        return result;
    }

    convertTextAreaContentWithBreaks(field, value) {
        this.updateSubmitData(field, value.split('\n').join('<br />'));
    }

    convertBreakTagToLineBreak(value) {
        if (value != null) {
            return value.split('<br />').join('\n');
        }
        return value;
    }

    updateSubmitData(field, value) {
        this.configuratorOfferDataService.addEditViewOfferFormData.generalInfoMapTxnDet[field] = value;
        this.configuratorOfferDataService.isAddEditOfferModified = true;
    }

    resetOfferSearchData() {
        this.offerSearchList = [];
    }

    searchOffer(searchOfferVal) {
        this.blockUI.start('Loading Offer Search List...');
        this.addOfferService.getCopyOfferSearch(this.searchOfferVal)
            .subscribe(
            data => {
                this.offerSearchList = data.offerModifyModelList;
                this.blockUI.stop();
            },
            error => {
                console.log("Error :: " + error);
                this.blockUI.stop();
            }
            );
    }

    updateOfferCodeForCopy(offerId) {
        this.offerIDForSearch = offerId;
        this.showCopyOfferAddButtonEnable();
    }

    showCopyOfferAddButtonEnable() {
        if ((!this.offerIDForSearch) || (this.offerIDForSearch === 0) || (typeof this.offerIDForSearch === 'undefined') || (this.offerIDForSearch == null)) {
            this.showCopyOfferAddButton = false;
        } else {
            this.showCopyOfferAddButton = true;
        }
    }

    triggerCopyOffer() {
        if (!this.offerIDForSearch) {
            return false;
        }
        this.blockUI.start('Copying Offer...');
        this.addOfferService.addOfferSearchForCopy(this.offerIDForSearch)
            .subscribe(
            data => {
                this.copyOfferFormData = data.offerModel;
                if (!this.copyOfferFormData.serviceAgreement) {
                    this.copyOfferFormData.serviceAgreement = {
                        'data': false,
                        'homeLife': false,
                        'phone': false,
                        'video': false,
                        'serviceAgrementIds': []
                    }
                };
                this.configuratorOfferDataService.modifyCopyOfferData(this.copyOfferFormData);
                this.blockUI.stop();
            },
            error => {
                console.log("Error :: " + error);
                this.blockUI.stop();
            }
            );
    }

    setTwoNumberDecimal($event, field, value) {
        const finalValue = parseFloat($event.target.value).toFixed(2);
        $event.target.value = finalValue;
        this.updateSubmitData(field, finalValue);
        this.configuratorOfferDataService.modifyOfferPrice(finalValue);
    }

    sort(key) {
        this.key = key;
        this.reverse = !this.reverse;
    }

}
