import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-project-list-grid',
  templateUrl: './project-list-grid.component.html'
})
export class ProjectListGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
