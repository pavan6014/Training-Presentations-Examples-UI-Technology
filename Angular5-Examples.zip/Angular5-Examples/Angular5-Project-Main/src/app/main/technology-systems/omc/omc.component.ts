import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-omc',
  templateUrl: './omc.component.html'
})
export class OmcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
