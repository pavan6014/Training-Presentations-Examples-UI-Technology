import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-pinpoint',
  templateUrl: './pinpoint.component.html'
})
export class PinpointComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
