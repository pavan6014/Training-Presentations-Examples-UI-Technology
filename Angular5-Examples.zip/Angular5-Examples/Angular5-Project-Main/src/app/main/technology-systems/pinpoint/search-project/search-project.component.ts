import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-search-project',
  templateUrl: './search-project.component.html'
})
export class PinPointSearchProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
