import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-project-list-grid',
  templateUrl: './project-list-grid.component.html'
})
export class PinPointProjectListGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
