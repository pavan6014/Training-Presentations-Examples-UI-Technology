import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-offer-detail-info',
  templateUrl: './offer-detail-info.component.html'
})
export class OfferDetailInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
