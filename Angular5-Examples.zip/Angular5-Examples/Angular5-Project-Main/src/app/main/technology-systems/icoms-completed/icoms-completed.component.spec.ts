import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcomsCompletedComponent } from './icoms-completed.component';

describe('IcomsCompletedComponent', () => {
  let component: IcomsCompletedComponent;
  let fixture: ComponentFixture<IcomsCompletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcomsCompletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcomsCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
