import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, Inject, OnInit } from '@angular/core';
import { DiscountIcomsModel, ExportIcomsUserRequest, IcomsInterface, IcomsStatusMasterData, IcomsUserFormData, ModifyIcomsUserRequest, Users } from '../icoms/icoms-interface';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';

import { AppConfigService } from '../../../shared/services/app-config.service';
// import { ConfiguratorDiscountDataService } from '../../configurator/discount/services/configurator-discount-data.service';
import { DiscountService } from '../../configurator/discount/discount-details/discount.service';
import { IcomsService } from '../icoms/icoms.service';
import { MatDialogModule } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { UtilitiesService } from '../../../shared/services/utilities.service';

@Component({
  selector: 'plm-icoms-completed',
  templateUrl: './icoms-completed.component.html',
  providers: [IcomsService, AppConfigService, UtilitiesService]
})
export class IcomsCompletedComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private icomsTableList: IcomsInterface;
  private usersMasterData: Users;
  private icomStatusMasterData: IcomsStatusMasterData;
  private usersData: IcomsUserFormData;
  private icomsUserList: DiscountIcomsModel[];
  private users: string;
  selectedAll: any;

  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private formDataAvailable: boolean;
  private updateUsersChecked: boolean;
  private submitFailed: boolean;
  private exportXlFailed: boolean;
  private exportXlSuccess: boolean;

  private filterByDiscountId: string;
  private filterByDiscountCode: string;
  private filterByDescription: string;
  private filterByVersion: string;
  private filterByICOMSStatus: string;
  private filterByOfferSeries: string;
  private filterByICOMSAssignedTo: string;
  private filterByPeerReviewedBy: string;
  private filterByDiscountCodeChanges: string;
  private filterByPricing: string;
  private filterByStartDate: string;
  private filterByEndDate: string;
  private filterByPricingMethod: string;
  private filterByDiscountCDStatus: string;
  private filterByDateCreated: string;
  private filterByIntakeRequestID: string;
  private filterBypeerRevwDate: string;

  private filterByDiscountIdSearchObj: any;
  private filterByDiscountCodeSearchObj: any;
  private filterByDescriptionSearchObj: any;
  private filterByVersionSearchObj: any;
  private filterByICOMSStatusSearchObj: any;
  private filterByOfferSeriesSearchObj: any;
  private filterByICOMSAssignedToSearchObj: any;
  private filterByPeerReviewedBySearchObj: any;
  private filterByDiscountCodeChangesSearchObj: any;
  private filterByPricingGroupsSearchObj: any;
  private filterByStartDateSearchObj: any;
  private filterByEndDateSearchObj: any;
  private filterByPricingMethodSearchObj: any;
  private filterByDiscountCDStatusSearchObj: any;
  private filterByDateCreatedSearchObj: any;
  private filterByIntakeRequestIDSearchObj: any;
  private filterBypeerRevwDateSearchObj: any;

  private IcomsDownloadFileUrl: any;
  private peerRevwDateMinDte: any;

  constructor(private discountService: DiscountService, private router: Router, public dialog: MatDialog, private icomsService: IcomsService, private appConfigService: AppConfigService, private utilitiesService: UtilitiesService) {
    this.formDataAvailable = false;
    this.updateUsersChecked = true;
    this.submitFailed = false;
    this.exportXlFailed = false;
    this.exportXlSuccess = false;
    this.IcomsDownloadFileUrl = '';
    this.peerRevwDateMinDte = '';

    this.filterByDiscountId = '';
    this.filterByDiscountCode = '';
    this.filterByDescription = '';
    this.filterByVersion = '';
    this.filterByICOMSStatus = '';
    this.filterByOfferSeries = '';
    this.filterByICOMSAssignedTo = '';
    this.filterByPeerReviewedBy = '';
    this.filterByDiscountCodeChanges = '';
    this.filterByPricing='';
    this.filterByStartDate = '';
    this.filterByEndDate = '';
    this.filterByPricingMethod = '';
    this.filterByDiscountCDStatus = '';
    this.filterByDateCreated = '';
    this.filterByIntakeRequestID = '';
    this.filterBypeerRevwDate = '';

    this.filterByDiscountIdSearchObj = '';
    this.filterByDiscountCodeSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    this.filterByVersionSearchObj = '';
    this.filterByICOMSStatusSearchObj = '';
    this.filterByOfferSeriesSearchObj = '';
    this.filterByICOMSAssignedToSearchObj = '';
    this.filterByPeerReviewedBySearchObj = '';
    this.filterByDiscountCodeChangesSearchObj = '';
    this.filterByPricingGroupsSearchObj='';
    this.filterByStartDateSearchObj = '';
    this.filterByEndDateSearchObj = '';
    this.filterByPricingMethodSearchObj = '';
    this.filterByDiscountCDStatusSearchObj = '';
    this.filterByDateCreatedSearchObj = '';
    this.filterByIntakeRequestIDSearchObj = '';
    this.filterBypeerRevwDateSearchObj = '';

    sessionStorage.removeItem('mode');
    sessionStorage.removeItem('discountId');
    sessionStorage.removeItem('backURL');
    sessionStorage.removeItem('isFromTechnologySystems');

    this.getFormData();
    this.blockUI.start('Loading ICOMS Table Data...');
  }

  ngOnInit() {
    this.getIocmsTableData();
  }

  selectAll(isChecked) {
    for (let i = 0; i < this.icomsUserList.length; i++) {
      this.icomsUserList[i].checked = isChecked;
      this.enableDisableUpdateButton(isChecked);
    }
  }
  selectDeselectAll() {
    for (let i = 0; i < this.icomsUserList.length; i++) {
      this.icomsUserList[i].checked = this.selectedAll;
    }
    this.checkIfAllSelected();
  }  
  redirectTo(url) {
    this.router.navigate([url]);
  }
  checkIfAllSelected() {
    this.selectedAll = this.icomsUserList.every(function (item: any) {
      return item.checked == true;
    });
    let count = 0;
    if (this.icomsUserList.length > 0) {
      for (let i = 0; i < this.icomsUserList.length; i++) {
        if (this.icomsUserList[i].checked) {
          count++;
        }
      }
    }
    if (count > 0) {
      this.updateUsersChecked = false;
    } else {
      this.updateUsersChecked = true;
    }
  }

  getIocmsTableData() {
    this.icomsService.getIcomsCompletedTableList().subscribe(
      data => {
        this.icomsUserList = data.discountIcomsModel;
        this.icomsUserList.map(function(value, key){
          value['peerRevwDateVal'] =value['peerRevwDate'] ? new Date(value['peerRevwDate']) : '';
        });
        this.initializeFilterContext();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }



  getFormData() {
    this.icomsService.getFormData()
      .subscribe(
      data => {
        this.usersData = data;
        this.populateData(data);
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }

  populateData(data) {
    this.usersMasterData = data.users;
    this.icomStatusMasterData = data.icomsStatus[0].records;
  }

  updateIcomsUsersData() {
    const reqObjArray: ModifyIcomsUserRequest = {
      "discountIcomsModel": []
    };
    let count = 0;
    if (this.icomsUserList.length > 0) {
      for (let i = 0; i < this.icomsUserList.length; i++) {
        if (this.icomsUserList[i].checked) {
          count++;
          const reqObj: any = {
            discountMapIcomsId: Number(this.icomsUserList[i].discountMapIcomsId),
            icomsStatusId: this.icomsUserList[i].icomsStatusId,
            discountId: Number(this.icomsUserList[i].discountId),
            discountCode: this.icomsUserList[i].discountCode,
            description: this.icomsUserList[i].description,
            version: this.icomsUserList[i].version,
            assignedTo: this.icomsUserList[i].assignedTo,
            peerReviewBy: this.icomsUserList[i].peerReviewBy,
            peerRevwDate: this.icomsUserList[i].peerRevwDate,
            discountCodeChanges: this.icomsUserList[i].discountCodeChanges,
            pricingGroups: this.icomsUserList[i].pricingGroups,
            startDate: this.icomsUserList[i].startDate,
            endDate: this.icomsUserList[i].endDate,
            priceMethodId: this.icomsUserList[i].priceMethodId,
            createdDate: this.icomsUserList[i].createdDate,
            discountCodeStatusId: this.icomsUserList[i].discountCodeStatusId,
            projectCode: this.icomsUserList[i].projectCode,
          };

          reqObjArray.discountIcomsModel.push(reqObj);
        }
      }
    }
    if (count > 0) {
      this.icomsService.updateIcomsTableList(reqObjArray)
        .subscribe(
        data => {
          if (data.actionStatus === "SUCCESS") {
            this.getIocmsTableData();
          } else {
            this.submitFailed = true;
            setTimeout(function () {
              this.hideStatus();
            }.bind(this), 5000);
          }
        },
        error => {
          console.log("Error :: " + error);
          this.submitFailed = true;
        }
        );
    }
    this.selectedAll = false;
  }

  getFileDownload() {
    const discountMapIcomsIds = this.exportIcomsUsersData();
    this.icomsService.getExportIcomsUsersData(discountMapIcomsIds)
      .subscribe(
      data => this.utilitiesService.downloadFile(data, 'ICOMS_Extract.xlsx'),
      error => {
        console.log('Error :: ' + error);
      }
      );
  }

  exportIcomsUsersData() {
    let count = 0;
    const discountMapIcomsId = [];
    if (this.icomsUserList.length > 0) {
      for (let i = 0; i < this.icomsUserList.length; i++) {
        if (this.icomsUserList[i].checked) {
          count++;
          discountMapIcomsId.push(Number(this.icomsUserList[i].discountMapIcomsId));
        }
      }
    }
    console.log(count);
    if (count > 0) {
      return JSON.stringify(discountMapIcomsId);
    }
    else {
      return null;
    }
  }

  getIndexByUserID(discountMapIcomsId) {
    let result = 0;
    for (let i = 0; i < this.icomsUserList.length; i++) {
      if (this.icomsUserList[i].discountMapIcomsId === discountMapIcomsId) {
        result = i;
        break;
      }
    }
    return result;
  }

  modifyIcomsUserListObject() {
    if (this.icomsUserList.length > 0) {
      for (let i = 0; i < this.icomsUserList.length; i++) {
        this.icomsUserList[i].discountMapIcomsId = this.icomsUserList[i].discountMapIcomsId;
        this.icomsUserList[i].icomsStatusId = this.icomsUserList[i].icomsStatusId;
        this.icomsUserList[i].discountCode = this.icomsUserList[i].discountCode;
        this.icomsUserList[i].description = this.icomsUserList[i].description;
        this.icomsUserList[i].version = this.icomsUserList[i].version;
        this.icomsUserList[i].assignedTo = this.icomsUserList[i].assignedTo;
        this.icomsUserList[i].peerReviewBy = this.icomsUserList[i].peerReviewBy;
        this.icomsUserList[i].peerRevwDate = this.icomsUserList[i].peerRevwDateVal;
        this.icomsUserList[i].discountCodeChanges = this.icomsUserList[i].discountCodeChanges;
        this.icomsUserList[i].startDate = this.icomsUserList[i].startDate;
        this.icomsUserList[i].endDate = this.icomsUserList[i].endDate;
        this.icomsUserList[i].priceMethodId = this.icomsUserList[i].priceMethodId;
        this.icomsUserList[i].createdDate = this.icomsUserList[i].createdDate;
        this.icomsUserList[i].discountCodeStatusId = this.icomsUserList[i].discountCodeStatusId;
        this.icomsUserList[i].projectCode = this.icomsUserList[i].projectCode;
        this.icomsUserList[i].pricingGroups = this.icomsUserList[i].pricingGroups;
      }
    }
    this.users = JSON.stringify(this.icomsUserList);
    this.initializeFilterContext();
  }

  enableDisableUpdateButton(index) {
    this.icomsUserList[index].checked = ! this.icomsUserList[index].checked;
    for(let i=0;i<this.icomsUserList.length;i++){
      if(this.icomsUserList[i].checked == true){   
      }
    }
    let count = 0;
    if (this.icomsUserList.length > 0) {
      for (let i = 0; i < this.icomsUserList.length; i++) {
        if (this.icomsUserList[i].checked) {
          count++;
        }
      }
    }
    if (count > 0) {
      this.updateUsersChecked = false;
    } else {
      this.updateUsersChecked = true;
    }
  }

  initializeFilterContext() {
    this.filterByDiscountIdSearchObj = {
      'discountId': {
        'type': 'text',
        'value': this.filterByDiscountId,
        'matchFullCase': false
      }
    };
    this.filterByDiscountCodeSearchObj = {
      'discountCode': {
        'type': 'text',
        'value': this.filterByDiscountCode,
        'matchFullCase': false
      }
    };
    this.filterByDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByDescription,
        'matchFullCase': false
      }
    };
    this.filterByVersionSearchObj = {
      'version': {
        'type': 'text',
        'value': this.filterByVersion,
        'matchFullCase': false
      }
    };
    this.filterByICOMSStatusSearchObj = {
      'icomsStatusId': {
        'type': 'text',
        'value': this.filterByICOMSStatus,
        'matchFullCase': false
      }
    };
    this.filterByOfferSeriesSearchObj = {
      'offerSeries': {
        'type': 'text',
        'value': this.filterByOfferSeries,
        'matchFullCase': false
      }
    };
    this.filterByICOMSAssignedToSearchObj = {
      'assignedTo': {
        'type': 'text',
        'value': this.filterByICOMSAssignedTo,
        'matchFullCase': false
      }
    };
    this.filterByPeerReviewedBySearchObj = {
      'peerReviewBy': {
        'type': 'text',
        'value': this.filterByPeerReviewedBy,
        'matchFullCase': false
      }
    };
    this.filterBypeerRevwDateSearchObj = {
      'peerRevwDate': {
        'type': 'text',
        'value': this.filterBypeerRevwDate,
        'matchFullCase': false
      }
    };
     this.filterByDiscountCodeChangesSearchObj = {
      'discountCodeChanges': {
        'type': 'text',
        'value': this.filterByDiscountCodeChanges,
        'matchFullCase': false
      }
    };
    this.filterByPricingGroupsSearchObj = {
      'pricingGroups': {
        'type': 'text',
        'value': this.filterByPricing,
        'matchFullCase': false
      }
    };
    this.filterByStartDateSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterByStartDate,
        'matchFullCase': false
      }
    };
    this.filterByEndDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByEndDate,
        'matchFullCase': false
      }
    };
    this.filterByPricingMethodSearchObj = {
      'priceMethodMasterName': {
        'type': 'text',
        'value': this.filterByPricingMethod,
        'matchFullCase': false
      }
    };
    this.filterByDiscountCDStatusSearchObj = {
      'discountCodeStatusName': {
        'type': 'text',
        'value': this.filterByDiscountCDStatus,
        'matchFullCase': false
      }
    };
    this.filterByDateCreatedSearchObj = {
      'createdDate': {
        'type': 'text',
        'value': this.filterByDateCreated,
        'matchFullCase': false
      }
    };
    this.filterByIntakeRequestIDSearchObj = {
      'projectCode': {
        'type': 'text',
        'value': this.filterByIntakeRequestID,
        'matchFullCase': false
      }
    };
  }

  hideStatus() {
    this.submitFailed = false;
    this.exportXlFailed = false;
    this.exportXlSuccess = false;
  }

  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  peerRvwDateChanged(key, dateVal, items) {
      items[key] = dateVal;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/discount/discount-code-list']);
  }

  returnBackDiscount() {
    this.router.navigate(['/plm-work-flow/plm.cssonfigurator/discount/add-discount']);
  }

  moveToAddDiscountPage(mode, discountId) {
    sessionStorage.setItem('mode', mode);
    sessionStorage.setItem('discountId', discountId);
    sessionStorage.setItem('backURL', 'plm-work-flow/technology-systems/icoms');
    sessionStorage.setItem('isFromTechnologySystems', 'true');
    this.router.navigate(['/plm-work-flow/configurator/discount/view-discount']);
  }

}
