import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-search-project',
  templateUrl: './search-project.component.html'
})
export class ECOMSearchProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
