import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-ecom',
  templateUrl: './ecom.component.html'
})
export class EcomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
