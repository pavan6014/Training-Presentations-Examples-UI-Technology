import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-search-offer',
  templateUrl: './search-offer.component.html'
})
export class SearchOfferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
