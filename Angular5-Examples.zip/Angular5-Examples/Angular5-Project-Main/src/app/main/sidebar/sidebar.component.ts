import { Component, OnInit, AfterViewChecked, ElementRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { AuthGuardDataService } from '../../shared/guard/auth-guard-data.service';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../shared/services/app-config.service';
import { LoginServiceService } from '../../login/login-service.service';

import { ProgressBarModalComponent } from '../../../app/progressbar-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap/modal/modal.module';
import { Keepalive } from '@ng-idle/keepalive';
import { EventTargetInterruptSource, Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';

@Component({
    selector: 'plm-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css'],
    providers: [LoginServiceService]
})
export class SidebarComponent implements OnInit {

    title = 'Session Timeout Demo';
    idleState = 'NOT_STARTED';
    timedOut = false;
    lastPing?: Date = null;
    progressBarPopup: NgbModalRef;

    isActive: boolean = false;
    showMenu: string = '';
    pushRightClass: string = 'push-right';
    currentUser: any;
    selectedIndex: number;
    private show_sidebar_plmWorkFlow_requestor: boolean;
    private show_sidebar_plmWorkFlow_configurator: boolean;

    constructor(private loginService: LoginServiceService, private http: HttpClient, private router: Router, private authGuardService: AuthGuardService, private authGuardDataService: AuthGuardDataService, private appConfigService: AppConfigService, private element: ElementRef, private idle: Idle, private keepalive: Keepalive, private ngbModal: NgbModal) {
        this.currentUser = sessionStorage.getItem('userName');
        this.showHideSideBarComponents();

        // sets an idle timeout of 1 hour.
        idle.setIdle(3600);
        // sets a timeout period of 5 minutes.
        idle.setTimeout(300);
        // sets the interrupts like Keydown, scroll, mouse wheel, mouse down, and etc
        idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

        idle.onIdleEnd.subscribe(() => {
            this.idleState = 'NO_LONGER_IDLE';
            this.closeProgressForm();
        });

        idle.onTimeout.subscribe(() => {
            this.idleState = 'TIMED_OUT';
            this.timedOut = true;
            this.closeProgressForm();
            this.onLoggedout();
        });

        idle.onIdleStart.subscribe(() => {
            this.idleState = 'IDLE_START', this.openProgressForm(1);
        });

        idle.onTimeoutWarning.subscribe((countdown: any) => {
            this.idleState = 'IDLE_TIME_IN_PROGRESS';
            this.progressBarPopup.componentInstance.count = (Math.floor((countdown - 1) / 60) + 1);
            this.progressBarPopup.componentInstance.progressCount = this.reverseNumber(countdown);
            this.progressBarPopup.componentInstance.countMinutes = (Math.floor(countdown / 60));
            this.progressBarPopup.componentInstance.countSeconds = countdown % 60;
        });

        // sets the ping interval to 15 seconds
        keepalive.interval(15);
        this.reset();
    }

    ngOnInit() {
        this.currentUser = sessionStorage.getItem('userName');
        this.showHideSideBarComponents();
    }

    reverseNumber(countdown: number) {
        return (300 - (countdown - 1));
    }

    reset() {
        this.idle.watch();
        this.idleState = 'Started.';
        this.timedOut = false;
    }

    openProgressForm(count: number) {
        this.progressBarPopup = this.ngbModal.open(ProgressBarModalComponent, {
            backdrop: 'static',
            keyboard: false
        });
        this.progressBarPopup.componentInstance.count = count;
        this.progressBarPopup.result.then((result: any) => {
            if (result !== '' && 'logout' === result) {
                this.onLoggedout();
            } else {
                this.reset();
            }
        });
    }

    closeProgressForm() {
        this.progressBarPopup.close();
    }

    resetTimeOut() {
        this.idle.stop();
        // this.idle.onIdleStart.unsubscribe();
        // this.idle.onTimeoutWarning.unsubscribe();
        // this.idle.onIdleEnd.unsubscribe();
        // this.idle.onIdleEnd.unsubscribe();
    }


    showHideSideBarComponents() {
        const showHideComponentArray = [
            'sidebar_plmWorkFlow_requestor',
            'sidebar_plmWorkFlow_configurator',
            'sidebar_userAdmin',
            'sidebar_userAdmin_addUser',
            'sidebar_userAdmin_userViewModify',
            'sidebar_businessCatalog',
            'sidebar_businessCatalog_offer',
            'sidebar_businessCatalog_products',
            'sidebar_businessCatalog_discounts',
			'sidebar_businessCatalog_relevancy_rules',
            'sidebar_businessCatalog_eligiblity_rules',
            'sidebar_businessCatalog_marketing_code',
            'sidebar_businessCatalog_price_book',
            'sidebar_businessCatalog_tiers',									  
            'sidebar_plmWorkFlow_requestor',
            'sidebar_plmWorkFlow_configurator',
            'sidebar_plmWorkFlow_configurator_offers',
            'sidebar_plmWorkFlow_configurator_discounts',
            'sidebar_plmWorkFlow_distributor',
            'sidebar_plmWorkFlow_distributor_omcTestQueue',
            'sidebar_plmWorkFlow_distributor_omcProdQueue',
            'sidebar_plmWorkFlow_distributor_products',
            'sidebar_plmWorkFlow_distributor_discounts',
            'sidebar_plmWorkFlow_configurator_tecode', 
			'sidebar_plmWorkFlow_technologySystems',									
            'sidebar_plmWorkFlow_technologySystems_uatUsers',
            'sidebar_plmWorkFlow_technologySystems_icoms',
            'sidebar_plmWorkFlow_technologySystems_omc',
            'sidebar_plmWorkFlow_technologySystems_pinPoint',
            'sidebar_plmWorkFlow_technologySystems_eCOM'
        ];
        for (let i = 0; i < showHideComponentArray.length; i++) {
            this['show_' + showHideComponentArray[i]] = this.authGuardService.checkForAuthentication(showHideComponentArray[i]);
        }
        if (sessionStorage.getItem('roleName') === 'Administrator') {
            this['show_sidebar_userAdmin'] = true;
            this['show_sidebar_userAdmin_addUser'] = true;
            this['show_sidebar_userAdmin_userViewModify'] = true;
        }
    }

    select(index: number) {
        this.selectedIndex = index;
    }

    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    sidebarExpand() {
        const dom: Element = document.querySelector('body.push-right');
        dom.classList.remove('push-right');
    }

    redirectTo(url) {
        this.router.navigate([url]);
    }

    onLoggedout() {
        this.loginService.logout()
            .subscribe(
            data => {
                if (data.actionStatus === 'SUCCESS') {
                    sessionStorage.removeItem('isLoggedIn');
                    sessionStorage.removeItem('sessionKey');
                    sessionStorage.removeItem('userId');
                    sessionStorage.removeItem('roleName');
                    sessionStorage.removeItem('userName');
                    sessionStorage.removeItem('workGroups');
                    this.resetTimeOut();
                    this.router.navigate(['/login']);
                } else if (data.actionStatus === 'Fail') {
                    return false;
                }
            },
            error => {
                console.log("Error :: " + error)
            }
            );

    }

}
