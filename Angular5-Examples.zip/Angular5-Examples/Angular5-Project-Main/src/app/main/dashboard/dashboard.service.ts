import { Injectable } from '@angular/core';

import { HttpClientModule, HttpClient, HttpResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../shared/services/bread-crumb';
import { AppConfigService } from '../../shared/services/app-config.service';
import { DashboardInterface } from '../dashboard/dashboard-interface';


@Injectable()
export class DashboardService {

   constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

 

   getChartData(): Observable<any> {
    const getChartData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_DASHBOARDS_STATUS_GRAPH'];
    return this.http
      .get(getChartData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getChartData = this.appConfigService.urlConstants['PLM_DASHBOARDS_STATUS_GRAPH']
    // return this.http
    //   .get(getChartData)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }
  

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
