export interface DashboardInterface {
  Dashboard: Dashboard[];
  newOfferCreation: NewOfferCreation[];
  DashboardProjectGraphMap: DashboardProjectGraphMap[];
}

export interface Dashboard {
    newOfferCreation: NewOfferCreation[];
    statusName: string;
    statusId: number;
    counter: number;
    projectTypeName: string;
    dashboardProjectGraphMap: Map<string, DashboardProjectGraphMap[]>;
    dashboardOfferGraph: ChartData[];
    dashboardDiscountGraph: ChartData[];
}

export interface NewOfferCreation {
    statusName: string;
    statusId: number;
    counter: number;
    projectTypeName: string;
    DashboardProjectGraphMap: DashboardProjectGraphMap[];
}

export interface DashboardProjectGraphMap {
    statusName: string;
    statusId: number;
    counter: number;
    projectTypeName: string;
}

export interface ChartData {
    statusName: string;
    statusId: number;
    counter: number;
}

