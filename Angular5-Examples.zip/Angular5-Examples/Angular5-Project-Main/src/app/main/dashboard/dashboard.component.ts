import { Component, OnInit, ViewChild, ElementRef, AfterContentInit, OnDestroy } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { chart } from 'highcharts';
import { DashboardService } from '../dashboard/dashboard.service';
import { DashboardInterface, Dashboard, NewOfferCreation } from '../dashboard/dashboard-interface';

@Component({
  selector: 'plm-dashboard',
  templateUrl: './dashboard.component.html',
  animations: [routerTransition()]
})
export class DashboardComponent implements OnInit, OnDestroy {
  @ViewChild('chartTarget') chartTarget: ElementRef;
  @ViewChild('chartTarget1') chartTarget1: ElementRef;
  @ViewChild('chartTarget2') chartTarget2: ElementRef;
  @ViewChild('chartTarget3') chartTarget3: ElementRef;
  chart: Highcharts.ChartObject;
  role: string;

  private dashboardData: Dashboard;
  private statusName: string;
  private statusId: number;
  private projectTypeName: string;
  private seriesData: any;
  private barChartColumns: string[];
  private barChartCount: number;

  constructor(private dashboardService: DashboardService) {
    this.statusName = '';
    this.statusId = 0;
    this.projectTypeName = '';
    this.barChartCount = 0;
    this.barChartColumns = [];
    this.getDashBoardData();

    
    
  }

   

  ngOnInit() {
    
  }


  getDashBoardData() {
    this.dashboardService.getChartData()
      .subscribe(
      data => {
        this.dashboardData = data;
        this.seriesData = [];
        this.updateHighChartData();
      },
      error => {
        console.log("Error :: " + error)
      }
      );
  }

  


  // Create the Project Status chart
  updateHighChartData() {
    const options: Highcharts.Options = {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Intake Request Status'
      },
      xAxis: {
        categories: this.barChartColumns
      },
      yAxis: {
        title: {
          text: 'Intake Request Status'
        }
      },
      series: this.getProjectChartData()
    };

    this.chart = chart(this.chartTarget.nativeElement, options);

    // Pie Chart Offer Status
    const option: Highcharts.Options = {
      chart: {
        type: 'pie'
      },
      title: {
        text: 'Offers Status'
      },
      series: [this.getGraphData('Offers', this.dashboardData.dashboardOfferGraph)]
    };

    this.chart = chart(this.chartTarget1.nativeElement, option);

    // Pie Chart Discount Status
    const optionDiscount: Highcharts.Options = {
      chart: {
        type: 'pie'
      },
      title: {
        text: 'Discount Status'
      },
      series: [this.getGraphData('Discount', this.dashboardData.dashboardDiscountGraph)]
    };

    this.chart = chart(this.chartTarget2.nativeElement, optionDiscount);

  }

  ngOnDestroy() {
    this.chart = null;
  }

  getProjectChartData() {
    const result = [];
    this.updateBarColumnValues();
    for (const prop in this.dashboardData.dashboardProjectGraphMap) {
      if (this.dashboardData.dashboardProjectGraphMap[prop]) {
        const resultObj = this.getProjectIndiviObj(prop, this.dashboardData.dashboardProjectGraphMap[prop]);
        result.push(resultObj);
      }
    }
    return result;
  }

  
  // getProjectsName() {


  //   const projectName = [];
   
  // }

  updateBarColumnValues() {
    for (const prop in this.dashboardData.dashboardProjectGraphMap) {

      if (this.dashboardData.dashboardProjectGraphMap[prop]) {
        this.updateBarChartColumns(this.dashboardData.dashboardProjectGraphMap[prop]);
      }
    }
  }

  getProjectIndiviObj(prop, dashboardProjectGraphMap) {
   const result = {};
   const projectDetails = {};
    result['name'] = prop;
    result['data'] = [];
    for (let i=0; i<this.barChartColumns.length; i++) {
     result['data'].push(this.getDashboardProjectGraphMap(this.barChartColumns[i], dashboardProjectGraphMap));
      //projectDetails['data'].push(this.getDashboardProjectGraphMap(this.barChartColumns[i],dashboardProjectGraphMap))
    }
    return result;
  }

  updateBarChartColumns(dashboardProjectGraphMap) {
    if (dashboardProjectGraphMap.length > this.barChartCount) {
      this.barChartCount = dashboardProjectGraphMap.length;
      for (let i=0; i<dashboardProjectGraphMap.length; i++) {
        this.barChartColumns.push(dashboardProjectGraphMap[i]['statusName']);
      }
    }
  }

  getDashboardProjectGraphMap(statusName, dashboardProjectGraphMap) {
    const result = {
      'name': statusName, 
      'y': 0, 
      'drilldown': statusName
    };
    for (let i=0; i<dashboardProjectGraphMap.length; i++) {
      if (dashboardProjectGraphMap[i]['statusName'] === statusName) {
        result['y'] = dashboardProjectGraphMap[i]['counter'];
      }
    }
    return result;
  }

 getProjectName(projectTypeName, dashboardProjectGraphMap){
    const projectDetails = {};
    for(let i=0; i<dashboardProjectGraphMap.length; i++) {
      if(dashboardProjectGraphMap.draft.projectTypeName === dashboardProjectGraphMap.SubmittedforConfigurator.projectTypeName)
       projectDetails['y'] = dashboardProjectGraphMap[i]['counter'];
    }
    return projectDetails;
  }



  getGraphData(nameVal, graphData) {
    const result = {};
    result['name'] = nameVal;
    result['data'] = [];
    for (let i=0; i<graphData.length; i++) {
      const resultObj = {
        'name': graphData[i]['statusName'],
        'y': graphData[i]['counter']
      };
      result['data'].push(resultObj);
    }
    return result;
  }

}
