import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-technology-actors',
  templateUrl: './technology-actors.component.html'
})
export class TechnologyActorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
