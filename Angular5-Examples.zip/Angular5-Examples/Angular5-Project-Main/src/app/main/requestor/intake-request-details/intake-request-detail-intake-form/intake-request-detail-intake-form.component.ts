import { Component, OnInit, OnChanges, Input, SimpleChange, SimpleChanges } from '@angular/core';
import { RequestorService } from '../../services/requestor.service';
import { RequestorDataService } from '../../services/requestor-data.service';
import { IntakeRequestMasterData, FetchAllIntakeRequest, RequestorRequestInterface, RequestorResponseInterface, IntakeFormReq, IntakeRequestForm, IntakeRequestFormIntakeForm } from '../../requestor.interface';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { UtilitiesService } from '../../../../shared/services/utilities.service';
@Component({
  selector: 'plm-intake-request-detail-intake-form',
  templateUrl: './intake-request-detail-intake-form.component.html',
  styleUrls: ['./intake-request-detail-intake-form.component.css']
})
export class IntakeRequestDetailIntakeFormComponent implements OnInit, OnChanges {
  @BlockUI() blockUI: NgBlockUI;
  @Input() addEditIntakeRequestForm: IntakeRequestForm;
  @Input() addEditIntakeRequestMasterData: IntakeRequestMasterData;
  private showIntakeFormHeader: Boolean;
  private addEditMode: Boolean;
  private viewMode: Boolean;
  private discountStartMinDate: Date;
  private discountEndMinDate: Date;
  private campaignCodesToChangeDropDownList = [];
  private campaignCodesToChangeSelectedItems = [];
  private stepupDuratnIdDropDownList = [];
  private stepupDuratnIdSelectedItems = [];
  private requirePLGDropDownList = [];
  private requirePLGSelectedItems = [];
  private tierRequirementsDropDownList = [];
  private tierRequirementsSelectedItems = [];
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private discountExpireDate: any;
  private showIntakeRequestForm: Boolean;

  constructor(private requestorService: RequestorService, private requestorDataService: RequestorDataService, private utilitiesService: UtilitiesService) {
    this.addEditIntakeRequestMasterData = this.requestorDataService.addEditIntakeRequestMasterData;
    this.showIntakeFormHeader = false;
    this.addEditMode = false;
    this.viewMode = false;
    this.updatePageMode();
    this.showIntakeRequestForm = false;
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: "Select One",
      enableSearchFilter: true
    }; 
    this.multiSelectSettings = {
        singleSelection: false,
        text: "Select",
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: true,
        classes: "myclass custom-class",
        badgeShowLimit: 3,
        maxHeight: 120
    };         
  }

  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      let change = changes[propName];
      if (propName === 'addEditIntakeRequestForm') {
          this.addEditIntakeRequestForm =  (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      }  else if (propName === 'addEditIntakeRequestMasterData') {
        this.addEditIntakeRequestMasterData = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      }
    }
    if (typeof this.addEditIntakeRequestMasterData.intakeFormMasterDropDown !== 'undefined') {
      this.updateDropDownList();
      if ((typeof this.addEditIntakeRequestForm !== 'undefined') && (this.addEditIntakeRequestForm.projectMasterModel !== null)) {
        this.updateSelectedItems();
         this.intializeProjectDate();
      }
    }
    this.blockUI.stop();
  }

  getAddEditIntakeRequestMasterDataObj() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.requestorDataService.addEditIntakeRequestMasterData = data;
        this.updateDropDownList();
        this.intializeProjectDate();
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  updateDropDownList() {
    this.campaignCodesToChangeDropDownList = this.getCampaignCodesForChangeDropDownList(this.addEditIntakeRequestMasterData);
    this.stepupDuratnIdDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'STEPUP_DURATION');
     this.stepupDuratnIdDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.requirePLGDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'REQUIRE_PLG');
      this.requirePLGDropDownList.unshift({
            'id':  '',
            'name':  'Select One'
        });
    this.tierRequirementsDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'TIER_REQUIREMENTS');
     this.showIntakeRequestForm = true;
  }

  updateSelectedItems(){
    this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.instltnIncFlgVal = ( this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.instltnIncFlg ) ? true : false;
    this.campaignCodesToChangeSelectedItems = this.getCampaignCodesListSelectedItemsObject(this.addEditIntakeRequestMasterData, this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.campCodeIds);
    this.stepupDuratnIdSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'STEPUP_DURATION', this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.stepupDuratnId);
    this.requirePLGSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'REQUIRE_PLG', this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.requirePlgId);
    this.tierRequirementsSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'TIER_REQUIREMENTS', this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.tireqIds);
  }

  getCampaignCodesForChangeDropDownList(masterData) {
    let result = [];
    for (let i = 0; i < masterData.campaignCodesList.length; i++) {
      result.push({
        "id": masterData.campaignCodesList[i]['key'],
        "name": masterData.campaignCodesList[i]['value']
      });
    }
    return result;
  }

  
  getDropDownListNgSelect(masterData, dropDownKey) {
    let result = [];
    if (!masterData.intakeFormMasterDropDown[dropDownKey]) {
      return result;
    }
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      result.push({
        "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
        "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
      });
    }
    return result;
  }
  
  getSelectedItemsObjectNgSelect(masterData, dropDownKey, dropDownList) {
    let result: any = [];
    if ((!masterData.intakeFormMasterDropDown[dropDownKey]) || (!dropDownList)) {
      return result;
    }
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId']) > -1)) {
        result.push({
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        });
      } else if (masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'] == dropDownList) {
        result = {};
        result = {
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        };
      }
    }
    return result;
  }

  getCampaignCodesListSelectedItemsObject(masterData, dropDownListVal) {
    let result:any = [], dropDownList = [];
    for (let j=0; j<dropDownListVal.length; j++) {
      dropDownList.push(dropDownListVal[j].toString());
    }
    for (let i = 0; i < masterData.campaignCodesList.length; i++) {
      if((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.campaignCodesList[i]['key']) > -1)){
        result.push({
          "id": masterData.campaignCodesList[i]['key'],
          "name": masterData.campaignCodesList[i]['value']
        });
      } else if (masterData.campaignCodesList[i]['key'] == dropDownList) {
        result = {};
        result = {
          "id": masterData.campaignCodesList[i]['key'],
          "name": masterData.campaignCodesList[i]['value']
        };
      }
    }
    return result;
  }

  updatePageMode(){
    if ((this.requestorDataService.addEditViewIntakeRequestMode == 'add') || ((this.requestorDataService.addEditViewIntakeRequestMode == 'edit'))) {
      this.addEditMode = true;
      this.viewMode = false;
      this.showIntakeFormHeader = (this.requestorDataService.addEditViewIntakeRequestMode == 'edit') ? true : false;
    } else if (this.requestorDataService.addEditViewIntakeRequestMode == 'view') {
      this.addEditMode = false;
      this.viewMode = true;
    }
  }

  intializeProjectDate() {
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    this.discountStartMinDate = new Date(todayYear, todayMonth, todayDate);
    this.discountEndMinDate = new Date(todayYear, todayMonth, todayDate);
  }

   startDateChanged(discountStartDate) {
    const startDateObj = new Date(discountStartDate);
    const endMinDate = Number(startDateObj.getDate());
    const endMinMonth = startDateObj.getMonth();
    const endMinYear = startDateObj.getFullYear();
    this.discountEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
    this.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel.discountExpireDate = '';
    this.updateSubmitData('discountStartDate', discountStartDate);
  }

  onCampaignCodesToChangeItemSelect(item: any) {
      this.updateSubmitData('campCodeIds', this.utilitiesService.getMultiSelectID(item));
  }
  
  onCampaignCodesToChangeItemDeSelect(item: any) {
      this.updateSubmitData('campCodeIds', this.requestorService.getMultiSelectID(this.campaignCodesToChangeSelectedItems));
  }

  onstepupDuratnIdItemSelect(item: any) {
      this.updateSubmitData('stepupDuratnId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }
  
  onstepupDuratnIdItemDeSelect(item: any) {
      this.updateSubmitData('stepupDuratnId', this.requestorService.getSingleSelectID(this.stepupDuratnIdSelectedItems));
  }

  onRequirePLGItemSelect(item: any) {
      this.updateSubmitData('requirePlgId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }
  
  onRequirePLGItemDeSelect(item: any) {
      this.updateSubmitData('requirePlgId', this.requestorService.getSingleSelectID(this.requirePLGSelectedItems));
  }

  onTierRequirementsItemSelect(item: any) {
    this.updateSubmitData('tireqIds', this.utilitiesService.getMultiSelectID(item));
  }
  
  onTierRequirementsItemDeSelect(item: any) {
    this.updateSubmitData('tireqIds', this.requestorService.getMultiSelectID(this.tierRequirementsSelectedItems));
  }

  onSelectAll(items: any, key: string) {
    this.updateSubmitData(key, this.requestorService.getMultiSelectID(items));
  }
  onDeSelectAll(items: any, key: string) {
    this.updateSubmitData(key, this.requestorService.getMultiSelectID(items));
  }
  
  updateSubmitData(field, value) {
    this.requestorDataService.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel[field] = value;
    this.requestorDataService.isAddEditIntakeRequestFormModified = true;
  }
  

  updateInstallationIncludedSubmitData(field, tempField, value) {
    this.requestorDataService.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel[field] = value;
    this.requestorDataService.addEditIntakeRequestForm.projectMasterModel.intakeFormReqTxnDetModel[field] = (value);
    this.requestorDataService.isAddEditIntakeRequestFormModified = true;
  }

  isInstallationIncludedTrue(data) {
    if (data) {
      return true;
    } else {
      return false;
    }
  }

}
