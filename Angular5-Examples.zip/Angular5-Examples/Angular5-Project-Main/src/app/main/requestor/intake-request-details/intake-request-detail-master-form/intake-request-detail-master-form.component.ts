import 'rxjs/Rx';

import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange, SimpleChanges, Inject } from '@angular/core';
import { FetchAllIntakeRequest, IntakeFormReq, IntakeRequestForm, IntakeRequestFormIntakeForm, IntakeRequestMasterData, RequestorRequestInterface, RequestorResponseInterface } from '../../../requestor/requestor.interface';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppConfigService } from '../../../../shared/services/app-config.service';
import { RequestorDataService } from '../../services/requestor-data.service';
import { RequestorService } from '../../services/requestor.service';
import { UtilitiesService } from '../../../../shared/services/utilities.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'plm-intake-request-detail-master-form',
  templateUrl: './intake-request-detail-master-form.component.html',
  styleUrls: ['./intake-request-detail-master-form.component.css']
})
export class IntakeRequestDetailMasterFormComponent implements OnInit, OnChanges {

  @Input() addEditIntakeRequestForm: IntakeRequestForm;

  @Input() addEditIntakeRequestMasterData: IntakeRequestMasterData;
  @Output() fileUpload: EventEmitter<any> = new EventEmitter<any>();
  @BlockUI() blockUI: NgBlockUI;
  private formDataLoaded: Boolean;
  private isAllSitesSelected: Boolean;
  private sitesSelected: Boolean;
  private selectSite: Object;
  private selectedAll: Boolean;
  private sites: number[];
  private projectStartMinDate: Date;
  private projectEndMinDate: Date;
  private addEditMode: Boolean;
  private MoreInfo: Boolean;
  private showDownloadUrl: Boolean;
  private showUploadFile: Boolean;
  private isTECodeIntakeRequest: Boolean;
  private viewMode: Boolean;
  private fileToUpload: File = null;
  private intakeRequestStatusIdDropDownList = [];
  private intakeRequestStatusIdSelectedItems = [];
  private intakeRequestTypeDropDownList = [];
  private intakeRequestTypeSelectedItems = [];
  private pricingOwnerIdDropDownList = [];
  private pricingOwnerIdSelectedItems = [];
  private trgtAudienceIdDropDownList = [];
  private trgtAudienceIdSelectedItems = [];
  private channelIdsDropDownList = [];
  private channelIdsSelectedItems = [];
  private categoryIdDropDownList = [];
  private categoryIdSelectedItems = [];
  private productIdsDropDownList = [];
  private productIdsSelectedItems = [];
  private teCodeTypeDropDownList = [];
  private teCodeTypeSelectedItems = [];
  private priorityIdDropDownList = [];
  private priorityIdSelectedItems = [];
  private singleSelectSettings = {};
  private multiSelectSettings = {};
  private noIntakeRequestType: Boolean;
  private showIntakeRequestForm: Boolean;
  private downloadFileUrl: string;
  private fileSizeExceeded: Boolean;
  private addEditIntakeRequestProjectID: string;

  private PopUPNotesData = [];

  constructor(private requestorService: RequestorService, private requestorDataService: RequestorDataService, private appConfigService: AppConfigService, private utilitiesService: UtilitiesService, private router: Router, public dialog: MatDialog) {
    this.formDataLoaded = false;
    this.addEditMode = false;
    this.showDownloadUrl = false;
    this.showUploadFile = false;
    this.viewMode = false;
    this.MoreInfo = false;
    this.isAllSitesSelected = false;
    this.sitesSelected = true;
    this.selectSite = {};
    this.selectedAll = false;
    this.showIntakeRequestForm = false;
    this.downloadFileUrl = '';
    this.fileSizeExceeded = false;
    this.isTECodeIntakeRequest = false;
    this.addEditIntakeRequestProjectID = this.requestorDataService.addEditViewIntakeRequestID;
  }

  ngOnInit() {
    this.singleSelectSettings = {
      singleSelection: true,
      text: "Select One",
      enableSearchFilter: true
    };
    this.multiSelectSettings = {
      singleSelection: false,
      text: "Select",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "myclass custom-class",
      badgeShowLimit: 3,
      maxHeight: 120
    };
  }


  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      let change = changes[propName];
      if (propName === 'addEditIntakeRequestForm') {
        this.addEditIntakeRequestForm = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      } else if (propName === 'addEditIntakeRequestMasterData') {
        this.addEditIntakeRequestMasterData = (typeof change.currentValue != 'undefined') ? (JSON.parse(JSON.stringify(change.currentValue))) : {};
      }
    }
    if (typeof this.addEditIntakeRequestMasterData.intakeFormMasterDropDown !== 'undefined') {
      this.updateDropDownList();
      this.checkIsFormDataLoaded();
      this.updatePageMode();
      this.intializeProjectDate();
      this.initializeSelectedItems();
      for (let i = 0; i < this.addEditIntakeRequestForm.projectMasterModel.sites.length; i++) {
        const currentSite = this.addEditIntakeRequestForm.projectMasterModel.sites[i];
        this.selectSite[currentSite] = this.isSitesExist(currentSite);
      }
    }
  }


  getAddEditIntakeRequestMasterData() {
    this.requestorService.getCreateUpdateIntakeRequestFormData().subscribe(
      data => {
        this.addEditIntakeRequestMasterData = data;
        this.updateDropDownList();
        this.checkIsFormDataLoaded();
        this.updatePageMode();
        this.intializeProjectDate();
        if ((typeof this.addEditIntakeRequestMasterData !== 'undefined') && (typeof this.requestorDataService.addEditViewIntakeRequestMode !== 'undefined') && (this.requestorDataService.addEditViewIntakeRequestMode !== 'add')) {
          this.initializeSelectedItems();
        }
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }

  getFileDownload() {
    this.requestorService.getDownLoad(this.addEditIntakeRequestForm.projectMasterModel.projectCode, this.addEditIntakeRequestForm.projectMasterModel.uploadIntakeRequestDocId)
      .subscribe(
      data => this.utilitiesService.downloadFile(data, this.addEditIntakeRequestForm.projectMasterModel.uploadIntakeRequestDocName),
      error => {
        console.log('Error :: ' + error);
      }
      );
  }

  updateDropDownList() {
    this.intakeRequestTypeDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_REQUEST_TYPE');
    this.intakeRequestTypeDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    this.pricingOwnerIdDropDownList = this.getPricingOwnerDropDownList(this.addEditIntakeRequestMasterData);
    this.intakeRequestStatusIdDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_REQUEST_STATUS');
    this.trgtAudienceIdDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'TARGET_AUDIENCE');
    this.trgtAudienceIdDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    this.channelIdsDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'CHANNELS');
    this.categoryIdDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_CATEGORY');
    this.categoryIdDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    this.productIdsDropDownList = this.getproductIdsDropDownList(this.addEditIntakeRequestMasterData);
    this.priorityIdDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_PRIORITY');
    this.priorityIdDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    this.teCodeTypeDropDownList = this.getDropDownListNgSelect(this.addEditIntakeRequestMasterData, 'TE_CODE');
    this.teCodeTypeDropDownList.unshift({
      'id': '',
      'name': 'Select One'
    });
    this.showIntakeRequestForm = true;
    if ((typeof this.addEditIntakeRequestMasterData !== 'undefined') && (typeof this.addEditIntakeRequestForm !== 'undefined') && (typeof this.requestorDataService.addEditViewIntakeRequestMode !== 'undefined') && (this.addEditIntakeRequestForm.projectMasterModel !== null)) {
      this.initializeSelectedItems();
    }
  }

  initializeSelectedItems() {
    this.intakeRequestTypeSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_REQUEST_TYPE', this.addEditIntakeRequestForm.projectMasterModel.projectTypeId);
    this.pricingOwnerIdSelectedItems = this.getPricingOwnerSelectedItemsObject(this.addEditIntakeRequestMasterData, this.addEditIntakeRequestForm.projectMasterModel.pricingOwnerId);
    this.intakeRequestStatusIdSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_REQUEST_STATUS', this.addEditIntakeRequestForm.projectMasterModel.intakeRequestStatusId);
    this.trgtAudienceIdSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'TARGET_AUDIENCE', this.addEditIntakeRequestForm.projectMasterModel.trgtAudienceId);
    this.channelIdsSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'CHANNELS', this.addEditIntakeRequestForm.projectMasterModel.channelIds);
    this.categoryIdSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_CATEGORY', this.addEditIntakeRequestForm.projectMasterModel.categoryId);
    this.productIdsSelectedItems = this.getproductIdsSelectedItemsObject(this.addEditIntakeRequestMasterData, this.addEditIntakeRequestForm.projectMasterModel.productIds);
    this.priorityIdSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'INTAKE_PRIORITY', this.addEditIntakeRequestForm.projectMasterModel.priorityId);
    this.teCodeTypeSelectedItems = this.getSelectedItemsObjectNgSelect(this.addEditIntakeRequestMasterData, 'TE_CODE', this.addEditIntakeRequestForm.projectMasterModel.teCodeTypeId);
    this.onIntakeRequestTypeItemSelect(this.intakeRequestTypeSelectedItems);
  }

  checkForIntakeRequestType() {
    if (!this.addEditIntakeRequestForm.projectMasterModel.projectTypeId) {
      this.noIntakeRequestType = true;
    } else {
      this.noIntakeRequestType = false;
    }
  }

  getDropDownListNgSelect(masterData, dropDownKey) {
    let result = [];
    if (!masterData.intakeFormMasterDropDown[dropDownKey]) {
      return result;
    }
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      result.push({
        "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
        "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
      });
    }
    return result;
  }

  getPricingOwnerDropDownList(masterData) {
    let result = [];
    if (!masterData['pricingOwners']) {
      return result;
    }
    for (let i = 0; i < masterData.pricingOwners.length; i++) {
      result.push({
        "id": masterData.pricingOwners[i]['userId'],
        "name": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
      });
    }
    return result;
  }

  getproductIdsDropDownList(masterData) {
    let result = [];
    if (!masterData['products']) {
      return result;
    }
    for (let i = 0; i < masterData.products.length; i++) {
      result.push({
        "id": masterData.products[i]['psuTypeId'],
        "name": masterData.products[i]['psuName']
      });
    }
    return result;
  }

  getSelectedItemsObjectNgSelect(masterData, dropDownKey, dropDownList) {
    let result: any = [];
    if ((!masterData.intakeFormMasterDropDown[dropDownKey]) || (!dropDownList)) {
      return result;
    }
    for (let i = 0; i < masterData.intakeFormMasterDropDown[dropDownKey].length; i++) {
      if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId']) > -1)) {
        result.push({
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        });
      } else if (masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'] == dropDownList) {
        result = {};
        result = {
          "id": masterData.intakeFormMasterDropDown[dropDownKey][i]['intakeFormDrpdwnDetailId'],
          "name": masterData.intakeFormMasterDropDown[dropDownKey][i]['objectName']
        };
      }
    }
    return result;
  }

  getproductIdsSelectedItemsObject(masterData, dropDownListVal) {
    let result: any = []; const dropDownList = [];
    if ((!masterData['products']) || (!dropDownListVal)) {
      return result;
    }
    for (let j = 0; j < dropDownListVal.length; j++) {
      dropDownList.push(dropDownListVal[j].toString());
    }
    for (let i = 0; i < masterData.products.length; i++) {
      if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.products[i]['psuTypeId']) > -1)) {
        result.push({
          "id": masterData.products[i]['psuTypeId'],
          "name": masterData.products[i]['psuName']
        });
      } else if (masterData.products[i]['psuTypeId'] == dropDownList) {
        result = {};
        result = {
          "id": masterData.products[i]['psuTypeId'],
          "name": masterData.products[i]['psuName']
        };
      }
    }
    return result;
  }

  getPricingOwnerSelectedItemsObject(masterData, dropDownList) {
    let result: any = [];
    if ((!masterData['pricingOwners']) || (!dropDownList)) {
      return result;
    }
    for (let i = 0; i < masterData.pricingOwners.length; i++) {
      if ((dropDownList instanceof Array) && (dropDownList.indexOf(masterData.pricingOwners[i]['userId']) > -1)) {
        result.push({
          "id": masterData.pricingOwners[i]['userId'],
          "name": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
        });
      } else if (masterData.pricingOwners[i]['userId'] == dropDownList) {
        result = {};
        result = {
          "id": masterData.pricingOwners[i]['userId'],
          "name": masterData.pricingOwners[i]['firstname'] + ' ' + masterData.pricingOwners[i]['lastname']
        };
      }
    }
    return result;
  }

  checkIsFormDataLoaded() {
    if (typeof this.addEditIntakeRequestMasterData != 'undefined') {
      this.formDataLoaded = true;
    } else {
      this.formDataLoaded = false;
    }
  }

  updatePageMode() {
    if ((this.requestorDataService.addEditViewIntakeRequestMode == 'add') || ((this.requestorDataService.addEditViewIntakeRequestMode == 'edit'))) {
      this.addEditMode = true;
      this.showUploadFile = true;
      this.showDownloadUrl = (this.requestorDataService.addEditViewIntakeRequestMode == 'add') ? false : true;
      this.MoreInfo = (this.requestorDataService.addEditViewIntakeRequestMode == 'add') ? false : true;
      this.viewMode = false;
    }
    else if (this.requestorDataService.addEditViewIntakeRequestMode == 'view') {
      this.addEditMode = false;
      this.showUploadFile = false;
      this.showDownloadUrl = true;
      this.viewMode = true;
      this.MoreInfo = true;
    }

  }

  intializeProjectDate() {
    const today = new Date();
    const todayDate = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    this.projectStartMinDate = new Date(todayYear, todayMonth, todayDate);
    this.projectEndMinDate = new Date(todayYear, todayMonth, todayDate);
  }

  startDateChanged(startDate) {
    const startDateObj = new Date(startDate);
    const endMinDate = Number(startDateObj.getDate());
    const endMinMonth = startDateObj.getMonth();
    const endMinYear = startDateObj.getFullYear();
    this.projectEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
    this.addEditIntakeRequestForm.projectMasterModel.projectEndDt = '';
    this.updateSubmitData('projectStartDt', startDate);
  }


  selectAllSites(selectedAll) {
    if (selectedAll) {
      this.addEditIntakeRequestForm.projectMasterModel.sites = [];
      for (let i = 0; i < this.addEditIntakeRequestMasterData.MARKETS.length; i++) {
        this.addEditIntakeRequestForm.projectMasterModel.sites.push(Number(this.addEditIntakeRequestMasterData.MARKETS[i]['siteId']));
      }
      this.selectedAll = true;
    } else {
      this.addEditIntakeRequestForm.projectMasterModel.sites = [];
      this.selectedAll = false;
    }
    this.isAllSitesSelectedCheck();
    this.updateSubmitData('sites', this.addEditIntakeRequestForm.projectMasterModel.sites);
  }

  isAllSitesSelectedCheck() {
    const marketSitesLength = Object.keys(this.addEditIntakeRequestMasterData.MARKETS).length;
    if (this.addEditIntakeRequestForm.projectMasterModel.sites.length === marketSitesLength) {
      this.selectedAll = true;
      return true;
    } else {
      this.selectedAll = false;
      return false;
    }
  }



  isSitesExist(site) {
    let result = false;
    for (let i = 0; i < this.addEditIntakeRequestForm.projectMasterModel.sites.length; i++) {
      if (Number(this.addEditIntakeRequestForm.projectMasterModel.sites[i]) == parseInt(site)) {
        result = true;
        break;
      }
    }
    this.selectSite[parseInt(site)] = result;
    this.selectSite[site] = result;
    return result;
  }

  selectAll(selectedAll) {
    if (selectedAll) {
      let sitesList = Object.keys(this.addEditIntakeRequestMasterData.mapMarketList);
      this.addEditIntakeRequestForm.projectMasterModel.sites = [];
      for (let i = 0; i < sitesList.length; i++) {
        this.addEditIntakeRequestForm.projectMasterModel.sites.push(Number(sitesList[i]));
      }
      this.isAllSitesSelected = true;
    } else {
      this.addEditIntakeRequestForm.projectMasterModel.sites = [];
      this.isAllSitesSelected = false;
    }
    this.sites = this.addEditIntakeRequestForm.projectMasterModel.sites;
    this.validateIsSitesSelected();
    this.updateSubmitData('sites', this.sites);
  }

  validateIsSitesSelected() {
    if (this.addEditIntakeRequestForm.projectMasterModel.sites.length > 0) {
      this.sitesSelected = true;
    } else {
      this.sitesSelected = false;
    }
  }

  addSite(selectSite, siteValue) {
    if (selectSite) {
      this.addEditIntakeRequestForm.projectMasterModel.sites.push(parseInt(siteValue));
      this.sites = this.addEditIntakeRequestForm.projectMasterModel.sites;
    } else {
      const sitesVal = JSON.parse(JSON.stringify(this.addEditIntakeRequestForm.projectMasterModel.sites));
      if (sitesVal.indexOf(Number(siteValue)) > -1) {
        sitesVal.splice(sitesVal.indexOf(Number(siteValue)), 1);
      }
      this.addEditIntakeRequestForm.projectMasterModel.sites = sitesVal;
      this.sites = sitesVal;
    }
    this.validateIsSitesSelected();
    this.isAllSitesSelectedCheck();
    this.updateSubmitData('sites', this.sites);
  }

  handleFileInput(files: FileList, event: any) {
    this.fileSizeExceeded = false;
    this.fileToUpload = files.item(0);
    const fileSizeInMB = (this.fileToUpload.size / (1024 * 1024)).toFixed(2);
    if (parseFloat(fileSizeInMB) > parseFloat(Number(20).toFixed(2))) {
      event.target.value = null;
      this.fileSizeExceeded = true;
      return false;
    }
    this.updateSubmitData('uploadIntakeRequestDoc', JSON.stringify(this.fileToUpload));
    this.fileUpload.emit(this.fileToUpload);
  }

  updateSubmitData(field, value) {
    this.requestorDataService.addEditIntakeRequestForm.projectMasterModel[field] = value;
    this.requestorDataService.isAddEditIntakeRequestFormModified = true;
    this.checkForIntakeRequestType();
  }

  downloadDECFile() {
    window.open('C:/Users/tkannan/eclipse-workspace/PLM_Docs/Requester_configrator_changesv0.5.pptx');
  }

  onIntakeRequestTypeItemSelect(item: any) {
    if (item.name === 'New TE Code Creation') {
      this.isTECodeIntakeRequest = true;
    } else {
      this.isTECodeIntakeRequest = false;
    }
    this.updateSubmitData('projectTypeId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }

  onIntakeRequestTypeItemDeSelect(item: any) {
    this.updateSubmitData('projectTypeId', this.requestorService.getSingleSelectID(this.intakeRequestTypeSelectedItems));
  }

  onpricingOwnerIdItemSelect(item: any) {
    this.updateSubmitData('pricingOwnerId', this.utilitiesService.getMultiSelectID(item));
  }

  onpricingOwnerIdItemDeSelect(item: any) {
    this.updateSubmitData('pricingOwnerId', this.requestorService.getMultiSelectID(this.pricingOwnerIdSelectedItems));
  }

  onintakeRequestStatusIdItemSelect(item: any) {
    this.updateSubmitData('intakeRequestStatusId', this.requestorService.getSingleSelectID(this.intakeRequestStatusIdSelectedItems));
  }

  onintakeRequestStatusIdItemDeSelect(item: any) {
    this.updateSubmitData('intakeRequestStatusId', this.requestorService.getSingleSelectID(this.intakeRequestStatusIdSelectedItems));
  }

  ontrgtAudienceIdItemSelect(item: any) {
    this.updateSubmitData('trgtAudienceId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }

  ontrgtAudienceIdItemDeSelect(item: any) {
    this.updateSubmitData('trgtAudienceId', this.requestorService.getSingleSelectID(this.trgtAudienceIdSelectedItems));
  }

  onchannelIdsItemSelect(item: any) {
    this.updateSubmitData('channelIds', this.utilitiesService.getMultiSelectID(item));
  }

  onchannelIdsItemDeSelect(item: any) {
    this.updateSubmitData('channelIds', this.requestorService.getMultiSelectID(this.channelIdsSelectedItems));
  }

  onCategoryIdItemDeSelect(item: any) {
    this.updateSubmitData('categoryId', this.requestorService.getSingleSelectID(this.categoryIdSelectedItems));
  }

  onCategoryIdItemSelect(item: any) {
    this.updateSubmitData('categoryId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }

  onproductIdsItemSelect(item: any) {
    this.updateSubmitData('productIds', this.utilitiesService.getMultiSelectID(item));
  }

  onTECodeTypeItemSelect(item: any) {
    this.updateSubmitData('teCodeTypeId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }

  onproductIdsItemDeSelect(item: any) {
    this.updateSubmitData('productIds', this.requestorService.getMultiSelectID(this.productIdsSelectedItems));
  }

  onpriorityIdItemSelect(item: any) {
    this.updateSubmitData('priorityId', this.utilitiesService.getSingleSelectIDNgSelect(item));
  }

  onpriorityIdItemDeSelect(item: any) {
    this.updateSubmitData('priorityId', this.requestorService.getSingleSelectID(this.priorityIdSelectedItems));
  }

  onSelectAll(items: any, key: string) {
    this.updateSubmitData(key, this.requestorService.getMultiSelectID(items));
  }

  onDeSelectAll(items: any, key: string) {
    this.updateSubmitData(key, this.requestorService.getMultiSelectID(items));
  }



  convertArrayElementsToString(arrayEl) {
    let result = [];
    for (let i = 0; i < arrayEl.length; i++) {
      result.push(arrayEl[i].toString());
    }
    return result;
  }


  popsnotes() {
    this.requestorDataService.popsNotes = '';
    this.blockUI.start('Loading Detail...');
    this.requestorService.getPopNotesData(this.addEditIntakeRequestProjectID).subscribe(
      data => {
        this.PopUPNotesData = data.offerPopsNoteslist;
        this.requestorDataService.popsNotes = this.PopUPNotesData;
        this.openPopNotes();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );

  }

  openPopNotes(): void {
    let dialogRef = this.dialog.open(InteqRequestPopNotes, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }

}


@Component({
  selector: 'plm-inteq-request-pop-notes',
  templateUrl: './inteq-request-pop-notes.html'
})
export class InteqRequestPopNotes implements OnInit, OnChanges {


  private showPopsNotes: boolean;
  private popUPNotesData: any;
  constructor(
    public dialogRef: MatDialogRef<InteqRequestPopNotes>,
    private router: Router,
    private requestorDataService: RequestorDataService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
    this.showPopsNotes = false;
    this.popUPNotesData = this.requestorDataService.popsNotes;
    if (this.popUPNotesData.length > 0) {
      this.showPopsNotes = true;
    }
  }

  ngOnInit() { }
  ngOnChanges() { }
  onNoClick(): void {
    this.dialogRef.close();
  }


  reloadPage() {
    this.dialogRef.close();
  }
}

