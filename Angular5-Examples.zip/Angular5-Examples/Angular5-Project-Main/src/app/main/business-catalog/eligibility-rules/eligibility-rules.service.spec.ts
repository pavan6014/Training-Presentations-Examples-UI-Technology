import { TestBed, inject } from '@angular/core/testing';

import { EligibilityRulesService } from './eligibility-rules.service';

describe('EligibilityRulesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EligibilityRulesService]
    });
  });

  it('should be created', inject([EligibilityRulesService], (service: EligibilityRulesService) => {
    expect(service).toBeTruthy();
  }));
});
