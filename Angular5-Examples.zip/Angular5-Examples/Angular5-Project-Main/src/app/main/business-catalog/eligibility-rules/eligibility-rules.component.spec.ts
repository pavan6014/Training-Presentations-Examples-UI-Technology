import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityRulesComponent } from './eligibility-rules.component';

describe('EligibilityRulesComponent', () => {
  let component: EligibilityRulesComponent;
  let fixture: ComponentFixture<EligibilityRulesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EligibilityRulesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EligibilityRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
