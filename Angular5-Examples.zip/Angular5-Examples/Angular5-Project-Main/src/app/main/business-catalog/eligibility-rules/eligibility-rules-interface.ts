export interface EligibilityRulesInterface {
    relevancySearchList: EligibilitySearchList[];
}


export interface EligibilitySearchList {
    eligiId: number;
    rule: string;
    description: string;
    ruleSyntax: string;
}

