import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { EligibilityRulesInterface, EligibilitySearchList } from '../eligibility-rules/eligibility-rules-interface';
import { EligibilityRulesService } from '../eligibility-rules/eligibility-rules.service';

@Component({
  selector: 'plm-eligibility-rules',
  templateUrl: './eligibility-rules.component.html',
  styleUrls: ['./eligibility-rules.component.css']
})
export class EligibilityRulesComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private eligibilityList: EligibilitySearchList[];
  private filterByrule: string;
  private filterBydescription: string;
  private filterByruleSyntax: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private searchEligibility: string;



  private filterByruleSearchObj: any;
  private filterBydescriptionSearchObj: any;
  private filterByruleSyntaxSearchObj: any;

   private searchEligibilityRulesList: any;


  constructor(
    private router: Router, 
    private eligibilityRulesService: EligibilityRulesService
  ) {
    this.searchEligibility = '';
    this.resetEligibilitySearchData();
    this.getEligibilityRulesData();

    this.filterByrule= '';
    this.filterBydescription= '';
    this.filterByruleSyntax= '';

    this.filterByruleSearchObj= '';
    this.filterBydescriptionSearchObj= '';
    this.filterByruleSyntaxSearchObj= '';
    this.searchEligibilityRulesList = {};
  }

  ngOnInit() {
  }

  resetEligibilitySearchData() {
    this.eligibilityList = [];
  }

  getEligibilityRulesData() {
    this.blockUI.start('Loading Eligiblity Rules...');
    this.eligibilityRulesService.getEligibilityRules().subscribe(
      data => {
        this.eligibilityList = data.eligibilitySearchList;
        this.initializeFilterContext();
        this.updateSearchEligibilityList();
        this.searchEligibilityRulesList = this.eligibilityList;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


updateSearchEligibilityList() {
    for (let i = 0; i < this.eligibilityList.length; i++) {
      this.eligibilityList[i]['searchString'] = this.getEligibiltyListConctString(this.eligibilityList[i]);
    }
  }

  getEligibiltyListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }


   getSearchEligibilitySearchDetails() {
    const searchString = this.searchEligibility;
    this.searchEligibilityRulesList = [];
    for (let i = 0; i < this.eligibilityList.length; i++) {
      const searchStringVal = this.eligibilityList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchEligibilityRulesList.push(this.eligibilityList[i]);
      }
    }
  }

  initializeFilterContext() {
    this.filterByruleSearchObj = {
      'rule': {
        'type': 'text',
        'value': this.filterByrule,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterBydescription,
        'matchFullCase': false
      }
    };
    this.filterByruleSyntaxSearchObj = {
      'ruleSyntax': {
        'type': 'text',
        'value': this.filterByruleSyntax,
        'matchFullCase': false
      }
    }; 
 }

 updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

redirectTo(url) {
    this.router.navigate([url]);
  }

  returnBack(){
    this.router.navigate(['']);
  }

sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }
  
}
