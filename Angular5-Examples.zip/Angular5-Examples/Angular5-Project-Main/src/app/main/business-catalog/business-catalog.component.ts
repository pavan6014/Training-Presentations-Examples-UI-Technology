import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-business-catalog',
  templateUrl: './business-catalog.component.html',
  styleUrls: ['./business-catalog.component.css']
})
export class BusinessCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
