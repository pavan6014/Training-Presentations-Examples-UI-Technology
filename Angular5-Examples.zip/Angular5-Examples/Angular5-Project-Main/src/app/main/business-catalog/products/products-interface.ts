export interface ProductsInterface {
    ProductID: string;
    ProductName: string;
    ProductDescription: string;
    ProductCategory: string;
    ProductPSU: string
    ProductTIER: string;
    ProductType: string;
    ProductICOMSCD: string;
    ProductServiceCodeCategory: string;
    ProductstartDt: string;
    ProductExpirationDate: string;
    products:any;
}
