import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { BusinessCatalogDataService } from '../../business-catalog-data.service';
import { ProductsService } from '../products.service';

@Component({
  selector: 'plm-products-view',
  templateUrl: './products-view.component.html',
  styleUrls: ['./products-view.component.css'],
  providers: [ProductsService]
})
export class ProductsViewComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private productId: number;
  private productDetails: any;
  private productChildrens: any[];

  constructor(
    private productsService: ProductsService, 
    private businessCatalogDataService: BusinessCatalogDataService,
    private router: Router 
  ) {
    this.productId = this.businessCatalogDataService.productId;
    this.productChildrens = [];
    this.productDetails = {};
    this.getProductDetails();
  }

  ngOnInit() {
  }

  getProductDetails() {
    this.blockUI.start('Loading Products...');
    this.productsService.getProductDetails(this.productId).subscribe(
      data => {
        this.productDetails = data.productSearchList[0];
        for(let i=1; i<data.productSearchList.length; i++) {
          this.productChildrens.push(data.productSearchList[i]);
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }
  returnBack() {
    this.router.navigate(['business-catalog/products']);
  }

}
