import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { ProductsInterface } from './products-interface';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';

@Injectable()
export class ProductsService {

  public constructor(
    private http: HttpClient,
    private appConfigService: AppConfigService
  ) { }
  
  getBuProductsData(): Observable<any> {
    const searchProductsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRODUCTS'];
    // const reqObj = {
    //   'searchKey' : searchProducts
    // };
    return this.http
      .get(searchProductsURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const searchProductUrl = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRODUCTS']
    // return this.http
    //   .get(searchProductUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }

  getProductDetails(productID): Observable<any> {
    const getProductDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRODUCT_DETAIL'] + '/' +productID;
    // const getProductDetailsURL = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRODUCT_DETAIL'];
    return this.http
      .get(getProductDetailsURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
