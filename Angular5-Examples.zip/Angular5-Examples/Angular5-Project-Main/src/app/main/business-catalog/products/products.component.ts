import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { ProductsInterface } from './products-interface';
import { ProductsService } from './products.service';
import { BusinessCatalogDataService } from '../business-catalog-data.service';

import { Serializer } from '@angular/compiler';


@Component({
  selector: 'plm-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private productsList: any[];

  private filterByProductID: string;
  private filterByProductName: string;
  private filterByProductDescription: string;
  private filterByProductCategory: string;
  private filterByProductPSU: string
  private filterByProductTIER: string;
  private filterByProductType: string;
  private filterByProductICOMSCD: string;
  private filterByProductServiceCodeCategory: string;
  private filterByProductstartDt: string;
  private filterByProductExpirationDate: string;
  private searchProducts: string;

  private searchProductsList: any;

  private key: string;
  private reverse: boolean;
  private showSearch: boolean;


  private filterByProductIDSearchObj: any;
  private filterByProductNameSearchObj: any;
  private filterByProductDescriptionSearchObj: any;
  private filterByProductCategorySearchObj: any;
  private filterByProductPSUSearchObj: any;
  private filterByProductTIERSearchObj: any;
  private filterByProductTypeSearchObj: any;
  private filterByProductICOMSCDSearchObj: any;
  private filterByProductServiceCodeCategorySearchObj: any;
  private filterByProductstartDtSearchObj: any;
  private filterByProductExpirationDateSearchObj: any;



  constructor(
    private router: Router,
    private ProductsService: ProductsService,
    private businessCatalogDataService: BusinessCatalogDataService
  ) {
    this.searchProducts = '';
    this.searchProductsList = {};
    this.resetProductList();
     this.getAllProductsDetails();
  }


  ngOnInit() {
    this.filterByProductID = '';
    this.filterByProductName = '';
    this.filterByProductDescription = '';
    this.filterByProductCategory = '';
    this.filterByProductPSU = '';
    this.filterByProductTIER = '';
    this.filterByProductType = '';
    this.filterByProductICOMSCD = '';
    this.filterByProductServiceCodeCategory = '';
    this.filterByProductstartDt = '';
    this.filterByProductExpirationDate = '';

    this.filterByProductIDSearchObj = '';
    this.filterByProductNameSearchObj = '';
    this.filterByProductDescriptionSearchObj = '';
    this.filterByProductCategorySearchObj = '';
    this.filterByProductPSUSearchObj = '';
    this.filterByProductTIERSearchObj = '';
    this.filterByProductTypeSearchObj = '';
    this.filterByProductICOMSCDSearchObj = '';
    this.filterByProductServiceCodeCategorySearchObj = '';
    this.filterByProductstartDtSearchObj = '';
    this.filterByProductExpirationDateSearchObj = '';
  }

  resetProductList() {
    this.productsList = [];
  }
redirectTo(url) {
    this.router.navigate([url]);
  }
  getAllProductsDetails() {
    this.blockUI.start('Loading Products...');
    this.ProductsService.getBuProductsData().subscribe(
      data => {
        this.productsList = data.productSearchList;
        this.updateSearchProductList();
        this.initializeFilterContext();
        this.searchProductsList = this.productsList;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  getSearchProductDetails() {
    const searchString = this.searchProducts;
    this.searchProductsList = [];
    for (let i = 0; i < this.productsList.length; i++) {
      const searchStringVal = this.productsList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchProductsList.push(this.productsList[i]);
      }
    }
  }


  updateSearchProductList() {
    for (let i = 0; i < this.productsList.length; i++) {
      this.productsList[i]['searchString'] = this.getProductListConctString(this.productsList[i]);
    }
  }

  getProductListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }


  initializeFilterContext() {
    this.filterByProductIDSearchObj = {
      'prodId': {
        'type': 'text',
        'value': this.filterByProductID,
        'matchFullCase': false
      }
    };
    this.filterByProductNameSearchObj = {
      'name': {
        'type': 'text',
        'value': this.filterByProductName,
        'matchFullCase': false
      }
    };
    this.filterByProductDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterByProductDescription,
        'matchFullCase': false
      }
    };
    this.filterByProductCategorySearchObj = {
      'category': {
        'type': 'text',
        'value': this.filterByProductCategory,
        'matchFullCase': false
      }
    };
    this.filterByProductPSUSearchObj = {
      'psu': {
        'type': 'text',
        'value': this.filterByProductPSU,
        'matchFullCase': false
      }
    };
    this.filterByProductTIERSearchObj = {
      'tier': {
        'type': 'text',
        'value': this.filterByProductTIER,
        'matchFullCase': false
      }
    };
    this.filterByProductTypeSearchObj = {
      'productType': {
        'type': 'text',
        'value': this.filterByProductType,
        'matchFullCase': false
      }
    };
    this.filterByProductICOMSCDSearchObj = {
      'icomsCd': {
        'type': 'text',
        'value': this.filterByProductICOMSCD,
        'matchFullCase': false
      }
    };
    this.filterByProductServiceCodeCategorySearchObj = {
      'svcCodeCategory': {
        'type': 'text',
        'value': this.filterByProductServiceCodeCategory,
        'matchFullCase': false
      }
    };
    this.filterByProductstartDtSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterByProductstartDt,
        'matchFullCase': false
      }
    };

    this.filterByProductExpirationDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByProductExpirationDate,
        'matchFullCase': false
      }
    };
  }



  returnBack() {
    this.router.navigate(['dashboard']);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  moveToproductView(prodId) {
    this.businessCatalogDataService.productId = prodId;
    this.router.navigate(['/business-catalog/productsView']);
  }

 updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

}
