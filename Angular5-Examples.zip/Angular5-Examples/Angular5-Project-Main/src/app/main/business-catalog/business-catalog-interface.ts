export interface BusinessCatalogInterface {
    actionResult: string;
    actionStatus: string;
    commonMasterData: commonMasterData[];
    marketMasterMap: marketMasterMap[];
}


export interface commonMasterData {
    name: string;
    records: Records[];
}

export interface Records {
    key: number;
    code: string;
    value: string;
}

export interface marketMasterMap {
    siteId: string;
    siteCode: string;
    siteCodeName: string;
    region: string;

}

