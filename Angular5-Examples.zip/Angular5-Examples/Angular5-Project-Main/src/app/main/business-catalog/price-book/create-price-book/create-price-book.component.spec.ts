import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePriceBookComponent } from './create-price-book.component';

describe('CreatePriceBookComponent', () => {
  let component: CreatePriceBookComponent;
  let fixture: ComponentFixture<CreatePriceBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePriceBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePriceBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
