import { TestBed, inject } from '@angular/core/testing';

import { PriceBookService } from './price-book.service';

describe('PriceBookService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PriceBookService]
    });
  });

  it('should be created', inject([PriceBookService], (service: PriceBookService) => {
    expect(service).toBeTruthy();
  }));
});
