import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { EligibilityRulesInterface, } from '../eligibility-rules/eligibility-rules-interface';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { Http, HttpModule } from '@angular/http'

@Injectable()
export class PriceBookService {

  constructor(private http: HttpClient,
    private appConfigService: AppConfigService) { }


  getPricingBookList(): Observable<any> {
    const getPricingBookListURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRICING_BOOK_SEARCH'];
    // const reqObj = {
    //   'searchKey': searchKey
    // };
    return this.http
      .get(getPricingBookListURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
    // const getPricingBookListURL = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRICING_BOOK_SEARCH'];
    //   return this.http
    //     .get(getPricingBookListURL)
    //     .map((response: any) => {
    //       return response;
    //     })
    //     .catch(this.handleError);
  }

  getPricingBookDetails(priceBookID): Observable<any> {
    const getPricingBookDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRICING_BOOK_DETAILS'] + '/' + priceBookID;
    // const getPricingBookDetailsURL = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_PRICING_BOOK_DETAILS'];
      return this.http
        .get(getPricingBookDetailsURL)
        .map((response: any) => {
          return response;
        })
        .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}

