export interface PriceBookInterface {
}
