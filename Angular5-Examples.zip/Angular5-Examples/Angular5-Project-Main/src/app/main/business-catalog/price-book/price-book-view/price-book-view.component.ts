import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { PriceBookService } from '../price-book.service';
import { BusinessCatalogDataService } from '../../business-catalog-data.service';

@Component({
  selector: 'plm-price-book-view',
  templateUrl: './price-book-view.component.html',
  styleUrls: ['./price-book-view.component.css'],
  providers: [PriceBookService]
})
export class PriceBookViewComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private priceBookDetails: any;
  constructor(
    private router: Router, 
    private priceBookService: PriceBookService, 
    private businessCatalogDataService: BusinessCatalogDataService
  ) {
    this.priceBookDetails = {};
    this.getPriceBookDetails();
   }

  ngOnInit() {
  }

  getPriceBookDetails(){
    this.blockUI.start('Loading Price Books...');
    this.priceBookService.getPricingBookDetails(this.businessCatalogDataService.priceBookId).subscribe(
      data => {
        this.priceBookDetails = data.priceBookMasterModel;
        this.populatePriceBookMasterDetails();
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  populatePriceBookMasterDetails() {
    for (let i=0; i<this.priceBookDetails.priceBookMasterDets.length; i++) {
      this.populateSiteMapValues(this.priceBookDetails.priceBookMasterDets[i]['priceBookSiteMaps'],i);
    }
  }

  populateSiteMapValues(arr, index) {
    if ((!arr) || (arr.length === 0)) {
      return '';
    }
    for (let i=0; i<arr.length; i++) {
      let siteName = arr[i]['site'];
      let amount = arr[i]['amount'];
      this.priceBookDetails.priceBookMasterDets[index][siteName] = amount;
    }
  }

  getPriceBookSiteAmount(arr, site) {
    let result = '';
    if ((!arr) || (arr.length === 0)) {
      return '';
    }
    for (let i=0; i<arr.length; i++) {
      if (arr[i]['site'] === site) {
        result = arr[i]['amount'];
        break;
      }
    }
    return result;
  }

  returnBack(){
    this.router.navigate(['/business-catalog/priceBook']);
  }
redirectTo(url) {
    this.router.navigate([url]);
  }
}
