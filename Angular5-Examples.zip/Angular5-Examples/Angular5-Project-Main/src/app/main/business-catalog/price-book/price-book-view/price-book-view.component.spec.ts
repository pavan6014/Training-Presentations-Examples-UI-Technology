import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PriceBookViewComponent } from './price-book-view.component';

describe('PriceBookViewComponent', () => {
  let component: PriceBookViewComponent;
  let fixture: ComponentFixture<PriceBookViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PriceBookViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PriceBookViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
