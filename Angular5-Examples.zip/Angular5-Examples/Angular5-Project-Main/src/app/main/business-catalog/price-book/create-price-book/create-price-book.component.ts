import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-create-price-book',
  templateUrl: './create-price-book.component.html',
  styleUrls: ['./create-price-book.component.css']
})
export class CreatePriceBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
