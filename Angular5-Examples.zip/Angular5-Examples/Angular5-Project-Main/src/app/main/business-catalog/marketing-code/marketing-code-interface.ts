export interface MarketingCodeInterface {

  teCodeMasterDataModels: TeCodeMasterDataModels[];
}


export interface TeCodeMasterDataModels {
  teCodeId: number;
  code: string;
  description: string;
  owner: string;
  createdDate: number;
  modifiedBy: string;
  modifiedDate: number;
  notes: string;
  recordId: number;
  recordOwner: string;
  type: string;
}




