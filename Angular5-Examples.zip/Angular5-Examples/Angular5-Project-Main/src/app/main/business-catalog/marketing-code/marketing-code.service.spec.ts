import { TestBed, inject } from '@angular/core/testing';

import { MarketingCodeService } from './marketing-code.service';

describe('MarketingCodeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MarketingCodeService]
    });
  });

  it('should be created', inject([MarketingCodeService], (service: MarketingCodeService) => {
    expect(service).toBeTruthy();
  }));
});
