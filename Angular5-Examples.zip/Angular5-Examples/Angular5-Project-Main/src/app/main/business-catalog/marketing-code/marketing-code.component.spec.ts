import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketingCodeComponent } from './marketing-code.component';

describe('MarketingCodeComponent', () => {
  let component: MarketingCodeComponent;
  let fixture: ComponentFixture<MarketingCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketingCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketingCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
