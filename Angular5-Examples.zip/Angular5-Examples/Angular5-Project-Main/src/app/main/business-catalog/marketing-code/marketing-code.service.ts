import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { MarketingCodeInterface, TeCodeMasterDataModels } from './marketing-code-interface';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';

@Injectable()
export class MarketingCodeService {

  constructor(private http: HttpClient,
    private appConfigService: AppConfigService) { }



getBuMarketingData(): Observable<any> {
      const buOfferLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_MARKETING'];
      // const reqObj = {
      //   'searchKey' : searchKey
      // };
      return this.http
        .get(buOfferLanding)
        .map((response: Response) => {
          return response;
        })
        .catch(this.handleError);
  //   //   const buOfferLanding = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_MARKETING'];

  //   // return this.http
  //   //   .get(buOfferLanding)
  //   //   .map((response: any) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
    }


  // getBuMarketingData(): Observable<MarketingCodeInterface> {
  //   //const buOfferLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_OFFER'];
  //   const buMarketingLanding = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_MARKETING'];
  //   return this.http
  //     .get(buMarketingLanding)
  //     .map((response: any) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
  // }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }
}
