import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { MarketingCodeInterface, TeCodeMasterDataModels } from './marketing-code-interface';
import { MarketingCodeService } from './marketing-code.service';

import { Serializer } from '@angular/compiler';

@Component({
  selector: 'plm-marketing-code',
  templateUrl: './marketing-code.component.html',
  styleUrls: ['./marketing-code.component.css']
})
export class MarketingCodeComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
    private marketingLists: TeCodeMasterDataModels[];
  private marketingList: MarketingCodeInterface;
  private filterBymarketingCode: string;
  private filterBymarketingDescription: string;
  private filterBymarketingType: string;
  private filterByOwner: string;
  private filterByNotes: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;

  private searchMarketingList: any;


  private filterBymarketingCodeSearchObj: any;
  private filterBymarketingDescriptionSearchObj: any;
  private filterBymarketingTypeSearchObj: any;
  private filterByOwnerSearchObj: any;
  private filterByNotesSearchObj: any;

  private searchMarkets: string;


  constructor(private router: Router,
    private TECOdeService: MarketingCodeService) {
    this.getAllmarketingDetails();

    this.filterBymarketingCode= '';
    this.filterBymarketingDescription= '';
    this.filterBymarketingType= '';
    this.filterByOwner= '';
    this.filterByNotes= '';

    this.filterBymarketingCodeSearchObj = '';
    this.filterBymarketingDescriptionSearchObj= '';
    this.filterBymarketingTypeSearchObj= '';
    this.filterByOwnerSearchObj= '';
    this.filterByNotesSearchObj= '';
    this.searchMarkets = '';

    this.searchMarketingList = {};
  }




  ngOnInit() {
    this.filterBymarketingCodeSearchObj = '';
    this.filterBymarketingDescriptionSearchObj = '';
    this.filterBymarketingTypeSearchObj = '';
    this.filterByOwnerSearchObj = '';
    this.filterByNotesSearchObj = '';
    this.searchMarkets = '';
    this.getAllmarketingDetails();
  }

  resetDiscountDetails() {
    this.marketingLists = [];
  }


  getAllmarketingDetails() {
    this.blockUI.start('Loading Marketing List...');
    this.TECOdeService.getBuMarketingData().subscribe(
      data => {
        this.marketingLists = data.teCodeMasterDataModels;
        this.updateSearchMarketingList();
        this.initializeFilterContext();
        this.searchMarketingList = this.marketingLists;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
      }
    );
  }


 getSearchMarketingDetails() {
    const searchString = this.searchMarkets;
    this.searchMarketingList = [];
    for (let i = 0; i < this.marketingLists.length; i++) {
      const searchStringVal = this.marketingLists[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchMarketingList.push(this.marketingLists[i]);
      }
    }
  }

  updateSearchMarketingList() {
    for (let i = 0; i < this.marketingLists.length; i++) {
      this.marketingLists[i]['searchString'] = this.getMarketingListConctString(this.marketingLists[i]);
    }
  }


getMarketingListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }

    initializeFilterContext() {
    this.filterBymarketingCodeSearchObj = {
      'code': {
        'type': 'text',
        'value': this.filterBymarketingCode,
        'matchFullCase': false
      }
    };
    this.filterBymarketingDescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterBymarketingDescription,
        'matchFullCase': false
      }
    };
    this.filterBymarketingTypeSearchObj = {
      'type': {
        'type': 'text',
        'value': this.filterBymarketingType,
        'matchFullCase': false
      }
    };
     this.filterByOwnerSearchObj = {
      'owner': {
        'type': 'text',
        'value': this.filterByOwner,
        'matchFullCase': false
      }
    };
    this.filterByNotesSearchObj = {
      'notes': {
        'type': 'text',
        'value': this.filterByNotes,
        'matchFullCase': false
      }
    };
}
redirectTo(url) {
    this.router.navigate([url]);
  }

  returnBack() {
    this.router.navigate(['dashboard']);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

  updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  convertBreakTagToLineBreak(value) {
      if (value != null) {
          return value.split('<br />').join('\n');
      }
      return value;
      
  }

}
