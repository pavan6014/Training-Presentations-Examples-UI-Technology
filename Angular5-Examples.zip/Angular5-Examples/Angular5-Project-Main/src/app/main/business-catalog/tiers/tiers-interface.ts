export interface TiersInterface {
    tierList: TierList[];
}


export interface TierList {
    tierId: number;
    name: string;
    psuName: string;
    tierLevel: string;
    createdDate: string;
    modifiedDate: string;
    createdBy: string;
}


