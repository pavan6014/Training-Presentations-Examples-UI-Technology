import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { TiersInterface, TierList } from './tiers-interface';
import { TiersService } from './tiers.service';

import { Serializer } from '@angular/compiler';

@Component({
  selector: 'plm-tiers',
  templateUrl: './tiers.component.html',
  styleUrls: ['./tiers.component.css']
})
export class TiersComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;

  private tiersLists: TierList[];

  private tiersList: TiersInterface;
  private filterBytiersName: string;
  private filterBytiersLevel: string;
  private filterBytiersPSUName: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private searchDiscounts: any;

 

private searchTiersList: any;

  private filterBytiersNameSearchObj: any;
  private filterBytiersLevelSearchObj: any;
  private filterBytiersPSUNameSearchObj: any;

  constructor(private router: Router,
    private TiersService: TiersService) {
    this.searchDiscounts = '';
    
  }

  ngOnInit() {

    this.searchDiscounts = '';
    this.getAlltiersDetails();
    this.filterBytiersName = '';
    this.filterBytiersLevel = '';
    this.filterBytiersPSUName = '';

    this.searchTiersList = {};
    

    this.filterBytiersNameSearchObj = '';
    this.filterBytiersLevelSearchObj = '';
    this.filterBytiersPSUNameSearchObj = '';
    
    
  }


  getAlltiersDetails() {
    this.blockUI.start('Loading Tiers List...');
    this.TiersService.getBuTiersData().subscribe(
      data => {
        this.tiersLists = data.tierList;
        this.updateSearchTiersList();
        this.initializeFilterContext();
        this.searchTiersList = this.tiersLists;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


    updateSearchTiersList() {
    for (let i = 0; i < this.tiersLists.length; i++) {
      this.tiersLists[i]['searchString'] = this.getTiersListConctString(this.tiersLists[i]);
    }
  }

  getTiersListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }

    getSearchTiersDetails() {
    const searchString = this.searchDiscounts;
    this.searchTiersList = [];
    for (let i = 0; i < this.tiersLists.length; i++) {
      const searchStringVal = this.tiersLists[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchTiersList.push(this.tiersLists[i]);
      }
    }
  }


  initializeFilterContext() {
    this.filterBytiersNameSearchObj = {
      'name': {
        'type': 'text',
        'value': this.filterBytiersName,
        'matchFullCase': false
      }
    };
    this.filterBytiersLevelSearchObj = {
      'tierLevel': {
        'type': 'text',
        'value': this.filterBytiersLevel,
        'matchFullCase': false
      }
    };
    this.filterBytiersPSUNameSearchObj = {
      'psuName': {
        'type': 'text',
        'value': this.filterBytiersPSUName,
        'matchFullCase': false
      }
    };

  }
redirectTo(url) {
    this.router.navigate([url]);
  }

  returnBack() {
    this.router.navigate(['dashboard']);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

updateFilterContext(obj,key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  
}
