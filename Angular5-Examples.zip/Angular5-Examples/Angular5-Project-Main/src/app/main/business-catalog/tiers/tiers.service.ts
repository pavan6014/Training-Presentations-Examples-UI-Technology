import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { TiersInterface, TierList } from './tiers-interface';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';


@Injectable()
export class TiersService {

  constructor(private http: HttpClient,
    private appConfigService: AppConfigService) { }


getBuTiersData(): Observable<any> {
      const buTiersLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_TIERS'];
      // const reqObj = {
      //   'searchKey' : searchKey
      // };
      return this.http
        .get(buTiersLanding)
        .map((response: Response) => {
          return response;
        })
        .catch(this.handleError);
  //   //   const getDiscountSearchURL = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_DISCOUNTS'];

  //   // return this.http
  //   //   .get(getDiscountSearchURL)
  //   //   .map((response: any) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
    }
  
  // getBuTiersData(): Observable<TiersInterface> {
  //   //const buOfferLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_OFFER'];
  //   const buTiersLanding = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_TIERS'];
  //   return this.http
  //     .get(buTiersLanding)
  //     .map((response: any) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
  // }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }
}
