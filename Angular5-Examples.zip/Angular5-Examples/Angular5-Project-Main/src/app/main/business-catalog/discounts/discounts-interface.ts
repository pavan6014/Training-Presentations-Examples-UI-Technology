export interface DiscountsInterface {

    discountSearchList: DiscountSearchList[];

}


export interface DiscountSearchList {
    discountId: number;
    discountCode: string;
    description: string;
    discountStatus: string;
    discountVersion: string;
    primary: string;
    site: string;
    intakeRequest: string;
    startDate: string;
    endDate: string;
    srvcAgreementRequired: string;
    marketingCode: string;
}
