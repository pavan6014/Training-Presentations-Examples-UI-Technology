import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { DiscountsInterface, DiscountSearchList } from './discounts-interface';
import { HttpHeaders } from '@angular/common/http/src/headers';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { Http, HttpModule } from '@angular/http'
import { BusinessCatalogInterface } from '../business-catalog-interface';


@Injectable()
export class DiscountsService {

  constructor(private http: HttpClient,
    private appConfigService: AppConfigService) { }




  getDiscountMasterData():Observable<any> {
    const getDiscountMasterDataUrl = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_MASTER'];
    return this.http
      .get(getDiscountMasterDataUrl)
      .map((response: any) => {
        return response;
      })
      .catch(this.handleError);
    // const getDiscountMasterDataUrl = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_MASTER'];
    // return this.http
    //   .get(getDiscountMasterDataUrl)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
  }



  getDiscountsData(): Observable<any> {
      const getDiscountSearchURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_DISCOUNTS'];
      // const reqObj = {
      //   'searchKey' : searchKey
      // };
      return this.http
        .get(getDiscountSearchURL)
        .map((response: Response) => {
          return response;
        })
        .catch(this.handleError);
  //   //   const getDiscountSearchURL = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_DISCOUNTS'];

  //   // return this.http
  //   //   .get(getDiscountSearchURL)
  //   //   .map((response: any) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
    // }

  // getDiscountsData(): Observable<DiscountsInterface> {
  //   // const buDiscountsLanding = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_DISCOUNTS'];
  //   const discountsData = this.appConfigService.urlConstants['PLM_BUSINESS_CATALOG_DISCOUNTS'];

  //   return this.http
  //     .get(discountsData)
  //     .map((response: any) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
   }



 private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
