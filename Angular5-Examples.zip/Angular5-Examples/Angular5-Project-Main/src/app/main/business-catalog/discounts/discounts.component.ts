import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit } from '@angular/core';
import { DiscountSearchList, DiscountsInterface } from './discounts-interface';

import { BusinessCatalogInterface } from '../business-catalog-interface';
import { DiscountsService } from './discounts.service';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { Serializer } from '@angular/compiler';

@Component({
  selector: 'plm-discounts',
  templateUrl: './discounts.component.html',
  styleUrls: ['./discounts.component.css']
})
export class DiscountsComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private discountList: DiscountSearchList[];
  private masterData: BusinessCatalogInterface[];
  private markets: any[];

  private filterByDiscountID: string;
  private filterByDescription: string;
  private filterByestimatedMrc: string;
  private filterByDiscountMarket: string
  private filterByDiscountMarketingCode: string;
  private filterByDiscountServiceAgreement: string;
  private filterByDiscountIntakeRequestID: string;
  private filterByDiscountstartDt: string;
  private filterByDiscountEndDate: string;
  private filterByDiscountCode: string;
  private filterByVersion: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private searchDiscounts: string;

  private searchDiscountList: any;



  private filterByDiscountIDSearchObj: any;
  private filterByDescriptionSearchObj: any;
  private filterByestimatedMrcSearchObj: any;
  private filterByDiscountMarketSearchObj: any;
  private filterByDiscountMarketingCodeSearchObj: any;
  private filterByDiscountServiceAgreementSearchObj: any;
  private filterByDiscountIntakeRequestIDSearchObj: any;
  private filterByDiscountstartDtSearchObj: any;
  private filterByDiscountEndDateSearchObj: any;
  private filterByDiscountCodeSearchObj: any;
  private filterByVersionSearchObj: any;



  constructor(
    private discountsService: DiscountsService,
    private router: Router
  ) {
    this.searchDiscounts = '';
    this.resetDiscountDetails();
    this.getAllDiscountsDetails();
    this.getDiscountMasterData();
  }

  ngOnInit() {
    this.filterByDiscountID = '';
    this.filterByDescription = '';
    this.filterByestimatedMrc = '';
    this.filterByDiscountMarket = '';
    this.filterByDiscountMarketingCode = '';
    this.filterByDiscountServiceAgreement = '';
    this.filterByDiscountIntakeRequestID = '';
    this.filterByDiscountstartDt = '';
    this.filterByDiscountEndDate = '';
    this.filterByDiscountCode = '';
    this.searchDiscounts = '';
    this.filterByDescription = '';
    this.filterByVersion = '';


    this.filterByDiscountIDSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    this.filterByestimatedMrcSearchObj = '';
    this.filterByDiscountMarketSearchObj = '';
    this.filterByDiscountMarketingCodeSearchObj = '';
    this.filterByDiscountServiceAgreementSearchObj = '';
    this.filterByDiscountIntakeRequestIDSearchObj = '';
    this.filterByDiscountstartDtSearchObj = '';
    this.filterByDiscountEndDateSearchObj = '';
    this.filterByDiscountCodeSearchObj = '';
    this.filterByVersionSearchObj = '';
    this.filterByDescriptionSearchObj = '';
    
    this.searchDiscountList = {};
    sessionStorage.removeItem('mode');
    sessionStorage.removeItem('discountId');
    sessionStorage.removeItem('backURL');
    sessionStorage.removeItem('isFromBusinessCatalog');

  }



  getDiscountMasterData() {
    this.discountsService.getDiscountMasterData()
      .subscribe(
      data => {
        this.masterData = data.marketMasterMap;
        this.markets = [];
        for (let prop in this.masterData) {
          this.pushMarketsData(this.masterData[prop]); 
        }
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  pushMarketsData(markets) {
    for(let i=0; i<markets.length; i++) {
      this.markets.push(markets[i]);
    }
  }

  getMarketsArray(discountMarkets){
    const result = [];
    if (discountMarkets.length === 0) {
      return [];
    }
    for (let i=0;i<this.markets.length; i++) {
      if(discountMarkets.indexOf(this.markets[i]['siteId']) > -1) {
        result.push(this.markets[i]['siteCodeName']);
      }
    }
    return result;
  }


  resetDiscountDetails() {
    this.discountList = [];
  }

  getAllDiscountsDetails() {
    this.blockUI.start('Loading Discounts...');
    this.discountsService.getDiscountsData().subscribe(
      data => {
        this.discountList = data.discountSearchList;
        this.updateSites();
        this.initializeFilterContext();
        this.updateSearchOfferList();
        this.searchDiscountList = this.discountList;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }



  updateSearchOfferList() {
    for (let i = 0; i < this.discountList.length; i++) {
      this.discountList[i]['searchString'] = this.getDiscountListConctString(this.discountList[i]);
    }
  }

  getDiscountListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }

  updateSites(){
    for(let i=0; i<this.discountList.length; i++) {
      this.discountList[i]['marketsInString'] = '';
      if (!this.discountList[i]['site']) {
        continue;
      }
      const sitesArray = this.getMarketsArray(this.getSitesArray(this.discountList[i]['site']));
      this.discountList[i]['marketsInString'] = sitesArray.join(', ');
    }
  }

  getSitesArray(site) {
    let sitesArray = [];
    if (site.indexOf(',') > -1) {
      sitesArray = site.split(',');
    } else {
      sitesArray.push(site);
    }
    return sitesArray;
  }


   getSearchDiscountDetails() {
    const searchString = this.searchDiscounts;
    this.searchDiscountList = [];
    for (let i = 0; i < this.discountList.length; i++) {
      const searchStringVal = this.discountList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchDiscountList.push(this.discountList[i]);
      }
    }
  }



  moveToDiscountView(mode, discountId) {
    sessionStorage.setItem('mode', mode);
    sessionStorage.setItem('discountId', discountId);
    sessionStorage.setItem('backURL', 'business-catalog/discounts');
    sessionStorage.setItem('isFromBusinessCatalog', 'true');
    this.router.navigate(['/plm-work-flow/configurator/discount/view-discount']);
  }

  initializeFilterContext() {
    this.filterByDiscountIDSearchObj = {
      'discountId': {
        'type': 'text',
        'value': this.filterByDiscountID,
        'matchFullCase': false
      }
    };
    this.filterByDescriptionSearchObj = {
      'descriptionVersion': {
        'type': 'text',
        'value': this.filterByDescription,
        'matchFullCase': false
      }
    };
    this.filterByVersionSearchObj = {
      'descriptionVersion': {
        'type': 'text',
        'value': this.filterByVersion,
        'matchFullCase': false
      }
    };
    this.filterByestimatedMrcSearchObj = {
      'estimatedMRC': {
        'type': 'text',
        'value': this.filterByestimatedMrc,
        'matchFullCase': false
      }
    };
    this.filterByDiscountMarketSearchObj = {
      'market': {
        'type': 'text',
        'value': this.filterByDiscountMarket,
        'matchFullCase': false
      }
    };
    this.filterByDiscountMarketingCodeSearchObj = {
      'marketingCode': {
        'type': 'text',
        'value': this.filterByDiscountMarketingCode,
        'matchFullCase': false
      }
    };
    this.filterByDiscountServiceAgreementSearchObj = {
      'serviceAgreement': {
        'type': 'text',
        'value': this.filterByDiscountServiceAgreement,
        'matchFullCase': false
      }
    };
    this.filterByDiscountIntakeRequestIDSearchObj = {
      'intakeRequest': {
        'type': 'text',
        'value': this.filterByDiscountIntakeRequestID,
        'matchFullCase': false
      }
    };
    this.filterByDiscountstartDtSearchObj = {
      'startDate': {
        'type': 'text',
        'value': this.filterByDiscountstartDt,
        'matchFullCase': false
      }
    };
    this.filterByDiscountEndDateSearchObj = {
      'endDate': {
        'type': 'text',
        'value': this.filterByDiscountEndDate,
        'matchFullCase': false
      }
    };
    this.filterByDiscountCodeSearchObj = {
      'discountCode': {
        'type': 'text',
        'value': this.filterByDiscountCode,
        'matchFullCase': false
      }

    }
  }

   updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  returnBack(){
    this.router.navigate(['']);
  }
redirectTo(url) {
    this.router.navigate([url]);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }
 

}
