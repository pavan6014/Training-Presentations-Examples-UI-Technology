import { Injectable } from '@angular/core';

@Injectable()
export class BusinessCatalogDataService {
  public priceBookId: number;
  public productId: number;
  constructor() { }

}
