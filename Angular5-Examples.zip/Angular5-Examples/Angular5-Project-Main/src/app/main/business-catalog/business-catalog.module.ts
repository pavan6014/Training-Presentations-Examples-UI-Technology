import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessCatalogRoutingModule } from './business-catalog-routing.module';
import { BusinessCatalogComponent } from './business-catalog.component';
import { OffersComponent } from './offers/offers.component';
import { DiscountsComponent } from './discounts/discounts.component';
import { ProductsComponent } from './products/products.component';
import { OffersService } from './offers/offers.service';
import { RelevancyRulesComponent } from './relevancy-rules/relevancy-rules.component';
import { EligibilityRulesComponent } from './eligibility-rules/eligibility-rules.component';
import { PriceBookComponent } from './price-book/price-book.component';
import { MarketingCodeComponent } from './marketing-code/marketing-code.component';
import { TiersComponent } from './tiers/tiers.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2PaginationModule } from 'ng2-pagination'; 
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ProductsViewComponent } from './products/products-view/products-view.component';
import { PriceBookViewComponent } from './price-book/price-book-view/price-book-view.component';
import { CreatePriceBookComponent } from './price-book/create-price-book/create-price-book.component';
import { BusinessCatalogDataService } from './business-catalog-data.service';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    BusinessCatalogRoutingModule,
    FormsModule,
    Ng2PaginationModule,
    Ng2OrderModule,
    Ng2SearchPipeModule,
    SharedModule
  ],
  declarations: [BusinessCatalogComponent, OffersComponent, DiscountsComponent, ProductsComponent, RelevancyRulesComponent, EligibilityRulesComponent, PriceBookComponent, MarketingCodeComponent, TiersComponent, ProductsViewComponent, PriceBookViewComponent, CreatePriceBookComponent],
  providers: [BusinessCatalogDataService]
})
export class BusinessCatalogModule { }
