import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../shared';
import { OffersComponent } from './offers/offers.component';
import { DiscountsComponent } from './discounts/discounts.component';
import { ProductsComponent } from './products/products.component';
import { RelevancyRulesComponent } from './relevancy-rules/relevancy-rules.component';
import {EligibilityRulesComponent} from './eligibility-rules/eligibility-rules.component';
import { MarketingCodeComponent } from './marketing-code/marketing-code.component';
import { PriceBookComponent } from './price-book/price-book.component';
import { TiersComponent }  from './tiers/tiers.component';
import { ProductsViewComponent } from './products/products-view/products-view.component';
import { PriceBookViewComponent } from './price-book/price-book-view/price-book-view.component';
import { CreatePriceBookComponent } from './price-book/create-price-book/create-price-book.component';

const routes: Routes = [
  { 
    path: 'offers', 
    component: OffersComponent, 
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/offers'}
  },
  { 
    path: 'discounts', 
    component: DiscountsComponent, 
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/discounts'} 
  },
  { 
    path: 'products', 
    component: ProductsComponent, 
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/products'} 
  },
  { 
    path: 'relevancyRules', 
    component: RelevancyRulesComponent, 
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/relevancyRules'} 
  },
  { 
    path: 'eligibilityRules', 
    component:EligibilityRulesComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/eligibilityRules'} 
  },
  { 
    path: 'marketingCode', 
    component:MarketingCodeComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/marketingCode'} 
  },
  { 
    path: 'priceBook', 
    component:PriceBookComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/priceBook'} 
  },
  { 
    path: 'tiers', 
    component:TiersComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/tiers'} 
  },
  { 
    path: 'productsView', 
    component:ProductsViewComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/productsView'} 
  },
  { 
    path: 'priceBookView',  
    component: PriceBookViewComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/priceBookView'} 
  },
  { 
    path: 'createPriceBook',  
    component: CreatePriceBookComponent,
    canActivate: [AuthGuard],
    data: { path : 'business-catalog/createPriceBook'} 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BusinessCatalogRoutingModule { }
