import { TestBed, inject } from '@angular/core/testing';

import { BusinessCatalogService } from './business-catalog.service';

describe('BusinessCatalogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BusinessCatalogService]
    });
  });

  it('should be created', inject([BusinessCatalogService], (service: BusinessCatalogService) => {
    expect(service).toBeTruthy();
  }));
});
