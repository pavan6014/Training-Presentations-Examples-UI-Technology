import { TestBed, inject } from '@angular/core/testing';

import { BusinessCatalogDataService } from './business-catalog-data.service';

describe('BusinessCatalogDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BusinessCatalogDataService]
    });
  });

  it('should be created', inject([BusinessCatalogDataService], (service: BusinessCatalogDataService) => {
    expect(service).toBeTruthy();
  }));
});
