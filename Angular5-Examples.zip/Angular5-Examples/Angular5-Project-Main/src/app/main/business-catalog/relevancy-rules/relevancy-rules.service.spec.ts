import { TestBed, inject } from '@angular/core/testing';

import { RelevancyRulesService } from './relevancy-rules.service';

describe('RelevancyRulesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RelevancyRulesService]
    });
  });

  it('should be created', inject([RelevancyRulesService], (service: RelevancyRulesService) => {
    expect(service).toBeTruthy();
  }));
});
