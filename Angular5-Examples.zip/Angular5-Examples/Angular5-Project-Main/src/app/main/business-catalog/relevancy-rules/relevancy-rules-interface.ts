export interface RelevancyRulesInterface {
  relevancySearchList: RelevancySearchList[]; 
}

export interface RelevancySearchList {
     relId: number;
    rule: string;
    description: string;
    ruleSyntax: string;
}
