import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { RelevancyRulesInterface, RelevancySearchList } from '../relevancy-rules/relevancy-rules-interface';
import { RelevancyRulesService } from '../relevancy-rules/relevancy-rules.service';

@Component({
  selector: 'plm-relevancy-rules',
  templateUrl: './relevancy-rules.component.html',
  styleUrls: ['./relevancy-rules.component.css']
})
export class RelevancyRulesComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
  private relevancyList: RelevancySearchList[];
  private filterByrule: string;
  private filterBydescription: string;
  private filterByruleSyntax: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private searchRelevancy: string;

   private searchRelevancyList: any;

   private filterByruleSearchObj: any;
  private filterBydescriptionSearchObj: any;
  private filterByruleSyntaxSearchObj: any;
  constructor(
    private router: Router, 
    private relevancyRulesService: RelevancyRulesService
  ) {
    this.searchRelevancy = '';
    this.resetRelevancySearchData();
    this.getRelevancyRulesData();

    this.searchRelevancyList = {};
    this.filterByrule= '';
    this.filterBydescription= '';
    this.filterByruleSyntax= '';

    this.filterByruleSearchObj= '';
    this.filterBydescriptionSearchObj= '';
    this.filterByruleSyntaxSearchObj= '';

  }

  ngOnInit() {
  }

  resetRelevancySearchData() {
    this.relevancyList = [];
  }

  getRelevancyRulesData() {
    this.blockUI.start('Loading Relevancy Rules...');
    this.relevancyRulesService.getRelevancyRules().subscribe(
      data => {
        this.relevancyList = data.relevancySearchList;
        this.updateSearchRelevancyList();
        this.initializeFilterContext();
        this.searchRelevancyList = this.relevancyList;
        this.blockUI.stop();
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }


  getSearchRelevancyRulesDetails() {
    const searchString = this.searchRelevancy;
    this.searchRelevancyList = [];
    for (let i = 0; i < this.relevancyList.length; i++) {
      const searchStringVal = this.relevancyList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchRelevancyList.push(this.relevancyList[i]);
      }
    }
  }


   updateSearchRelevancyList() {
    for (let i = 0; i < this.relevancyList.length; i++) {
      this.relevancyList[i]['searchString'] = this.getRelevancyListConctString(this.relevancyList[i]);
    }
  }

  getRelevancyListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }


  initializeFilterContext() {
    this.filterByruleSearchObj = {
      'rule': {
        'type': 'text',
        'value': this.filterByrule,
        'matchFullCase': false
      }
    };
    this.filterBydescriptionSearchObj = {
      'description': {
        'type': 'text',
        'value': this.filterBydescription,
        'matchFullCase': false
      }
    };
    this.filterByruleSyntaxSearchObj = {
      'ruleSyntax': {
        'type': 'text',
        'value': this.filterByruleSyntax,
        'matchFullCase': false
      }
    };
    
 }
 redirectTo(url) {
    this.router.navigate([url]);
  }

  returnBack(){
    this.router.navigate(['']);
  }

sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }
  
  updateFilterContext(obj,key, newVal) {
    console.log(obj,key, newVal);
    this[obj][key]['value'] = newVal;
  }
  
}
