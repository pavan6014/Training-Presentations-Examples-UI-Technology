export interface OffersInterface {
    offerModifyModelList: offerModifyModelList[];
}


export interface offerModifyModelList {
    offerId: number;
    offerName: string;
    offerDescription: string;
    salesAdvice: string;
    webDisplayName: string;
    estimatedmrc: string;
    offerStartDate: string;
    offerEndDate: string;
    primaryDiscount: string;
    offerStatus: string;
    changeRemarks: string;
    offerCategory: string;
    offerBundle: string;
    offerType: string;
    markets: string;
    channels: string;
    version: string;
    intakeRequestId: string;
    offerModifiedDate: string;
}
