import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Component, OnInit } from '@angular/core';
import { OffersInterface, offerModifyModelList } from '../offers/offers-interface';

import { BusinessCatalogInterface } from '../business-catalog-interface';
import { Observable } from 'rxjs/Observable';
import { OffersService } from './offers.service';
import { Router } from '@angular/router';
import { Serializer } from '@angular/compiler';

@Component({
  selector: 'plm-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {

  @BlockUI() blockUI: NgBlockUI;
  private offerList: offerModifyModelList[];
  private masterData: BusinessCatalogInterface[];
  private markets: any[];
  private searchOffer: string;
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private offerListLoaded: boolean;

  private filterByofferId: string;
  private filterByofferName: string;
  private filterByofferDescription: string;
  private filterByestimatedMrc: string;
  private filterBypsu: string
  private filterByofferCategory: string;
  private filterByofferBundleName: string;
  private filterByprimaryDiscountCode: string;
  private filterByPrimaryDiscountVersion: string;
  private filterBystartDt: string;
  private filterByendDt: string;
  private filterBylastModify: string;
  private filterBystatus: string;
  private filterByprojectCode: string;

  private filterByIdSearchObj: any;
  private filterByOfferNameSearchObj: any;
  private filterByOfferDescriptionSearchObj: any;
  private filterByOfferMrcSearchObj: any;
  private filterByOfferPsuSearchObj: any;
  private filterByOfferCategorySearchObj: any;
  private filterByOfferBundleSearchObj: any;
  private filterByOfferPrimaryDiscountCodeSearchObj: any;
  private filterByOfferPrimaryDiscountVersionSearchObj: any;
  private filterByOfferstartDtSearchObj: any;
  private filterByOfferendDtSearchObj: any;
  private filterByOfferlastModifySearchObj: any;
  private filterByOfferstatusSearchObj: any;
  private filterByOfferprojectCodeSearchObj: any;
  private searchOfferList: any;

  constructor(
    private router: Router,
    private offersService: OffersService
  ) {
    this.searchOffer = '';
    this.offerListLoaded = false;
    this.resetOfferSearchData();
    this.getAllOfferDetails();
  }

  ngOnInit() {
    this.filterByofferId = '';
    this.filterByofferName = '';
    this.filterByofferDescription = '';
    this.filterByestimatedMrc = '';
    this.filterBypsu = '';
    this.filterByofferCategory = '';
    this.filterByofferBundleName = '';
    this.filterByprimaryDiscountCode = '';
    this.filterByPrimaryDiscountVersion = '';
    this.filterBystartDt = '';
    this.filterByendDt = '';
    this.filterBylastModify = '';
    this.filterBystatus = '';
    this.filterByprojectCode = '';
    this.searchOffer = '';

    this.filterByIdSearchObj = '';
    this.filterByOfferNameSearchObj = '';
    this.filterByOfferDescriptionSearchObj = ';'
    this.filterByOfferMrcSearchObj = '';
    this.filterByOfferPsuSearchObj = '';
    this.filterByOfferCategorySearchObj = '';
    this.filterByOfferBundleSearchObj = '';
    this.filterByOfferPrimaryDiscountCodeSearchObj = '';
    this.filterByOfferPrimaryDiscountVersionSearchObj = '';
    this.filterByOfferstartDtSearchObj = '';
    this.filterByOfferendDtSearchObj = '';
    this.filterByOfferlastModifySearchObj = '';
    this.filterByOfferstatusSearchObj = '';
    this.filterByOfferprojectCodeSearchObj = '';
    this.searchOfferList = {};
    sessionStorage.removeItem('mode');
    sessionStorage.removeItem('offerId');
    sessionStorage.removeItem('backURL');
  }


  getDiscountMasterData() {
    this.offersService.getOffersMasterData()
      .subscribe(
        data => {
          this.masterData = data.marketMasterMap;
          this.markets = [];
          for (const prop in this.masterData) {
            if (this.masterData[prop]) {
              this.pushMarketsData(this.masterData[prop]);
            }
          }
          this.blockUI.stop();
        },
        error => {
          console.log('Error :: ' + error);
          this.blockUI.stop();
        }
      );
  }

  pushMarketsData(markets) {
    for (let i = 0; i < markets.length; i++) {
      this.markets.push(markets[i]);
    }
  }



  resetOfferSearchData() {
    this.offerList = [];
  }

  redirectTo(url) {
    this.router.navigate([url]);
  }
  getAllOfferDetails() {
    this.blockUI.start('Loading Offers List...');
    this.offersService.getBuOffersData().subscribe(
      data => {
        this.offerList = data.catalogOffers;
        this.initializeFilterContext();
        this.updateSearchOfferList();
        this.searchOfferList = this.offerList;
        this.blockUI.stop();
        this.offerListLoaded = true;
      },
      error => {
        console.log('Error :: ' + error);
        this.blockUI.stop();
      }
    );
  }

  updateSearchOfferList() {
    for (let i = 0; i < this.offerList.length; i++) {
      this.offerList[i]['searchString'] = this.getOfferListConctString(this.offerList[i]);
    }
  }

  getOfferListConctString(obj) {
    let result = '';
    const resultArray = [];
    for (const objVal in obj) {
      if (obj[objVal]) {
        resultArray.push(obj[objVal]);
      }
    }
    result = resultArray.join(' , ');
    return result;
  }

  getSearchOfferDetails() {
    const searchString = this.searchOffer;
    this.searchOfferList = [];
    for (let i = 0; i < this.offerList.length; i++) {
      const searchStringVal = this.offerList[i]['searchString'].toLowerCase();
      if (searchStringVal.indexOf(searchString.toLowerCase()) > -1) {
        this.searchOfferList.push(this.offerList[i]);
      }
    }
  }


  //  updateSites(){
  //     for(let i=0; i<this.offerList.length; i++) {
  //       this.offerList[i]['marketsInString'] = '';
  //       let sitesArray = this.getMarketsArray(this.offerList[i]['site']);
  //       this.offerList[i]['marketsInString'] = sitesArray.join(', ');
  //     }
  //   }

  getMarketsArray(discountMarkets) {
    const result = [];
    if (!discountMarkets) {
      return [];
    }
    for (let i = 0; i < this.markets.length; i++) {
      if (discountMarkets.indexOf(Number(this.markets[i]['siteId'])) > -1) {
        result.push(this.markets[i]['siteCodeName']);
      }
    }
    return result;
  }


  moveToOfferView(mode, offerId) {
    sessionStorage.setItem('mode', mode);
    sessionStorage.setItem('offerId', offerId);
    sessionStorage.setItem('backURL', 'business-catalog/offers');
    sessionStorage.setItem('isFromBusinessCatalog', 'true');
    this.router.navigate(['/plm-work-flow/configurator/offer/view-offer']);
  }

  initializeFilterContext() {
    this.filterByIdSearchObj = {
      'offerId': {
        'type': 'text',
        'value': this.filterByofferId,
        'matchFullCase': false
      }
    };
    this.filterByOfferNameSearchObj = {
      'offerName': {
        'type': 'text',
        'value': this.filterByofferName,
        'matchFullCase': false
      }
    };
    this.filterByOfferDescriptionSearchObj = {
      'offerDescription': {
        'type': 'text',
        'value': this.filterByofferDescription,
        'matchFullCase': false
      }
    };
    this.filterByOfferMrcSearchObj = {
      'estimatedMrc': {
        'type': 'text',
        'value': this.filterByestimatedMrc,
        'matchFullCase': false
      }
    };
    this.filterByOfferPsuSearchObj = {
      'offerType': {
        'type': 'text',
        'value': this.filterBypsu,
        'matchFullCase': false
      }
    };
    this.filterByOfferCategorySearchObj = {
      'offerCategory': {
        'type': 'text',
        'value': this.filterByofferCategory,
        'matchFullCase': false
      }
    };
    this.filterByOfferBundleSearchObj = {
      'offerBundleName': {
        'type': 'text',
        'value': this.filterByofferBundleName,
        'matchFullCase': false
      }
    };
    this.filterByOfferPrimaryDiscountCodeSearchObj = {
      'primaryDiscountCode': {
        'type': 'text',
        'value': this.filterByprimaryDiscountCode,
        'matchFullCase': false
      }
    };
    this.filterByOfferPrimaryDiscountVersionSearchObj = {
      'discPrimaryFlag': {
        'type': 'text',
        'value': this.filterByPrimaryDiscountVersion,
        'matchFullCase': false
      }
    };
    this.filterByOfferstartDtSearchObj = {
      'startDt': {
        'type': 'text',
        'value': this.filterBystartDt,
        'matchFullCase': false
      }
    };
    this.filterByOfferendDtSearchObj = {
      'endDt': {
        'type': 'text',
        'value': this.filterByendDt,
        'matchFullCase': false
      }
    };

    this.filterByOfferlastModifySearchObj = {
      'offerModifiedDate': {
        'type': 'text',
        'value': this.filterBylastModify,
        'matchFullCase': false
      }
    };

    this.filterByOfferstatusSearchObj = {
      'status': {
        'type': 'text',
        'value': this.filterBystatus,
        'matchFullCase': false
      }
    };

    this.filterByOfferprojectCodeSearchObj = {
      'intakeRequestId': {
        'type': 'text',
        'value': this.filterByprojectCode,
        'matchFullCase': false
      }
    };
  }

  updateFilterContext(obj, key, newVal) {
    this[obj][key]['value'] = newVal;
  }

  returnBack() {
    this.router.navigate(['dashboard']);
  }
  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }

}
