import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule, MatCheckboxModule,MatExpansionModule,MatDatepickerModule} from '@angular/material';
import { BlockUIModule } from 'ng-block-ui';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';


import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardService } from './dashboard/dashboard.service';
import { ActorsComponent } from './dashboard/actors/actors.component';
import { TechnologyActorsComponent } from './dashboard/technology-actors/technology-actors.component';
import { AuthGuardService } from '../shared/guard/auth-guard.service';
import { AuthGuardDataService } from '../shared/guard/auth-guard-data.service';
import { OffersService } from './business-catalog/offers/offers.service';
import { RelevancyRulesService } from  './business-catalog/relevancy-rules/relevancy-rules.service';
import { EligibilityRulesService} from './business-catalog/eligibility-rules/eligibility-rules.service';
import { DiscountsService } from './business-catalog/discounts/discounts.service';
import { MarketingCodeService } from './business-catalog/marketing-code/marketing-code.service';
import { PriceBookService } from './business-catalog/price-book/price-book.service';
import { ProductsService } from './business-catalog/products/products.service';
import { TiersService } from './business-catalog/tiers/tiers.service';

@NgModule({
    imports: [
        CommonModule,
        MainRoutingModule,
        TranslateModule,
        FormsModule,
        ReactiveFormsModule,
        NgbDropdownModule.forRoot(),
        SharedModule,
        MatDatepickerModule,
        BlockUIModule,
        NgIdleKeepaliveModule.forRoot()
    ],
    declarations: [
        MainComponent,
        SidebarComponent,
        DashboardComponent,
        ActorsComponent,
        TechnologyActorsComponent
    ],
    providers : [
        AuthGuardService,
        AuthGuardDataService,
        OffersService,
        RelevancyRulesService,
        EligibilityRulesService,
        DiscountsService,
        MarketingCodeService,
        PriceBookService,
        ProductsService,
        TiersService, 
        DashboardService
    ]
})
export class MainModule { }
