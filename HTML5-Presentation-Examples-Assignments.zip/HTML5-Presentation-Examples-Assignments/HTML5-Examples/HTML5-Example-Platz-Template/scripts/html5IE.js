/* HTML 5 Works in all Browsers using below JS */
document.createElement("header");
document.createElement("nav");
document.createElement("section");
document.createElement("aside");
document.createElement("article");
document.createElement("footer");
document.createElement("element");