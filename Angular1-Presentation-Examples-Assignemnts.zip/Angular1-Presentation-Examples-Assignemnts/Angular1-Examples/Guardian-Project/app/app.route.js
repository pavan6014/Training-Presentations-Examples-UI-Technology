//Config the router and remove the hash tag from URL
attApp.config(['$locationProvider', '$routeProvider', '$httpProvider' , function($locationProvider, $routeProvider, $httpProvider){
	// $httpProvider.defaults.useXDomain = true;
    // delete $httpProvider.defaults.headers.common['X-Requested-With'];
	$httpProvider.defaults.useXDomain = true;
	$httpProvider.defaults.withCredentials = true;
	delete $httpProvider.defaults.headers.common["X-Requested-With"];
	$httpProvider.defaults.headers.common["Access-Control-Allow-Origin"] = "*";
	$httpProvider.defaults.headers.common["Accept"] = "application/json";
	$httpProvider.defaults.headers.common["Content-Type"] = "application/json";
	
	
    $routeProvider.
	when("/home", {
        templateUrl: "app/components/home/home.html",
		controller:'homeController'
    }).
	when("/pending-req", {
        templateUrl: "app/components/pending-req/pending-req.html",
		controller:'pendingReqController'
    }).
	when("/faq", {
        templateUrl: "app/components/faq/faq.html",
		controller:'faqController'
    }).
	when("/user-role", {
        templateUrl: "app/components/user-role/user-role.html",
		controller:'userRoleController'
    }).
	when("/90-days-search", {
        templateUrl: "app/components/90-day-search/90-day-search.html",
		controller:'NinetyDaysSearchController'
    }).
	when("/market-administration-market", {
        templateUrl: "app/components/market-administration-market/market-administration-market.html",
		controller:'marketAdministrationMarketController'
    }).
    when("/request-search", {
            templateUrl: "app/components/request-search/request-search.html",
    		controller:'requestSearchController'
    }).
	otherwise({
        redirectTo: '/home'
    });
}]);

attApp.constant('config', {
    appName: 'AT&T Application',
    appVersion: 1.0,
    apiUrl: 'http://www.google.com?api',
	isConnectedToBackend: 0, // 0 point to local file while 1 point to actual service
	serviceUrl: {
		getCompanyUrl: 'http://localhost:8080/srstudy/resteasyService/getAgents/company'
	},
	localUrl: {
		listOfValues: 'data/listOfValues.json',
		listOfUserRoles: 'data/userRole.json',
		listOfFaq: 'data/faq.json',
		listOfAdminMarket: 'data/marketAdministrationMarket.json'
	}
	
});
