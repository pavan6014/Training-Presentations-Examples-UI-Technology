attApp.controller('NinetyDaysSearchController', ['$rootScope', '$scope', '$location', '$window', 'NinetyDaysSearchService', function($rootScope, $scope, $location, $window, NinetyDaysSearchService) {	
	
	init();
	
	function init(){

	}
	
}]);