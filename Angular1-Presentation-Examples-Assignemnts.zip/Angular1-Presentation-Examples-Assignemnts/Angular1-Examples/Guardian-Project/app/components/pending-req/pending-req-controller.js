attApp.controller('pendingReqController', ['$rootScope', '$scope', '$location', '$window', 'pendingReqService', function($rootScope, $scope, $location, $window, pendingReqService) {	
	
	init();
	
	function init(){

	}
	
}]);