attApp.controller('marketAdministrationMarketController', ['$rootScope', '$scope', '$location', '$window', 'marketAdministrationMarketService', function($rootScope, $scope, $location, $window, marketAdministrationMarketService) {	
	
	init();

	function init(){
		marketAdministrationMarketService.getListOfAdminMarket().then(handleSuccess, handleError)
	}

	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}

	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
}]);