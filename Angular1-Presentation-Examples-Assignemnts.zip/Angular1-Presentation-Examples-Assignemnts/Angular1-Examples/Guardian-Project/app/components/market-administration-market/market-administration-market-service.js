attApp.service('marketAdministrationMarketService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){

	return ({
       getListOfAdminMarket: getListOfAdminMarket,
    });

    function getListOfAdminMarket(){
         var request = $http({
            method: "GET",
            async: true,
            cache: false,
            url: $rootScope.URL.listOfAdminMarket
        });
        return (request.then(handleSuccess, handleError));
    }

    function handleSuccess(response){
        return response.data;
    }

    function handleError(response){
        console.log("error handling stratum info service");
    }

}]);