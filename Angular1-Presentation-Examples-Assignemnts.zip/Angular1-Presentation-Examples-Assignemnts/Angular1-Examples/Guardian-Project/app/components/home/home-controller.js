attApp.controller('homeController', ['$rootScope', '$scope', '$location', '$window', 'homeService', function($rootScope, $scope, $location, $window, homeService) {	
	
	init();
	
	function init(){
		
	}
	
}]);