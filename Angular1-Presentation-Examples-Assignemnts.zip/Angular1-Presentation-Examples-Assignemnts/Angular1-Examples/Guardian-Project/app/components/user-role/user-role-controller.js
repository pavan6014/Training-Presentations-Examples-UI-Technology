attApp.controller('userRoleController', ['$rootScope', '$scope', '$location', '$window', 'userRoleService', function($rootScope, $scope, $location, $window, userRoleService) {	
	
	init();
	
	function init(){
		userRoleService.getListOfUserRoles().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
}]);