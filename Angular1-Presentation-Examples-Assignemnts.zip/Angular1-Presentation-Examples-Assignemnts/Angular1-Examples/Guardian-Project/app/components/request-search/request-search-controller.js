attApp.controller('requestSearchController', ['$rootScope', '$scope', '$location', '$window', 'requestSearchService', function($rootScope, $scope, $location, $window, requestSearchService) {
	
	init();
	
	function init(){

	}
	
}]);