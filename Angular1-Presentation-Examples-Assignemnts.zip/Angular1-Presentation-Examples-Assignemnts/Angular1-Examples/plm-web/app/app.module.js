var myApp = angular.module('myApp', ['ui.bootstrap', 'ngRoute', 'uiSwitch','dm.stickyNav','blockUI','angularUtils.directives.dirPagination','ui.date','toaster']);
