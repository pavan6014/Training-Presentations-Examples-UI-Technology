myApp.controller('reportController', ['$rootScope', '$scope', '$location', '$window', 'reportService', function($rootScope, $scope, $location, $window, reportService) {	
	
	init();


	function init(){
		reportService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);