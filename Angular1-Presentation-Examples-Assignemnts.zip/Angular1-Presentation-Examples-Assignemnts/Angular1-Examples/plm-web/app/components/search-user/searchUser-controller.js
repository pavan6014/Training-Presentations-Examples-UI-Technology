myApp.controller("searchUserController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "$timeout",
  "searchUserService",
  function ($rootScope, $scope, $location, $window, $timeout, searchUserService) {

    $scope.moveToUpdate = true;
    $scope.currentUser = "";
    $scope.statusUpdated = false;
    $scope.isInvalidUser = false;
    $scope.statusVal = {};
    $scope.userNotSelected = true;

    $scope.getHeaderDropDownList = function () {
      searchUserService.getHeaderData().then(function (response) {
        //   console.log(response);
        $scope.searchData = response.users;
        $scope.headers = response.headers;
        for (var i = 0; i < $scope.searchData.length; i++) {
          $scope.statusVal['' + i] = $scope.searchData[i]['selectedstatus'];
          // console.log($scope.statusVal[''+i]);
        }
      })
    }

    $scope.searchUser = function () {
      //   console.log($scope.searchInput);
      //   console.log($scope.searchIn);
      searchUserService.getSearchUsersData($scope.searchInput, $scope.searchIn).then(function (response) {
        //   console.log(response);
        if (response.users.length > 0) {
          $scope.searchData = response.users;
          for (var i = 0; i < $scope.searchData.length; i++) {
            $scope.statusVal['' + i] = $scope.searchData[i]['selectedstatus'];
            //   console.log($scope.statusVal[''+i]);
          }
          $scope.isInvalidUser = false;
        } else {
          $scope.isInvalidUser = true;
        }
        //   angular.forEach($scope.searchData, function(value,key){
        //       console.log(''+key);
        //       $scope.statusVal[''+key] = value['selectedstatus'];
        //   });            
      });
    };

    $scope.addUserForUpdate = function () {
      console.log($scope.searchData);
      var count = 0;
      for (var i = 0; i < $scope.searchData.length; i++) {
        if ($scope.searchData[i].Selected) {
          count += 1;
        }
      }
      if (count > 0) {
        $scope.userNotSelected = false;
      } else {
        $scope.userNotSelected = true;
      }
    };

    $scope.modifyUserData = function (index) {
      //   console.log($scope.statusVal);
      //   console.log($scope.statusVal[index]);
      $scope.searchData[index]['selectedstatus'] = $scope.statusVal[index];
      // console.log($scope.searchData);
    };

    //   $scope.populateEditUsersData = function (UserID) {
    //         angular.forEach($scope.searchData, function (arrayObj) {
    //             angular.forEach(arrayObj, function (userPropValue, userPropKey) {
    //                 if ((userPropKey === "UserID") && (userPropValue === UserID)) {
    //                     $scope.currentUser = arrayObj;
    //                 }
    //             });
    //         });
    //     };


    $scope.updateUsersData = function () {
      var reqObjArray = [], count = 0;
      console.log($scope.searchData);

      for (var i = 0; i < $scope.searchData.length; i++) {
        if ($scope.searchData[i].Selected) {
          count++;
          reqObjArray.push($scope.searchData[i]);
        }
      }
      if (count > 0) {
        searchUserService.updateUsersData(JSON.stringify(reqObjArray)).then(function (response) {
          //   console.log(response);
          if (response.status == "success") {
            $scope.statusUpdated = true;
          } else {
            $scope.statusUpdated = false;
          }
          $timeout(function () {
            $scope.statusUpdated = false;
          }, 10000);
          //   angular.forEach($scope.searchData, function(value,key){
          //       console.log(''+key);
          //       $scope.statusVal[''+key] = value['selectedstatus'];
          //   });            
        });
      }

      // angular.forEach($scope.searchData, function (arrayObj, index) {
      //     angular.forEach(arrayObj, function (userPropValue, userPropKey) {
      //         if ((userPropKey === "UserID") && (userPropValue === UserID)) {
      //             $scope.searchData[index].name = $scope.currentUser.name;
      //             $scope.searchData[index].email = $scope.currentUser.email;
      //             $scope.searchData[index].status = $scope.currentUser.status;

      //             angular.element('#editUserData').modal('hide');
      //         }
      //     });
      // });

    };



    // $scope.changeUserProfile = function(UserID){
    //     angular.forEach($scope.searchData, function (arrayObj, index) {
    //         angular.forEach(arrayObj, function (userPropValue, userPropKey) {
    //             if ((userPropKey === "UserID") && (userPropValue === UserID)) {
    //                 $scope.currentUser = arrayObj;

    //                $scope.moveToUpdate = false;

    //             }
    //         });
    //     });
    // };

    $scope.getHeaderDropDownList();


    /*$scope.getSearchUsersstatusDetails = function() {
        searchUserService.getSearchUsersstatusData().then(function(response){
            $scope.sample = response;
            console.log("123",$scope.items);        
        })
    }
    $scope.getSearchUsersstatusDetails();
    */


    //  $scope.toggleDisablingDropdown = function(){
    //     $scope.isDisable = $scope.checked;
    // };
    //   $scope.toggleDisablingDropdown();


    //   $scope.IsVisible = false;
    //   $scope.ShowHide = function () {
    //         //If DIV is visible it will be hidden and vice versa.
    //         $scope.IsVisible = true;
    //         $("html, body").animate({
    //             scrollTop: 0
    //         }, 600);
    //         return false;  
    //   }




  }
]);