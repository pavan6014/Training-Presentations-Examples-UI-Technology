myApp.service('searchUserService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	
	return ({
        getHeaderData: getHeaderData,
        getSearchUsersData:getSearchUsersData,
        getSearchData:getSearchData,
        updateUsersData: updateUsersData
    });
	

    function getHeaderData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/searchUser.json"
        });
        return (requester.then(headerDataSuccess,headerDataError));
    }
    function headerDataSuccess(response){
        return response.data;
    }
    function headerDataError(response){
        console.log("error message");
    }
    
	
    function getSearchUsersData(searchInput, searchIn){
        var reqObj = {
            "searchInput" : searchInput,
            "searchIn" : searchIn
        }
        var requester = $http({
            method:"POST",
            async:true,
            cache:false,
            data: reqObj,
            url:"/data/searchUser.json"
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
    
    
    
    function getSearchData(){
        var requesterData = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/searchUser.json"
        });
        return (requesterData.then(requesterSuccess,equesterError));
    }
    function requesterSuccess(response){
        return response.data;
    }
    function equesterError(response){
        console.log("error message");
    }
    
      
    
    
function updateUsersData(reqObjArray){
        var reqObj = JSON.parse(reqObjArray);
        console.log(reqObj);
        var requester = $http({
            method:"POST",
            async:true,
            cache:false,
            data: reqObj,
            url:"/data/searchUser.json"
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }

    
	/*
    
    function getSearchUsersStatusData(){
        var search = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/serchStatus.json"
        });
        return (search.then(searchSuccess,searchError));
    }
    function searchSuccess(response){
        return response.data;
    }
    function searchError(response){
        console.log("error message");
    }*/
	
}]);