myApp.controller('distributorProductsController', ['$rootScope', '$scope', '$location', '$window', 'distributorProductsService', function($rootScope, $scope, $location, $window, distributorProductsService) {	
	
	init();


	function init(){
		distributorProductsService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);