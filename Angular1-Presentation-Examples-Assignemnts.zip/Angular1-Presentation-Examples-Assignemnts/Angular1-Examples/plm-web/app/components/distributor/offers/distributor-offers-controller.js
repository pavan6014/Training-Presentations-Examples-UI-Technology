myApp.controller("distributorOffersController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "distributorService",
  function($rootScope, $scope, $location, $window, distributorService) {
//    $scope.showICOMSPublish = false;
//    $scope.showOMCPublish = false;
//    $scope.showPinPointPublish = false;
//    $scope.showECOMPublish = false;
//
//    if ($rootScope.subStreamValue === "ICOMS") {
//      $scope.showICOMSPublish = true;
//    } else if ($rootScope.subStreamValue === "OMC") {
//      $scope.showOMCPublish = true;
//    } else if ($rootScope.subStreamValue === "Pin Point") {
//      $scope.showPinPointPublish = true;
//    } else if ($rootScope.subStreamValue === "E-COM") {
//      $scope.showECOMPublish = true;
//    }

    $scope.disableOCMPublish = true;

    $scope.enableOCMPublish = function () {
      $scope.disableOCMPublish = false;
    }

    $scope.moveToICOMS = function () {
      $location.path("/icoms");
      $rootScope.resetSideBarHighlighted("icoms");
    };

    $scope.moveToOMC = function () {
      $location.path("/omc");
      $rootScope.resetSideBarHighlighted("omc");
    };

    $scope.moveToPinPoint = function () {
      $location.path("/pin-point");
      $rootScope.resetSideBarHighlighted("pin-point");
    };

    $scope.moveToECOM = function () {
      $location.path("/e-com");
      $rootScope.resetSideBarHighlighted("e-com");
    };
      
    $scope.moveToOMCUAT = function () {
      $location.path("/omcUATUsers");
      $rootScope.resetSideBarHighlighted("omcUATUsers");
    };
    
     $scope.moveToOMCProd = function () {
      $location.path("/distributorOMCProd");
      $rootScope.resetSideBarHighlighted("distributorOMCProd");
    };
      
      
      $scope.getOffersDetails = function() {
          distributorService.getOffersData().then(function(response){
              $scope.offers = response;
          })
      }
      
     
    $scope.getOffersDetails();
      
      
      
       $scope.getOMCDetails = function() {
          distributorService.getOMCTestData().then(function(response){
              $scope.omcTest = response;
          })
      }
      
     
    $scope.getOMCDetails();
      
     $scope.getUATDetails = function() {
          distributorService.getOMCUATData().then(function(response){
              $scope.uatData = response;
          })
      }
      
     
    $scope.getUATDetails();
      
      
      
//      $scope.status = {check1:'new',
//                    check2:'new',
//                    check3:'new',
//                    check4:'new',
//                    check5:'new',
//                    check6:'new',
//                    check7:'new'}
      
//       $scope.publishToDistributor = function(subStream) {
//          $rootScope.subStreamValue = subStream;
//          $location.path("/distributor");
//          $rootScope.resetSideBarHighlighted("distributor");
//    }
      
      

      
      

    /* Product to Service/Package Code Mapping auto complete function starts here */
    $scope.productItemsTable  = [];

    $scope.productItems  = [
      {
        "id": "1",
        "name": "Name 1" ,
        "type": "Type 1",
        "psu": "PSU 1",
        "packageCode":"Package Code 1"
      },
      {
        "id": "2",
        "name": "Name 2" ,
        "type": "Type 2",
        "psu": "PSU 2",
        "packageCode":"Package Code 2"
      },
      {
        "id": "3",
        "name": "Name 3" ,
        "type": "Type 3",
        "psu": "PSU 3",
        "packageCode":"package Code 3"
      }
    ];
    
    $scope.showAddProductError = false;

    $scope.productAddNew = function(item){
     var result = true;
     for (var i=0; i< $scope.productItemsTable.length; i++) {
      if (item.name === $scope.productItemsTable[i].name){
        result = false;
       }
     }
       if (result) {
        $scope.productItemsTable.push({ 
                'id': item.id, 
                'name': item.name,
                'type': item.type,
                "psu": item.psu,
                "packageCode": item.packageCode
            });
     $scope.showAddProductError = false;
      } else {
       $scope.showAddProductError = true;
      }
    };

    $scope.productRemoveRow = function (rowIndex) {
        $scope.productItemsTable.splice(rowIndex, 1);
    }
    /* Product to Service/Package auto complete function ends here */

      
      
                    
      
  }
]);