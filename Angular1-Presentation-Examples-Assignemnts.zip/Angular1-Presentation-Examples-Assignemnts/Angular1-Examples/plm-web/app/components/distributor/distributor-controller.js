myApp.controller("distributorController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  function($rootScope, $scope, $location, $window) {
    $scope.showDistributorProjectList = true;
    $scope.showDiscountsPage = false;
    $scope.showOfferPage = false;

    if ($rootScope.subStreamValue === "ICOMS") {
      $scope.showICOMSPublish = true;
    } else if ($rootScope.subStreamValue === "OMC") {
      $scope.showOMCPublish = true;
    } else if ($rootScope.subStreamValue === "Pin Point") {
      $scope.showPinPointPublish = true;
    } else if ($rootScope.subStreamValue === "E-COM") {
      $scope.showECOMPublish = true;
    }
    
    /* Show Success Message for OMC test queue Start here*/
    $scope.omcTestSubmitMessage = false;

    $scope.rleaseToTestSubmit = function(){
      $scope.omcTestSubmitMessage = true;
      $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;  
    };
    /* Show Success Message for OMC test queue ends here*/

     /* Show Success Message for OMC Prod Que Start here*/
    $scope.omcProdSubmitMessage = false;

    $scope.rleaseToProdSubmit = function(){
      $scope.omcProdSubmitMessage = true;
      $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;  
    };
    /* Show Success Message for OMC Prod Que ends here*/


    $scope.showDiscountsPageSec = function(){
    	$scope.showDistributorProjectList = false;
        $scope.showDiscountsPage = true;
        $scope.showOfferPage = false;
    }
    
    $scope.showOffersPage = function(){
    	$scope.showDistributorProjectList = false;
        $scope.showDiscountsPage = false;
        $scope.showOfferPage = true;
    }

    $scope.moveToICOMS = function () {
      $location.path("/icoms");
      $rootScope.resetSideBarHighlighted("icoms");
    };

    $scope.moveToOMC = function () {
      $location.path("/omc");
      $rootScope.resetSideBarHighlighted("omc");
    };

    $scope.moveToPinPoint = function () {
      $location.path("/pin-point");
      $rootScope.resetSideBarHighlighted("pin-point");
    };

    $scope.moveToECOM = function () {
      $location.path("/e-com");
      $rootScope.resetSideBarHighlighted("e-com");
    };
  }
]);