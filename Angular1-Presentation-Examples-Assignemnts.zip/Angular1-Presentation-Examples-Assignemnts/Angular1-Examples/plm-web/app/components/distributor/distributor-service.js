myApp.service('distributorService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	
	return ({
		getCreateNewProject : getCreateNewProject,
        getListOfFaq : getListOfFaq,
        getDiscountData : getDiscountData,
        getOffersData : getOffersData,
		setCurrentProjectToConfigure : setCurrentProjectToConfigure,
		getCurrentProjectToConfigure : getCurrentProjectToConfigure,
		setProjectToConfigureOffers : setProjectToConfigureOffers,
		getProjectToConfigureOffers : getProjectToConfigureOffers,
        getOMCTestData : getOMCTestData,
        getOMCUATData : getOMCUATData
    });
	
	function getListOfFaq(){
		 var request = $http({
            method: "GET",
            async: true,
            cache: false,
            url: "data/faq.json"
        });
        return (request.then(handleSuccess, handleError));
	}
	
	function handleSuccess(response){
		return response.data;
	}
	
	function handleError(response){
		console.log("error handling stratum info service");
	}
	
	function getCreateNewProject() {
		var projectRequest = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "/data/requestorAfterNewProject.json"
		});
		return (projectRequest.then(createSuccess, createError));
	}
	function createSuccess(response) {
		return response.data;
	}
	function createError(response) {
		console.log("error message");
	}
	
	 
    function getDiscountData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/discounts.json"
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
    
    function getOffersData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/offers.json"
        });
        return (requester.then(offerSuccess,offerError));
    }
    function offerSuccess(response){
        return response.data;
    }
    function offerError(response){
        console.log("error message");
    }
    
    var currentProjectToConfigure = "";

	function setCurrentProjectToConfigure(project) {
		currentProjectToConfigure = project;
	}

	function getCurrentProjectToConfigure() {
		return currentProjectToConfigure;
	}


	var projectToConfigureOffers = "";

	function setProjectToConfigureOffers(project) {
		projectToConfigureOffers = project;
	}

	function getProjectToConfigureOffers() {
		return projectToConfigureOffers;
	}
    
  function getOMCTestData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/distributorOMC.json"
        });
        return (requester.then(omcSuccess,omcError));
    }
    function omcSuccess(response){
        return response.data;
    }
    function omcError(response){
        console.log("error message");
    }
    
    function getOMCUATData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/omcUAT.json"
        });
        return (requester.then(uatSuccess,uatError));
    }
    function uatSuccess(response){
        return response.data;
    }
    function uatError(response){
        console.log("error message");
    }
    
	
	
}]);