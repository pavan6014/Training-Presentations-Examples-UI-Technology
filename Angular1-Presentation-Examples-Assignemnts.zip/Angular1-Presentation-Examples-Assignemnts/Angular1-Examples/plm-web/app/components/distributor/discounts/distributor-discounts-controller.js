myApp.controller("distributorDiscountsController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "distributorService",
  function($rootScope, $scope, $location, $window,distributorService) {
//    $scope.showICOMSPublish = false;
//    $scope.showOMCPublish = false;
//    $scope.showPinPointPublish = false;
//    $scope.showECOMPublish = false;
//
//    if ($rootScope.subStreamValue === "ICOMS") {
//      $scope.showICOMSPublish = true;
//    } else if ($rootScope.subStreamValue === "OMC") {
//      $scope.showOMCPublish = true;
//    } else if ($rootScope.subStreamValue === "Pin Point") {
//      $scope.showPinPointPublish = true;
//    } else if ($rootScope.subStreamValue === "E-COM") {
//      $scope.showECOMPublish = true;
//    }

    $scope.disableICOMSPublish = true;

    $scope.enableICOMSPublish = function(){
      $scope.disableICOMSPublish = false;
    }

    $scope.moveToICOMS = function () {
      $location.path("/icoms");
      $rootScope.resetSideBarHighlighted("icoms");
    };

    $scope.moveToOMC = function () {
      $location.path("/omc");
      $rootScope.resetSideBarHighlighted("omc");
    };

    $scope.moveToPinPoint = function () {
      $location.path("/pin-point");
      $rootScope.resetSideBarHighlighted("pin-point");
    };

    $scope.moveToECOM = function () {
      $location.path("/e-com");
      $rootScope.resetSideBarHighlighted("e-com");
    };
      
    
      $scope.getDiscountsDetails = function() {
          distributorService.getDiscountData().then(function(response){
              $scope.discounts = response;
          })
      }
      
     
    $scope.getDiscountsDetails();
      
      
      
    //$scope.status = "New";
      
//    $scope.status = {check1:'new',
//                    check2:'new',
//                    check3:'new',
//                    check4:'new',
//                    check5:'new',
//                    check6:'new',
//                    check7:'new'}
                    
    
//       $scope.publishToDistributor = function(subStream) {
//          $rootScope.subStreamValue = subStream;
//          $location.path("/distributor");
//          $rootScope.resetSideBarHighlighted("distributor");
//      }
      
  }
]);