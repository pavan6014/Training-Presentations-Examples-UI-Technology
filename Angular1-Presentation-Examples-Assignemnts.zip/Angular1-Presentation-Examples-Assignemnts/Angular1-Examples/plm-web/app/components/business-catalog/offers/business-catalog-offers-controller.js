myApp.controller('businessOffersController', ['$rootScope', '$scope', '$location', '$window', 'businessOffersService', function($rootScope, $scope, $location, $window, businessOffersService) {	
	
	init();


	function init(){
		businessOffersService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);