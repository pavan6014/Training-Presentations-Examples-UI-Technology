myApp.controller('businessProductsController', ['$rootScope', '$scope', '$location', '$window', 'businessProductsService', function($rootScope, $scope, $location, $window, businessProductsService) {	
	
	init();


	function init(){
		businessProductsService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);