myApp.controller('businessDiscountsController', ['$rootScope', '$scope', '$location', '$window', 'businessDiscountsService', function($rootScope, $scope, $location, $window, businessDiscountsService) {	
	
	init();


	function init(){
		businessDiscountsService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);