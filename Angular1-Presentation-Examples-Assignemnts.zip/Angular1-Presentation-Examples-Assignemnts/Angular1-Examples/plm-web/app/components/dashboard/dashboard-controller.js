myApp.controller('dashboardController', ['$rootScope', '$scope', '$location', '$window', 'dashboardService', function($rootScope, $scope, $location, $window, dashboardService) {	
	
	init();
	
	function init(){
		//dashboardService.getListOfUserRoles().then(handleSuccess, handleError)
	}
	
	/*function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}*/

	$scope.showRequestor= function(){
		$location.path("/requestor");
		$rootScope.resetSideBarHighlighted("requestor");
	};
	
	$scope.showConfigurator = function() {
		$location.path("/configurator");
		$rootScope.resetSideBarHighlighted("configurator");
	};

	$scope.showDistributor = function() {
		$location.path("/distributor");
		$rootScope.resetSideBarHighlighted("distributor");
	};
	
	$scope.showICOMS = function() {
		$location.path("/icoms");
		$rootScope.resetSideBarHighlighted("icoms");
	};
	
	$scope.showOMC = function() {
		$location.path("/omc");
		$rootScope.resetSideBarHighlighted("omc");
	};
  
	$scope.showPinPoint = function() {
		$location.path("/pin-point");
		$rootScope.resetSideBarHighlighted("pin-point");
  	};

	$scope.showECOM = function () {
		$location.path("/e-com");
		$rootScope.resetSideBarHighlighted("e-com");
	};
    
 
Highcharts.setOptions({
    colors: ['#058DC7', '#ED561B','#DBD9B1','#50B432']
});

 // Create the Project Status chart
    
    
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Project Status'
    },
//    subtitle: {
//        text: 'Click columns to drill down to single series. Click categories to drill down both.'
//    },
    xAxis: {
        type: 'category'
    },

    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true
            }
        }
    },
    
    
    




    series: [{
        name: 'NEW',
        data: [{
            name: 'New Offer Creation',
            y: 5,
            drilldown: 'New Offer Creation'
        }, {
            name: 'Offer Extension',
            y: 2,
            drilldown: 'Offer Extension'
        }, {
            name: 'Offer Expiration',
            y: 3,
            drilldown: 'Offer Expiration'
        }, {
            name: 'Offer Attributes Modification',
            y: 8,
            drilldown: 'Offer Attributes Modification'
        }, {
            name: 'Offer Pricing Change',
            y: 6,
            drilldown: 'Offer Pricing Change'
        }]
    }, {
        name: 'WIP',
        data: [{
            name: 'New Offer Creation',
            y: 8,
            drilldown: 'New Offer Creation'
        }, {
            name: 'Offer Extension',
            y: 3,
            drilldown: 'Offer Extension'
        }, {
            name: 'Offer Expiration',
            y: 6,
            drilldown: 'Offer Expiration'
        }, {
            name: 'Offer Attributes Modification',
            y: 2,
            drilldown: 'Offer Attributes Modification'
        }, {
            name: 'Offer Pricing Change',
            y: 4,
            drilldown: 'Offer Pricing Change'
        }]
    }, {
        name: 'WIP-Configurator-Distributor',
        data: [{
            name: 'New Offer Creation',
            y: 8,
            drilldown: 'New Offer Creation'
        }, {
            name: 'Offer Extension',
            y: 4,
            drilldown: 'Offer Extension'
        }, {
            name: 'Offer Expiration',
            y: 6,
            drilldown: 'Offer Expiration'
        }, {
            name: 'Offer Attributes Modification',
            y: 5,
            drilldown: 'Offer Attributes Modification'
        }, {
            name: 'Offer Pricing Change',
            y: 2,
            drilldown: 'Offer Pricing Change'
        }]
    },
//             {
//        name: 'WIP',
//        data: [{
//            name: 'New Offer Creation',
//            y: 4,
//            drilldown: 'New Offer Creation'
//        }, {
//            name: 'Offer Extension',
//            y: 3,
//            drilldown: 'Offer Extension'
//        }, {
//            name: 'Offer Expiration',
//            y: 8,
//            drilldown: 'Offer Expiration'
//        }, {
//            name: 'Offer Attributes Modification',
//            y: 7,
//            drilldown: 'Offer Attributes Modification'
//        }, {
//            name: 'Offer Pricing Change',
//            y: 9,
//            drilldown: 'Offer Pricing Change'
//        }]
//    }, 
    {
        name: 'COMPLETED',
        data: [{
            name: 'New Offer Creation',
            y: 5,
            drilldown: 'New Offer Creation'
        }, {
            name: 'Offer Extension',
            y: 4,
            drilldown: 'Offer Extension'
        }, {
            name: 'Offer Expiration',
            y: 8,
            drilldown: 'Offer Expiration'
        }, {
            name: 'Offer Attributes Modification',
            y: 2,
            drilldown: 'Offer Attributes Modification'
        }, {
            name: 'Offer Pricing Change',
            y: 3,
            drilldown: 'Offer Pricing Change'
        }]
    }],
    drilldown: {
        series: [{
            id: 'New Offer Creation',
            data: [
                ['East', 4],
                ['West', 2],
                ['North', 1],
                ['South', 4]
            ]
        }, {
            id: 'Offer Extension',
            data: [
                ['East', 6],
                ['West', 2],
                ['North', 2],
                ['South', 4]
            ]
        }, {
            id: 'Offer Expiration',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        },{
            id: 'Offer Attributes Modification',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        },{
            id: 'Offer Pricing Change',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        }, {
            id: 'New Offer Creation',
            data: [
                ['East', 2],
                ['West', 4],
                ['North', 1],
                ['South', 7]
            ]
        }, {
            id: 'Offer Extension',
            data: [
                ['East', 4],
                ['West', 2],
                ['North', 5],
                ['South', 3]
            ]
        }, {
            id: 'Offer Expiration',
            data: [
                ['East', 7],
                ['West', 8],
                ['North', 2],
                ['South', 2]
            ]
        },{
            id: 'Offer Attributes Modification',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        },{
            id: 'Offer Pricing Change',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        }, {
            id: 'New Offer Creation',
            data: [
                ['East', 2],
                ['West', 4],
                ['North', 1],
                ['South', 7]
            ]
        }, {
            id: 'Offer Extension',
            data: [
                ['East', 4],
                ['West', 2],
                ['North', 5],
                ['South', 3]
            ]
        }, {
            id: 'Offer Expiration',
            data: [
                ['East', 7],
                ['West', 8],
                ['North', 2],
                ['South', 2]
            ]
        },{
            id: 'Offer Attributes Modification',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        },{
            id: 'Offer Pricing Change',
            data: [
                ['East', 2],
                ['West', 7],
                ['North', 3],
                ['South', 2]
            ]
        }]
    }
});


//Highcharts.chart('container', {
//    chart: {
//        type: 'column'
//    },
//    title: {
//        text: 'Project Status'
//    },
////    subtitle: {
////        text: 'Click the columns to view versions. Source: <a href="http://netmarketshare.com">netmarketshare.com</a>.'
////    },
//    xAxis: {
//        type: 'category'
//    },
//    yAxis: {
////        title: {
////            text: 'Total percent market share'
////        }
//
//    },
//    legend: {
//        enabled: false
//    },
//    plotOptions: {
//        series: {
//            borderWidth: 0,
//            dataLabels: {
//                enabled: true
////                format: '{point.y:.1f}%'
//            }
//        }
//    },
//
//    tooltip: {
//        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
//        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:,.0f}</b> of total<br/>'
//    },
//
//    series: [{
//        name: 'Offers',
//        colorByPoint: true,
//        data: [{
//            name: 'New',
//            y: 70,
//            drilldown: 'New'
//        }, {
//            name: 'In Progress',
//            y: 24,
//            drilldown: 'In Progress'
//        }, {
//            name: 'Completed',
//            y: 50,
//            drilldown: 'Completed'
//        }]
//    }],
//    drilldown: {
//        series: [{
//            name: 'New',
//            id: 'New',
//            data: [
//                [
//                    'v11.0',
//                    13
//                ],
//                [
//                    'v8.0',
//                    2
//                ],
//                [
//                    'v9.0',
//                    11
//                ],
//                [
//                    'v10.0',
//                    33
//                ],
//                [
//                    'v6.0',
//                    6
//                ],
//                [
//                    'v7.0',
//                    5
//                ]
//            ]
//        }, {
//            name: 'In Progress',
//            id: 'In Progress',
//            data: [
//                [
//                    '1.0',
//                    15
//                ],
//                [
//                    '2.0',
//                    32
//                ],
//                [
//                    '32.0',
//                    68
//                ],
//                [
//                    '4.0',
//                    96
//                ],
//                [
//                    '5.0',
//                    53
//                ],
//                [
//                    '6.0',
//                    45
//                ],
//                [
//                    '7.0',
//                    24
//                ],
//                [
//                    '8.0',
//                    85
//                ],
//                [
//                    '9.0',
//                    6
//                ],
//                [
//                    '10.0',
//                    55
//                ],
//                [
//                    '11.0',
//                    38
//                ],
//                [
//                    'v33.0',
//                    0.19
//                ],
//                [
//                    '12.0',
//                    14
//                ],
//                [
//                    '13.0',
//                    14
//                ]
//            ]
//        }, {
//            name: 'Completed',
//            id: 'Completed',
//            data: [
//                [
//                    '1',
//                    10
//                ],
//                [
//                    '2',
//                    30
//                ],
//                [
//                    '3',
//                    20
//                ],
//                [
//                    '4',
//                    40
//                ],
//                [
//                    '5',
//                    50
//                ],
//                [
//                    '6',
//                    60
//                ],
//                [
//                    '7',
//                    70
//                ],
//                [
//                    '8',
//                    80
//                ]
//            ]
//        }]
//    }
//});
    
//Pie Chart Offer Status 
Highcharts.setOptions({
    colors: ['#FFC000', '#058DC7', '#50B432', '#24CB35']
});

    Highcharts.chart('container1', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Offers Status'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:,.0f}',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'Offers',
        colorByPoint: true,
        data: [{
            name: 'Draft',
            y: 56
        }, {
            name: 'Ready For Test',
            y: 24,
            sliced: true,
            selected: true
        }, {
            name: 'Ready For Publish',
            y: 10
        }, {
            name: 'Published',
            y: 4
        }]
    }]
});

    
    
//Pie Chart Campaign Status 
Highcharts.setOptions({
    colors: ['#FFC000', '#058DC7', '#50B432', '#ED561B','#24CB35']
}); 

    Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Discount Status'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:,.0f}</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:,.0f}',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'Discount',
        colorByPoint: true,
        data: [{
            name: 'Draft',
            y: 56
        }, {
            name: 'ICOMS WIP',
            y: 24,
            sliced: true,
            selected: true
        }, {
            name: 'ICOMS Confirmed',
            y: 10
        }, {
            name: 'Completed',
            y: 4
        }]
    }]
});

    
//Pie Chart Campaign Status 
Highcharts.setOptions({
    colors: ['#FFC000','#50B432']
});

    Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Product Status'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:,.0f}</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:,.0f}',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'Product',
        colorByPoint: true,
        data: [{
            name: 'Draft',
            y: 56
        }, {
            name: 'Completed',
            y: 4
        }]
    }]
});
    
//    $rootScope.resetSideBarHighlighted("dashboard");
    
    
}]);