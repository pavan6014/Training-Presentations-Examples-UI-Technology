myApp.service('dashboardService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	return ({
        getListOfUserRoles: getListOfUserRoles,
        getChartData: getChartData
    });
	
	function getListOfUserRoles(){
		 var request = $http({
            method: "GET",
            async: true,
            cache: false,
            url: "data/userRole.json"
        });
        return (request.then(handleSuccess, handleError));
	}
	
	function handleSuccess(response){
		return response.data;
	}
	
	function handleError(response){
		console.log("error handling stratum info service");
	}
	
	
    function getChartData() {
        var request = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"data/dashBoard.json"
        });
        return (request.then(dataSuccess,dataError));
        
    }
    
    function dataSuccess(response){
        return response.data;
    }
    
    function dataError(response){
        console.log("error handling the chart data");
    }
    
    
}]);