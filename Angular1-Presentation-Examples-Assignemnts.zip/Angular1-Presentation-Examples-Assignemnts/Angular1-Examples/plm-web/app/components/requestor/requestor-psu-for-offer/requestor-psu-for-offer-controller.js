myApp.controller("requestorPSUForOfferController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "$q",
    "requestorService",
    function ($rootScope, $scope, $location, $window, $q, requestorService) {

        $rootScope.psuUnderProject = {
            "projectID": "",
            "psu": {
                "1P": [],
                "2P": [],
                "3P": [],
                "4P": []
            }
        };

        $scope.cols1 = "";
        $scope.cols2 = "";
        $scope.cols3 = "";
        $scope.cols4 = "";

        $scope.products = ['DATA', 'PHONE', 'VIDEO', 'HOMELIFE'];
        $scope.psu1PArray = [];
        $scope.psu2PArray = [];
        $scope.psu3PArray = [];
        $scope.psu4PArray = [];
        $scope.psu1PArrayEmpty = [0,1,2,3,4,5];
        $scope.psu2PArrayEmpty = [0,1,2,3,4,5];
        $scope.psu3PArrayEmpty = [0,1,2,3,4,5];
        $scope.psu4PArrayEmpty = [0,1,2,3,4,5];
        $scope.psuForOfferTableHeaderCount = [0,1,2,3,4,5];

        $scope.makeArray = function (type, cols) {
//        	if (cols > $scope.psuForOfferTableHeaderCount) {
//        		var count=0;
//        		$scope.psuForOfferTableHeaderCount = [];
//        		for (var i=0; i<cols; i++) {
//        			$scope.psuForOfferTableHeaderCount.push(count++);
//        		}
//        	} else {
//        		$scope.psuForOfferTableHeaderCount = [0,1,2,3,4,5];;
//        	}
            type = type.toUpperCase();
            // //console.log(type + " " + cols)
            switch (type) {
                case '1P':
                    $scope.psu1PArray = [];
                    $scope.psu1PArrayEmpty = [];
                    createArray(type, $scope.psu1PArray, $scope.psu1PArrayEmpty, cols);
                    break;
                case '2P':
                    $scope.psu2PArray = [];
                    $scope.psu2PArrayEmpty = [];
                    createArray(type, $scope.psu2PArray, $scope.psu2PArrayEmpty, cols);
                    break;
                case '3P':
                    $scope.psu3PArray = [];
                    $scope.psu3PArrayEmpty = [];
                    createArray(type, $scope.psu3PArray, $scope.psu3PArrayEmpty, cols);
                    break;
                case '4P':
                    $scope.psu4PArray = [];
                    $scope.psu4PArrayEmpty = [];
                    createArray(type, $scope.psu4PArray, $scope.psu4PArrayEmpty, cols);
                    break;
            }

        }
        function createArray(type, arr, emptyArr, cols) {
            for (var i = 0; i < parseInt(cols); i++) {
                arr.push(i);
                var psuForOfferObj = {
                    "offerID": "",
                    "addMarketingOfferConfigured": false,
                    "addOfferConfigured": false,
                    "psuType": "",
                    "psuData": [],
                    "currentPSUForForm" : false
                };
                psuForOfferObj.psuData = {};
                if (type === "1P") {
                    psuForOfferObj.psuData['1'] = "";
                } else if (type === "2P") {
                    psuForOfferObj.psuData['1'] = "";
                    psuForOfferObj.psuData['2'] = "";
                } else if (type === "3P") {
                    psuForOfferObj.psuData['1'] = "";
                    psuForOfferObj.psuData['2'] = "";
                    psuForOfferObj.psuData['3'] = "";
                } else if (type === "4P") {
                    psuForOfferObj.psuData['1'] = "DATA";
                    psuForOfferObj.psuData['2'] = "PHONE";
                    psuForOfferObj.psuData['3'] = "VIDEO";
                    psuForOfferObj.psuData['4'] = "HOMELIFE";
                }
                $rootScope.psuUnderProject.psu[type].push(psuForOfferObj);
            }
            for (var j = 0; j < (parseInt(6) - parseInt(cols)); j++) {
                emptyArr.push(j);
            }
            $scope.updatePSUForOfferObj();
        }
        
        $scope.submitRequestorProject = function(){
        	$scope.goToDashboard();
        }

        $scope.disableNextButton = false;

        $scope.updatePSUForOfferObj = function () {
            var result = false, keepGoing = true;
            if (($scope.cols1 === "") || ($scope.cols2 === "") || ($scope.cols3 === "") || ($scope.cols4 === "")) {
                $scope.disableNextButton = true;
            }
            if (keepGoing) {
                angular.forEach($rootScope.psuUnderProject.psu, function (psuTypeArray, psuTypeShort) {
                    for (var i = 0; i < psuTypeArray.length; i++) {
                        angular.forEach(psuTypeArray[i], function (psuArrayPropValue, psuArrayPropKey) {
                            if ((psuTypeShort === "1P") && (psuTypeArray[i]['psuData']['1'] === "")) {
                                $scope.disableNextButton = true;
                                keepGoing = false;
                            } else if ((psuTypeShort === "2P") && ((psuTypeArray[i]['psuData']['1'] === "") || (psuTypeArray[i]['psuData']['2'] === ""))) {
                                $scope.disableNextButton = true;
                                keepGoing = false;
                            } else if ((psuTypeShort === "3P") && ((psuTypeArray[i]['psuData']['1'] === "") || (psuTypeArray[i]['psuData']['2'] === "") || (psuTypeArray[i]['psuData']['3'] === ""))) {
                                $scope.disableNextButton = true;
                                keepGoing = false;
                            } else {
                                $scope.disableNextButton = false;
                            }
                        });
                    }
                });
            }
        }

        $scope.updatePSUForOfferObj();
        
        $scope.callShowOffersPSUFormSec = function (
        	      psuType,
        	      productType,
        	      index,
        	      offerID,
        	      psuHeader,
        	      showDataField,
        	      showPhoneField,
        	      showVideoField,
        	      showHomeLifeField
        	    ) {
        	      console.log(JSON.parse(JSON.stringify($rootScope.psu)));
        	      $rootScope.currentPSUTypeForForm = psuType;
        	      $rootScope.currentProductTypeForForm = productType;
        	      $rootScope.currentPSUForFormIndex = index;
        	      $rootScope.currentPSUTypeOfferIDForForm = offerID;
        	      $rootScope.psu[psuType][productType][index]['addMarketingOfferConfigured'] = true;
        	      console.log(JSON.parse(JSON.stringify($rootScope.psu)));
        	      $scope.showOffersPSUFormSec(psuType,
                	      productType,
                	      index,
                	      offerID,
                	      psuHeader,
                	      showDataField,
                	      showPhoneField,
                	      showVideoField,
                	      showHomeLifeField);
        };

        $scope.categorizePSUForOfferObject = function () {
            angular.forEach($rootScope.psuUnderProject.psu, function (psuTypeArray, psuTypeShort) {
                for (var i = 0; i < psuTypeArray.length; i++) {
                    angular.forEach(psuTypeArray[i], function (psuArrayPropValue, psuArrayPropKey) {
                        if (psuTypeShort === "1P") {
                            $rootScope.psuUnderProject.psu[psuTypeShort][i]['psuType'] = psuTypeArray[i]['psuData']['1'];
                        } else if (psuTypeShort === "2P") {
                            var psuTypeData = getPSUTypeDef(psuTypeArray[i]['psuData']['1'] + "_" + psuTypeArray[i]['psuData']['2']);
                            $rootScope.psuUnderProject.psu[psuTypeShort][i]['psuType'] = psuTypeData;
                        } else if (psuTypeShort === "3P") {
                            var psuTypeData = getPSUTypeDef(psuTypeArray[i]['psuData']['1'] + "_" + psuTypeArray[i]['psuData']['2'] + "_" + psuTypeArray[i]['psuData']['3']);
                            $rootScope.psuUnderProject.psu[psuTypeShort][i]['psuType'] = psuTypeData;
                        } else if (psuTypeShort === "4P") {
                            $rootScope.psuUnderProject.psu[psuTypeShort][i]['psuType'] = "ALL";
                        }
                    });
                }
                requestorService.setProjectToConfigureOffers($rootScope.psuUnderProject);
                //console.log($rootScope.psuUnderProject);
            });
            $rootScope.psuUnderProject.projectID = $rootScope.projectForConfigure.ProjectCode;
            loadInit();
        }

        var getPSUTypeDef = function (psuTypeString) {
            var result = "", keepGoing = true;;
            angular.forEach(dataMapping, function (dataMappingValue, dataMappingKey) {
                if (keepGoing) {
                    if (dataMappingValue.indexOf(psuTypeString) > -1) {
                        result = dataMappingKey;
                        keepGoing = false;
                    }
                }
            });
            return result;
        }

        var dataMapping = {
            "DATA_PHONE": ["DATA_PHONE", "PHONE_DATA"],
            "DATA_VIDEO": ["DATA_VIDEO", "VIDEO_DATA"],
            "DATA_HOMELIFE": ["DATA_HOMELIFE", "HOMELIFE_DATA"],
            "PHONE_VIDEO": ["PHONE_VIDEO", "VIDEO_PHONE"],
            "PHONE_HOMELIFE": ["PHONE_HOMELIFE", "HOMELIFE_PHONE"],
            "VIDEO_HOMELIFE": ["VIDEO_HOMELIFE", "HOMELIFE_VIDEO"],
            "VIDEO_HOMELIFE": ["VIDEO_HOMELIFE", "HOMELIFE_VIDEO"],
            "DATA_PHONE_VIDEO": ["DATA_PHONE_VIDEO", "DATA_VIDEO_PHONE", "PHONE_DATA_VIDEO", "PHONE_VIDEO_DATA", "VIDEO_PHONE_DATA", "VIDEO_DATA_PHONE"],
            "DATA_PHONE_HOMELIFE": ["DATA_PHONE_HOMELIFE", "DATA_HOMELIFE_PHONE", "PHONE_DATA_HOMELIFE", "PHONE_HOMELIFE_DATA", "HOMELIFE_PHONE_DATA", "HOMELIFE_DATA_PHONE"],
            "DATA_VIDEO_HOMELIFE": ["DATA_VIDEO_HOMELIFE", "DATA_HOMELIFE_VIDEO", "VIDEO_DATA_HOMELIFE", "VIDEO_HOMELIFE_DATA", "HOMELIFE_VIDEO_DATA", "HOMELIFE_DATA_VIDEO"],
            "PHONE_VIDEO_HOMELIFE": ["PHONE_VIDEO_HOMELIFE", "PHONE_HOMELIFE_VIDEO", "VIDEO_PHONE_HOMELIFE", "VIDEO_HOMELIFE_PHONE", "HOMELIFE_VIDEO_PHONE", "HOMELIFE_PHONE_VIDEO"]
        };

        //code for Offer Under controllers

        $rootScope.psuUnderProjectID = "";
        $rootScope.psu = {
            "1P": { "DATA": [], "PHONE": [], "VIDEO": [], "HOMELIFE": [], "colSpan": 0 },
            "2P": { "DATA_PHONE": [], "DATA_VIDEO": [], "DATA_HOMELIFE": [], "PHONE_VIDEO": [], "PHONE_HOMELIFE": [], "VIDEO_HOMELIFE": [], "colSpan": 0 },
            "3P": { "DATA_PHONE_VIDEO": [], "DATA_PHONE_HOMELIFE": [], "DATA_VIDEO_HOMELIFE": [], "PHONE_VIDEO_HOMELIFE": [], "colSpan": 0 },
            "4P": { "ALL": [] }
        };
        $scope.rowCount = 0;

        $scope.checkIfArrayElementExist = function (psuType, productType, index) {
            var result = false;
            if ((typeof $rootScope.psu[psuType][productType][index] !== "undefined") && ($rootScope.psu[psuType][productType][index] !== null)) {
                $rootScope.psu[psuType][productType][index] = {};
                result = true;
            }
            return result;
        }

        $scope.getNumber = function (num) {
            return new Array(num);
        }

        $scope.showNextToConfiguratorButton = function () {
            var result = true;
            // //console.log(JSON.stringify($rootScope.psu));
            // //console.log(JSON.parse(JSON.stringify($rootScope.psu)));
            var currentPSUObj = JSON.parse(JSON.stringify($rootScope.psu));
            angular.forEach(currentPSUObj, function (psuDef, psuType) {
                // //console.log(psuDef);
                angular.forEach(psuDef, function (productArray, product) {
                    // //console.log(productArray);
                    if ((productArray != null) && (productArray.length > 0)) {
                        for (var i=0; i< productArray.length; i++) {
                            var currentProduct = JSON.parse(JSON.stringify(productArray[i]));
                            //console.log(currentProduct);
                            if (!currentProduct.addMarketingOfferConfigured) {
                                result= false;
                            }
                        }
                    }
                });
            });
            return (result == false ? true : false);
        }

        function loadInit() {
            var reqObj = {
                "projectID": "GTM2B2017_1"
            }
            //console.log($rootScope.psuUnderProject);
            // //console.log();
            var psuUnderProjectData = JSON.parse(JSON.stringify($rootScope.psuUnderProject));
            //console.log(psuUnderProjectData);
            manipulatePSUUnderProjectData(psuUnderProjectData);
            // requestorService.getPSUUnderProject(reqObj).then(function (reponseObj) {
            //   manipulatePSUUnderProjectData(reponseObj);
            // }, function (errorObj) {
            //   //console.log(errorObj);
            // });

        }


        function manipulatePSUUnderProjectData(responseObj) {
            // //console.log($rootScope.psu);
            $rootScope.psuUnderProjectID = responseObj.projectID;
            var loopPromises = [];
            angular.forEach(responseObj.psu, function (value, key) {
            	var deferred1 = $q.defer();
            	loopPromises.push(deferred1.promise);
            	for (var i=0; i<value.length; i++) {
            		 var currentArrayElement = value[i];
            		 angular.forEach(currentArrayElement, function (psuPropValue, psuPropKey) {
                         // //console.log(psuPropKey + " <--> " + psuPropValue);
                         if ((psuPropKey === "psuType") && (psuPropValue !== "")) {
                         	//console.log(psuPropKey + " <--> " + psuPropValue);
                             // //console.log(JSON.parse(JSON.stringify(currentArrayElement)));
                             // //console.log($rootScope.psu[key][psuPropValue]);
                             // //console.log(typeof $rootScope.psu[key][psuPropValue]);
                             $rootScope.psu[key][psuPropValue][$rootScope.psu[key][psuPropValue].length] = (JSON.parse(JSON.stringify(currentArrayElement)));
                             // //console.log(JSON.parse(JSON.stringify($rootScope.psu[key][psuPropValue])));
                             // //console.log(JSON.parse(JSON.stringify($rootScope.psu)));
                         }
                     });
            	}
//                angular.forEach(value, function (array) {
                   
                    
//                });
                deferred1.resolve();
                // //console.log($rootScope.psu);
            });
            $q.all(loopPromises).then(function () {
                //console.log('forEach loop completed. Do Something after it...');
                updateUIDatas();
            });
            
        }

        function updateUIDatas() {
        	var loopPromises = [];
            angular.forEach($rootScope.psu, function (psuDef, psuType) {
            	var deferred1 = $q.defer();
            	loopPromises.push(deferred1.promise);
                angular.forEach(psuDef, function (productArray, product) {
                    if (productArray.length > $scope.rowCount) {
                        $scope.rowCount = productArray.length;
                    }
                    if (productArray.length > 0) {
                        ++$rootScope.psu[psuType]["colSpan"];
                    }
                });
                deferred1.resolve();
            });
            $q.all(loopPromises).then(function () {
            	console.log("*************");
            	console.log(JSON.parse(JSON.stringify($rootScope.psu)));
            	console.log("*************");
            	$scope.showOfferUnderProject();
            });
            // //console.log($scope.psu);
            // //console.log($scope.rowCount);
        }
    }
]);
