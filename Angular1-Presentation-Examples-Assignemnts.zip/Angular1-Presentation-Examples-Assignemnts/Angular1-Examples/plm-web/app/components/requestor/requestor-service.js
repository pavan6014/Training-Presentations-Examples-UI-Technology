myApp.service('requestorService', ['$rootScope', '$http', '$q', function ($rootScope, $http, $q) {
	return { 
		getProjectDropDown: getProjectDropDown,
		getMarketDropDown: getMarketDropDown, 
		isSubmittedFromICOMS: isSubmittedFromICOMS, 
		setisSubmittedFromICOMS: setisSubmittedFromICOMS, 
		getisSubmittedFromICOMS: getisSubmittedFromICOMS,
        getRequesterData: getRequesterData,
        getRequesterModelData: getRequesterModelData,
		getPSUUnderProject: getPSUUnderProject,
		getCreateNewProject: getCreateNewProject,
		getPSUFormData: getPSUFormData,
		setCurrentProjectToConfigure: setCurrentProjectToConfigure,
		getCurrentProjectToConfigure: getCurrentProjectToConfigure,
		setProjectToConfigureOffers: setProjectToConfigureOffers,
		getProjectToConfigureOffers: getProjectToConfigureOffers
	};

	var isSubmittedFromICOMS = false;

	function setisSubmittedFromICOMS(value) {
		isSubmittedFromICOMS = value;
	}

	function getisSubmittedFromICOMS(value) {
		return isSubmittedFromICOMS;
	}

	function getProjectDropDown() {
		var request = $http({
			method: "GET",
			async: true,
			cache: false,
			url: "data/project-drop-down.json"
		});
		return (request.then(handleSuccess, handleError));
	}

	function getMarketDropDown() {
		var request = $http({
			method: "GET",
			async: true,
			cache: false,
			url: "data/market-drop-down.json"
		});
		return (request.then(handleSuccess, handleError));
	}

	function handleSuccess(response) {
		return response.data;
	}

	function handleError(response) {
		console.log("error handling stratum info service");
	}
    
    function getRequesterData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/requestor.json"
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
    
   
    
    function getCreateNewProject(){
        var projectRequest = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/requestorAfterNewProject.json"
        });
        return (projectRequest.then(createSuccess,createError));
    }
    function createSuccess(response){
        return response.data;
    }
    function createError(response){
        console.log("error message");
    }
    
    
    
    
    function getRequesterModelData(){
        var requestorModel = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/requestorModel.json"
        });
        return (requestorModel.then(modelSuccess,modelError));
    }
    function modelSuccess(response){
        return response.data;
    }
    function modelError(response){
        console.log("Model is wrong");
	}
//    
//    function getNewProjectRequesteData(){
//        var newRequestData = $http({
//            method:"GET",
//            async:true,
//            cache:false,
//            url:"/data/newProjectRequest.json"
//        });
//        return (newRequestData.then(newSuccess,newError));
//    }
//    function newSuccess(response){
//        return response.data;
//    }
//    function newError(response){
//        console.log("Model is wrong");
//	}
//	
	function getPSUUnderProject(reqObj) {
		var request = $http({
			method: "GET",
			async: true,
			cache: false,
			data: reqObj,
			url: api_urls.PSUUNDERPROJECT
		});
		return (request.then(handlePSUUnderProjSuccess, handlePSUUnderProjError));
	}

	function handlePSUUnderProjSuccess(response) {
		return response.data;
	}

	function handlePSUUnderProjError(response) {
		console.log("error handling");
	}

	function getPSUFormData() {
		var requester = $http({
			method: "GET",
			async: true,
			cache: false,
			url: "/data/psuForm.json"
		});
		return (requester.then(psuFormDataSuccess, psuFormDataError));
	}
	function psuFormDataSuccess(response) {
		return response.data;
	}
	function psuFormDataError(response) {
		console.log("error message");
	}

	var currentProjectToConfigure = "";

	function setCurrentProjectToConfigure(project) {
		currentProjectToConfigure = project;
	}

	function getCurrentProjectToConfigure() {
		return currentProjectToConfigure;
	}


	var projectToConfigureOffers = "";

	function setProjectToConfigureOffers(project) {
		projectToConfigureOffers = project;
	}

	function getProjectToConfigureOffers() {
		return projectToConfigureOffers;
	}

	// function submitMarketingOfferForm(reqObj) {
	// 	var request = $http({
	// 		method: 'POST',
	// 		url: "/",
	// 		data: reqObj,
	// 		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
	// 		async: true,
	// 		cache: false
	// 	});
	// 	return (request.then(handleSubmitMarketingOfferSuccess, handleSubmitMarketingOfferError));
	// }

	// function handleSubmitMarketingOfferSuccess(response) {
	// 	return response.data;
	// }

	// function handleSubmitMarketingOfferError(response) {
	// 	console.log("error handling");
	// }


}]);