myApp.service('requestorLandingService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	
	return ({
		getNewRequestData: getNewRequestData,
        getIntakeFormData:getIntakeFormData
    });
	
	    
    function getIntakeFormData(){
        var intake = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/inTakeForm.json"
        });
        return (intake.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
    
    function getNewRequestData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/newProjectRequest.json"
        });
        return (requester.then(newRequestSuccess,newRequestError));
    }
    function newRequestSuccess(response){
        return response.data;
    }
    function newRequestError(response){
        console.log("error message");
    }

	
	
}]);