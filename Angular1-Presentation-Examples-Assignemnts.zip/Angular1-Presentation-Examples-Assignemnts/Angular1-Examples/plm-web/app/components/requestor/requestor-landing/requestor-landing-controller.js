myApp.controller("requestorLandingController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "requestorService",
    "requestorLandingService",
    function ($rootScope, $scope, $location, $window, requestorService, requestorLandingService) {
        $scope.currentProject = "";
        $scope.noMarketData = false;
        $scope.marketing = "false";
        $scope.offer = "false";
        $scope.discount = "false";
        $scope.showRequestorCreateNewProject = true;
        $scope.showRequestorProjectView = false;
        $scope.disableConfigureMarketingOffer = true;
        $scope.isAddProject = true;
        $scope.isUpdateProject = false;
        $scope.disableAddProject = false;
        
        $scope.getRequestData = function () {
        	requestorService.getRequesterData().then(function (response) {
                $scope.requester = response;
            })
        };
        
        $scope.gotoMarketingOffers = function() {
        	/*$rootScope.cols1 = "";
            $rootScope.cols2 = "";
            $rootScope.cols3 = "";
            $rootScope.cols4 = "";
        	$rootScope.makeArray("1P",0);
        	$rootScope.makeArray("2P",0);
        	$rootScope.makeArray("3P",0);
        	$rootScope.makeArray("4P",0);*/
        	$scope.showPSUForMarketingOfferTable();
        }
        
        $scope.addNewProject = function(form){
        	var result = true;
        	angular.forEach($scope.requester, function (arrayObj) {
        		if (arrayObj.ProjectCode == $scope.newRequest.ProjectCode) {
        			result = false;
        		}
        	});
        	if (!result){
        		return;
        	}
        	var addProjectObj = {};
        	addProjectObj.ProjectCode = $scope.newRequest.ProjectCode;
        	addProjectObj.ProjectType = $scope.newRequest.ProjType;
        	addProjectObj.ProjectCategoery = $scope.newRequest.ProjectCategory;
        	addProjectObj.Market = $scope.market;
        	addProjectObj.Status = "New";
        	var startDate = new Date($scope.newRequest.StartDate);
        	addProjectObj.StartDate = (('0'+ (parseInt(startDate.getMonth()) + 1))).slice(-2) +"/"+ startDate.getDate() +"/"+ startDate.getFullYear();
        	var endDate = new Date($scope.newRequest.EndDate);
        	addProjectObj.EndDate = (('0'+ (parseInt(endDate.getMonth()) + 1))).slice(-2) +"/"+ endDate.getDate() +"/"+ endDate.getFullYear();
        	console.log(JSON.stringify(addProjectObj));
        	$scope.requester.unshift(addProjectObj);
        	$scope.disableAddProject = true;
        	// Create the event.
        	var event = document.createEvent('Event');
        	$scope.changeProjectForConfigure(event, addProjectObj.ProjectCode);
        	form.$setPristine();
            form.$setUntouched();
        };
        
        function getIncProjectCode(){
        	var result = 0;
        	for (var i=0; i<$scope.requester.length; i++ ) {
        		var reqObj = $scope.requester[i];
        		var indexVal = reqObj.ProjectCode.split("_")[1];
        		if (indexVal > result) {
        			result = indexVal;
        		}
        	}
        	return "GTM2B2017_"+ (parseInt(result)+1);
        }
        
        $scope.editProjectData = function(projectCode, type) {
        	$scope.isAddProject = false;
        	$scope.populateViewEditProjectData(projectCode, type);
        };
        
        
        $scope.viewProjectData = function(projectCode, type) {
        	$scope.showRequestorCreateNewProject = false;
            $scope.showRequestorProjectView = true;	
        	$scope.populateViewEditProjectData(projectCode, type);
        };

        $scope.populateViewEditProjectData = function (projectCode, type) {
            angular.forEach($scope.requester, function (arrayObj) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                        $scope.currentProject = arrayObj;
                        if (typeof ($scope.currentProject.MarketsView) === "undefined") {
                            $scope.noMarketData = true;
                        }
                        if (type === 'view') {
                        	$scope.showRequestorCreateNewProject = false;
                            $scope.showRequestorProjectView = true;	
                        } else if (type === 'edit') {
//                        	console.log(arrayObj);
                        	$scope.newRequest.ProjectCode = arrayObj.ProjectCode;
//                        	$scope.newRequest.ProjectType = arrayObj.ProjectType;
                        	$scope.newRequest.ProjType = arrayObj.ProjectType;
                        	$scope.newRequest.ProjectCategoery = arrayObj.ProjectCategory;
                        	$scope.market = arrayObj.Market;
                        	$scope.newRequest.Status = arrayObj.Status;
                        	var startDateArray = arrayObj.StartDate.split("/");
                        	$scope.newRequest.StartDate = new Date(startDateArray[2], startDateArray[0], startDateArray[1]);
                        	var endDateArray = arrayObj.EndDate.split("/");
                        	$scope.newRequest.EndDate = new Date(endDateArray[2], endDateArray[0], endDateArray[1]);
                        }
                    }
                });
            });
        };
        
        $scope.returnToRequestorLanding = function(){
        	$scope.showRequestorCreateNewProject = true;
            $scope.showRequestorProjectView = false;
        };
        
        $scope.updateProject = function (projectCode) {
        	$scope.isAddProject = true;
            angular.forEach($scope.requester, function (arrayObj) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
//                        $scope.currentProject = arrayObj;
                        arrayObj.ProjectCode = $scope.newRequest.ProjectCode;
                        arrayObj.ProjectType = $scope.newRequest.ProjType;
                        arrayObj.ProjectCategoery = $scope.newRequest.ProjectCategory;
                        arrayObj.Market = $scope.market;
                        arrayObj.Status = $scope.newRequest.Status;
                    	var startDate = new Date($scope.newRequest.StartDate);
                    	arrayObj.ProjectStartDate = (('0'+ (parseInt(startDate.getMonth()) + 1))).slice(-2) +"/"+ startDate.getDate() +"/"+ startDate.getFullYear();
                    	var endDate = new Date($scope.newRequest.EndDate);
                    	arrayObj.ProjectEndDate = (('0'+ (parseInt(endDate.getMonth()) + 1))).slice(-2) +"/"+ endDate.getDate() +"/"+ endDate.getFullYear();
                    	console.log(JSON.stringify(arrayObj));
                    }
                });
            });
        };
        
        $scope.updateProjectData = function(projectCode){
            angular.forEach($scope.requester, function (arrayObj, index) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                        $scope.requester[index].ProjectCode = $scope.currentProject.ProjectCode;
                        $scope.requester[index].ProjectType = $scope.currentProject.ProjectType;
                        $scope.requester[index].ProjectCategoery = $scope.currentProject.ProjectCategoery;
                        $scope.requester[index].Market = $scope.currentProject.Market;
                        $scope.requester[index].Status = $scope.currentProject.Status;
                        $scope.requester[index].AssignedTo = $scope.currentProject.AssignedTo;
                        angular.element('#editProject').modal('hide');
                    }
                });
            });
        };
        
        $scope.changeProjectForConfigure = function(event, projectCode){
//        	console.log(event.target.checked);
        	
            angular.forEach($scope.requester, function (arrayObj, index) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                       $rootScope.projectForConfigure = arrayObj;
                       $rootScope.projectCodeForConfigure = projPropValue;
                       $scope.moveToAddMarketingOffer = false;
                       requestorService.setCurrentProjectToConfigure(projPropValue);
                    //    console.log(requestorService.getCurrentProjectToConfigure());
                        // console.log($rootScope.projectForConfigure);
                    }
                });
            });
            
            var projectCountSelected = 0;
            var projectCodeToBeConfigured = "";
            angular.forEach(document.getElementsByClassName("projectForConfigure"), function(element){
        		if(element.checked) {
        			projectCountSelected += 1;
        			projectCodeToBeConfigured = element.value;
        		} 
        	});
            $scope.disableAddProject = true;
        	if (projectCountSelected == 1) {
        		$scope.disableConfigureMarketingOffer = false;
        		if (event.target.checked) {
        			$scope.populateViewEditProjectData(projectCode, 'edit');
            	} else {
            		$scope.populateViewEditProjectData(projectCodeToBeConfigured, 'edit');
            	}
//        		$scope.disableAddProject = false;
        	} else {
        		$scope.disableConfigureMarketingOffer = true;
        		$scope.disableAddProject = false;
            	$scope.newRequest.ProjectCode = getIncProjectCode();
//            	$scope.newRequest.ProjectType = "";
            	$scope.newRequest.ProjType = "";
            	$scope.newRequest.ProjectCategoery = "";
            	$scope.market = "";
            	$scope.newRequest.Status = "";
            	$scope.newRequest.StartDate = "";
            	$scope.newRequest.EndDate = "";
        	}
        };

        $scope.closeModalDialog = function () {
            angular.element('#viewProject').modal('hide');
        }

        $scope.getRequestData();
        
          
       $scope.marketingData = function () {
            $scope.marketing = $scope.marketing? true:false;
        }

        $scope.marketingData(); 
        
        
         $scope.offerData = function () {
            $scope.offer = $scope.offer? true:false;
        }

        $scope.offerData(); 
        
         $scope.discountData = function () {
            $scope.discount = $scope.discount? true:false;
        }

        $scope.discountData(); 
        
        $scope.resultsWithInfo = [{
        name: "Baseline",
        id: "something_unique1",
        idx: 1,
        eui: 100
      }, {
        name: "Alt1",
        id: "something_unique2",
        idx: 2,
        eui: 90
      }, {
        name: "Alt2",
        id: "something_unique3",
        idx: 3,
        eui: 80
      }, {
        name: "Alt3",
        id: "something_unique4",
        idx: 4,
        eui: 75
      }, {
        name: "Alt4",
        id: "something_unique5",
        idx: 5,
        eui: 60
      }];

      
      $scope.selected_baselines = [];
      $scope.selected_baseline_settings = {
      	template: '<b>{{option.name}}</b>',
        searchField: 'name',
        enableSearch: true,
        selectionLimit: 4,
        selectedToTop: true // Doesn't work
      };
      
      $scope.selected_baselines_customTexts = {buttonDefaultText: 'Select Users'};
      $scope.showRequestorOfferIntakeForm = false;  
        
      $scope.getNewProjectRequest = function() {
          requestorLandingService.getNewRequestData().then(function(response){
              $scope.newRequest = response;
          })
          
      }
     
       $scope.getNewProjectRequest();  
       
       
       $scope.getIntakeData = function() {
           requestorLandingService.getIntakeFormData().then(function(response){
               $scope.intakeFormData = response;
           })
       }
       
       $scope.getIntakeData();       

        
        $scope.showMarketData = function(){
            $scope.isShowMore = !$scope.isShowMore;
       }   
        
        
    
         
    }
]);