myApp.controller("requestorOfferIntakeFormController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "requestorOfferIntakeFormService",
  function($rootScope, $scope, $location, $window, requestorOfferIntakeFormService) {
      
      $scope.getIntakeData = function() {
          requestorOfferIntakeFormService.getIntakeFormData().then(function(response){
              $scope.intakeFormData = response;
          })
      }
      
      $scope.getIntakeData();
  }
]);