myApp.service('requestorOfferIntakeFormService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	
	return ({
        getIntakeFormData:getIntakeFormData
    });
	
	    
    function getIntakeFormData(){
        var intake = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/inTakeForm.json"
        });
        return (intake.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
	
	
}]);