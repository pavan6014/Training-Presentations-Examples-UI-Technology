myApp.controller("requestorOfferUnderProjectController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "$timeout",
  "requestorService",
  function ($rootScope, $scope, $location, $window, $timeout, requestorService) {
    loadInit();

    $scope.psuUnderProjectID = "";
    $scope.psu = {
      "1P" : {"DATA":[], "PHONE":[], "VIDEO":[], "HOMELIFE":[], "colSpan":0},
      "2P": { "DATA_PHONE": [], "DATA_VIDEO": [], "DATA_HOMELIFE": [], "PHONE_VIDEO": [], "PHONE_HOMELIFE": [], "VIDEO_HOMELIFE": [], "colSpan": 0},
      "3P": { "DATA_PHONE_VIDEO": [], "DATA_PHONE_HOMELIFE": [], "DATA_VIDEO_HOMELIFE": [], "PHONE_VIDEO_HOMELIFE": [], "colSpan": 0},
      "4P" : {"ALL" : []}
    };
    $scope.rowCount = 0;

    $scope.checkIfArrayElementExist = function(psuType, productType, index) {
      var result = false;
      if ((typeof $scope.psu[psuType][productType][index] !== "undefined") && ($scope.psu[psuType][productType][index] !== null)) {
        $scope.psu[psuType][productType][index] = {};
        result = true;
      }
      return result;
    }

    $scope.getNumber = function (num) {
      return new Array(num);
    }

    $scope.showNextToConfiguratorButton = function () {
      var result = true;
      if ($scope.psu11 !== "" && $scope.psu12 !== "" && $scope.psu13 !== "" && $scope.psu14 !== "" && $scope.psu15 !== "" && $scope.psu16 !== "" && $scope.psu17 !== "" && $scope.psu21 !== "" && $scope.psu22 !== "" && $scope.psu23 !== "" && $scope.psu24 !== "" && $scope.psu25 !== "" && $scope.psu26 !== "" && $scope.psu27 !== "" && $scope.psu31 !== "" && $scope.psu32 !== "" && $scope.psu33 !== "" && $scope.psu34 !== "" && $scope.psu35 !== "" && $scope.psu36 !== "" && $scope.psu37 !== "" && $scope.psu45 !== "" && $scope.psu47 !== "") {
        result = false;
      } else {
        result = true;
      }
      return result;
    }

    function loadInit() {
      var reqObj = {
        "projectID" : "GTM2B2017_1"
      }
      console.log($rootScope.psuUnderProject);
      console.log();
      manipulatePSUUnderProjectData($rootScope.psuUnderProject);
      // requestorService.getPSUUnderProject(reqObj).then(function (reponseObj) {
      //   manipulatePSUUnderProjectData(reponseObj);
      // }, function (errorObj) {
      //   console.log(errorObj);
      // });
      
    }

    function manipulatePSUUnderProjectData(responseObj) {
      $scope.psuUnderProjectID = responseObj.projectID;
      angular.forEach(responseObj.psu, function (value, key) {
        angular.forEach(value, function (array) {
          angular.forEach(array, function (psuPropValue, psuPropKey) {
            if (psuPropKey === "psuType") {
              ($scope.psu[key][psuPropValue]).push(array);
            }
          });
        });
      });
      updateUIDatas();
    }

    function updateUIDatas() {
      angular.forEach($scope.psu, function (psuDef, psuType) {
        angular.forEach(psuDef, function (productArray, product) {
          if (productArray.length > $scope.rowCount) {
            $scope.rowCount = productArray.length;
          }
          if (productArray.length > 0) {
            ++$scope.psu[psuType]["colSpan"];
          }
        });
      });
      // console.log($scope.psu);
      // console.log($scope.rowCount);
    }
    
  }
]);
