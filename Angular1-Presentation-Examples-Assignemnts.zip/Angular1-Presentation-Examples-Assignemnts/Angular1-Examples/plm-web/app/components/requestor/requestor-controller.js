myApp.controller("requestorController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "requestorService",
  function ($rootScope, $scope, $location, $window, requestorService) {	  

    $rootScope.requester = "";

    $scope.showRequestorLanding = true;
    $scope.showRequestorCreateNewProject = true;
    $scope.showRequestorOfferIntakeForm = false;
    $scope.showRequestorProjectList = false;
    $scope.showRequestorPSUForMarketingOffer = false;
    $scope.showRequestorOffersUnderProject = false;
    $scope.showRequestorOffersPSUForm = false;

    $scope.currentProjectForViewEdit = "";

    // $scope.psuData = "1P";
    // $scope.projectCode = "GTM2B2017_1";
    // $scope.offerID = "Offer_0101";
    $scope.price = "$149";
    $scope.priceSpec = "12 month(+$20 in 13-24 month)";
    $rootScope.projectCodeForConfigure = "";

    $scope.showDataField = true;
    $scope.showPhoneField = true;
    $scope.showVideoField = true;
    $scope.showHomeLifeField = true;

    // $scope.psu11 = "";
    // $scope.psu12 = "";
    // $scope.psu13 = "";
    // $scope.psu14 = "";
    // $scope.psu15 = "";
    // $scope.psu16 = "";
    // $scope.psu17 = "";
    // $scope.psu21 = "";
    // $scope.psu22 = "";
    // $scope.psu23 = "";
    // $scope.psu24 = "";
    // $scope.psu25 = "";
    // $scope.psu26 = "";
    // $scope.psu27 = "";
    // $scope.psu31 = "";
    // $scope.psu32 = "";
    // $scope.psu33 = "";
    // $scope.psu34 = "";
    // $scope.psu35 = "";
    // $scope.psu36 = "";
    // $scope.psu37 = "";
    // $scope.psu41 = "";
    // $scope.psu42 = "";
    // $scope.psu43 = "";
    // $scope.psu44 = "";
    // $scope.psu45 = "";
    // $scope.psu46 = "";
    // $scope.psu47 = "";

    $scope.showCreateNewProject = function(){
      $scope.showRequestorLanding = true;
      $scope.showRequestorCreateNewProject = true;
      $scope.showRequestorOfferIntakeForm = false;
      $scope.showRequestorProjectList = false;
      $scope.showRequestorPSUForMarketingOffer = false;
      $scope.showRequestorOffersUnderProject = false;
      $scope.showRequestorOffersPSUForm = false;
    };

    $scope.showIntakeFormSec = function(){
      $scope.showRequestorLanding = false;
      $scope.showRequestorCreateNewProject = false;
      $scope.showRequestorOfferIntakeForm = true;
      $scope.showRequestorProjectList = false;
      $scope.showRequestorPSUForMarketingOffer = false;
      $scope.showRequestorOffersUnderProject = false;
      $scope.showRequestorOffersPSUForm = false;
    };

    $scope.returnToCreateNewProject = function(){
      $scope.showCreateNewProject();
    };

    $scope.showProjectListSec = function(){
      $scope.showRequestorLanding = false;
      $scope.showRequestorCreateNewProject = false;
      $scope.showRequestorOfferIntakeForm = false;
      $scope.showRequestorProjectList = true;
      $scope.showRequestorPSUForMarketingOffer = false;
      $scope.showRequestorOffersUnderProject = false;
      $scope.showRequestorOffersPSUForm = false;
    };

    $scope.showPSUForMarketingOfferTable = function () {
      $scope.showRequestorLanding = false;
      $scope.showRequestorCreateNewProject = false;
      $scope.showRequestorOfferIntakeForm = false;
      $scope.showRequestorProjectList = false;
      $scope.showRequestorPSUForMarketingOffer = true;
      $scope.showRequestorOffersUnderProject = false;
      $scope.showRequestorOffersPSUForm = false;
    };

    $scope.showOfferUnderProject = function () {
      $scope.showRequestorLanding = false;
      $scope.showRequestorCreateNewProject = false;
      $scope.showRequestorOfferIntakeForm = false;
      $scope.showRequestorProjectList = false;
      $scope.showRequestorPSUForMarketingOffer = false;
      $scope.showRequestorOffersUnderProject = true;
      $scope.showRequestorOffersPSUForm = false;
    };

    $scope.returnToOfferUnderProject = function(){
      $scope.showOfferUnderProject();
    };

    $scope.moveToConfigurator = function(){
        $location.path('/configurator');
        $rootScope.resetSideBarHighlighted("configurator");
    };

    $rootScope.currentPSUTypeForForm = "";
    $rootScope.currentProductTypeForForm = "";
    $rootScope.currentPSUForFormIndex = "";
    $rootScope.currentPSUTypeOfferIDForForm = "";

    $scope.showOffersPSUFormSec = function (
      psuType,
      productType,
      index,
      offerID,
      psuHeader,
      showDataField,
      showPhoneField,
      showVideoField,
      showHomeLifeField
    ) {
     /* console.log(JSON.parse(JSON.stringify($rootScope.psu)));
      $rootScope.currentPSUTypeForForm = psuType;
      $rootScope.currentProductTypeForForm = productType;
      $rootScope.currentPSUForFormIndex = index;
      $rootScope.currentPSUTypeOfferIDForForm = offerID;
      $rootScope.psu[psuType][productType][index]['addMarketingOfferConfigured'] = true;
      console.log(JSON.parse(JSON.stringify($rootScope.psu)));*/
      $scope.psuData = psuHeader;
      $scope.showDataField = showDataField;
      $scope.showPhoneField = showPhoneField;
      $scope.showVideoField = showVideoField;
      $scope.showHomeLifeField = showHomeLifeField;
      $scope.showRequestorLanding = false;
      $scope.showRequestorCreateNewProject = false;
      $scope.showRequestorOfferIntakeForm = false;
      $scope.showRequestorProjectList = false;
      $scope.showRequestorPSUForMarketingOffer = false;
      $scope.showRequestorOffersUnderProject = false;
      $scope.showRequestorOffersPSUForm = true;
    };


    // $scope.showHideDiv = function () {
    //   if ($scope.chkStatus) {
    //     $scope.showhideprop = true;
    //   } else {
    //     $scope.showhideprop = false;
    //   }
    // };

    // $scope.populateViewEditProjectData = function(projectCode){
    //   angular.forEach($scope.requester, function (arrayObj) {
    //     angular.forEach(arrayObj, function (projPropValue, projPropKey) {
    //       if ((currentProjectForViewEdit === "ProjectCode") && (projPropValue === projectCode)) {
    //         $scope.currentProjectForViewEdit = arrayObj;
    //       }
    //     });
    //   });
    // }
              
    // $scope.getRequesterModel = function() {
    //     requestorService.getRequesterModelData().then(function(response){
    //         $scope.requestorModel = response.requestorTableModelData;
    //         console.log("model",$scope.requestorModel);
    //     })
    // }
    
    
   

//    $scope.getRequesterModel();
//      
//      $scope.getNewRequestData = function() {
//        requestorService.getNewProjectRequesteData().then(function(response){
//            $scope.newRequestData = response;
//            console.log("Data",$scope.newRequestData);
//        })
//    }

//    $scope.getNewRequestData();

   
    
    // function handleSuccess(response){
    //    console.log("Success in calling");
    // }
    
    // function handleError(errorObj){
    //   console.log("Error in calling");
    // }
      
    $scope.market= [];
      
  }
]);