myApp.controller("requestorOfferPSUFormController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "requestorService",
  function ($rootScope, $scope, $location, $window, requestorService) {
    $scope.projectCode = "";
    // console.log($rootScope.projectForConfigure.ProjectCode);
    $scope.newOfferID = $scope.offerID;
    $scope.offerType = "";
    $scope.offerName = "";
    $scope.offerStartDate = "";
    $scope.offerEndDate = "";
    $scope.offerDescription = "";
    $scope.psu = {
      "data" : "",
      "phone" : "",
      "video" : "",
      "homeLife" : ""
    };
    $scope.price = "";
    $scope.discountType = "";
    $scope.discountValue = "";
    $scope.priceSpec = "";
    $scope.supplementaryRule = "";

    $scope.getPSUFormDataResp = function() {
      // console.log(requestorService);
      requestorService.getPSUFormData().then(function(response){
          $scope.psuFormData = response;
          // console.log("model", $scope.psuFormData);
      });
    }
    $scope.getPSUFormDataResp();

    $scope.showFormError = function(){
      console.log($scope.psuForm.$error.required);
    }

    $scope.submitPSUFormInfo = function(form){
    	if (!form.$valid) {
    		return;
    	}
        $scope.submitted=true;
	      var reqObj = {
	        "projectCode" : $scope.projectCode,
	        "offerID" : $scope.offerID,
	        "offerType" : $scope.offerType,
	        "offerName" : $scope.offerName,
	        "offerStartDate" : $scope.offerStartDate,
	        "offerEndDate" : $scope.offerEndDate,
	        "offerDescription" : $scope.offerDescription,
	        "psu" : $scope.psu,
	        "price" : $scope.price,
	        "priceSpec" : $scope.priceSpec,
	        "discountType" : $scope.discountType,
	        "discountValue" : $scope.discountValue,
	        "discountDuration" : $scope.discountDuration,
	        "supplementaryRule" : $scope.supplementaryRule
	      };
      /*console.log(JSON.parse(JSON.stringify($rootScope.psu)));
       console.log($scope.currentPSUTypeForForm);
       console.log($scope.currentProductTypeForForm);
       console.log($scope.currentPSUForFormIndex);
      $rootScope.psu[$rootScope.currentPSUTypeForForm][$rootScope.currentProductTypeForForm][$rootScope.currentPSUForFormIndex]['offerID'] = $scope.offerID;
      $rootScope.psu[$rootScope.currentPSUTypeForForm][$rootScope.currentProductTypeForForm][$rootScope.currentPSUForFormIndex]['addMarketingOfferConfigured'] = true;
      console.log(JSON.parse(JSON.stringify($rootScope.psu)));*/
      $scope.returnToOfferUnderProject();
    };

      
     
      
      $scope.submitFun = function($event) {
         $scope.submitted = true;
          if (!$scope.myForm.$valid) 
          {
                $event.preventDefault();
           }
  }
      
      
  }
]);