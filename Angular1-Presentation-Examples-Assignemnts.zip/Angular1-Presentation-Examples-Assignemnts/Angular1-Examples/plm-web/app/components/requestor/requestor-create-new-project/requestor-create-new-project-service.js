myApp.service('requestorCreateNewProjectService', ['$rootScope', '$http', '$q', function ($rootScope, $http, $q) {
	return { 
		getNewRequestData: getNewRequestData,
		
	};

	
function getNewRequestData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
            url:"/data/newProjectRequest.json"
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }

}]);