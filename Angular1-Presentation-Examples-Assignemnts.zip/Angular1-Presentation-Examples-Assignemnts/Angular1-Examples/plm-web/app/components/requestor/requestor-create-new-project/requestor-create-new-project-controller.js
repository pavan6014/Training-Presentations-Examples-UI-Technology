myApp.controller("requestorCreateNewProjectController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "requestorCreateNewProjectService",
    function ($rootScope, $scope, $location, $window,requestorCreateNewProjectService) {
        
        $scope.resultsWithInfo = [{
        name: "Baseline",
        id: "something_unique1",
        idx: 1,
        eui: 100
      }, {
        name: "Alt1",
        id: "something_unique2",
        idx: 2,
        eui: 90
      }, {
        name: "Alt2",
        id: "something_unique3",
        idx: 3,
        eui: 80
      }, {
        name: "Alt3",
        id: "something_unique4",
        idx: 4,
        eui: 75
      }, {
        name: "Alt4",
        id: "something_unique5",
        idx: 5,
        eui: 60
      }];

      
      $scope.selected_baselines = [];
      $scope.selected_baseline_settings = {
      	template: '<b>{{option.name}}</b>',
        searchField: 'name',
        enableSearch: true,
        selectionLimit: 4,
        selectedToTop: true // Doesn't work
      };
      
      $scope.selected_baselines_customTexts = {buttonDefaultText: 'Select Users'};
      $scope.showRequestorOfferIntakeForm = false;  
        
      $scope.getNewProjectRequest = function() {
          requestorCreateNewProjectService.getNewRequestData().then(function(response){
              $scope.newRequest = response;
          })
          
      }
     
       $scope.getNewProjectRequest();  
        
    }
]);