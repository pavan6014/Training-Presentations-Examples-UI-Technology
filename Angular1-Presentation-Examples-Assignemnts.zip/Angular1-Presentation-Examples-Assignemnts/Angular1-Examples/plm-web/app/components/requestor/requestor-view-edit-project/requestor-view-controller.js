myApp.controller("requestorViewProjectController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "requestorService",
    function ($rootScope, $scope, $location, $window, requestorService) {
        $scope.currentProject = $scope.currentProjectForViewEdit;
        $scope.noMarketData = false;
        if ((typeof ($scope.currentProject.MarketsView) === "undefined") || (Object.keys($scope.currentProject.MarketsView).length === 0)) {
            $scope.noMarketData = true;
        }

    }
]);