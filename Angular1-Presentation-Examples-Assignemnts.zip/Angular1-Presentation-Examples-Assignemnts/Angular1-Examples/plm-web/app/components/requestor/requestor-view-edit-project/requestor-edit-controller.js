myApp.controller("requestorEditProjectController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "requestorService",
    function ($rootScope, $scope, $location, $window, requestorService) {
        $scope.currentProject = $scope.currentProjectForViewEdit;
        console.log($scope.currentProjectForViewEdit);
    }
]);