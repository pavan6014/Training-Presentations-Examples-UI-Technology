myApp.service('loginService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){

   return ({
	   getLoginInfo: getLoginInfo
	});
	
	function getLoginInfo(reqObj){
		var request = $http({
            method: "GET",
            async: true,
			cache: false,
			params: {
				userName : reqObj.userName,
				password : reqObj.password
			},
			url: api_urls.LOGIN
        });
        return (request.then(handleSuccess, handleError));
	}

	function handleSuccess(response){
		return response.data;
	}
	
	function handleError(response){
		console.log("error handling");
	}
	
}]);