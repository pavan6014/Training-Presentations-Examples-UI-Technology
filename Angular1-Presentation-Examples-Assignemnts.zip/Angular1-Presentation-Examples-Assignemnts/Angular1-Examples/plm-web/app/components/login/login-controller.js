myApp.controller("loginController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "loginService",
  function ($rootScope, $scope, $location, $window, loginService) {
    $scope.email = "";
    $scope.password = "";
    $scope.invalidLogin = false;
    $scope.rememberMe = false;

    $scope.submitLogin = function () {
      var reqObj = {
        "userName": $scope.email,
        "password": $scope.password
      };

      loginService.getLoginInfo(reqObj).then(function (reponseObj) {
        if (reponseObj.actionStatus === "SUCCESS") {
            $rootScope.isValidLogin = true;
            $rootScope.bodyBackground = "bodyThickBackground";
            $rootScope.viewStyles = "page-wrapper";
            $location.path("/dashboard");
            $rootScope.resetSideBarHighlighted("dashboard");
          } else {
            $scope.invalidLogin = false;
          }
        }, function (errorObj) {
          $scope.invalidLogin = false;
        });
    };

  }
]);
