myApp.controller('faqController', ['$rootScope', '$scope', '$location', '$window', 'faqService', function($rootScope, $scope, $location, $window, faqService) {	
	
	init();


	function init(){
		faqService.getListOfFaq().then(handleSuccess, handleError)
	}
	
	function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}
	
	
}]);