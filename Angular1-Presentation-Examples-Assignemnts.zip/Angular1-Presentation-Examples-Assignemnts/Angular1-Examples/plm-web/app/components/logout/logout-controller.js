myApp.controller("logoutController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  function($rootScope, $scope, $location, $window) {
    $scope.goToLoginPage = function() {
      $location.path("/login");
    };
  }
]);