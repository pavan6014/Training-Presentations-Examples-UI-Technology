myApp.controller("eCOMController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  function($rootScope, $scope, $location, $window) {
  }
]);