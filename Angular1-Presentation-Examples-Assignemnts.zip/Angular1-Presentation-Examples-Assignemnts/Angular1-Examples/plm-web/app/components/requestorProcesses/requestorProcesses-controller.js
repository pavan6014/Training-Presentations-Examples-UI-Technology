myApp.controller('requestorProcessesController', ['$rootScope', '$scope', '$location', '$window', 'faqService', function($rootScope, $scope, $location, $window, faqService) {	
	
	
   $scope.name = "xxxx"; 
    
    
	
	
}]);