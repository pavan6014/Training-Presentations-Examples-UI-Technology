myApp.controller("configuratorController", [
  "$rootScope",
  "$scope",
  "$location",
  "$timeout",
  "$window",
  "configuratorService",
  function ($rootScope, $scope, $location, $timeout, $window, configuratorService) {
	$scope.showConfigureProjectList = true;
    $scope.showConfiguratorOffersUnderProject = false;
    $scope.showConfiguratorOfferForm = false;
    $scope.showConfiguratorOfferList = false;
    $scope.currentCellPSUNo = "";

    $scope.projectCode = "GTM2B2017_1";
    $scope.campgnId = "CAMP_0101";

    $scope.psu11 = { "offerID": "Offer_0101", "configured": false };
    $scope.psu12 = {
      "offerID": "Offer_0102", "configured": false
    };
    $scope.psu13 = {
      "offerID": "Offer_0103", "configured": false
    };
    $scope.psu14 = {
      "offerID": "Offer_0104", "configured": false
    };
    $scope.psu15 = {
      "offerID": "Offer_0105", "configured": false
    };
    $scope.psu16 = {
      "offerID": "Offer_0106", "configured": false
    };
    $scope.psu17 = {
      "offerID": "Offer_0107", "configured": false
    };
    $scope.psu21 = {
      "offerID": "Offer_0201", "configured": false
    };
    $scope.psu22 = {
      "offerID": "Offer_0202", "configured": false
    };
    $scope.psu23 = {
      "offerID": "Offer_0203", "configured": false
    };
    $scope.psu24 = {
      "offerID": "Offer_0204", "configured": false
    };
    $scope.psu25 = {
      "offerID": "Offer_0205", "configured": false
    };
    $scope.psu26 = {
      "offerID": "Offer_0206", "configured": false
    };
    $scope.psu27 = {
      "offerID": "Offer_0207", "configured": false
    };
    $scope.psu31 = {
      "offerID": "Offer_0301", "configured": false
    };
//    $scope.psu32 = {
//      "offerID": "Offer_0302", "configured": false
//    };
    $scope.psu33 = {
      "offerID": "Offer_0303", "configured": false
    };
    $scope.psu34 = {
      "offerID": "Offer_0304", "configured": false
    };
    $scope.psu35 = {
      "offerID": "Offer_0305", "configured": false
    };
    $scope.psu36 = {
      "offerID": "Offer_0306", "configured": false
    };
    $scope.psu37 = {
      "offerID": "Offer_0307", "configured": false
    };
    $scope.psu41 = {
      "offerID": "Offer_0401", "configured": false
    };
//    $scope.psu42 = {
//      "offerID": "Offer_0402", "configured": false
//    };
//    $scope.psu43 = {
//      "offerID": "Offer_0403", "configured": false
//    };
//    $scope.psu44 = {
//      "offerID": "Offer_0404", "configured": false
//    };
//    $scope.psu45 = {
//      "offerID": "Offer_0405", "configured": false
//    };
//    $scope.psu46 = {
//      "offerID": "Offer_0406", "configured": false
//    };
//    $scope.psu47 = {
//      "offerID": "Offer_0407", "configured": false
//    };

    $rootScope.psuUnderProjectID = "";
    $rootScope.psu = {
      "1P": { "DATA": [], "PHONE": [], "VIDEO": [], "HOMELIFE": [], "colSpan": 0 },
      "2P": { "DATA_PHONE": [], "DATA_VIDEO": [], "DATA_HOMELIFE": [], "PHONE_VIDEO": [], "PHONE_HOMELIFE": [], "VIDEO_HOMELIFE": [], "colSpan": 0 },
      "3P": { "DATA_PHONE_VIDEO": [], "DATA_PHONE_HOMELIFE": [], "DATA_VIDEO_HOMELIFE": [], "PHONE_VIDEO_HOMELIFE": [], "colSpan": 0 },
      "4P": { "ALL": [] }
    };
    $rootScope.psu = "";
    $scope.rowCount = 0;

    $scope.checkIfArrayElementExist = function (psuType, productType, index) {
      var result = false;
      if ((typeof $rootScope.psu[psuType][productType][index] !== "undefined") && ($rootScope.psu[psuType][productType][index] !== null)) {
        $rootScope.psu[psuType][productType][index] = {};
        result = true;
      }
      return result;
    }

    $scope.getNumber = function (num) {
      return new Array(num);
    }
    
    $scope.projectValidationList = "";
    
    $scope.getRequestData = function () {
    	var reqObj = {
    	        "projectID": "GTM2B2017_4"
    	      }
    	      configuratorService.getPSUUnderProject(reqObj).then(function (responseObj) {
    	        console.log(responseObj);
    	        /*$rootScope.psu = {};
    	        var responseObjPSU = JSON.parse(JSON.stringify(responseObj));
    	        $rootScope.psuUnderProjectID = responseObj.projectID;
    	        angular.forEach(responseObjPSU["psu"], function(psuTypes, psuType){
    	        	console.log(psuType);
    	        	$rootScope.psu[psuType] = {};
    	        	angular.forEach(psuTypes, function(psuTypeValArray, psuTypeVal){
    	        		console.log(psuTypeVal);
    	        		$rootScope.psu[psuType][psuTypeVal] = [];
    	        		if (psuTypeVal != "colSpan") {
    	        			for (var i=0; i<psuTypeValArray.length; i++) {
    	            			$rootScope.psu[psuType][psuTypeVal][i] = {};
    	            			var currentPSUObjVal = JSON.parse(JSON.stringify(psuTypeValArray[i]));
    	            			console.log(currentPSUObjVal);
    	            			angular.forEach(currentPSUObjVal, function (value, key){
    	            				console.log(key +" <--> "+ value);
    	            				$rootScope.psu[psuType][psuTypeVal][i][key] = value;
    	            				updateUIDatas();
    	            			});
    	            		}
    	        		}
    	        	});
    	        });*/
    	        $rootScope.psuUnderProjectID = responseObj.projectID;
    	        $rootScope.psu = JSON.parse(JSON.stringify(responseObj['psu']));
    	        updateUIDatas();
    	      }, function (errorObj) {
    	        console.log(errorObj);
    	      });
    	configuratorService.getProjectValidationList(reqObj).then(function (responseObj) {
	          console.log(responseObj);
	          $scope.projectValidationList = responseObj;
	        }, function (errorObj) {
	          console.log(errorObj);
	        });    
    };
    
    
    	$scope.getRequestData();
    	
    $scope.getIndexNo = function(index, count) {
    	return (parseInt(index)+1+parseInt(count));
    }
    

    function updateUIDatas() {
      angular.forEach($rootScope.psu, function (psuDef, psuType) {
        angular.forEach(psuDef, function (productArray, product) {
          if ((product !== 'colSpan') && (productArray.length > $scope.rowCount)) {
            $scope.rowCount = productArray.length;
          }
        });
      });
    }

    $scope.showOfferListSec = function () {
      $scope.showConfiguratorOffersUnderProject = false;
      $scope.showConfiguratorOfferForm = false;
      $scope.showConfiguratorOfferList = true;
    };
    
    $scope.showConfiguratorLanding = function(){
    	$scope.showConfigureProjectList = true;
        $scope.showConfiguratorOffersUnderProject = false;
        $scope.showConfiguratorOfferForm = false;
        $scope.showConfiguratorOfferList = false;
    }
    
    $scope.showOfferUnderProject = function(){
    	$scope.showConfigureProjectList = false
        $scope.showConfiguratorOffersUnderProject = true;
        $scope.showConfiguratorOfferForm = false;
        $scope.showConfiguratorOfferList = false;
    }

    $scope.showOfferForm = function (psuNo) {
      $scope.currentCellPSUNo = psuNo;
      $scope.showConfigureProjectList = false
      $scope.showConfiguratorOffersUnderProject = false;
      $scope.showConfiguratorOfferForm = true;
      $scope.showConfiguratorOfferList = false;
    };

    $scope.showOffersPSUFormSec = function (
      psuType,
      productType,
      index,
      offerID,
      psuHeader,
      showDataField,
      showPhoneField,
      showVideoField,
      showHomeLifeField
    ) {
      $scope.currentPSUTypeForForm = psuType;
      $scope.currentProductTypeForForm = productType;
      $scope.currentPSUForFormIndex = index;
      $scope.currentPSUTypeOfferIDForForm = offerID;
      $scope.showConfiguratorOffersUnderProject = false;
      $scope.showConfiguratorOfferForm = true;
      $scope.showConfiguratorOfferList = false;
    };

    $scope.returnToOfferTable = function(){
      // if (isToUpdate === 'configured') {
      //   $scope[$scope.currentCellPSUNo]["configured"] = true;
      // } else {
      //   $scope[$scope.currentCellPSUNo]["configured"] = false;
      // }
      $scope.showConfiguratorOffersUnderProject = true;
      $scope.showConfiguratorOfferForm = false;
      $scope.showConfiguratorOfferList = false;
    };

    $scope.checkAllOffersConfigured = function () {
      var result = true;
      if ($scope.psu11.configured === true && $scope.psu12.configured === true && $scope.psu13.configured === true && $scope.psu14.configured === true && $scope.psu15.configured === true && $scope.psu16.configured === true && $scope.psu17.configured === true && $scope.psu21.configured === true && $scope.psu22.configured === true && $scope.psu23.configured === true && $scope.psu24.configured === true && $scope.psu25.configured === true && $scope.psu26.configured === true && $scope.psu27.configured === true && $scope.psu31.configured === true && $scope.psu33.configured === true && $scope.psu34.configured === true && $scope.psu35.configured === true && $scope.psu36.configured === true && $scope.psu37.configured === true && $scope.psu41.configured === true) {
        result = false;
      } else {
        result = true;
      }
      return result;
    } 

    $scope.publishToDistributor = function(subStream) {
      $rootScope.subStreamValue = subStream;
      $location.path("/distributor");
      $rootScope.resetSideBarHighlighted("distributor");
    }

    $scope.onChangeBrowserChoices = function(primarydiscount){  
        if (primarydiscount === 'Browse Choices') {
          $('#selectDiscountcode').modal('show');
        }    
    }

    $scope.onChangeAddNewProduct = function(offerName){  
        if (offerName === 'Add New Product') {
          $('#addNewProductPopup').modal('show');
        }    
    }

    $scope.moveToDistributorDiscounts = function(){
      $scope.redirectTo('discounts');
      $rootScope.resetSideBarHighlighted("distributor");
    }
    
    $scope.offersForDistributor = [];
    $scope.submitConfiguratorProjectData = function(){
    	var offerListCheckboxes = document.getElementsByClassName("offerList");
    	angular.forEach(offerListCheckboxes, function(offerListcheckbox){
    		if(offerListcheckbox.checked) {
    			$scope.offersForDistributor.push(offerListcheckbox.value);
    		}
    	});
    	$scope.redirectTo('dashboard');
    }
    
    
    
     $scope.getGenrealInfoData = function() {
             configuratorService.getGeneralInfo().then(function(response){
                 $scope.general = response;
                 console.log("vvvvvv",$scope.general);
             })
         
      }
      
     
    $scope.getGenrealInfoData();
      
    
    $scope.getConfiguratorProcessData = function() {
             configuratorService.getConfiguratorProcess().then(function(response){
                 $scope.process = response;
                 console.log("vvvvvv",$scope.process);
             })
         
      }
      
    $scope.showMore = function(){
        $scope.isShowMore = !$scope.isShowMore;
    } 
    
    
    $scope.getGenrealInfoData();
      
    
    $scope.getMarketInfoData = function() {
             configuratorService.getMarketData().then(function(response){
                 $scope.market = response;
                console.log("market",$scope.market);
             })
         
      }
     $scope.getMarketInfoData();
   
  
    /* Product Association auto complete function starts here */
    $scope.productItemsTable  = [];

    $scope.productItems  = [
      {
        "id": "1",
        "name": "Name 1" ,
        "type": "Type 1",
        "psu": "PSU 1",
        "packageCode":"Package Code 1"
      },
      {
        "id": "2",
        "name": "Name 2" ,
        "type": "Type 2",
        "psu": "PSU 2",
        "packageCode":"Package Code 2"
      },
      {
        "id": "3",
        "name": "Name 3" ,
        "type": "Type 3",
        "psu": "PSU 3",
        "packageCode":"package Code 3"
      }
    ];
    
    $scope.showAddProductError = false;

    $scope.productAddNew = function(item){
    	var result = true;
    	for (var i=0; i< $scope.productItemsTable.length; i++) {
    		if (item.name === $scope.productItemsTable[i].name){
    			result = false;
    		}
    	}
    	if (result) {
    		$scope.productItemsTable.push({ 
                'id': item.id, 
                'name': item.name,
                'type': item.type,
                "psu": item.psu,
                "packageCode": item.packageCode
            });
    		$scope.showAddProductError = false;
    	} else {
    		$scope.showAddProductError = true;
    	}
    };

    $scope.productRemoveRow = function (rowIndex) {
        $scope.productItemsTable.splice(rowIndex, 1);
    }
    /* Product Association auto complete function ends here */

    /* Discount Association auto complete function starts here */
    $scope.discountItemsTable  = [];

    $scope.discountItems= [
      {
        "id": "1",
        "name": "Discount 1",
        "type": "Type 1"
      },
      {
        "id": "2",
        "name": "Discount 2",
        "type": "Type 2"
      },
      {
        "id": "3",
        "name": "Discount 3",
        "type": "Type 3"
      }
    ];

    $scope.discountAddNew = function(discountItem){
      var result = true;
      for (var i=0; i< $scope.discountItemsTable.length; i++) {
        if (discountItem.name === $scope.discountItemsTable[i].name){
          result = false;
        }
      }
      if (result) {
         $scope.discountItemsTable.push({ 
            'id': discountItem.id, 
            'name': discountItem.name,
            'type': discountItem.type
        });
        $scope.showAddDiscountError = false;
      } else {
        $scope.showAddDiscountError = true;
      }
    };

    $scope.discountRemoveRow = function (rowIndex) {
        $scope.discountItemsTable.splice(rowIndex, 1);
    }
    /* Discount Association auto complete function ends here */


    /* Relevancy Rules auto complete function starts here */
    $scope.rulesItemsTable  = [];

    $scope.rulesItems= [
      {
        "id": "1",
        "ruleName": "Rule Name 1",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 1"
      },
      {
        "id": "2",
        "ruleName": "Rule Name 2",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 2"
      },
      {
        "id": "3",
        "ruleName": "Rule Name 3",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 3"
      }
    ];

    $scope.rulesAddNew = function(rulesItem){
      var result = true;
      for (var i=0; i< $scope.rulesItemsTable.length; i++) {
        if (rulesItem.ruleName === $scope.rulesItemsTable[i].ruleName){
          result = false;
        }
      }
      if (result) {
         $scope.rulesItemsTable.push({ 
            'id': rulesItem.id, 
            'ruleName': rulesItem.ruleName,
            'createdDate': rulesItem.createdDate,
            'modifiedDate':rulesItem.modifiedDate,
            'modificationOwner': rulesItem.modificationOwner
        });
        $scope.showAddRulesError = false;
      } else {
        $scope.showAddRulesError = true;
      }
    };

    $scope.rulesRemoveRow = function (rowIndex) {
        $scope.rulesItemsTable.splice(rowIndex, 1);
    }
    /* Relevancy Rules auto complete function ends here */

    /* Eligibility Rules auto complete function starts here */
    $scope.elrulesItemsTable  = [];

    $scope.elrulesItems= [
      {
        "id": "1",
        "ruleName": "Rule Name 1",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 1"
      },
      {
        "id": "2",
        "ruleName": "Rule Name 2",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 2"
      },
      {
        "id": "3",
        "ruleName": "Rule Name 3",
        "createdDate": "01-01-2017",
        "modifiedDate": "01-16-2017",
        "modificationOwner": "Modification Owner 3"
      }
    ];

    $scope.elrulesAddNew = function(rulesItem){
      var result = true;
      for (var i=0; i< $scope.elrulesItemsTable.length; i++) {
        if (rulesItem.ruleName === $scope.elrulesItemsTable[i].ruleName){
          result = false;
        }
      }
      if (result) {
        $scope.elrulesItemsTable.push({ 
            'id': rulesItem.id, 
            'ruleName': rulesItem.ruleName,
            'createdDate': rulesItem.createdDate,
            'modifiedDate':rulesItem.modifiedDate,
            'modificationOwner': rulesItem.modificationOwner
        });
        $scope.showAddElRulesError = false;
      } else {
        $scope.showAddElRulesError = true;
      }
    };

    $scope.elrulesRemoveRow = function (rowIndex) {
        $scope.elrulesItemsTable.splice(rowIndex, 1);
    }
    /* Eligibility Rules auto complete function ends here */

  }
]);