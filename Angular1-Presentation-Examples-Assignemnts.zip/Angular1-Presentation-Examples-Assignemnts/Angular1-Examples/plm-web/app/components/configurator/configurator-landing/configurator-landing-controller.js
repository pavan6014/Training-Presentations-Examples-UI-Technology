myApp.controller("configuratorProjectListController", [
    "$rootScope",
    "$scope",
    "$location",
    "$window",
    "configuratorService",
    function ($rootScope, $scope, $location, $window, configuratorService) {

        $rootScope.projectForConfigure = "";
        $scope.currentProject = "";
        $scope.noMarketData = false;
        $scope.moveToAddOffer = true;
        $scope.projectCheckedCount = 0;

        $scope.getProjectList = function () {
            configuratorService.getCreateNewProject().then(function (response) {
                $scope.projectList = response;
            })
        }
        
        // $scope.getRequestData = function () {
        //     configuratorService.getRequesterData().then(function (response) {
        //         $scope.requester = response;
        //     })
        // };

        $scope.populateViewEditProjectData = function (projectCode) {
            angular.forEach($scope.projectList, function (arrayObj) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                        $scope.currentProject = arrayObj;
                        console.log($scope.currentProject);
                        console.log(typeof ($scope.currentProject.MarketsView));
                        // console.log(Object.keys($scope.currentProject.MarketsView).length);
                        if (typeof ($scope.currentProject.MarketsView) === "undefined") {
                            $scope.noMarketData = true;
                            console.log($scope.noMarketData);
                        } else {
                            $scope.noMarketData = false;
                        }
                    }
                });
            });
        };

        $scope.updateProjectData = function (projectCode) {
            angular.forEach($scope.projectList, function (arrayObj, index) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                        $scope.projectList[index].ProjectCode = $scope.currentProject.ProjectCode;
                        $scope.projectList[index].ProjectType = $scope.currentProject.ProjectType;
                        $scope.projectList[index].ProjectCategoery = $scope.currentProject.ProjectCategoery;
                        $scope.projectList[index].Market = $scope.currentProject.Market;
                        $scope.projectList[index].Status = $scope.currentProject.Status;
                        $scope.projectList[index].AssignedTo = $scope.currentProject.AssignedTo;
                        angular.element('#edits').modal('hide');
                    }
                });
            });
        };

        $scope.closeModalDialog = function(){
            angular.element('#viewProjectList').modal('hide');
        }

        $scope.changeProjectForConfigure = function(projectCode){
            angular.forEach($scope.projectList, function (arrayObj, index) {
                angular.forEach(arrayObj, function (projPropValue, projPropKey) {
                    if ((projPropKey === "ProjectCode") && (projPropValue === projectCode)) {
                       $rootScope.projectForConfigure = arrayObj;
                       $scope.moveToAddOffer = false;
                       configuratorService.setCurrentProjectToConfigure(arrayObj);
                    //    console.log(configuratorService.getCurrentProjectToConfigure());
                        // console.log($rootScope.projectForConfigure);
                    }
                });
            });
        };

        $scope.getProjectList();

        // $scope.getRequestData();
        
        
        
        
        
        
        
        
    }
]);