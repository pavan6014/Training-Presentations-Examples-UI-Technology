myApp.controller('configuratorDiscountsController', ['$rootScope', '$scope', '$location', '$window', 'configuratorDiscountsService', function($rootScope, $scope, $location, $window, configuratorDiscountsService) { 
  
  init();


  function init(){
    configuratorDiscountsService.getListOfFaq().then(handleSuccess, handleError)
  }
  
  function handleSuccess(responseObj){
    $scope.tbdata = responseObj;
  }
  
  function handleError(errorObj){
    console.log("error in calling service");
  }
  
  
}]);