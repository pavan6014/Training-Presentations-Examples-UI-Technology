myApp.controller("configuratorOfferFormController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  function($rootScope, $scope, $location, $window) {
    
  }
]);