myApp.service('configuratorProductsService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	
	return ({
        getListOfFaq: getListOfFaq
    });
	
	function getListOfFaq(){
		 var request = $http({
            method: "GET",
            async: true,
            cache: false,
            url: "data/faq.json"
        });
        return (request.then(handleSuccess, handleError));
	}
	
	function handleSuccess(response){
		return response.data;
	}
	
	function handleError(response){
		console.log("error handling stratum info service");
	}
	
	
}]);