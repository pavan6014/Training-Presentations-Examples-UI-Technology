myApp.controller('configuratorProductsController', ['$rootScope', '$scope', '$location', '$window', 'configuratorProductsService', function($rootScope, $scope, $location, $window, configuratorProductsService) { 
  
  init();


  function init(){
    configuratorProductsService.getListOfFaq().then(handleSuccess, handleError)
  }
  
  function handleSuccess(responseObj){
    $scope.tbdata = responseObj;
  }
  
  function handleError(errorObj){
    console.log("error in calling service");
  }
  
  
}]);