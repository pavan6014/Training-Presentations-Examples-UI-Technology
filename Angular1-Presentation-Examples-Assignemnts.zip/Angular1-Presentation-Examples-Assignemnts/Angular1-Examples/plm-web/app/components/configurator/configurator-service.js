myApp.service('configuratorService', [ '$rootScope', '$http', '$q', function($rootScope, $http, $q) {
	return {
		getListOfUserRoles : getListOfUserRoles,
		isSubmittedFromICOMS : isSubmittedFromICOMS,
		setisSubmittedFromICOMS : setisSubmittedFromICOMS,
		getisSubmittedFromICOMS : getisSubmittedFromICOMS,
		getPSUUnderProject : getPSUUnderProject,
		getCreateNewProject : getCreateNewProject,
		setCurrentProjectToConfigure : setCurrentProjectToConfigure,
		getCurrentProjectToConfigure : getCurrentProjectToConfigure,
		setProjectToConfigureOffers : setProjectToConfigureOffers,
		getProjectToConfigureOffers : getProjectToConfigureOffers,
        getGeneralInfo : getGeneralInfo,
        getConfiguratorProcess : getConfiguratorProcess,
        getMarketData : getMarketData,
        getProjectValidationList : getProjectValidationList
	};

	var isSubmittedFromICOMS = false;

	function setisSubmittedFromICOMS(value) {
		isSubmittedFromICOMS = value;
	}

	function getisSubmittedFromICOMS(value) {
		return isSubmittedFromICOMS;
	}

	function getListOfUserRoles() {
		var request = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "data/userRole.json"
		});
		return (request.then(handleSuccess, handleError));
	}

	function handleSuccess(response) {
		return response.data;
	}

	function handleError(response) {
		console.log("error handling stratum info service");
	}
	
	function getProjectValidationList() {
		var request = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "data/configuratorReleaselist.json"
		});
		return (request.then(handleProjectValidationSuccess, handleProjectValidationError));
	}

	function handleProjectValidationSuccess(response) {
		return response.data;
	}

	function handleProjectValidationError(response) {
		console.log("error handling stratum info service");
	}

	function getPSUUnderProject(reqObj) {
		var request = $http({
			method : "GET",
			async : true,
			cache : false,
			data : reqObj,
			url : "data/configurationPSUData.json"
		});
		return (request.then(handlePSUUnderProjSuccess, handlePSUUnderProjError));
	}

	function handlePSUUnderProjSuccess(response) {
		return response.data;
	}

	function handlePSUUnderProjError(response) {
		console.log("error handling");
	}

	function getCreateNewProject() {
		var projectRequest = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "/data/requestorAfterNewProject.json"
		});
		return (projectRequest.then(createSuccess, createError));
	}
	function createSuccess(response) {
		return response.data;
	}
	function createError(response) {
		console.log("error message");
	}
	
	var currentProjectToConfigure = "";

	function setCurrentProjectToConfigure(project) {
		currentProjectToConfigure = project;
	}

	function getCurrentProjectToConfigure() {
		return currentProjectToConfigure;
	}


	var projectToConfigureOffers = "";

	function setProjectToConfigureOffers(project) {
		projectToConfigureOffers = project;
	}

	function getProjectToConfigureOffers() {
		return projectToConfigureOffers;
	}
    
    
    function getGeneralInfo() {
		var generalOnfoRequest = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "/data/generalInfo.json"
		});
		return (generalOnfoRequest.then(infoSuccess, infoError));
	}
	function infoSuccess(response) {
		return response.data;
	}
	function infoError(response) {
		console.log("error message");
	}
    
    
    function getConfiguratorProcess() {
		var ConfiguratorProcess = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "/data/configuratorProcess.json"
		});
		return (ConfiguratorProcess.then(processSuccess, processError));
	}
	function processSuccess(response) {
		return response.data;
	}
	function processError(response) {
		console.log("error message");
	}


    
     function getMarketData() {
		var marketData = $http({
			method : "GET",
			async : true,
			cache : false,
			url : "/data/market.json"
		});
		return (marketData.then(marketSuccess, marketError));
	}
	function marketSuccess(response) {
		return response.data;
	}
	function marketError(response) {
		console.log("error message");
	}
    
    
    
    
} ]);