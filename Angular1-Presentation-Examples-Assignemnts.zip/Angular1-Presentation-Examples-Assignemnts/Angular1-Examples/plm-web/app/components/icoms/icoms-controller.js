myApp.controller("icomsController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "icomsService",
  function(
    $rootScope,
    $scope,
    $location,
    $window,
    icomsService,
    pricingOperationsService
  ) {
    init();

    function init() {
      //dashboardService.getListOfUserRoles().then(handleSuccess, handleError)
    }

    /*function handleSuccess(responseObj){
		$scope.tbdata = responseObj;
	}
	
	function handleError(errorObj){
		console.log("error in calling service - stratum Info");
	}*/

    $scope.submitICOMS = function() {
      $location.path("/pricing-operations");
    };
  }
]);