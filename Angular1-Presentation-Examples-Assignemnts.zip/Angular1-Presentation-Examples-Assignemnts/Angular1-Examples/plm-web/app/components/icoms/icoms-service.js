myApp.service('icomsService', ['$rootScope', '$http', '$q', function($rootScope, $http, $q){
	return ({
        getListOfUserRoles: getListOfUserRoles
    });
	
	function getListOfUserRoles(){
		 var request = $http({
            method: "GET",
            async: true,
            cache: false,
            url: "data/userRole.json"
        });
        return (request.then(handleSuccess, handleError));
	}
	
	function handleSuccess(response){
		return response.data;
	}
	
	function handleError(response){
		console.log("error handling stratum info service");
	}
	
	
}]);