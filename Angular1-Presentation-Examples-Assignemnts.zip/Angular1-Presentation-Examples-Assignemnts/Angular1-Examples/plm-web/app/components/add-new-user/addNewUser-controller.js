myApp.controller("addNewUserController", [
  "$rootScope",
  "$scope",
  "$location",
  "$window",
  "$filter",
  "$timeout",
  "addNewUserService",
  function($rootScope, $scope, $location, $window,$filter, $timeout, addNewUserService) {
	  $scope.emailExists= false;
      $scope.emailNotExists= false;
      $scope.newUserAdded = false;
      $scope.newUserNotAdded = false;
      $scope.currentUserData = "";
      $scope.getNewUsersDetails = function() {
          addNewUserService.getNewUsersData().then(function(response){
              $scope.usersData = response;
              $scope.usersData.workGroupModelArray = new Array();
              for (var i=0; i<$scope.usersData.workGroupModels.length; i++) {
            	  $scope.usersData.workGroupModelArray.push($scope.usersData.workGroupModels[i].workGroupName);
              }
              console.log("fffff",$scope.usersData);
            })
      }
      
       $scope.getNewUsersDetails();

      $scope.getUsersDetails = function() {
    	  $scope.emailNotExists= false;
          addNewUserService.getUsersData($scope.email).then(function(response){
        	  console.log("1254",$scope.usersDetails);
        	  if (Object.keys(response).length === 0 ) {
        		  $scope.emailNotExists = true;
        	  } else {
        		  $scope.usersDetails = response;
        		  $scope.emailNotExists = false;
        	  }
        	  $timeout(function(){
        		  $scope.emailNotExists= false;
        	  }, 10000);
          })
      }
            
      $scope.addNewUser = function() {
          $scope.newUserAdded = false;
          $scope.newUserNotAdded = false;
          var workGroupIDs = new Array();
          for (var i=0; i<$scope.usersData.workGroupModels.length; i++) {
        	  if (workGroupIDs.indexOf($scope.usersData.workGroupModels[i].workGroupName) > -1) {
        		  workGroupIDs.push($scope.usersData.workGroupModels[i].workGroupId);
        	  }
          }
    	  var reqObj = {
    	     "Email" : $scope.email,
    	     "RoleId": $scope.roles, 
    	     "FirstName": $scope.fname,
    	     "LastName": $scope.lname,
    	     "StatusId": $scope.status,
    	     "WorkGroupId": workGroupIDs,
    	     "DeafultWorkGroup": $scope.defaultWorkGroup
    	  };
    	  console.log(reqObj);
    	  addNewUserService.addNewUserData(reqObj).then(function(response){
    		  console.log(response);
    		  if (response.status == "success") {
    			  $scope.newUserAdded = true;
    		  } else {
    			  $scope.newUserNotAdded = true;
    		  }
    		  $timeout(function(){
    			  $scope.newUserAdded = false;
    	          $scope.newUserNotAdded = false;
        	  }, 10000);
          })
      }
      
      
       $scope.userSearch = true;

        $scope.userStatus = function () {
          $scope.userSearch = false;
        }
   
  }
]);