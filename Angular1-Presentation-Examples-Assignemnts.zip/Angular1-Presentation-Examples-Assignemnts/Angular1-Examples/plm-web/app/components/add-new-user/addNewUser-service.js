myApp.service('addNewUserService', ['$rootScope', '$http', '$q','$location',function($rootScope, $http, $q,$location){
	
	return ({
        getNewUsersData:getNewUsersData,
        getUsersData:getUsersData,
        addNewUserData: addNewUserData
    });
	
	
    function getNewUsersData(){
        var requester = $http({
            method:"GET",
            async:true,
            cache:false,
           	url:$location.protocol() + '://' + $location.host() + ':'
      			+ $location.port() + api_urls.PLM_GET_ADMIN_ALL_INFO
        });
        return (requester.then(success,Error));
    }
    function success(response){
        return response.data;
    }
    function Error(response){
        console.log("error message");
    }
    
    function getUsersData(email){
    	var reqObj = {
    		"email" : email
    	};
        var users = $http({
            method:"POST",
            async:true,
            cache:false,
            data: reqObj,
            url:$location.protocol() + '://' + $location.host() + ':'
      			+ $location.port() + api_urls.PLM_GET_ADMIN_EMAIL_INFO
        });
        return (users.then(userSuccess,userError));
    }
    function userSuccess(response){
        return response.data;
    }
    function userError(response){
        console.log("error message");
    }
    
    function addNewUserData(userObj){
    	var reqObj = {
       	     "Email" : userObj.email,
       	     "RoleId": userObj.roles, 
       	     "FirstName": userObj.fname,
       	     "LastName": userObj.lname,
       	     "StatusId": userObj.status,
       	     "WorkGroupId": userObj.workGroup,
       	     "DeafultWorkGroup": userObj.defaultWorkGroup
       	  };
        var users = $http({
            method:"POST",
            async:true,
            cache:false,
            data: reqObj,
            url:$location.protocol() + '://' + $location.host() + ':'
      			+ $location.port() + api_urls.PLM_POST_ADD_USER
        });
        return (users.then(addNewUserDataSuccess,addNewUserDataError));
    }
    function addNewUserDataSuccess(response){
        return response.data;
    }
    function addNewUserDataError(response){
        console.log("error message");
    }
	
	
}]);