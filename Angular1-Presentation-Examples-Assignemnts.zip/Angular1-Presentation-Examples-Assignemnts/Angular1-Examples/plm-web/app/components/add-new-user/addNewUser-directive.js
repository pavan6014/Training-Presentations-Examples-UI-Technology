myApp.directive('uniqueId', ['addNewUserService', function(addNewUserService) {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        element.bind('blur', function(e) {
          if (!ngModel || !element.val()) return;
          ngModel.$setValidity('unique', true)
//          var keyProperty = scope.$eval(attrs.uniqueId);
         
          var currentValue = element.val();

          addNewUserService.getNewUsersData().then(function(currentusers) {

              
                //Ensure value that being checked hasn't changed
                //since the Ajax call was made
              if (currentValue == element.val()) {
                angular.forEach(currentusers,function(user) {
                  if (currentValue === user.Email) {
                    ngModel.$setValidity('unique', false)
                  }
                });

              }
            }, function() {
              //Probably want a more robust way to handle an error
              //For this demo we'll set unique to true though
              ngModel.$setValidity('unique', true);
            });
        });
      }
    }
  }]);