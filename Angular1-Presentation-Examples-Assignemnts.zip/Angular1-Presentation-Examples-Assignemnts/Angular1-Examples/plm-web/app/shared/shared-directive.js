myApp.directive('customDatepicker',function(){                            
	return {
		replace:true,
		template: "<div class=\"enhanced-datepicker\">" +
					"<div class=\"input-group\">" +
 "<input type=\"text\" class=\"form-control\" ng-required=\"ngRequired\" tooltip-trigger=\"{{tooltipTrigger}}\" tooltip-enable=\"{{tooltipEnable}}\" uib-tooltip=\"{{uibTooltip}}\" ng-model=\"ngModel\" ng-disabled=\"ngDisabled\" name=\"{{name}}\" ui-date=\"dateOptions\"/\">" +
						"<span class=\"input-group-btn\">" +
						"<button class=\"btn btn-default calendar-btn\" type=\"button\"><i class=\"glyphicon glyphicon-calendar custom-calendar-icon\"></i></button>" + 
						"</span>" + 
					"</div>" + 
				"</div>",
		scope: {
			ngModel: '=',
			dateOptions: '=',
			ngDisabled: '=',
			name: '@',
			uibTooltip:'@',
			tooltipTrigger:'@',
			tooltipEnable:'@',
			ngRequired:'='
		},
		link: function($scope, $element, $attrs, $controller){
			var $button = $element.find('button');
			var $input = $element.find('input');
			$button.on('click',function(){
				if($input.is(':focus')){
					$input.trigger('blur');
				} else {
					$input.trigger('focus');
				}
			});
		}    
	};
});


myApp.directive('loading', function () {
  return {
    restrict: 'E',
    replace:true,
    template: '<div class="loading"><img src="assets/img/loading.gif" width="100" height="100" /></div>',
    link: function (scope, element, attr) {
          scope.$watch('loading', function (val) {
              if (val)
                  $(element).show();
              else
                  $(element).hide();
          });
    }
  }
});

myApp.directive('tooltip', function () {
  return {
    restrict: 'A',
    link: function (scope, element, attr) {
       $('[data-toggle="tooltip"]').tooltip();
    }
  }
});

myApp.directive("dropdownMultiselect", ['$document', function($document){
	return {
	    restrict: 'E',
	    scope: {
	        model: '=',
	        options: '=',
	    },
	    template:
	            "<div class='btn-group' style='width:100%' data-ng-class='{open: open}'>" +
	                "<button class='btn btn-default btn-full-width' data-ng-click='openDropdown()'>Select... {{model}} </button>" +
	                "<button class='btn btn-default dropdown-toggle' data-ng-click='openDropdown()'> <span class='caret'></span></button>" +
	                "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
	                    "<li><a data-ng-click='selectAll()'> <span class='glyphicon glyphicon-ok green' aria-hidden='true'></span> Check All</a></li>" +
	                    "<li><a data-ng-click='deselectAll();'> <span class='glyphicon glyphicon-remove red' aria-hidden='true'></span> Uncheck All</a></li>" +
	                    "<li class='divider'></li>" +
	                    "<li data-ng-repeat='option in options'> <a data-ng-click='toggleSelectItem(option)'> <span data-ng-class='getClassName(option)' aria-hidden='true'></span> {{option}}</a></li>" +
	                "</ul>" +
	            "</div>",

	    controller: function ($scope, $element) {
	        $scope.openDropdown = function () {
	            $scope.open = !$scope.open;
	        };

	        $scope.selectAll = function () {
	            $scope.model = [];
	            angular.forEach($scope.options, function (item, index) {
	                $scope.model.push(item);
	            });
	        };

	        $scope.deselectAll = function () {
	            $scope.model = [];
	        };

	        $scope.toggleSelectItem = function (option) {
	            var intIndex = -1;
	            angular.forEach($scope.model, function (item, index) {
	                if (item == option) {
	                    intIndex = index;
	                }
	            });

	            if (intIndex >= 0) {
	                $scope.model.splice(intIndex, 1);
	            }
	            else {
	                $scope.model.push(option);
	            }
	        };

	        $element.bind('click', function(event) {
	        	event.stopPropagation();      
	        });
	                        
	        $document.bind('click', function(){
		        $scope.open = false;
		        $scope.$apply();
	        });

	        $scope.getClassName = function (option) {
	            var varClassName = 'glyphicon glyphicon-remove red';
	            angular.forEach($scope.model, function (item, index) {
	                if (item == option) {
	                    varClassName = 'glyphicon glyphicon-ok green';
	                }
	            });
	            return (varClassName);
	        };
	    }
	}
}

]);

myApp.directive('dateInput', function(){
    return {
        restrict : 'A',
        scope : {
            ngModel : '='
        },
        link: function (scope) {
            if (scope.ngModel) scope.ngModel = new Date(scope.ngModel);
        }
    }
});


myApp.directive('uiSref', function () {
  return {
    restrict: 'A',
    link: function (scope, element, attr) {
       $('li a').click(function (e) {
	        e.preventDefault();
	        $('a').removeClass('active');
	        $(this).addClass('active');
	        console.log("test");
       });
    }
  }
});

myApp.directive('autocompleteDropdown', function () {
  return {
    restrict: 'A',
    link: function (scope, element, attr) {
       $('select.auto-complete-drop-down').combobox();
    }
  }
});

myApp.directive('onetimeChekbox', function () {
  return {
    restrict: 'A',
    link: function (scope, element, attr) {
       $('input[type=checkbox].discountsCheckbox').change(function(){
		    if($(this).is(':checked')){
					$('input[type=checkbox].discountsCheckbox').attr('disabled',true);
		    	$(this).attr('disabled','');
				}
		    else{
		    	$('input[type=checkbox].discountsCheckbox').attr('disabled','');
		    }
		});
    }
  }
});

