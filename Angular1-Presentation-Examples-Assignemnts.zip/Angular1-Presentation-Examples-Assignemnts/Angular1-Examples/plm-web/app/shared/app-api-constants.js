var api_urls = {
    "LOGIN": "data/login_response.json",
    "PSUUNDERPROJECT" : "data/psuUnderProject.json"
};