myApp.directive('fontResizer', function() {
    return {
        restrict: 'AE',
        replace: false,
        templateUrl: 'app/shared/templates/font-resizer.html'
	};
});

myApp.directive('tooltip', function(){
    return {
        restrict: 'A',
        link: function(scope, element, attrs){
            $('[data-submenu]').submenupicker();
			$(element).tooltip(); 
        }
    };
});