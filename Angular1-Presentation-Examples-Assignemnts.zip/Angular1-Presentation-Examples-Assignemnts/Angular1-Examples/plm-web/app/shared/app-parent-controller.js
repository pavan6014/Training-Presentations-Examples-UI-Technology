myApp.controller('appParentController', ['$rootScope', '$scope', '$location', '$window', function($rootScope, $scope, $location, $window) {
	
	init();
	
	$rootScope.isValidLogin = false;
	$rootScope.bodyBackground = "bodyWhiteBackground";
	$rootScope.viewStyles = false;
	$rootScope.subStreamValue = "";
	
	$scope.goToDashboard = function(){
		 $rootScope.bodyBackground = "bodyThickBackground";
	     $rootScope.viewStyles = true;
	     $location.path("/dashboard");
	}

	$scope.goToLoginPage = function () {
		$rootScope.isValidLogin = true;
		$rootScope.bodyBackground = "bodyThickBackground";
		$rootScope.viewStyles = true;
		$rootScope.subStreamValue = "";
	};

	$scope.goToLogoutPage = function(){
		$rootScope.isValidLogin = false;
		$rootScope.bodyBackground = "bodyWhiteBackground";
		$rootScope.viewStyles = false;
		$rootScope.subStreamValue = "";
		$location.path("/login");
		$location.path("/logout");
	}

	$scope.isSubmittedFromICOMS = false;

	$scope.redirectTo = function(redirectTo){
		if (redirectTo === "dashboard") {
			$rootScope.bodyBackground = "bodyThickBackground";
	     	$rootScope.viewStyles = true;
			$location.path("/dashboard");
			$('.plmHome').trigger( "click" ); 
		} 
		if (redirectTo === "requestor") {
			$location.path("/requestor");
		} 
		else if (redirectTo === "configurator") {
			$location.path("/configurator");
			$('.config-offers').trigger("click");
		} 
		else if (redirectTo === "configProducts") {
			$location.path("/configuratorProducts");
		}
		else if (redirectTo === "configDiscounts") {
			$location.path("/configuratorDiscounts");
		}  
        else if (redirectTo === "distributor") {
			$location.path("/distributor");
			$('.distributor').trigger("click");
		} 
		else if (redirectTo === "distributorProducts") {
			$location.path("/distributorProducts");
        }
        else if (redirectTo === "distributorOffers") {
			$location.path("/distributorOffers");
        }
		else if (redirectTo === "distributorDiscounts") {
			$location.path("/distributorDiscounts");
        } 
        
        
        else if (redirectTo === "distributorOMCTest") {
			$location.path("/distributorOMCTest");
        } 
        else if (redirectTo === "omcUATUsers") {
			$location.path("/omcUATUsers");
        } 
        else if (redirectTo === "distributorOMCProd") {
			$location.path("/distributorOMCProd");
        } 
        
        
        
		else if (redirectTo === "icoms") {
			$location.path("/icoms");
		} 
		else if (redirectTo === "omc") {
			$location.path("/omc");
		} 
		else if (redirectTo === "pin-point") {
			$location.path("/pin-point");
		} 
		else if (redirectTo === "e-com") {
			$location.path("/e-com");
		} 
		else if (redirectTo === "newUser") {
			$location.path("/add-new-user");
		} 
		else if (redirectTo === "searchUser") {
			$location.path("/search-user");
		} 
		else if (redirectTo === "businessOffers") {
			$location.path("/businessOffers");
		} 
		else if (redirectTo === "businessProducts") {
			$location.path("/businessProducts");
		} 
		else if (redirectTo === "businessDiscounts") {
			$location.path("/businessDiscounts");
		} 
		else if (redirectTo === "report") {
			$location.path("/report");
		} 
		
	};

	$rootScope.resetSideBarHighlighted = function (highlightBar){
		if (highlightBar === "dashboard") {
			$('.plmHome').trigger( "click" ); 
		} 
		if (highlightBar === "requestor") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.requestor').trigger( "click" ); 
		} 
		else if (highlightBar === "configurator") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #configuratorNav').collapse('show');
            $('.config-offers').trigger("click");
		} 
		else if (highlightBar === "configDiscounts") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #configuratorNav').collapse('show');
            $('.config-discounts').trigger( "click" );
		} 
		else if (highlightBar === "configProducts") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #configuratorNav').collapse('show');
            $('.config-products').trigger( "click" );
		} 
		else if (highlightBar === "distributor") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor').trigger("click");
		} 
		else if (highlightBar === "distributorOffers") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-offers').trigger("click");
		} 
		else if (highlightBar === "distributorProducts") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-products').trigger("click");
		} 
		else if (highlightBar === "distributorDiscounts") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-discounts').trigger("click");
		} 
        
      
        
        else if (highlightBar === "distributorOMCTest") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-discounts').trigger("click");
		} 
        else if (highlightBar === "omcUATUsers") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-discounts').trigger("click");
		} 
        else if (highlightBar === "distributorOMCProd") {
			$('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #distributorNav').collapse('show');
            $('.distributor-discounts').trigger("click");
		} 
        
        
        
        else if (highlightBar === "icoms") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #techNav').collapse('show');
            $('.icoms').trigger( "click" );
		} 
		else if (highlightBar === "omc") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #techNav').collapse('show');
            $('.omc').trigger( "click" );
		} 
		else if (highlightBar === "pin-point") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #techNav').collapse('show');
            $('.pin-point').trigger( "click" );
		} 
		else if (highlightBar === "e-com") {
            $('.sidebar-nav #workflowNav').collapse('show');
            $('.sidebar-nav #techNav').collapse('show');
            $('.e-com').trigger( "click" );
		} 
		else if (highlightBar === "businessOffers") {
			$('.sidebar-nav #businessCatNav').collapse('show');
			$('.business-offers').trigger("click");
		} 
		else if (highlightBar === "businessProducts") {
			$('.sidebar-nav #businessCatNav').collapse('show');
			$('.business-products').trigger("click");
		} 
		else if (highlightBar === "businessDiscounts") {
			$('.sidebar-nav #businessCatNav').collapse('show');
			$('.business-discounts').trigger("click");
		} 
		else if (highlightBar === "add-new-user") {
            $('.sidebar-nav #userAdminNav').collapse('show');
            $('.new-user').trigger( "click" );
		} 
		else if (highlightBar === "search-user") {
            $('.sidebar-nav #userAdminNav').collapse('show');
            $('.search-user').trigger( "click" );    
		} 
		else if (highlightBar === "report") {
			$('.report').trigger( "click" ); 
		}
		else if (highlightBar === "dashboard") {
			$('.plmHome').trigger( "click" ); 
		}
	}
	
	function init(){
		$scope.fontSize=14;
	}
	
	/* Sorting for table implementation */
	$scope.sort = function(keyname){
		$scope.sortKey = keyname;   //set the sortKey to the param passed
		$scope.reverse = !$scope.reverse; //if true make it false and vice versa
	}
	
	$scope.print = function(){
		$('.panel-collapse:not(".in")').collapse('show');
		window.print();
	}
	
	/* Left Navigatin expand and collpase code starts here */

	$rootScope.isSideNavActive = true;

	$rootScope.sideBarCollpseExpand = function() {
		$rootScope.isSideNavActive = !$scope.isSideNavActive;
		$('.sidebar-nav .collapse.in').collapse('hide');
	} 

	$rootScope.sideBarExpand = function() {
		$rootScope.isSideNavActive = true;
	}  

	/* Left Navigatin expand and collpase code ends here */
	
	
}]);