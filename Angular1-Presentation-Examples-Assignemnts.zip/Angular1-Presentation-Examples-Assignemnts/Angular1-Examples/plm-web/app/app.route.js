myApp.config(['$locationProvider', '$routeProvider', '$httpProvider' , function($locationProvider, $routeProvider, $httpProvider){
    $routeProvider
      .when("/login", {
        templateUrl: "app/components/login/login.html",
        controller: "loginController"
      })
      .when("/logout", {
        templateUrl: "app/components/logout/logout.html",
        controller: "logoutController"
      })
      .when("/faq", {
        templateUrl: "app/components/faq/faq.html",
        controller: "faqController"
      })
      .when("/dashboard", {
        templateUrl: "app/components/dashboard/dashboard.html",
        controller: "dashboardController"
      })
      .when("/requestor", {
        templateUrl: "app/components/requestor/requestor.html",
        controller: "requestorController"
      })
      .when("/requestorProcesses", {
        templateUrl:"app/components/requestorProcesses/requestorProcesses.html",
        controller: "requestorProcessesController"
      })
      .when("/configurator", {
        templateUrl:"app/components/configurator/configurator.html",
        controller: "configuratorController"
      })
      .when("/configuratorProducts", {
        templateUrl: "app/components/configurator/products/products.html",
        controller: "configuratorProductsController"
      })
      .when("/configuratorDiscounts", {
        templateUrl: "app/components/configurator/discounts/discounts.html",
        controller: "configuratorDiscountsController"
      })
      .when("/distributor", {
        templateUrl:"app/components/distributor/distributor.html",
        controller: "distributorController"
      })
      .when("/distributorProducts", {
        templateUrl:"app/components/distributor/products/products.html",
        controller: "distributorProductsController"
      })
      .when("/distributorOffers", {
        templateUrl:"app/components/distributor/offers/offers.html",
        controller: "distributorOffersController"
      })
      .when("/distributorDiscounts", {
        templateUrl:"app/components/distributor/discounts/discounts.html",
        controller: "distributorDiscountsController"
      })
      .when("/distributorOMCTest", {
          templateUrl:"app/components/distributor/distributor-omc/distributor-omc.html",
          controller: "distributorController"
       })
      .when("/omcUATUsers", {
          templateUrl:"app/components/distributor/omc-uat/omc-uat.html"   
       })
      .when("/distributorOMCProd", {
          templateUrl:"app/components/distributor/omc-prod/omc-prod.html",
          controller: "distributorController"  
      })
      .when("/icoms", {
        templateUrl: "app/components/icoms/icoms.html",
        controller: "icomsController"
      })
      .when("/omc", {
        templateUrl: "app/components/omc/omc.html",
        controller: "omcController"
      })
      .when("/pin-point", {
        templateUrl: "app/components/pin-point/pin-point.html",
        controller: "pinPointController"
      })
      .when("/e-com", {
        templateUrl: "app/components/e-com/e-com.html",
        controller: "eCOMController"
      })
      .when("/businessOffers", {
        templateUrl: "app/components/business-catalog/offers/offers.html",
        controller: "businessOffersController"
      })
      .when("/businessProducts", {
        templateUrl: "app/components/business-catalog/products/products.html",
        controller: "businessProductsController"
      })
      .when("/businessDiscounts", {
        templateUrl: "app/components/business-catalog/discounts/discounts.html",
        controller: "businessDiscountsController"
      })
      .when("/add-new-user", {
        templateUrl: "app/components/add-new-user/add-new-user.html",
        controller: "addNewUserController"
      })
      .when("/search-user", {
        templateUrl: "app/components/search-user/search-user.html",
        controller: "searchUserController"
      })
      .when("/report", {
        templateUrl: "app/components/report/report.html",
        controller: "reportController"
      })
      .when("/unauthorized-user", {
        templateUrl: "app/components/unauthorized-user/unauthorized-user.html",
        controller: "unauthorizedUserController"
      })
      .otherwise({ redirectTo: "/login" });

      $locationProvider.html5Mode(true);
}]);

