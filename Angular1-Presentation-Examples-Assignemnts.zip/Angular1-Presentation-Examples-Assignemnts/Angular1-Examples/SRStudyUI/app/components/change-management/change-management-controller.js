attApp.controller('changeManagementController', ['$rootScope', '$scope', '$location', 'changeManagementService', 'officialResultsService', '$uibModal', '$window', function($rootScope, $scope, $location, changeManagementService, officialResultsService, $uibModal , $window) {
	
	$rootScope.isFooterFixed = false;	
	
	init();
	function init(){
		
		
	}	
}]);

