attApp.controller('standardlistController', ['$rootScope', '$scope', '$location', '$http',function($rootScope, $scope, $location,$http) {
	onPageload(){
		 dnads = sdksd
		 http.get{
		 }.respese. {
			  success
			  error
			  try {

			  }
		 }
	}
	onDelete{
	 
	}
	onUpdate{
	 
	}
	onclickPrev(){
	 
	}
	onClickNext() {
	 
	}

}]);