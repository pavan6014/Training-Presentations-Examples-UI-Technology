var MSG = "Hello World!";
      
function hideMessage() {
 $("#pMsg").html(''); 
}
 
function showMessage() {
 $( "#pMsg").html(MSG); 
}

/* ------------------------------------------------------- */