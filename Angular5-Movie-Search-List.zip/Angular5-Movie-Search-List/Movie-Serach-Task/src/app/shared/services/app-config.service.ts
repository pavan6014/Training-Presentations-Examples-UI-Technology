import { Injectable, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';

@Injectable()
export class AppConfigService implements OnInit {
  // public protocol: string;
  // public host: string;
  // public port: string;
  // public url: string;
  public urlConstants: {};
  constructor(@Inject(DOCUMENT) private document) {
      // this.protocol = document.location.protocol;
      // this.host = document.location.host;
      // this.port = document.location.port;
      // this.url = 'http://localhost:4200/';
      this.urlConstants = {
        'MOVIE_API' : 'http://starlord.hackerearth.com/movieslisting'
      };
  }

  ngOnInit() {
   
  }

}
