import { Injectable } from '@angular/core';
import { AppConfigService } from './app-config.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import 'rxjs/Rx'; 
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MoviesApiService {

  public constructor(
    private http: HttpClient,
    private appConfigService: AppConfigService
  ) { }

  getApiData():Observable<any>{
    const url = this.appConfigService.urlConstants['MOVIE_API'];
    return this.http
      .get(url)
      .map((response: Response) => {
        return response;
      })

      .catch(this.handleError);
  }

  private handleError(error: Response) {
      return Observable.throw(error.statusText);
  }

}
