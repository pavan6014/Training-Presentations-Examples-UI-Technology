import { Component, OnInit, OnChanges } from '@angular/core';
import { NgModule } from '@angular/core';
import { MoviesApiService } from './shared/services/movies-api.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [MoviesApiService]
})
export class AppComponent implements OnInit {

  private moviesList: any;
  constructor(private moviesApiService: MoviesApiService) {

  }

  ngOnInit() {
    this.getMoviesData();
  }

  getMoviesData(){
    this.moviesApiService.getApiData().subscribe(
      data => {
          this.moviesList = data;
      },
      error => {
          console.log('Error :: ' + error);
      }
    );
  }

  
  
}
