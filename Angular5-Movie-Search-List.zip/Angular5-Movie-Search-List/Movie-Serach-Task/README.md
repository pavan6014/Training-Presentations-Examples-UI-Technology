Introduction:
Develop a pseudo Front End Application which would let the users search for different movies online.

Technical Info
1) Application build in using Angular 5 framework.
2) Shared folder contains common componets(header, footer) and services.
3) Created Responsive grids using bootstrap 4.
4) Search functionality to list movies in a web page.

How to run the app:
1) npm install -g @angular/cli
2) Go to project folder
3) npm install
4) ng serve
5) open http://localhost:4200/

 
